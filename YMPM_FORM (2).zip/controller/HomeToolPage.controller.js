sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("com.spe.YMPM_FORM.controller.HomeToolPage", {
		onInit: function () {
			this.Router = sap.ui.core.UIComponent.getRouterFor(this);
		},
		onItemSelect: function (oEvent) {
			var oItem = oEvent.getParameter("item");
			this.byId("pageContainer").to(this.getView().createId(oItem.getKey()));

		},
		onPressNavListItem: function (oEvent) {

			var sAction = oEvent.getSource().getProperty("text");
			switch (sAction) {

			case "Home":
				this.Router.navTo("Home");
				break;
			case "FAQs":
				this.Router.navTo("FAQ");
				break;
			case "MPM Attributes maintenance":
				this.Router.navTo("MaintainMPM");
				break;
			case "Search MPM Form":
				this.Router.navTo("SearchMPM");
				break;

			}

		}
	});
});