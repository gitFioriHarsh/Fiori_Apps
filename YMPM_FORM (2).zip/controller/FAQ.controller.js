sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel"
], function (Controller,JSONModel) {
	"use strict";

	return Controller.extend("com.spe.YMPM_FORM.controller.FAQ", {

	
		onInit: function () {
			var oModel = new JSONModel({
				QUES1: "<p>Q: Please provide some brief information on this Fiori e-form.</p>" +
					"<p>A: This Fiori e-form has been created to take care maintenance request of MPM Attributes.",
					QUES2: "<p>Q: Provide some important points to take care while submitting request.</p>" +
					"<p>A: Below are some important points to note:</p>" +
					"<ul><li>Fields are available with Asterisk (*) are mandatory to fill.</li>" +
					"<li>We can save the form as many times as we can.</li>" +
					"<li>Once we have maintained all details, we need to click on ‘Submit’ that will move ahead for approval process.</li>",
				QUES3: "<p>Q: Any Tips and Tricks to raise any new request?</p>" +
					"<p>A: Under 'Search Form' section you can search with existing Fiori e-Forms raised by Other Users in past to create or change. You can review one of the form as a reference.</p>",
				QUES4: " "
			});
			this.getView().setModel(oModel);

		},

	

	});

});