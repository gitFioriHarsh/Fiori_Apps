sap.ui.define([
	"com/spe/YMPM_FORM/test/unit/controller/HomeToolPage.controller"
], function () {
	"use strict";
});