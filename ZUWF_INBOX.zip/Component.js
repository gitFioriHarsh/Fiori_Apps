/*&---------------------------------------------------------------------*
*& Development ID: ZDDE-00019502                                       *
*&                                                                     *
*& Inbox                                                               *
*&                                                                     *
*&---------------------------------------------------------------------*
*& Change Log:                                                         *
*&                                                                     *
*& Init. Who          Date         Text                                *
*& JHU   HUNDEJU1     24-06-2015   Initial version CD 1200006098       *
*& JHU   HUNDEJU1     23-07-2015   Initial version CD 1200006975       *
*&---------------------------------------------------------------------*/

jQuery.sap.declare("com.novartis.uwf.inbox.Component");

jQuery.sap.registerModulePath('com.novartis.uwf.lib', '/sap/bc/ui5_ui5/sap/zuwf_lib');
sap.ui.component.load({ name: 'com.novartis.uwf.lib' });
jQuery.sap.registerModulePath('cross.fnd.fiori.inbox', '/sap/bc/ui5_ui5/sap/ca_fiori_inbox');
sap.ui.component.load({ name: 'cross.fnd.fiori.inbox' });

jQuery.sap.require('com.novartis.uwf.lib.util.Component');
jQuery.sap.require('com.novartis.uwf.lib.model.TaskProcessing');


jQuery.sap.require('cross.fnd.fiori.inbox.Component');
jQuery.sap.require('com.novartis.uwf.inbox.util.TaskStatusFilterProvider');
jQuery.sap.require('com.novartis.uwf.inbox.util.DataManager');
jQuery.sap.require('sap.ui.core.Configuration');

jQuery.sap.require('com.novartis.uwf.inbox.util.Template');
jQuery.sap.require('com.novartis.uwf.inbox.util.Formatter');

cross.fnd.fiori.inbox.Component.extend("com.novartis.uwf.inbox.Component", {
    metadata: {
        name: 'Universal Workflow - Inbox',
        version: '1.0',
        includes: ["css/style.css"],
        dependencies: {
            'libs' : [
                'sap.m',
                'sap.me'
            ],
            'components' : [
            ]
        },
                  'services':{
          'ShellUIService': {
          'factoryName': 'sap.ushell.ui5service.ShellUIService'
          }
          },

         config: {
            'resourceBundle' : 'i18n/i18n.properties',
            'titleResource' : 'SHELL_TITLE',
            'icon' : 'sap-icon://approvals',
            'favIcon' : './resources/sap/ca/ui/themes/base/img/favicon/Approve_Requests.ico', //FIXME: should use F0392, but resource is not like that for W1s
            'homeScreenIconPhone' : './resources/sap/ca/ui/themes/base/img/launchicon/Approve_Requests/57_iPhone_Desktop_Launch.png', //FIXME: should use F0392, but resource is not like that for
            'homeScreenIconPhone@2' : './resources/sap/ca/ui/themes/base/img/launchicon/Approve_Requests/114_iPhone-Retina_Web_Clip.png', //FIXME: should use F0392, but resource is not like that for
            'homeScreenIconTablet' : './resources/sap/ca/ui/themes/base/img/launchicon/Approve_Requests/72_iPad_Desktop_Launch.png', //FIXME: should use F0392, but resource is not like that for
            'homeScreenIconTablet@2' : './resources/sap/ca/ui/themes/base/img/launchicon/Approve_Requests/144_iPad_Retina_Web_Clip.png', //FIXME: should use F0392, but resource is not like that for
            'startupImage320x460' : './resources/sap/ca/ui/themes/base/img/splashscreen/320_x_460.png',
            'startupImage640x920' : './resources/sap/ca/ui/themes/base/img/splashscreen/640_x_920.png',
            'startupImage640x1096' : './resources/sap/ca/ui/themes/base/img/splashscreen/640_x_1096.png',
            'startupImage768x1004' : './resources/sap/ca/ui/themes/base/img/splashscreen/768_x_1004.png',
            'startupImage748x1024' : './resources/sap/ca/ui/themes/base/img/splashscreen/748_x_1024.png',
            'startupImage1536x2008' : './resources/sap/ca/ui/themes/base/img/splashscreen/1536_x_2008.png',
            'startupImage1496x2048' : './resources/sap/ca/ui/themes/base/img/splashscreen/1496_x_2048.png',

            'sap.ca.serviceConfigs': [
            {
                name: 'TASKPROCESSING',
                serviceUrl: com.novartis.uwf.lib.model.TaskProcessing.getServiceURL(true)
            },
            {
                name: 'POSTACTION',
                serviceUrl: com.novartis.uwf.lib.model.TaskProcessing.getServiceURL(true)
            }
        ]

        },
        customizing: {
            'sap.ui.viewExtensions': {
                'cross.fnd.fiori.inbox.view.S2': {
                    'CustomerExtensionForObjectListItem': {
                        className: 'sap.ui.core.Fragment',
                        fragmentName: 'com.novartis.uwf.inbox.fragment.master.ObjectListItem',
                        type: 'XML'
                    }
                },
                'cross.fnd.fiori.inbox.view.S3': {
                    'CustomerExtensionForObjectHeader': {
                        className: 'sap.ui.core.Fragment',
                        fragmentName: 'com.novartis.uwf.inbox.fragment.detail.ObjectHeader',
                        type: 'XML'
                    },

                    'CustomerExtensionForInfoTabContent': {
                        className: 'sap.ui.core.Fragment',
                        fragmentName: 'com.novartis.uwf.inbox.fragment.detail.InfoTabContent',
                        type: 'XML'
                    },

                    'CustomerExtensionForAdditionalTabs': {
                        className: 'sap.ui.core.Fragment',
                        fragmentName: 'com.novartis.uwf.inbox.fragment.detail.AdditionalTabs',
                        type: 'XML'
                    },



                    'CustomerExtensionForAttachmentTabContent': {
                        className: 'sap.ui.core.Fragment',
                        fragmentName: 'com.novartis.uwf.inbox.fragment.detail.AttachmentTabContent',
                        type: 'XML'
                    }
                }
            },

            'sap.ui.controllerExtensions': {
                'cross.fnd.fiori.inbox.Main': {
                    'controllerName': 'com.novartis.uwf.inbox.Main'
                },

                'cross.fnd.fiori.inbox.view.S2': {
                    'controllerName': 'com.novartis.uwf.inbox.view.S2'
                },

                'cross.fnd.fiori.inbox.view.S3': {
                    'controllerName': 'com.novartis.uwf.inbox.view.S3'
                },

                'cross.fnd.fiori.inbox.view.Forward': {
                    'controllerName': 'com.novartis.uwf.inbox.view.Forward'
                }
            }
        }
    },
    createContent: function() {
        var that = this;
        var componentUtil = new com.novartis.uwf.lib.util.Component(this, true);

        // Load scenario customizing synchronous to stay in the context of the component creation
        com.novartis.uwf.lib.model.TaskProcessing.read(['ConsumerScenarioCollection'], {
            async: false
        }, function(data, model, scenarios) {
            // Set scenario customizing as global model
            that.setModel(new sap.ui.model.json.JSONModel(scenarios.data.results), 'scenarios');

            // Set i18n model
            componentUtil.setI18NModel();
        });

        // Keep session up
        setInterval(function () {
            jQuery.get('/');
        }, 5 * 60 * 1000);

        // Continue with standard logic
        return cross.fnd.fiori.inbox.Component.prototype.createContent.apply(this, arguments);
    }
});