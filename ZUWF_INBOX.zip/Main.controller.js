/*&---------------------------------------------------------------------*
*& Development ID: ZDDE-00019502                                       *
*&                                                                     *
*& Inbox                                                               *
*&                                                                     *
*&---------------------------------------------------------------------*
*& Change Log:                                                         *
*&                                                                     *
*& Init. Who          Date         Text                                *
*& JHU   HUNDEJU1     24-06-2015   Initial version CD 1200006098       *
*& JHU   HUNDEJU1     23-07-2015   Initial version CD 1200006975       *
*&---------------------------------------------------------------------*/

jQuery.sap.declare('com.novartis.uwf.inbox.Main');
jQuery.sap.require('sap.ca.ui.dialog.factory');

sap.ui.controller('com.novartis.uwf.inbox.Main', {
	onInit: function() {
		// Remove menu items in shell menu
		var model = sap.ui.getCore().byId('shell') && sap.ui.getCore().byId('shell').getModel();
		if (model) {
			// Reset buttons
			var buttonsInModel = model.getProperty('/currentState/actions');
			//    buttonsInModel.length = 0;

			// Only add standard shell actions
			//    var buttonsInModelShellActions = model.getProperty('/currentState/shellActions');
			//   for (var i = 0; i < buttonsInModelShellActions.length; i++) {
			//      buttonsInModel.push(buttonsInModelShellActions[i]);
			//     }

			// Add 'My Delegation' button if user has the corresponding role
			var service = sap.ushell.Container.getService('NavTargetResolution');
			var target = '#ZUWF-setdelegation';
			service.isIntentSupported([ target ]).then(
				function(intents) {
					if (intents[target] && intents[target].supported) {
						this.loadDelegationApp();
					}
				}.bind(this)
			);

			model.setProperty('/currentState/actions', buttonsInModel);
		}

		// Always show details when an error occurs
		var _showMessageBox = sap.ca.ui.dialog.factory.showMessageBox;
		sap.ca.ui.dialog.factory.showMessageBox = function(settings, onClose) {
			// Change title
			settings.title = sap.ca.ui.utils.resourcebundle.getText('messagetype.info');

			// Try to show actual error message
			if (settings.details) {
				try {
					var json = JSON.parse(settings.details);
					settings.message = json.error.message.value;
				} catch (e) {
					try {
						var xml = $($.parseXML(settings.details));
						settings.message = xml.find('message:first').text();
					} catch (err) {
						// Keep standard details if object could not be parsed
						if (typeof settings.details === 'string') {
							settings.message = settings.details;
							delete settings.details;
						}
					}
				}	
			}

			settings.message = (settings.message || '').split('#').join("\n");
			_showMessageBox.apply(this, [ settings, onClose ]);
		};

		var showMessageBox = sap.ca.ui.message.showMessageBox;
		sap.ca.ui.message.showMessageBox = function(oSettings) {
			if (oSettings && oSettings.message === 'Request aborted') {
				jQuery.sap.log.error('showMessageBox was skipped since the request was intentionally aborted.');
				return;
			}

			// Otherwise try to run the standard function
			return showMessageBox.apply(this, arguments);
		};

		// Suppress message toast as it confused users
		sap.ca.ui.message.showMessageToast = function(message) {
				jQuery.sap.log.error('showMessageToast was muted.');
			jQuery.sap.log.debug(message);
		};
	},

	loadDelegationApp: function() {
		var buttons = [];
		var delegationButton = new sap.m.Button({
			text: sap.ui
				.component(sap.ui.core.Component.getOwnerIdFor(this.getView()))
				.getModel('i18nCustom')
				.getProperty('ZMY_DELEGATIONS'),
			icon: 'sap-icon://citizen-connect',
			press: function(event) {
				var navigationService = sap.ushell.Container.getService('CrossApplicationNavigation');
				navigationService.toExternal({
					target: {
						shellHash: 'ZUWF-setdelegation'
					}
				});
			}
		});

		buttons.push(delegationButton);
		sap.ushell.services.AppConfiguration.addApplicationSettingsButtons(buttons);
	},

	onAfterRendering: function() {
		var id = 'NEW_THEME';
		var payload = { id: id };
		var service = '/sap/zuwf_json/zuwf_communicat?random=' + new Date().getTime();
		jQuery.get(service, payload).fail(function() {
			var dialog = new sap.m.Dialog({
				title: 'My Approvals new release available!',
				content: [
					new sap.m.FormattedText({
						htmlText: '<p style="padding: 0 10px; line-height: 22px;">Thanks to input from various interviews with you additional changes and new functionality is available now:</p>' +
						'<ul style="padding-right: 10px; line-height: 22px;">' + 
						'<li style="padding-bottom: 5px;">Desktop application offering real-time notification for new work items is available via Software Self-Service now!</li>' +
						'<li style="padding-bottom: 5px;">Harmonized layouts across the different integrations makes you finding relevant information easier.</li>' +
						'<li style="padding-bottom: 5px;">Work items are now grouped by scenario for you to find bunch of work items quicker.</li>' +
						'<li style="padding-bottom: 5px;">Escalation notification for Automated Insider System to managers if the due date is reached.</li>' +
						'</ul>'
					})
				],
				endButton: new sap.m.Button({
					text: 'Confirm',
					press: function() {
						jQuery.post(service, payload);
						dialog.close();
					}
				}),
				afterClose: function() {
					dialog.destroy();
				}
			});

			dialog.open();
		});
	}
});
