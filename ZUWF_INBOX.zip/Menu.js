/*&---------------------------------------------------------------------*
*& Development ID: ZDDE-00019502                                       *
*&                                                                     *
*& Inbox                                                               *
*&                                                                     *
*&---------------------------------------------------------------------*
*& Change Log:                                                         *
*&                                                                     *
*& Init. Who          Date         Text                                *
*& JHU   HUNDEJU1     24-06-2015   Initial version CD 1200006098       *
*& JHU   HUNDEJU1     23-07-2015   Initial version CD 1200006975       *
*&---------------------------------------------------------------------*/

jQuery.sap.declare('com.novartis.uwf.inbox.Main');
jQuery.sap.require('sap.ca.ui.dialog.factory');

sap.ui.controller('com.novartis.uwf.inbox.Main', {
    onInit: function() {
        // Remove menu items in shell menu
        var model = sap.ui.getCore().byId('shell') && sap.ui.getCore().byId('shell').getModel();
        if (model) {
            // Reset buttons
            var buttonsInModel = model.getProperty('/currentState/actions');
            buttonsInModel.length = 0;

            // Only add standard shell actions
            var buttonsInModelShellActions = model.getProperty('/currentState/shellActions');
            for (var i = 0; i < buttonsInModelShellActions.length; i++) {
                buttonsInModel.push(buttonsInModelShellActions[i]);
            }

            // Add 'My Delegation' button if user has the corresponding role
            var service = sap.ushell.Container.getService('NavTargetResolution');
            var target = '#ZUWF-setdelegation';
            service.isIntentSupported([target]).then(function(intents) {
                if (intents[target] && intents[target].supported) {
                    this.loadDelegationApp();
                }
            }.bind(this));

            model.setProperty('/currentState/actions', buttonsInModel);
        }

        // Always show details when an error occurs
        var showMessageBox = sap.ca.ui.dialog.factory.showMessageBox;
        sap.ca.ui.dialog.factory.showMessageBox = function(settings, onClose) {
            // Change title
            settings.title = sap.ca.ui.utils.resourcebundle.getText('messagetype.info');

            // Try to show actual error message
            try {
                var parsed = JSON.parse(settings.details);
                settings.message = parsed.error.message.value;
            } catch (e) {
                // Keep standard details if object could not be parsed
            }

            showMessageBox.apply(this, [settings, onClose]);
        };
    },

    loadDelegationApp: function () {
        var buttons = [];
        var delegationButton = new sap.m.Button({
            text: sap.ui.component(sap.ui.core.Component.getOwnerIdFor(this.getView())).getModel('i18nCustom').getProperty('ZMY_DELEGATIONS'),
            icon: 'sap-icon://citizen-connect',
            press: function(event) {
                var navigationService = sap.ushell.Container.getService('CrossApplicationNavigation');
                navigationService.toExternal({
                    target: {
                        shellHash : 'ZUWF-setdelegation'
                    }
                });
            }
        });

        buttons.push(delegationButton);
        sap.ushell.services.AppConfiguration.addApplicationSettingsButtons(buttons);
    }
});
