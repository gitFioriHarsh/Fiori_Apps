jQuery.sap.declare('com.novartis.uwf.inbox.control.NovExpandableTextArea');
jQuery.sap.require("sap.m.TextArea");

sap.m.TextArea.extend("com.novartis.uwf.inbox.control.NovExpandableTextArea", {

  self : this,
  mTextAreaElement : null,
  mOldValue : null,
  mPage : null,
  mView : null,
  mApp : null,

  metadata : {
    properties : {
      showCount     : { type : "boolean", defaultValue : false },
      showCountText : { type : "string", defaultValue : '{0} of {1} characters' }
    },
    aggregations : {
      count : {type : "sap.m.Text", multiple : false}
    }
  },


  constructor : function(settings) {
    "use strict";
    sap.m.TextArea.prototype.constructor.apply(this, arguments);

    this.attachLiveChange(this.updateTextAreaHeightChange,this);
    this.addEventDelegate(this.eventDelegates, this);

    if (this.getShowCount()) {
      //See https://www.nabisoft.com/tutorials/sapui5/creating-custom-controls-in-sapui5
      //for examples on how to create composite elements.
      this.setAggregation("count", new sap.m.Text({ text : "" }));
    }
  },

  init : function(){

    sap.m.TextArea.prototype.init.apply(this, arguments);

  },

  findParentOfType : function(aObjectType, oParent) {
    oParent = oParent || this;

    if (!oParent.getMetadata) {
      return null;
    } 

    if (!oParent.getMetadata().getElementName) {
      return null;
    } 

    var sElementName = oParent.getMetadata().getElementName();
    var oCurrParent = oParent.getParent();
    if (aObjectType.indexOf(sElementName) > -1) {
      //oParent is of desired object type
      return oParent;
    } else {
      if (!oCurrParent) {
        //Reached top most node without finding a view
        return null;
      } else {
        return this.findParentOfType(aObjectType, oCurrParent);
      }
    }
  },

  eventDelegates : {
    onAfterInit : function() {
      jQuery.sap.log.debug("Event Delegate : onAfterInit");

    },

    onBeforeRendering : function() {
      jQuery.sap.log.debug("Event Delegate : onBeforeRendering");
      this.mPage = this.findParentOfType([
        'sap.m.Page'
      ]);

      this.mView = this.findParentOfType([
        'sap.ui.core.mvc.HTMLView',
        'sap.ui.core.mvc.XMLView',
        'sap.ui.core.mvc.JSView'
      ],this.mPage);

      this.mApp = this.findParentOfType([
        'sap.m.App',
        'sap.m.SplitApp'
      ],this.mView);
    },

    onAfterRendering : function() {
      jQuery.sap.log.debug("Event Delegate : onAfterRendering");

      this.mTextAreaElement = this._$input[0];
      if (!this.mTextAreaElement) {
        return;
      }

      this.mTextAreaElement.style.overflow = "hidden";

      var oContext = this.mView.getObjectBinding();
      if ( oContext ) {
        if ( !this.mView.getModel().getData( oContext.sPath ) ) {
          //The models data has not been loaded. However the text area has already been rendered. This will cause an issue where
          //the scroll height will get an unusually large value. We need to wait till the model loads before we set the scroll
          //height again.
          this.mView.getElementBinding().attachEventOnce("dataReceived",jQuery.proxy(this.updateAfterModelInit, this));
        } else {
          this.updateTextAreaHeight( this.mTextAreaElement );
        }
        /*
        else {
          //In case the model's data has already been loaded
          this.setOldValue(this.getValue());
          this.updateTextAreaHeight( this.mTextAreaElement );
        }
        */
      } else {
        //In case the view is not bound to any model.
        this.setOldValue(this.getValue());
        this.updateTextAreaHeight( this.mTextAreaElement );
      }

      //this.mApp.addEventDelegate(this.eventDelegates, this);
      this.mView.addEventDelegate(this.eventDelegates, this);
    },

    onAfterNavigate : function () {
      jQuery.sap.log.debug("Event Delegate : onAfterNavigate");
    },

    onAfterShow : function () {
      jQuery.sap.log.debug("Event Delegate : onAfterShow");
      this.updateAfterModelInit();
    },

    onExit : function() {
      jQuery.sap.log.debug("Event Delegate : onExit");
    }
  },

  updateTextAreaHeightChange : function(oEvent){
    jQuery.sap.log.debug("updateTextAreaHeightChange called");

    var sValue = this.getValue();
    var nCurrentLength = sValue.replace(/\n/g, "\n\r").length;

    if ( nCurrentLength > this.getMaxLength() ) {
      //In the rare situation where the text has exceeded despite a MaxLength specified, we handle it here.
      //We will truncate the text, but this happens so fast that to the user, it only appears like we blocked
      //the input from being entered into the text area
      while ( sValue.replace(/\n/g, "\n\r").length > this.getMaxLength() ) {
        sValue = sValue.substring(0,sValue.length - 1);
      }
      this.setValue(sValue);
      nCurrentLength = sValue.replace(/\n/g, "\n\r").length;
    }

    this.updateTextAreaHeight(this.mTextAreaElement);

  },

  updateAfterModelInit : function(oEvent){
    "use strict";
    jQuery.sap.log.debug("updateAfterModelInit");
    this.setOldValue(this.getValue());
    this.updateTextAreaHeight( this.mTextAreaElement );

    var nCurrentLength = this.getValue().replace(/\n/g, "\n\r").length;
    if (this.getShowCount()) {
      this.getAggregation("count").setText(this.getCountText(nCurrentLength,this.getMaxLength()));
    }

    //this.mBindingInfos.value.binding.detachChange(this.updateAfterModelInit);
    //var oBinding = this.mBindingInfos.value ? this.mBindingInfos.value.binding : this.mBindingInfos.placeholder.binding;
    //oBinding.detachChange(jQuery.proxy(this.updateAfterModelInit, this));
  },

  updateTextAreaHeight : function(oTextArea){
    jQuery.sap.log.debug("updateTextAreaHeight called to change text area height");

    //oTextArea.style.height = "auto";
    //oTextArea.style.height = oTextArea.scrollHeight + "px";

    if ((navigator.userAgent.indexOf("MSIE") != -1 ) || (!!document.documentMode == true )) {
      //IE specific solution. This is required because if we simply set the height to 1px, then reset 
      //the height to the desired height, the UI actually updates to 1px and to the larger height. This
      //causes a jumpy scrollbar effect. We mitigate this by trying to detect the action the user performed
      if (oTextArea.scrollTop != 0) {
        //Text Area has grown. Adjust the size to fit
        oTextArea.style.height = oTextArea.scrollHeight + "px";
      } else {
        //This is an inefficient solution. Here we shrink the height until we know that the content
        //is too big for the text box's size. Then we set it back to the content's size.
        var nHeight = oTextArea.style.height.replace("px","");
        while ( nHeight > oTextArea.scrollHeight && nHeight > 0) {
          nHeight = nHeight - 1;
          oTextArea.style.height = nHeight + "px";
        }
        oTextArea.style.height = oTextArea.scrollHeight + "px";
      }
    } else {
      //Solution for non IE browsers
      oTextArea.style.height = "auto";
      oTextArea.style.height = oTextArea.scrollHeight + "px";
    }

    if (this.getShowCount()) {
      var sValue = this.getValue();
      var nCurrentLength = sValue.replace(/\n/g, "\n\r").length;
      this.getAggregation("count").setText(this.getCountText(nCurrentLength,this.getMaxLength()));
    }
  },

  getCountText : function(nCurrentLength, nMaxLength) {
    var sText = this.getShowCountText();
    sText = sText.replace('{0}', nCurrentLength);
    sText = sText.replace('{1}', this.getMaxLength());
    return sText;
  },

  setOldValue : function(value) {
    jQuery.sap.log.debug("Set mOldValue to " + value);
    this.mOldValue = value;
  },

  isChanged : function() {
    var newValue = this.getValue();
    return (this.mOldValue !== newValue);
  },

  renderer: function(oRm, oControl) {
    //sap.m.TextArea.prototype.renderer.apply(this, arguments);
    sap.m.TextAreaRenderer.render(oRm, oControl);
    if (oControl.getShowCount()) {
      oRm.renderControl(oControl.getAggregation("count"));
    }
    oRm.renderControl(oControl._icon);
    }
});