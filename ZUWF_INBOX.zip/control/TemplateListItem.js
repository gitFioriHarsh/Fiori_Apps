/*&---------------------------------------------------------------------*
*& Development ID: ZDDE-00019502                                       *
*&                                                                     *
*& Inbox                                                               *
*&                                                                     *
*&---------------------------------------------------------------------*
*& Change Log:                                                         *
*&                                                                     *
*& Init. Who          Date         Text                                *
*& JHU   HUNDEJU1     24-06-2015   Initial version CD 1200006098       *
*& JHU   HUNDEJU1     23-07-2015   Initial version CD 1200006975       *
*& SRKP  SIVARPR3     11-06-2018   Initial version CD 1200041834       *
*&---------------------------------------------------------------------*/
/*New template added as upgrade--sivarpr3*/

jQuery.sap.declare('com.novartis.uwf.inbox.control.TemplateListItem');
jQuery.sap.require('com.novartis.uwf.inbox.util.Template');
jQuery.sap.require('sap.m.library');
jQuery.sap.require('com.novartis.uwf.lib.control.ObjectListItem');

com.novartis.uwf.lib.control.ObjectListItem.extend('com.novartis.uwf.inbox.control.TemplateListItem', {
    metadata: {
        properties: {
            template: {
                type: 'string'
            },
            selected: {
                type: 'boolean',
                defaultValue: false
            }
        },
        library: 'sap.m'
    },

    _rendered: false,

    onBeforeRendering: function() {
        /*if (this._rendered) {
            return;
        }

        var controller = new com.novartis.uwf.lib.util.Component().getController('com.novartis.uwf.inbox.view.S2'),
            fragment = com.novartis.uwf.inbox.util.Template.loadMaster(this.getTemplate()).getListItem(controller);

        // Copy model
        fragment.setModel(this.getModel());

        // Copy events
        for (var eventName in fragment.mEventRegistry) {
            var event = fragment.mEventRegistry[eventName];
            for (var listenerName in event) {
                var listener = event[listenerName];
                this.attachEvent(eventName, listener.oData, listener.fFunction, listener.oListener);
            }
        }

        // Copy aggregations
        for (var aggregationName in fragment.mAggregations) {
            var aggregation = fragment.mAggregations[aggregationName];
            if (aggregation.length) {
                while (aggregation.length > 0) {
                    this.addAggregation(aggregationName, aggregation[0]);
                }
            } else {
                this.setAggregation(aggregationName, aggregation);
            }
        }

        // Copy properties
        for (var property in fragment.mProperties) {
            this.setProperty(property, fragment.mProperties[property]);
        }

        // Copy bindings
        for (var binding in fragment.mBindingInfos) {
            this.bindProperty(binding, fragment.mBindingInfos[binding]);
        }

        // Already rendered
        this._rendered = true;
        fragment.destroy();*/
    },
    renderer: {
        render: function(rm, control) {
             var templates = com.novartis.uwf.inbox.util.Template.loadMaster(control.getTemplate()).getListItem();
             var json = control.getModel().getProperty(control.getBindingContextPath() + '/ZJSON') || '{}';
             var renderTemplate = function renderElement(template) {
                try {
                    template.setModel(control.getModel());
                        template.setModel(new sap.ui.model.json.JSONModel(JSON.parse(json)), 'JSONHeader');
                    template.setModel(control.getModel('i18nCustom'), 'i18nCustom');
                    template.setBindingContext(control.getBindingContext());
                    template.attachPress(function() { control.firePress(); });
                    template.setType(control.getSelected() ? 'Inactive' : 'Active');
                    
                    return rm.renderControl(template);
                 } catch(error) {
                    return rm.write("<div>Error in template " + control.getTemplate() + "</div>");
                 }
             };

             if (Array.isArray(templates)) {
                return templates.map(renderTemplate);
             } else {
                return renderTemplate(templates);
             }
        }
    }
});