/*&--------------------------------------------------------------------------*
 *& FS ID  : FSW-00009407 - Credit Debit Memo Workflow Approval          *
 *&--------------------------------------------------------------------------*
 *& Inbox                                    								 *
 *&--------------------------------------------------------------------------*
 *& Change Log:                                                              *
 *&--------------------------------------------------------------------------*
 *& Author      ¦ Date           ¦ Comment                                   *
 *&--------------------------------------------------------------------------*
 *& VADTHDE1      25-10-2022       Initial Version                         *
 *&                                  CR# 1500017375  CD# 1600010195           *
 *&--------------------------------------------------------------------------*/

jQuery.sap.declare('com.novartis.uwf.inbox.template.detail.CDM.template');
jQuery.sap.require('com.novartis.uwf.inbox.template.detail.generic');
jQuery.sap.require('sap.ui.core.format.DateFormat');

com.novartis.uwf.inbox.template.detail.generic.extend('com.novartis.uwf.inbox.template.detail.CDM.template', {
	_controller: null,

	_ItemTab: null,

	_NotesTab: null,

	_headerFooterOptions: null,
	_sNote: '',
	_rejectCode : '',

	getEntitySetsToExpand: function (item) {
		return ['ZCDMHeaderNav', 'ZCDMItemNav', 'ZCDMUserProfileNav', 'ZCDMRejectionCodeNav', 'ZCDMCommentsNav'];
	},

	getObjectHeader: function (controller) {
		return sap.ui.xmlfragment('com.novartis.uwf.inbox.template.detail.CDM.ObjectHeader', controller);
	},

	destroy: function () {

		// Remove references
		this._headerFooterOptions = null;
		// Also destroy parent
		com.novartis.uwf.inbox.template.detail.generic.prototype.destroy.apply(this, arguments);
	},

	getInfoTab: function (controller) {
		// Extend controller
		this._controller = jQuery.extend(controller, {
			openRejectCommentDialog: jQuery.proxy(this.openRejectCommentDialog, this),
			onDialogCloseButton: jQuery.proxy(this.onDialogCloseButton, this),
			onDialogCancelButton: jQuery.proxy(this.onDialogCancelButton, this),
			handleResponsivePopoverPress: jQuery.proxy(this.handleResponsivePopoverPress, this),
			dateChange: jQuery.proxy(this.dateChange, this),
			onTALiveChange: jQuery.proxy(this.onTALiveChange, this)
		});

		return sap.ui.xmlfragment(
			this._controller.getView().getId(),
			'com.novartis.uwf.inbox.template.detail.CDM.InfoTabContent',
			this._controller
		);
	},

	beforeDataLoaded: function (controller, detailData) {
		var view = this._controller.getView(),
			i18nCustom = view.getModel('i18nCustom');

		//creating items tab
		this._controller
			.getView()
			.setModel(new sap.ui.model.json.JSONModel({
				commentsLoading: true
			}), 'items');

		// Already create risks tab
		if (!this._ItemTab) {
			this._ItemTab = new sap.m.IconTabFilter({
				key: 'ITEM',
				icon: 'sap-icon://sales-order-item',
				text: 'Item details', //i18nCustom.getProperty('ZTAB_DPO_COMMENTS'),
				content: sap.ui.xmlfragment('com.novartis.uwf.inbox.template.detail.CDM.ItemDetailsContent', this._controller)
			});
		}

		// Indicates loading
		view.getModel('items').setProperty('/ItemDetailsLoading', true);
		// end of Item tab code

		//creating comments tab
		this._controller
			.getView()
			.setModel(new sap.ui.model.json.JSONModel({
				commentsLoading: true
			}), 'notes');

		// Already create risks tab
		if (!this._NotesTab) {
			this._NotesTab = new sap.m.IconTabFilter({
				key: 'NOTESS',
				//		count : 
				icon: 'sap-icon://comment',
				text: 'Comments',
				content: sap.ui.xmlfragment('com.novartis.uwf.inbox.template.detail.CDM.NotesTabContent', this._controller)
			});
		}

		// Indicates loading
		view.getModel('notes').setProperty('/notesLoading', true);
		// end of comments tab code

	},

	configureTabs: function (tabbar) {
		var tabs = tabbar.getItems(),
			alreadyItemAdded = false,
			alreadyNoteAdded = false;

		for (var i = 0; i < tabs.length; i++) {
			if (tabs[i].getProperty('key') === 'ITEM') {
				alreadyItemAdded = true;
			}

			if (tabs[i].getProperty('key') === 'NOTESS') {
				alreadyNoteAdded = true;
			}
			if (tabs[i].getProperty('key') === 'OBJECTLINKS' || tabs[i].getProperty('key') === 'NOTES' || tabs[i].getProperty('key') === 'ATTACHMENTS') { 
				tabbar.removeItem(tabs[i]);
			}

			if (tabs[i].getProperty('key') === 'DESCRIPTION') {
				tabs[i].setText("Header details");
			}

		}

		// rearrangement of tabs
		// moving attachment to last 

		// end of rearrangement

		// adding ItemDetails tab
		if (!alreadyItemAdded) {
			tabbar.addItem(this._ItemTab);
		}

		// adding Notes tab
		if (!alreadyNoteAdded) {
			tabbar.addItem(this._NotesTab);
		}
	},

	configureButtons: function (buttonList, controller) {
		//removing Forward button
	//	buttonList.aButtonList = [];
		// attaching footer options to controller.
		this._headerFooterOptions = controller._oHeaderFooterOptions;
	},

	handleResponsivePopoverPress: function (event) {
		var controller = this._controller,
			items = controller.getView().getModel('detail'),
			index = event.getSource().getParent().getBindingContextPath(),
			description = items.getProperty(index + '/SystemDesc');

		// Create popover with the system description as content
		var popover = new sap.m.Popover({
			showHeader: false
		});
		popover.addStyleClass('sapUiPopupWithPadding');
		popover.addStyleClass('novApvGRCSystemPopover');
		popover.addContent(new sap.m.Text({
			text: description
		}));
		popover.openBy(event.getSource());
	},

	showDecisionDialog: function (approve) {
		var decisionText = approve ? 'XBUT_APPROVE' : 'XBUT_REJECT',
			decisionTextI18n = this._controller.i18nBundle.getText(decisionText),
			mandatory = approve ? false : true;


			sap.ca.ui.dialog.confirmation.open({
					question: this._controller.i18nBundle.getText('XMSG_DECISION_QUESTION', decisionTextI18n),
					showNote: true,
					title: this._controller.i18nBundle.getText('XTIT_SUBMIT_DECISION'),
					confirmButtonLabel: this._controller.i18nBundle.getText('XBUT_SUBMIT'),
					noteMandatory: mandatory
				},
				jQuery.proxy(function (result) {
					if (result.isConfirmed) {
						this._sNote = result.sNote;
						// Send action
						this.sendAction(true);
					}
				}, this)
			);
	},

	sendAction: function (oEvent) {
		var that = this,
			controller = this._controller,
			origin = 'LOCAL_GW',
			model = new sap.ui.model.odata.ODataModel(controller.oDataManager.oPostActionModel.sServiceUrl + origin),
			instanceId = controller.getView().getBindingContext().getProperty('InstanceID'),
			decision = oEvent ? "Approve" : "Reject";
			

		// Prepare request
		var parameters = {
			SAP__Origin: origin,
			InstanceID: instanceId,
			Decision: decision, // Reject or Approve
			Comment: this._sNote,
			RejectCode : this._rejectCode
		};

		// Submit asynchronously
		that._controller.oDataManager.fnShowReleaseLoader(true);
		model.callFunction(
			'ZCDMCoiDecision',
			'POST',
			parameters,
			null,
			function (data) {
				that._controller.oDataManager.fnShowReleaseLoader(false);

				// Remove the processed item from the list
				that._controller.oDataManager.processListAfterAction(origin, instanceId);
				that._controller.oDataManager.triggerRefresh('SENDACTION', this.ACTION_SUCCESS);
				that._controller.oDataManager.fireActionPerformed();

				jQuery.sap.delayedCall(500, that._controller, function () {
					sap.ca.ui.message.showMessageToast(that._controller.i18nBundle.getText('dialog.success.complete'));
				});
			},
			function (error) {
				that._controller.oDataManager.fnShowReleaseLoader(false);

				var customError = {
					customMessage: {
						message: jQuery(error.response.body).find('message:first').text(),
						details: error.response.body
					}
				};

				that._controller.oDataManager.oDataRequestFailed(customError, function () {});
				//that._controller.oDataManager.processListAfterAction(origin, instanceId);
			},
			true
		);

	},

	openRejectCommentDialog: function (event, rejectCommentDialog) {
		var controller = this._controller;
		//		element = event.getParameter('selectedItem');

		// Deselected?
		//	if (element.getKey() === 'Reject') {
		if (!this.rejectCommentDialog) {
			this.rejectCommentDialog = sap.ui.xmlfragment(
				'com.novartis.uwf.inbox.template.detail.CDM.RejectCommentDialog',
				controller
			);
			controller.getView().addDependent(this.rejectCommentDialog);

			// Store element on dialog
			//	this.rejectCommentDialog.element = element;

			// Toggle compact style
			jQuery.sap.syncStyleClass('sapUiSizeCompact', controller.getView(), this.rejectCommentDialog);

			// Open dialog
			this.rejectCommentDialog.open();
		}
	},

	onDialogCloseButton: function (event) {
		this._sNote = this.rejectCommentDialog.getContent()[1].getValue();
		this._rejectCode = this.rejectCommentDialog.getContent()[2].getSelectedKey();
		this.rejectCommentDialog.close();
		this.sendAction(false);
	},

	onDialogCancelButton: function (event) {
		this.rejectCommentDialog.destroy();
		this.rejectCommentDialog = null;
	},

	afterDataLoaded: function (controller, detailData) {

		/* Set item details note*/
		if (detailData.ZDPOItems && detailData.ZDPOItems.results) {
			if (detailData.ZDPOItems.results.length > 0) {
				this._ItemTab.setCount(detailData.ZDPOItems.results.length);
			} else {
				this._ItemTab.setCount("0");
			}
		}
		/* End of Item note */
		
		jQuery.extend(this._headerFooterOptions, {
			oPositiveAction: {
				sI18nBtnTxt: 'XBUT_APPROVE',
				onBtnPressed: $.proxy(this.showDecisionDialog, this, true)
			},
			oNegativeAction: {
				sI18nBtnTxt: 'XBUT_REJECT',
				onBtnPressed: $.proxy(this.openRejectCommentDialog, this, false)
			}
		});
		// Update footer with buttons
		this._controller.setHeaderFooterOptions(this._headerFooterOptions);
	},
	convertToUserPrpfileDecimal: function (sValue, DecimalNotation) {
		if (sValue && DecimalNotation) {
			//	sValue = parseFloat(sValue);
			var countDecimals = function (value) {
				if (Math.floor(value) == value) return 0;
				return value.toString().split(".")[1].length || 0;
			};
			var oCurrSettings = {
				showMeasure: false,
				groupingSeparator: DecimalNotation.charAt(1),
				decimalSeparator: DecimalNotation.charAt(9),
				decimals: countDecimals(sValue)
			};
			return sap.ui.core.format.NumberFormat.getCurrencyInstance(oCurrSettings).format(parseFloat(sValue));
		} else
			return "";
	},
	addingSpaceUnit: function (unitPrice) {
		if (unitPrice) {
			return "\u00a0 " + unitPrice;
		} else
			return false;
	},
	setCurrencyDecimalSettings: function (sValue, DecimalNotation, CurrencyDecimal) {
		if (sValue && DecimalNotation) {
			sValue = parseFloat(sValue);

			var oCurrSettings = {
				showMeasure: false,
				groupingSeparator: DecimalNotation.charAt(1),
				decimalSeparator: DecimalNotation.charAt(9),
				decimals: parseInt(CurrencyDecimal)
			};
			return sap.ui.core.format.NumberFormat.getCurrencyInstance(oCurrSettings).format(sValue);
		}
		return "";
	},
	onTALiveChange : function(oEvent){
		if(oEvent.getSource().getValue().length > 0){
			this.rejectCommentDialog.getBeginButton().setEnabled(true);
		}
		
			if(oEvent.getSource().getValue().length === 0){
			this.rejectCommentDialog.getBeginButton().setEnabled(false);
		}
	},
	commentDate: function (d, t) {

		if (d === null) {
			d = '';
		}

		if (t === null) {
			t = '';
		}

		// Return nothing if both dates are initial
		if (!d && !t) {
			return '';
		}

		// Parse if necessary
		if (typeof d == 'string') {
			d = new Date(d);
		}
		// millisecond to Time
		function msToTime(s) {
			var ms = s % 1000;
			s = (s - ms) / 1000;
			var secs = s % 60;
			s = (s - secs) / 60;
			var mins = s % 60;
			var hrs = (s - mins) / 60;

			return hrs + ':' + mins + ':' + secs;
		}

		return (
			com.novartis.uwf.lib.util.Formatter.dateFormat(d) +
			' - ' +
			msToTime(t.ms)
		);

	},
	commentUser: function (userID, level, decision) {
		if (!userID || !level) {
			return "";
		}
		if (userID === null || level === null) {
			return "";
		}
		
		return userID + ": "+decision+" Level "+level;

	},
	forward: function (controller, result) {

		if (this._validICSError) {
			//	sap.m.MessageToast.show("Please Provide Relavent Data");
			sap.m.MessageBox.error("Required Data to Approve Process is missing.");
			this._errorElements[0].focus();
			return true;
		}
		// Forward workflow
		if (result && result.bConfirmed) {
			var that = this,
				view = controller.getView(),
				context = view.getBindingContext(),
				origin = 'LOCAL_GW',
				instanceId = context.getProperty('InstanceID'),
				model = new sap.ui.model.odata.ODataModel(
					controller.oDataManager.oPostActionModel.sServiceUrl + origin
				),
				itemsToSend = [];

			// Prepare request
			var parameters = {
				SAP__Origin: origin,
				InstanceID: instanceId,
			//	Note: result.sNote,
				Agent: result.oAgentToBeForwarded.UniqueName,
			};

			// Submit asynchronously
			that._controller.oDataManager.fnShowReleaseLoader(true);
			model.callFunction(
				'ZCDMCoiForward',
				'POST',
				parameters,
				null,
				function (data) {
					that._controller.oDataManager.fnShowReleaseLoader(false);

					// Remove the processed item from the list
					//  that._controller.oDataManager.oModel.bFullRefreshNeeded = true;
					//that._controller.oDataManager.processListAfterAction(origin, instanceId);

					that._controller.oDataManager.processListAfterAction(origin, instanceId);
					that._controller.oDataManager.triggerRefresh('SENDACTION', this.ACTION_SUCCESS);
					that._controller.oDataManager.fireActionPerformed();

					jQuery.sap.delayedCall(500, that._controller, function () {
						sap.ca.ui.message.showMessageToast(
							controller.i18nBundle.getText(
								'dialog.success.forward',
								result.oAgentToBeForwarded.DisplayName
							)
						);
					});
				},
				function (error) {
					that._controller.oDataManager.fnShowReleaseLoader(false);

					var customError = {
						customMessage: {
							message: jQuery(error.response.body).find('message:first').text(),
							details: error.response.body
						}
					};

					that._controller.oDataManager.oDataRequestFailed(customError, function () {});
					//that._controller.oDataManager.processListAfterAction(origin, instanceId);
				},
				true
			);
		}
	}
	

});