/*&---------------------------------------------------------------------*
*& Development ID: ZDDE-00019502                                       *
*&                                                                     *
*& Inbox                                                               *
*&                                                                     *
*&---------------------------------------------------------------------*
*& Change Log:                                                         *
*&                                                                     *
*& Init. Who          Date         Text                                *
*& JHU   HUNDEJU1     24-06-2015   Initial version CD 1200006098       *
*& JHU   HUNDEJU1     23-07-2015   Initial version CD 1200006975       *
*& JHU   HUNDEJU1     10-08-2015   Read risks sep.  CD 1200007843      *
*& JHU   HUNDEJU1     20-08-2015   Description Formatter CD 1200007843 *
*& DEE   BASUDE4      09-02-2021   SAP UI Upgrade Fix CD 1600003335    *
*&---------------------------------------------------------------------*/

jQuery.sap.declare('com.novartis.uwf.inbox.template.detail.GRC.template');
jQuery.sap.require('com.novartis.uwf.inbox.template.detail.generic');

com.novartis.uwf.inbox.template.detail.generic.extend('com.novartis.uwf.inbox.template.detail.GRC.template', {
  _controller: null,

  _riskTab: null,

  _headerFooterOptions: null,

  getEntitySetsToExpand: function(item) {
    return [ 'ZGRCHeaderDetails', 'ZGRCItems' ];
  },

  getObjectHeader: function(controller) {
    return sap.ui.xmlfragment('com.novartis.uwf.inbox.template.detail.GRC.ObjectHeader', controller);
  },

  destroy: function() {
    // Destroy risks tab
    if (this._riskTab) {
      this._riskTab.destroy();
    }

    // Remove references
    this._headerFooterOptions = null;

    // Also destroy parent
    com.novartis.uwf.inbox.template.detail.generic.prototype.destroy.apply(this, arguments);
  },

  getInfoTab: function(controller) {
    // Extend controller
    this._controller = jQuery.extend(controller, {
      openRejectCommentDialog: jQuery.proxy(this.openRejectCommentDialog, this),
      onDialogCloseButton: jQuery.proxy(this.onDialogCloseButton, this),
      onDialogCancelButton: jQuery.proxy(this.onDialogCancelButton, this),
      handleResponsivePopoverPress: jQuery.proxy(this.handleResponsivePopoverPress, this),
      dateChange: jQuery.proxy(this.dateChange, this)
    });

    return sap.ui.xmlfragment(
      this._controller.getView().getId(),
      'com.novartis.uwf.inbox.template.detail.GRC.InfoTabContent',
      this._controller
    );
  },

  beforeDataLoaded: function(controller) {
    var view = this._controller.getView(),
      i18nCustom = view.getModel('i18nCustom');

    // Set generic model
    this._controller
      .getView()
      .setModel(new sap.ui.model.json.JSONModel({ risksLoading: true, isRoleOwner: false }), 'grcModel');

    // Already create risks tab
    if (!this._riskTab) {
      this._riskTab = new sap.m.IconTabFilter({
        key: 'risks',
        icon: 'sap-icon://alert',
        text: i18nCustom.getProperty('ZTAB_GRC_RISKS'),
        content: sap.ui.xmlfragment('com.novartis.uwf.inbox.template.detail.GRC.Risks', this._controller)
      });
    }

    // Indicates loading
    view.getModel('grcModel').setProperty('/risksLoading', true);
  },

  afterDataLoaded: function(controller, detailData) {
    var that = this,
      view = this._controller.getView(),
      model = view.getModel('detail'),
      details = detailData.ZGRCHeaderDetails,
      context = view.getBindingContext(),
      items = model.getProperty('/ZGRCItems');

    if (items) {
      // Preselect items
      for (var i = 0; i < items.results.length; i++) {
        var item = items.results[i];

        model.setProperty('/ZGRCItems/results/' + i + '/Selected', 'Approve');

        // Check if date contains year 9999. if this is the case the time zone difference has to be removed for the date picker otherwise it may crash
        if (item.ValidTo.toString().indexOf('9999') > -1) {
          var userOffset = item.ValidTo.getTimezoneOffset() * 60000,
            newTime = new Date(item.ValidTo.getTime() + userOffset);

          model.setProperty('/ZGRCItems/results/' + i + '/ValidTo', newTime);
          //items[i].ValidTo = newTime;
        }
      }
    }

    // Check if user acts as role owner or line manager and reconfigure buttons accordingly
    var isRoleOwner = details.StageConfigId.indexOf('ROLE') > -1;
    view.getModel('grcModel').setProperty('/isRoleOwner', isRoleOwner);

    if (isRoleOwner) {
      jQuery.extend(this._headerFooterOptions, {
        oPositiveAction: {
          sI18nBtnTxt: this._controller.getView().getModel('i18nCustom').getProperty('ZBUT_CONFIRM'),
          onBtnPressed: $.proxy(this.sendAction, this)
        },
        oNegativeAction: null
      });
    } else {
      jQuery.extend(this._headerFooterOptions, {
        oPositiveAction: {
          sI18nBtnTxt: 'XBUT_APPROVE',
          onBtnPressed: $.proxy(this.sendAction, this)
        },
        oNegativeAction: {
          sI18nBtnTxt: 'XBUT_REJECT',
          onBtnPressed: $.proxy(this.showDecisionDialog, this, false)
        }
      });
    }

    // Check if forward is disabled
    var forwardDisabled = details.ForwardDisabled;
    if (forwardDisabled) {
      var buttons = this._headerFooterOptions.buttonList;

      for (var i = 0; i < buttons.length; i++) {
        var button = buttons[i];

        if (button.sI18nBtnTxt === 'XBUT_FORWARD') {
          buttons.splice(i, 1);
          break;
        }
      }
    }

    // Read risks separately
    context.getModel().read('ZGRCRisks', {
      context: context,
      async: true,
      success: function(data) {
        var risks = data.results;

        // Update counter and table
        if (risks) {
          that._riskTab.setCount(risks.length);
          view.setModel(new sap.ui.model.json.JSONModel(risks), 'risksModel');
        }

        // Loading finished
        view.getModel('grcModel').setProperty('/risksLoading', false);
      }
    });

    // Update footer with buttons
    this._controller.setHeaderFooterOptions(this._headerFooterOptions);
  },

  configureTabs: function(tabbar) {
    var tabs = tabbar.getItems(),
      alreadyAdded = false;

    // Check if risks tab already exists
    for (var i = 0; i < tabs.length; i++) {
      if (tabs[i].getProperty('key') === 'risks') {
        alreadyAdded = true;
      }
    }

    // Add risk tab if necessary
    if (!alreadyAdded) {
      tabbar.addItem(this._riskTab);
    }
  },

  configureButtons: function(buttonList, controller) {
    this._headerFooterOptions = controller._oHeaderFooterOptions;
  },

  dateChange: function(event) {
    var parameters = event.getParameters(),
      source = event.getSource();

    // Restore old value if invalid
    if (!parameters.valid) {
      var formattedValue = source._formatValue(source.getDateValue(), true);

      source.setValue(formattedValue);
    }
  },

  handleResponsivePopoverPress: function(event) {
    var controller = this._controller,
      items = controller.getView().getModel('detail'),
      index = event.getSource().getParent().getBindingContextPath(),
      description = items.getProperty(index + '/SystemDesc');

    // Create popover with the system description as content
    var popover = new sap.m.Popover({ showHeader: false });
    popover.addStyleClass('sapUiPopupWithPadding');
    popover.addStyleClass('novApvGRCSystemPopover');
    popover.addContent(new sap.m.Text({ text: description }));
    popover.openBy(event.getSource());
  },

  showDecisionDialog: function(approve) {
    var decisionText = approve ? 'XBUT_APPROVE' : 'XBUT_REJECT',
      decision = approve ? 'Approve' : 'Reject',
      decisionTextI18n = this._controller.i18nBundle.getText(decisionText),
      mandatory = approve ? false : true;

    // Only mandatory for rejection
    sap.ca.ui.dialog.confirmation.open(
      {
        question: this._controller.i18nBundle.getText('XMSG_DECISION_QUESTION', decisionTextI18n),
        showNote: true,
        title: this._controller.i18nBundle.getText('XTIT_SUBMIT_DECISION'),
        confirmButtonLabel: this._controller.i18nBundle.getText('XBUT_SUBMIT'),
        noteMandatory: mandatory
      },
      jQuery.proxy(function(result) {
        if (result.isConfirmed) {
          var view = this._controller.getView(),
            items = view.getModel('detail').getProperty('/ZGRCItems').results;

          // Select/deselect all items based on the decision
          var firstItem = true;
          for (var i = 0; i < items.length; i++) {
            var item = items[i];

            // Set decision on item
            item.Selected = decision;

            // Set note only to the first one
            if (firstItem && !item.NotForApproval) {
              item.Comment = result.sNote;
              firstItem = false;
            } else {
              item.Comment = '';
            }
          }

          // Send action
          this.sendAction();
        }
      }, this)
    );
  },

  sendAction: function() {
    var that = this,
      controller = this._controller,
      view = controller.getView(),
      items = view.getModel('detail').getProperty('/ZGRCItems').results,
      context = view.getBindingContext(),
      origin = 'LOCAL_GW',
      model = new sap.ui.model.odata.ODataModel(controller.oDataManager.oPostActionModel.sServiceUrl + origin),
      instanceId = context.getProperty('InstanceID'),
      itemsToSend = [];

    // Create batch request
    for (var i = 0; i < items.length; i++) {
      var item = items[i],
        decision = null,
        comment = '',
        validTo = null,
        validToFormatted = '';

      // Is for approval?
      if (item.NotForApproval) {
        continue;
      }

      // Decision
      if (item.Selected === 'Approve') {
        // Approve
        decision = '0001';
      } else {
        // Reject
        decision = '0002';
      }
      comment = item.Comment ? item.Comment : '';

      // Validity date
      validTo = item.ValidTo;
      validToFormatted =
        '' +
        validTo.getFullYear() +
        ('0' + (validTo.getMonth() + 1)).slice(-2) +
        ('0' + validTo.getDate()).slice(-2);

      // Prepare item
      itemsToSend.push({
        req_id: item.ReqId,
        wi_id: item.WiId,
        decikey: decision,
        comments: comment,
        valid_to: validToFormatted
      });
    }

    // Prepare request
    var parameters = {
      SAP__Origin: origin,
      InstanceID: instanceId,
      Items: JSON.stringify(itemsToSend)
    };

    // Submit asynchronously
        that._controller.oDataManager.fnShowReleaseLoader(true);
    model.callFunction(
      'ZGRCItemDecision',
      'POST',
      parameters,
      null,
      function(data) {
                that._controller.oDataManager.fnShowReleaseLoader(false);
        
        // Remove the processed item from the list
        that._controller.oDataManager.processListAfterAction(origin, instanceId);
        that._controller.oDataManager.triggerRefresh('SENDACTION', this.ACTION_SUCCESS);
        that._controller.oDataManager.fireActionPerformed();

        jQuery.sap.delayedCall(500, that._controller, function() {
          sap.ca.ui.message.showMessageToast(that._controller.i18nBundle.getText('dialog.success.complete'));
        });
      },
      function(error) {
                that._controller.oDataManager.fnShowReleaseLoader(false);
                
        var customError = {
          customMessage: {
            message: jQuery(error.response.body).find('message:first').text(),
            details: error.response.body
          }
        };

        that._controller.oDataManager.oDataRequestFailed(customError, function() {});
        //that._controller.oDataManager.processListAfterAction(origin, instanceId);
      },
      true
    );
  },

  forward: function(controller, result) {
    // Forward workflow
    if (result && result.bConfirmed) {
      var that = this,
        view = controller.getView(),
        items = view.getModel('detail').getProperty('/ZGRCItems').results,
        context = view.getBindingContext(),
        origin = 'LOCAL_GW',
        instanceId = context.getProperty('InstanceID'),
        model = new sap.ui.model.odata.ODataModel(
          controller.oDataManager.oPostActionModel.sServiceUrl + origin
        ),
        itemsToSend = [];

      for (var i = 0; i < items.length; i++) {
        var item = items[i],
          instanceID = item.WiId;

        // Add prefix (scenario, system and client)
        var prefix = context.getProperty('InstanceID').split('-').slice(0, 3).join('-');
        instanceID = prefix + '-' + instanceID;

        // Is for approval?
        if (item.NotForApproval) {
          continue;
        }

        // Prepare forward item
        itemsToSend.push({
          wi_id: item.WiId
        });
      }

      // Prepare request
      var parameters = {
        SAP__Origin: origin,
        InstanceID: instanceId,
        Note: result.sNote,
        Agent: result.oAgentToBeForwarded.UniqueName,
        Items: JSON.stringify(itemsToSend)
      };

      // Submit asynchronously
      that._controller.oDataManager.fnShowReleaseLoader(true);
      model.callFunction(
        'ZGRCItemForward',
        'POST',
        parameters,
        null,
        function(data) {
              that._controller.oDataManager.fnShowReleaseLoader(false);
            
          // Remove the processed item from the list
          //  that._controller.oDataManager.oModel.bFullRefreshNeeded = true;
          //that._controller.oDataManager.processListAfterAction(origin, instanceId);

          that._controller.oDataManager.processListAfterAction(origin, instanceId);
          that._controller.oDataManager.triggerRefresh('SENDACTION', this.ACTION_SUCCESS);
          that._controller.oDataManager.fireActionPerformed();

          jQuery.sap.delayedCall(500, that._controller, function() {
            sap.ca.ui.message.showMessageToast(
              controller.i18nBundle.getText(
                'dialog.success.forward',
                result.oAgentToBeForwarded.DisplayName
              )
            );
          });
        },
        function(error) {
              that._controller.oDataManager.fnShowReleaseLoader(false);
                    
          var customError = {
            customMessage: {
              message: jQuery(error.response.body).find('message:first').text(),
              details: error.response.body
            }
          };

          that._controller.oDataManager.oDataRequestFailed(customError, function() {});
          //that._controller.oDataManager.processListAfterAction(origin, instanceId);
        },
        true
      );
    }
  },

  openRejectCommentDialog: function(event, rejectCommentDialog) {
    var controller = this._controller,
      element = event.getParameter('selectedItem');

    // Deselected?
    if (element.getKey() === 'Reject') {
      this.rejectCommentDialog = sap.ui.xmlfragment(
        'com.novartis.uwf.inbox.template.detail.GRC.RejectCommentDialog',
        controller
      );
      controller.getView().addDependent(this.rejectCommentDialog);

      // Store element on dialog
      this.rejectCommentDialog.element = element;

      // Reset comment field to blank
      sap.ui.getCore().byId('rejectDialogComment').setValue('');

      // Toggle compact style
      jQuery.sap.syncStyleClass('sapUiSizeCompact', controller.getView(), this.rejectCommentDialog);

      // Open dialog
      this.rejectCommentDialog.open();
    } else {
      // Approved again and thus the comment needs to be removed
      var items = controller.getView().getModel('detail'),
        index = element.getParent().getParent().getParent().getParent()
        .getBindingInfo("selectedKey").binding.getContext().getPath(); // CD 1600003335

      items.setProperty(index + '/Comment', '');
    }
  },

  onDialogCloseButton: function(event) {
    var controller = this._controller,
      items = controller.getView().getModel('detail'),
      rejectComment = sap.ui.getCore().byId('rejectDialogComment').getValue(),
      index = this.rejectCommentDialog.element
        .getParent()
        .getParent()
        .getParent()
        .getParent()
        .getBindingInfo("selectedKey").binding.getContext().getPath(); // CD 1600003335

    // Check if comment was entered
    if (rejectComment.length == 0) {
      // Output error
      var i18nCustom = controller.getView().getModel('i18nCustom');

      sap.ui
        .getCore()
        .byId('rejectDialogCommentMissing')
        .setText(i18nCustom.getProperty('ZTAB_GRC_INFO_TBL_REJECT_DIA_COMMENT_MISSING'));
    } else {
      // Set comment to item
      items.setProperty(index + '/Comment', rejectComment);

      // Restore initial state when user canceled
      sap.ui.getCore().byId('rejectDialogCommentMissing').setText('');
      this.rejectCommentDialog.destroy();
      this.rejectCommentDialog = null;
    }
  },

  onDialogCancelButton: function(event) {
    var controller = this._controller,
      items = controller.getView().getModel('detail'),
      index = this.rejectCommentDialog.element
        .getParent()
        .getParent()
        .getParent()
        .getParent()
        .getBindingInfo("selectedKey").binding.getContext().getPath(); // CD 1600003335

    // Set comment to item
    items.setProperty(index + '/Comment', '');
    items.setProperty(index + '/Selected', 'Approve');

    // Restore initial state when user canceled
    sap.ui.getCore().byId('rejectDialogCommentMissing').setText('');

    this.rejectCommentDialog.destroy();
    this.rejectCommentDialog = null;
  },

  descriptionFormatter: function(value) {
    var formattedText = value === '()' ? '' : value;

    if (value && value.indexOf(';') > 0) {
      // Remove duplicates
      var parts = value.split(';');
      parts = parts.filter(function(item, pos) {
        return parts.indexOf(item) == pos;
      });

      // Return "multiple" text if more than one ; is available
      if (parts.length > 1) {
        formattedText = this.getModel('i18nCustom').getProperty('ZTAB_GRC_DESC_MULTIPLE');
      } else {
        formattedText = parts[0];
      }
    }

    return formattedText;
  },

  dateValidityPeriodFormat: function(dateFrom, dateTo) {
    if (dateFrom == null || dateFrom.getFullYear() === 1970) {
      dateFrom = '';
    }

    if (dateTo == null || dateTo.getFullYear() === 1970) {
      dateTo = '';
    }

    // Return nothing if both dates are initial
    if (!dateFrom && !dateTo) {
      return '';
    }

    // Parse if necessary
    if (typeof dateFrom == 'string') {
      dateFrom = new Date(dateFrom);
    }
    if (typeof dateTo == 'string') {
      dateTo = new Date(dateTo);
    }

    return (
      com.novartis.uwf.lib.util.Formatter.dateFormat(dateFrom) +
      ' - ' +
      com.novartis.uwf.lib.util.Formatter.dateFormat(dateTo)
    );
  },

  getStyleClassForDatePicker: function(value) {
    var styleClass = 'novInfoTabGRCTableGeneric novInfoTabGRCTableDateText';

    if (value) {
      styleClass = 'novInfoTabGRCTableGeneric novInfoTabGRCTableDateInput';
    }

    return styleClass;
  }
});