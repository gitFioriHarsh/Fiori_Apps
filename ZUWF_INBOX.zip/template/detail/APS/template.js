/*&---------------------------------------------------------------------*
*& Development ID: ZDDE-00019502                                       *
*&                                                                     *
*& Inbox                                                               *
*&                                                                     *
*&---------------------------------------------------------------------*
*& Change Log:                                                         *
*&                                                                     *
*& Init. Who          Date         Text                                *
*& JHU   HUNDEJU1     24-06-2015   Initial version CD 1200006098       *
*& JHU   HUNDEJU1     23-07-2015   Initial version CD 1200006975       *
*&---------------------------------------------------------------------*/

jQuery.sap.declare('com.novartis.uwf.inbox.template.detail.APS.template');
jQuery.sap.require('com.novartis.uwf.inbox.template.detail.generic');

com.novartis.uwf.inbox.template.detail.generic.extend('com.novartis.uwf.inbox.template.detail.APS.template', {
	_controller: null,

	getEntitySetsToExpand: function(item) {
		return [ 'ZXXXDetails' ];
	},

	beforeDataLoaded: function(controller, detailData) {
		// Create local model for submit
		controller.getView().setModel(new sap.ui.model.json.JSONModel({}), 'APSModel');
	},

	getObjectHeader: function(controller) {
		return sap.ui.xmlfragment('com.novartis.uwf.inbox.template.detail.APS.ObjectHeader', controller);
	},

	getInfoTab: function(controller) {
		return sap.ui.xmlfragment(
			controller.getView().getId(),
			'com.novartis.uwf.inbox.template.detail.APS.InfoTabContent',
			controller
		);
	},

	configureButtons: function(buttonList, controller) {
		this._controller = controller;

		// Remove extra buttons
		buttonList.aButtonList.length = 0;

		// Change action of buttons
		buttonList.oPositiveAction.onBtnPressed = jQuery.proxy(this.onApprovePress, this);
		buttonList.oNegativeAction.onBtnPressed = jQuery.proxy(this.onRejectPress, this);
	},

	configureTabs: function(oTabBar) {
		var aItems = oTabBar.getItems();

		/* hide standard tabs */
		for (var i = 0; i < aItems.length; i++) {
			if (aItems[i].getId().indexOf('MIBNoteIconTabFilter') != -1) {
				aItems[i].setVisible(false);
			} else if (aItems[i].getId().indexOf('MIBAttachmentIconTabFilter') != -1) {
				aItems[i].setVisible(false);
			}
		}
	},

	onApprovePress: function() {
		var oController = this._controller,
			oLocalModel = oController.getView().getModel('APSModel'),
			oI18nModel = oController.getView().getModel('i18n'),
			oResourceBundle,
			sAction;

		if (oI18nModel) {
			oResourceBundle = oI18nModel.getResourceBundle();
			if (oResourceBundle) {
				sAction = oResourceBundle.getText('XBUT_APPROVE');
			}
		}

			oLocalModel.setProperty('/submitTitle', sAction);
			oLocalModel.setProperty('/submitAction', 'approve');
			oLocalModel.setProperty('/submitNeedComment', false);
			this.onActionPress();
	},

	onRejectPress: function(oEvent) {
		var oController = this._controller,
			oLocalModel = oController.getView().getModel('APSModel'),
			oI18nModel = oController.getView().getModel('i18n'),
			oResourceBundle,
			sAction;

		if (oI18nModel) {
			oResourceBundle = oI18nModel.getResourceBundle();
			if (oResourceBundle) {
				sAction = oResourceBundle.getText('XBUT_REJECT');
			}
		}

			oLocalModel.setProperty('/submitTitle', sAction);
			oLocalModel.setProperty('/submitAction', 'reject');
			oLocalModel.setProperty('/submitNeedComment', true);
			this.onActionPress();
	},

	onActionPress: function() {
		var oController = this._controller;

		if (!this._submitDialog) {
			this._submitDialog = sap.ui.xmlfragment('com.novartis.uwf.inbox.template.detail.APS.SubmitDialog', this);
			oController.getView().addDependent(this._submitDialog);
		}

		this._submitDialog.open();
	},

	onCancelSubmit: function(oEvent) {
		var oLocalModel = this._controller.getView().getModel('APSModel');

		oLocalModel.setProperty('/passwordState', 'None');
		oLocalModel.setProperty('/password', '');
		oLocalModel.setProperty('/comment', '');
		oLocalModel.setProperty('/commentState', 'None');

		this._submitDialog.close();
	},

	onSubmitDecision: function() {
		var oController = this._controller,
			oContext = oController.getView().getBindingContext(),
			oLocalModel = oController.getView().getModel('APSModel'),
			sOrigin = oContext.getProperty('SAP__Origin'),
			sInstanceId = oContext.getProperty('InstanceID'),
			sPassword = oLocalModel.getProperty('/password') || '',
			sComment = oLocalModel.getProperty('/comment') || '',
			sDecision = oLocalModel.getProperty('/submitAction'),
			bNeedComment = oLocalModel.getProperty('/submitNeedComment');

		var iDummyPos = sInstanceId.indexOf('-DUMMY');

		if (iDummyPos != -1) {
			sInstanceId = sInstanceId.substring(0, iDummyPos);
		}

		// Validate input
		if (!sPassword) {
			oLocalModel.setProperty('/passwordState', 'Error');
			oLocalModel.setProperty('/password', '');
		}
		if (!sComment && bNeedComment) {
			oLocalModel.setProperty('/commentState', 'Error');
		}

		if (!sPassword || (!sComment && bNeedComment)) {
			return;
		}

		// Reset fields
		oLocalModel.setProperty('/passwordState', 'None');
		oLocalModel.setProperty('/password', '');
		oLocalModel.setProperty('/comment', '');
		oLocalModel.setProperty('/commentState', 'None');
		
		// Pad password and add before comment
		var iLength = 20;
		var sSpaces = new Array(iLength).join(' ');
		var sPaddedPassword = (sPassword + sSpaces).slice(0, iLength);
		var sPasswordAndComment = sPaddedPassword + sComment;

		// Submit asynchronously
		this._submitDialog.close();
		oController.oDataManager.sendAction(
			oController.oDataManager.FUNCTION_IMPORT_DECISION,
			{
				SAP__Origin: sOrigin,
				InstanceID: sInstanceId,
				DecisionKey: sDecision
			},
			sPasswordAndComment
		);
	}
});
