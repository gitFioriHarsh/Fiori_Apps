/*&---------------------------------------------------------------------*
*& Development ID: ZDDE-00019502                                       *
*&                                                                     *
*& Inbox                                                               *
*&                                                                     *
*&---------------------------------------------------------------------*
*& Change Log:                                                         *
*&                                                                     *
*& Init. Who          Date         Text                                *
*& JHU   HUNDEJU1     24-06-2015   Initial version CD 1200006098       *
*& JHU   HUNDEJU1     23-07-2015   Initial version CD 1200006975       *
*&---------------------------------------------------------------------*/

jQuery.sap.declare('com.novartis.uwf.inbox.template.detail.SRM.template');
jQuery.sap.require('com.novartis.uwf.inbox.template.detail.generic');
jQuery.sap.require('com.novartis.uwf.lib.util.Formatter');

com.novartis.uwf.inbox.template.detail.generic.extend('com.novartis.uwf.inbox.template.detail.SRM.template', {
	_controller: null,

	getEntitySetsToExpand: function(item) {
		return ['ZSRMHeaderDetails', 'ZSRMItems'];
	},

	getObjectHeader: function(controller) {
		return sap.ui.xmlfragment('com.novartis.uwf.inbox.template.detail.SRM.ObjectHeader', controller);
	},

	getInfoTab: function(controller) {
		// Extend controller
		this._controller = jQuery.extend(controller, {
			itemPress: jQuery.proxy(this.itemPress, this)
		});

		return sap.ui.xmlfragment(controller.getView().getId(), 'com.novartis.uwf.inbox.template.detail.SRM.InfoTabContent', this._controller);
	},

	afterDataLoaded: function(controller, detailData) {
		// Fix element at top
		this.fixElement(controller, 'fixedDetails');
	},

	configureButtons: function(buttonList, controller) {
		var data = controller.oModel2.getData();

		// Directly send action without confirmation
		if (buttonList.oPositiveAction) {
			buttonList.oPositiveAction.onBtnPressed = $.proxy(controller.sendAction, controller, 'Decision', {
				SAP__Origin: data.SAP__Origin,
				InstanceID: data.InstanceID,
				DecisionKey: '0001'
			}, '');
		}
	},

	itemPress: function(event) {
		var controller = this._controller,
			view = controller.getView(),
			page = view.getAggregation('content')[0],
			items = view.getModel('detail'),
			item = event.getParameter('listItem'),
			index = item.getBindingContextPath(),
			intIndex = parseInt(index.split('/').slice(-1).pop(), 10),
			y = event.getSource().getItems()[intIndex].$().position().top + event.getSource().$().position().top + event.getSource().$().find('.sapMListTbl').position().top + view.byId('fixedDetails').$().height();

		// Update texts
		view.byId('Supplier').setText(items.getProperty(index + '/Supplier'));
		view.byId('AccAssign').setText(items.getProperty(index + '/AccAssign'));

		// Prevent default event
		event.preventDefault();
		event.cancelBubble();

		// Scroll to item position
		event.getSource().getItemNavigation().focusItem(intIndex + 1, {});
		page.scrollTo(y, 100);
	}
});
