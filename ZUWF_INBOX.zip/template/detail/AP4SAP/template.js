/*&---------------------------------------------------------------------*
*& Development ID: ZDDE-00019502                                       *
*&                                                                     *
*& Inbox                                                               *
*&                                                                     *
*&---------------------------------------------------------------------*
*& Change Log:                                                         *
*&                                                                     *
*& Init. Who          Date         Text                                *
*& JCP   COSTAJOJ     20-10-2015   Initial version CD 1200005515       *
*&---------------------------------------------------------------------*/

jQuery.sap.declare('com.novartis.uwf.inbox.template.detail.AP4SAP.template');
jQuery.sap.require('com.novartis.uwf.inbox.template.detail.generic');

com.novartis.uwf.inbox.template.detail.generic.extend('com.novartis.uwf.inbox.template.detail.AP4SAP.template', {
	_controller: null,

	_headerFooterOptions: null,

	getEntitySetsToExpand: function(item) {
		return [ 'ZAP4HeaderDetails', 'ZAP4Items' ];
	},

	getObjectHeader: function(controller) {
		return sap.ui.xmlfragment('com.novartis.uwf.inbox.template.detail.AP4SAP.ObjectHeader', controller);
	},

	getInfoTab: function(controller) {
		// Extend controller
		this._controller = jQuery.extend(controller, {});

		return sap.ui.xmlfragment(
			controller.getView().getId(),
			'com.novartis.uwf.inbox.template.detail.AP4SAP.InfoTabContent',
			controller
		);
	},

	configureButtons: function(buttonList, controller) {
		var length = buttonList.aButtonList.length;
		buttonList.aButtonList.splice(0, length);
		this._headerFooterOptions = controller._oHeaderFooterOptions;
	},

	handleText: function(decisionText) {
		var index = decisionText.indexOf('@');
		var text = decisionText.slice(0, index);
		return text;
	},

	afterDataLoaded: function(controller, detailData) {
		var view = this._controller.getView(),
			model = view.getModel('detail'),
			details = detailData.ZAP4HeaderDetails,
			context = view.getBindingContext(),
			buttons = model.getProperty('/ZDecisionOptions'),
			endorseButtons = [],
			rejectButtons = [],
			endorseModel = new sap.ui.model.json.JSONModel(),
			rejectModel = new sap.ui.model.json.JSONModel();

		var instanceID = details.WiId;
		var prefix = context.getProperty('InstanceID').split('-').slice(0, 3).join('-');
		instanceID = prefix + '-' + instanceID;

		buttons.results.forEach(function(button) {
			if (button.DecisionKey == '0001') {
				endorseButtons.push(button);
			} else {
				rejectButtons.push(button);
			}
		});
		//
		endorseModel.setData(endorseButtons);
		rejectModel.setData(rejectButtons);
		//
		var actionEndorse = new sap.m.ActionSheet({
			showCancelButton: true,
			placement: 'Top',
			buttons: {
				path: '/',
				template: new sap.m.Button({
					text:
						"{path: 'DecisionText', formatter: 'com.novartis.uwf.inbox.template.detail.AP4SAP.template.prototype.handleText'}",
					//                            press: jQuery.proxy(this.sendAction, model, this),
					press: jQuery.proxy(this.showDecisionDialog, model, this),
					customData: [
						new sap.ui.core.CustomData({ key: 'Decision', value: '{DecisionKey}' }),
						new sap.ui.core.CustomData({ key: 'RetId', value: '{Nature}' }),
						new sap.ui.core.CustomData({ key: 'WiId', value: details.WiId }),
						new sap.ui.core.CustomData({ key: 'ZObjType', value: details.ZObjType }),
						new sap.ui.core.CustomData({ key: 'InstanceId', value: instanceID })
					]
				})
			}
		});
		//
		var actionReject = new sap.m.ActionSheet({
			showCancelButton: true,
			placement: 'Top',
			buttons: {
				path: '/',
				template: new sap.m.Button({
					text:
						"{path: 'DecisionText', formatter: 'com.novartis.uwf.inbox.template.detail.AP4SAP.template.prototype.handleText'}",
					//                            press: jQuery.proxy(this.sendAction, model, this),
					press: jQuery.proxy(this.showDecisionDialog, model, this),
					customData: [
						new sap.ui.core.CustomData({ key: 'Decision', value: '{DecisionKey}' }),
						new sap.ui.core.CustomData({ key: 'RetId', value: '{Nature}' }),
						new sap.ui.core.CustomData({ key: 'WiId', value: details.WiId }),
						new sap.ui.core.CustomData({ key: 'ZObjType', value: details.ZObjType }),
						new sap.ui.core.CustomData({ key: 'InstanceId', value: instanceID })
					]
				})
			}
		});
		//
		actionEndorse.setModel(endorseModel);
		actionReject.setModel(rejectModel);

		var positiveButtonText;
		if (detailData.ZObjectType == 'AIFP') {
			positiveButtonText = controller.getView().getModel('i18nCustom').getProperty('ZTAB_AP4_INFO_BUTTON_END');
		} else {
			positiveButtonText = controller.getView().getModel('i18nCustom').getProperty('ZTAB_AP4_INFO_BUTTON_APPV');
		}

		jQuery.extend(this._headerFooterOptions, {
			oPositiveAction: {
				sI18nBtnTxt: positiveButtonText,
				onBtnPressed: jQuery.proxy(function() {
					var buttons = this._controller.getView().getAggregation('content')[0].getFooter().getContentRight();
					var buttonOpen;
					for (var i = 0; i < buttons.length; i++) {
						if (buttons[i]._sTypeInBar == 'Accept') {
							buttonOpen = buttons[i];
							break;
						}
					}
					actionEndorse.openBy(buttonOpen);
				}, this)
			},
			oNegativeAction: {
				sI18nBtnTxt: this._controller.getView().getModel('i18nCustom').getProperty('ZTAB_AP4_INFO_BUTTON_REJ'),
				onBtnPressed: jQuery.proxy(function() {
					var buttons = this._controller.getView().getAggregation('content')[0].getFooter().getContentRight();
					var buttonOpen;
					for (var i = 0; i < buttons.length; i++) {
						if (buttons[i]._sTypeInBar == 'Reject') {
							buttonOpen = buttons[i];
							break;
						}
					}
					actionReject.openBy(buttonOpen);
				}, this)
			}
		});

		// Update footer with buttons
		if (details.ZObjType == 'AUMD') {
			delete this._headerFooterOptions.oNegativeAction;
		}

		this._controller.setHeaderFooterOptions(this._headerFooterOptions);
	},

	setUrl: function(title, controller) {},

	showDecisionDialog: function(controller, event) {
		controller._controller.evt = event.getSource().getCustomData();
		//        controller._controller.url = this.setUrl(event.getSource().getProperty('text'),controller);
		var decisions = controller._controller.getView().getModel('detail').oData.ZDecisionOptions.results;
		var url = '';
		var isMandatory = false;
		decisions &&
			decisions.forEach(function(item) {
				if (item.DecisionText.indexOf(event.getSource().getProperty('text')) >= 0) {
					var len = item.DecisionText.length;
					var index = item.DecisionText.indexOf('@');
					url = item.DecisionText.slice(index + 1, len);
					isMandatory = item.DecisionKey != '0001';
				}
			});
		controller._controller.url = url;

		/*if (controller._controller.getView().getModel('detail').oData.ZObjectType == 'ANPC' && event.getSource().getProperty('text') == 'Accept'){
            controller._controller.url = controller._controller.getView().getModel('detail').oData.UIExecutionLink.GUI_Link;
        }*/

		if (controller._controller.url.length === 0) {
			controller._controller.urlExists = false;
		} else {
			controller._controller.urlExists = true;
		}

		var tablet =
			sap.ui.Device.system.tablet && (sap.ui.Device.os.name == 'Android' || sap.ui.Device.os.name == 'iOS');
		var openDialog = function() {
			sap.ca.ui.dialog.confirmation.open(
				{
					showNote: true,
					title: controller._controller.i18nBundle.getText('XTIT_SUBMIT_DECISION'),
					confirmButtonLabel: controller._controller.i18nBundle.getText('XBUT_SUBMIT'),
					noteMandatory: isMandatory
				},
				jQuery.proxy(function(result) {
					if (result.isConfirmed) {
						this.openUrl(this);
						this._controller.reason = result.sNote;
						if (
							this._controller.getView().getModel('detail').oData.ZObjectType != 'ANPC' ||
							!this._controller.urlExists
						) {
							this.sendAction(this);
						}
					}
				}, controller)
			);
		};

		if ((sap.ui.Device.system.phone || tablet) && controller._controller.urlExists) {
			// Please complete the task from a PC
			sap.ca.ui.dialog.confirmation.open(
				{
					showNote: false,
					title: sap.ca.ui.message.Type.WARNING.title,
					question: controller._controller
						.getView()
						.getModel('i18nCustom')
						.getProperty('ZTAB_AP4_INFO_MSG_COMPLETE_PC'),
					confirmButtonLabel: controller._controller
						.getView()
						.getModel('i18nCustom')
						.getProperty('ZBUT_CONFIRM'),
					details: ''
				},
				function(result) {
					if (result.isConfirmed) {
						openDialog();
					}
				}
			);
		} else {
			openDialog();
		}
	},

	openUrl: function(controller) {
		if (controller._controller.urlExists && !jQuery.device.is.phone) {
			var win = window.open(controller._controller.url, '_blank');
			win.focus();
		}
	},

	sendAction: function(controller, event) {
		var origin = 'LOCAL_GW';
		var instanceId = controller._controller.getView().getBindingContext().getProperty('InstanceID');
		var decision = {
			instance_id: '',
			decision: '',
			ret_id: '',
			wi_id: '',
			zobj_type: '',
			reason: ''
		};
		var itemsToSend = [];
		var InstanceID;
		var model = new sap.ui.model.odata.ODataModel(
			controller._controller.oDataManager.oPostActionModel.sServiceUrl + origin
		);
		//        var customData = event.getSource().getCustomData();
		var customData = controller._controller.evt;
		customData.forEach(function(item) {
			if (item.getKey() == 'Decision') {
				decision.decision = item.getValue();
			}
			if (item.getKey() == 'RetId') {
				decision.ret_id = item.getValue();
			}
			if (item.getKey() == 'WiId') {
				decision.wi_id = item.getValue();
			}
			if (item.getKey() == 'ZObjType') {
				decision.zobj_type = item.getValue();
			}
			if (item.getKey() == 'InstanceId') {
				decision.instance_id = item.getValue();
				InstanceID = item.getValue();
			}
		});

		if (controller._controller.reason !== null) {
			decision.reason = controller._controller.reason;
		}

		itemsToSend.push(decision);

		var parameters = {
			SAP__Origin: origin,
			InstanceID: InstanceID,
			Items: JSON.stringify(itemsToSend)
		};

		//        // Submit asynchronously
		controller._controller.oDataManager.fnShowReleaseLoader(true);
		model.callFunction(
			'ZAP4ItemDecision',
			'POST',
			parameters,
			null,
			function(data) {
				//              // Remove the processed item from the list
				controller._controller.oDataManager.fnShowReleaseLoader(false);
				controller._controller.oDataManager.processListAfterAction(origin, instanceId);
				controller._controller.oDataManager.triggerRefresh('SENDACTION', this.ACTION_SUCCESS);
				controller._controller.oDataManager.fireActionPerformed();
				//
				jQuery.sap.delayedCall(500, controller._controller, function() {
					sap.ca.ui.message.showMessageToast(
						controller._controller.i18nBundle.getText('dialog.success.complete')
					);
				});
			},
			function(error) {
				controller._controller.oDataManager.fnShowReleaseLoader(false);

				var customError = {
					customMessage: {
						message: jQuery(error.response.body).find('message:first').text(),
						details: error.response.body
					}
				};

				controller._controller.oDataManager.oDataRequestFailed(customError, function() {});
				//that._controller.oDataManager.processListAfterAction(origin, instanceId);
			},
			true
		);
	},

	periodFormatter: function(date) {
		var period = '',
			fullDate = sap.ui.core.format.DateFormat.getDateInstance({ style: 'long' });

		if (date) {
			period = fullDate.format(date);
		}

		return period;
	},

	isTypeValid: function(value) {
		return value !== undefined && value !== '';
	},

	isTypePO: function(type) {
		return type == 'APQD' || type == 'APPD';
	},

	isNotTypePO: function(type) {
		return type != 'APQD' && type != 'APPD';
	},

	isTypeAPQD: function(type) {
		return type == 'APQD';
	},

	isTypeAPPD: function(type) {
		return type == 'APPD';
	},

	textByObj: function(type) {
		if (type) {
			return this.getModel('i18nCustom').getProperty('ZTAB_AP4_INFO_HEADER_MSG_' + type);
		} else {
			return this.getModel('i18nCustom').getProperty('ZTAB_AP4_INFO_HEADER_MSG_UNK');
		}
	},

	showPONum: function(type) {
		if (type == 'AIFP' || type == 'APIE' || type == 'AUMD' || type == 'AILA') {
			return true;
		} else {
			return false;
		}
	},

	showPOItemDescription: function(type) {
		if (type == 'AIFP' || type == 'AILA') {
			return true;
		} else {
			return false;
		}
	},

	showPOItem: function(type) {
		if (type == 'APIE' || type == 'AUMD') {
			return true;
		} else {
			return false;
		}
	},

	calcTax: function(gross, net, currency) {
		if (gross && net && currency && gross != 0) {
			var value = gross - net;
			var valDec = parseFloat(value).toFixed(2);
			var val = valDec.toString();
			return val + ' ' + currency;
		}
		return 0;
	},

	isNotEndorse: function(type) {
		if (type == 'ANPA' || type == 'ANPC') {
			return true;
		} else {
			return false;
		}
	},

	configureTabs: function(tabbar) {},

	removeLeadZeros: function(plkey) {
		if (plkey) {
			return plkey.replace(/\b0+/g, '');
		}
	},

	mergePurchaseOrderItem: function(number, item) {
		if (number && item) {
			return number + ' - ' + item.replace(/\b0+/g, '');
		}
	}
});
