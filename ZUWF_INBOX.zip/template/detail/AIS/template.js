/*&---------------------------------------------------------------------*
*& Development ID: ZDDE-00019502                                       *
*&                                                                     *
*& Inbox                                                               *
*&                                                                     *
*&---------------------------------------------------------------------*
*& Change Log:                                                         *
*&                                                                     *
*& Init. Who          Date         Text                                *
*& JHU   HUNDEJU1     24-06-2015   Initial version CD 1200006098       *
*& JHU   HUNDEJU1     23-07-2015   Initial version CD 1200006975       *
*&---------------------------------------------------------------------*/

jQuery.sap.declare('com.novartis.uwf.inbox.template.detail.AIS.template');
jQuery.sap.require('com.novartis.uwf.inbox.template.detail.generic');

com.novartis.uwf.inbox.template.detail.generic.extend('com.novartis.uwf.inbox.template.detail.AIS.template', {
	_controller : null,

	getEntitySetsToExpand: function(item) {
		return [];
	},

	getObjectHeader: function(controller) {
		return sap.ui.xmlfragment('com.novartis.uwf.inbox.template.detail.AIS.ObjectHeader', controller);
	},

	getInfoTab: function(controller) {
		return sap.ui.xmlfragment(controller.getView().getId(), 'com.novartis.uwf.inbox.template.detail.AIS.InfoTabContent', controller);
	},

	configureButtons: function(buttonList, controller) {
		// Remove extra buttons
		buttonList.aButtonList.length = 0;
		
		// Change action of positive button
		buttonList.oPositiveAction.onBtnPressed = function() {
			var oItem = controller.oModel2.getData();
			controller.showConfirmationDialog(controller.oDataManager.FUNCTION_IMPORT_CONFIRM, oItem);
		};
	},

  configureTabs: function(oTabBar) {
		var aItems = oTabBar.getItems();

		/* hide standard tabs */
    for (var i = 0; i < aItems.length; i++) {
      if (aItems[i].getId().indexOf('MIBNoteIconTabFilter') != -1) {
        aItems[i].setVisible(false);
      } else if (aItems[i].getId().indexOf('MIBAttachmentIconTabFilter') != -1) {
        aItems[i].setVisible(false);
      }
    }
	}
});
