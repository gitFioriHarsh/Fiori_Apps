/*&---------------------------------------------------------------------*
*& Development ID: ZDDE-00019502                                       *
*&                                                                     *
*& Inbox                                                               *
*&                                                                     *
*&---------------------------------------------------------------------*
*& Change Log:                                                         *
*&                                                                     *
*& Init. Who          Date         Text                                *
*& JHU   HUNDEJU1     24-06-2015   Initial version CD 1200006098       *
*& JHU   HUNDEJU1     23-07-2015   Initial version CD 1200006975       *
*&---------------------------------------------------------------------*/

jQuery.sap.declare('com.novartis.uwf.inbox.template.detail.ETRAVEL.template');
jQuery.sap.require('com.novartis.uwf.inbox.template.detail.generic');

com.novartis.uwf.inbox.template.detail.generic.extend('com.novartis.uwf.inbox.template.detail.ETRAVEL.template', {
	_controller : null,

	getEntitySetsToExpand: function(item) {
		return ['ZETRHeaderDetails', 'ZETRItems', 'ZETRDestinations', 'ZETRCostAssignments'];
	},

	getObjectHeader: function(controller) {
		return sap.ui.xmlfragment('com.novartis.uwf.inbox.template.detail.ETRAVEL.ObjectHeader', controller);
	},

	getInfoTab: function(controller) {
		// Extend controller
		this._controller = jQuery.extend(controller, {
			scrollToAnchor : jQuery.proxy(this.scrollToAnchor, this)
		});

		return sap.ui.xmlfragment(controller.getView().getId(), 'com.novartis.uwf.inbox.template.detail.ETRAVEL.InfoTabContent', controller);
	},

	configureButtons: function(buttonList, controller) {
		var data = controller.oModel2.getData();

		// Remove Forward button
		buttonList.aButtonList = [];

		// Directly send action without confirmation
		if (buttonList.oPositiveAction) {
			buttonList.oPositiveAction.onBtnPressed = $.proxy(controller.sendAction, controller, 'Decision', {
				SAP__Origin: data.SAP__Origin,
				InstanceID: data.InstanceID,
				DecisionKey: '0001'
			}, '');
		}
	},

	complianceFormatter: function(value) {
		var styleClass = '';

		if (value === '001') {
			styleClass = 'green';
		} else if (value === '002') {
			styleClass = 'yellow';
		}
		this.addStyleClass(styleClass);
		return '_';
	},

	hrefGenerator: function(value) {
		return '#' + this.getId() + 'Target';
	},

	scrollToAnchor: function(event) {
		var view = this._controller.getView(),
			page = view.getAggregation('content')[0],
			scroller = page._oScroller,
			target = $('#' + event.getSource().getId() + 'Target');

		// Does target exist?
		if (target.length != 0) {
			var topHeaders = target.offsetParent().offsetParent().offsetParent().offsetParent().offset().top,
				verticalPixel = target.offset().top; // 96 px

			page.scrollTo(verticalPixel - topHeaders + scroller._scrollY, 1000); // 44px
		}
	},

	isTypeTRIP: function(type) {
		//"TRIP" (Travel Request)
		//ZTAB_ETr_INFO_HEADER_ESTIMATED_COST=Estimated cost
		//ZTAB_ETr_INFO_HEADER_SUM_ADVANCE=Advance amount

		return (type === 'TRIP');
	},

	isTypeEXPE: function(type) {
		//"EXPE" (Expense Report)
		//ZTAB_ETr_INFO_HEADER_TOTAL_COST=Total Cost of trip
		//ZTAB_ETr_INFO_HEADER_SUM_REIMBURSED=Amount to be reimbursed

		return (type === 'EXPE');
	}
});
