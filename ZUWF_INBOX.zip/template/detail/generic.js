/*&---------------------------------------------------------------------*
*& Development ID: ZDDE-00019502                                       *
*&                                                                     *
*& Inbox                                                               *
*&                                                                     *
*&---------------------------------------------------------------------*
*& Change Log:                                                         *
*&                                                                     *
*& Init. Who          Date         Text                                *
*& JHU   HUNDEJU1     24-06-2015   Initial version CD 1200006098       *
*& JHU   HUNDEJU1     23-07-2015   Initial version CD 1200006975       *
*&---------------------------------------------------------------------*/

jQuery.sap.declare('com.novartis.uwf.inbox.template.detail.generic');

sap.ui.base.Object.extend('com.novartis.uwf.inbox.template.detail.generic', {
    destroy: function(controller) {
        var view = controller.getView(),
            models = jQuery.extend({}, view.oModels);

        // Unbind scroll event if necessary
        if (this.fixedElement) {
            this.fixedElement.scroller._onScroll = this.fixedElement.onScroll;

            if (this.fixedElement.clone) {
                this.fixedElement.clone.remove();
            }

            this.fixedElement = null;
        }
        controller.getView().getAggregation('content')[0].rerender(true);

        // Remove all custom models from the view
        for (var model in models) {
            if (model === 'undefined' || model == 'i18n' || model == 'device') {
                continue;
            }

            view.setModel(null, model);
        }
    },

    getEntitySetsToExpand: function(item) {
        return [];
    },

    getObjectHeader: function(controller) {
        return sap.ui.xmlfragment('com.novartis.uwf.inbox.template.detail.ObjectHeader', controller);
    },

    getInfoTab: function(controller) {
        return sap.ui.xmlfragment('com.novartis.uwf.inbox.template.detail.InfoTabContent', controller);
    },

    configureTabs: function(tabbar) {

    },

    configureButtons: function(buttonList, controller) {

    },

    beforeDataLoaded: function(controller, detailData) {

    },

    afterDataLoaded: function(controller, detailData) {

    },

    forward: function(controller, result) {
        // Forward workflow
        if (result && result.bConfirmed) {
            var item = controller.oModel2.getData(),
                origin = item.SAP__Origin,
                instanceID = item.InstanceID;

            controller.oDataManager.doForward(origin, instanceID, result.oAgentToBeForwarded.UniqueName, result.sNote, jQuery.proxy(function() {
                sap.ca.ui.message.showMessageToast(controller.i18nBundle.getText('dialog.success.forward', result.oAgentToBeForwarded.DisplayName));
            }, controller));
        }
    },

    fixElement: function(controller, id) {
        var that = this,
          view = controller.getView(),
          page = view.getAggregation('content')[0],
          scroller = page._oScroller,
          onScroll = scroller._onScroll;

        // Store onScroll and scroller
        this.fixedElement = {
            scroller: scroller,
            onScroll: onScroll
        };

        // React on scrolling
        scroller._onScroll = function(event) {
            // Call parent
            onScroll.apply(scroller, arguments);

            // Clone fixed element if necessary
            var fixedElement = view.byId(id), fixedElementClone = fixedElement._clone;

            if (fixedElementClone && fixedElementClone.contents().length == 0) {
                fixedElementClone.remove();
                fixedElementClone = null;
            }

            if (!fixedElementClone) {
                var cloneId = fixedElement.$().attr('id') + '_clone';

                fixedElementClone = fixedElement.$().clone();
                fixedElementClone.attr('id', cloneId);
                fixedElementClone.attr('data-sap-ui', cloneId);
                fixedElementClone.css({
                    position : 'absolute',
                    top : 0,
                    zIndex : 17,
                    background : '#FFFFFF'
                });
                scroller._$Container.prepend(fixedElementClone);

                fixedElement._clone = fixedElementClone;
                that.fixedElement.clone = fixedElementClone;

                // Remove all existing IDs
                fixedElement.$().find('[id]').attr('id', '');

                // Hide fixed element if tab changes
                var tabbar = view.byId('tabBar');

                tabbar.attachSelect(function(event) {
                    var selectedItem = event.getParameter('selectedItem'),
                        selectedIndex = tabbar.getItems().indexOf(selectedItem);

                    if (selectedIndex != 0) {
                        fixedElementClone.css('display', 'none');
                    } else {
                        fixedElementClone.css('display', 'block');
                    }
                });
            }

            // Does element need to be fixed?
            var header = $(view.byId('ObjectHeader').$().children()[0]), tabHeader = view.byId('tabBar--header').$(), headerHeight = tabHeader.height()
                    + header.outerHeight(true), scrollY = 0, fixElement = false;

            // Current position
            scrollY = scroller._scrollY;

            // Fix?
            fixElement = headerHeight <= scrollY;

            fixedElementClone.css('top', ((fixElement) ? scrollY : headerHeight) + 'px');
            fixedElementClone.css('padding', ((jQuery.device.is.phone) ? 'inherit' : '0 1rem'));
        };

        page.rerender(true);
    },

    headerLabelWidthFormatter: function() {
        var runningOnTablet = sap.ui.Device.system.tablet,
            runningOnPhone = sap.ui.Device.system.phone;

        if (runningOnPhone) {
            return '8';
        } else if (runningOnTablet) {
            return '5';
        } else {
            return '4';
        }
    }
});
