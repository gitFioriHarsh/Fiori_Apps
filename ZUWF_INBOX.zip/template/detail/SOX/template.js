/*&---------------------------------------------------------------------*
*& Development ID: ZDDE-00019502                                       *
*&                                                                     *
*& Inbox                                                               *
*&                                                                     *
*&---------------------------------------------------------------------*
*& Change Log:                                                         *
*&                                                                     *
*& Init. Who          Date         Text                                *
*& JHU   HUNDEJU1     24-06-2015   Initial version CD 1200006098       *
*& JHU   HUNDEJU1     23-07-2015   Initial version CD 1200006975       *
*&---------------------------------------------------------------------*/

jQuery.sap.declare('com.novartis.uwf.inbox.template.detail.SOX.template');
jQuery.sap.require('com.novartis.uwf.inbox.template.detail.generic');

com.novartis.uwf.inbox.template.detail.generic.extend('com.novartis.uwf.inbox.template.detail.SOX.template', {
	_controller : null,
	doNotFetchDataOnTabSelect: true,
	doNotFetchObjectLinks: true,
	attachmentLabel: null,

	entityVisibilityFormatter: function(entity) {
		if (entity && entity.substr(0, 1) !== 'R') {
			return false;
		}
		
		return true;
	}, 

	labelVisibilityFormatter: function(entity) {
		if (entity && entity.substr(0, 1) === 'R') {
			return false;
		}
		
		return true;
	}, 

	getEntitySetsToExpand: function(item) {
		return [];
	},

	getObjectHeader: function(controller) {
		return sap.ui.xmlfragment('com.novartis.uwf.inbox.template.detail.SOX.ObjectHeader', controller);
	},

	getInfoTab: function(controller) {
		return sap.ui.xmlfragment(controller.getView().getId(), 'com.novartis.uwf.inbox.template.detail.SOX.InfoTabContent', controller);
	},

	afterDataLoaded: function (controller, detailData) {
		var view = controller.getView();
		var detailModel = view.getModel('detail');
		this._controller = controller;

		// Bind attachments
		var attachments = view.getModel('JSONHeader').getProperty('/attachments');
		if (attachments) {
			detailModel.setProperty('/Attachments/results', attachments.map(function(attachment, index) {
				return {
					SAP__Origin: 'LOCAL_GW',
					InstanceID: detailModel.getProperty('/InstanceID'),
					ID: index,
					FileName: attachment,
					CreatedAt: '',
					CreatedBy: '',
					CreatedByName: '',
					mime_type: '',
					FileSize: null,
					FileDisplayName: attachment,
					AttachmentSupports: true,
					__metadata: {
						media_src: ''
					}
				};
			}));
			detailModel.setProperty('/AttachmentsCount', attachments.length);
		}

		// Bind comments
		var comments = view.getModel('JSONHeader').getProperty('/comments');
		if (comments) {
			detailModel.setProperty('/Comments/results', [comments].map(function (comment, index) {
				return {
					SAP__Origin: 'LOCAL_GW',
					InstanceID: detailModel.getProperty('/InstanceID'),
					ID: index,
					Text: comment,
					CreatedBy: '',
					CreatedByName: '',
					CreatedAt: null
				};
			}));
			detailModel.setProperty('/CommentsCount', 1);
		}     
		
		// Add label above attachments
		if (attachments && attachments.length > 0) {
			var uploadCollection = controller.getView().byId('uploadCollection');
			this.attachmentLabel = new sap.m.Text('SOX_ATTACHMENT_LABEL', {
				text: 'Please log on to SOX302 app to view attachments.'
			});
			uploadCollection.getParent().insertContent(this.attachmentLabel, 0);
		}
	},

	configureButtons: function(buttonList, controller) {
		// Remove extra buttons
		buttonList.aButtonList.length = 0;
		
		// Change action of positive button
		buttonList.oPositiveAction.onBtnPressed = function() {
			var oItem = controller.oModel2.getData();
			controller.showConfirmationDialog(controller.oDataManager.FUNCTION_IMPORT_CONFIRM, oItem);
		};
	},

	configureTabs: function(oTabBar) {
		var aItems = oTabBar.getItems();
		
		for (var i = 0; i < aItems.length; i++) {
			var oItem = aItems[i];

			if (oItem.getId().indexOf('DescriptionContent') != -1) {
				oItem.setText('Letter');
			}
			if (oItem.getId().indexOf('MIBAttachmentIconTabFilter') != -1) {
				oItem.setText('Attachments');
			}
			if (oItem.getId().indexOf('MIBNoteIconTabFilter') != -1) {
				oItem.setText('Comments');
			}
		}
	},

	destroy: function() {
		  // Remove label
		  if (this.attachmentLabel) {
			  this.attachmentLabel.destroy();
		  }
		  
		  this._controller = null;
	  }     
});
