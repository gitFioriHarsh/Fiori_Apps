/*&---------------------------------------------------------------------*
 *& Development ID: ZDDE-00019502                                       *
 *&                                                                     *
 *& Inbox                                                               *
 *&                                                                     *
 *&---------------------------------------------------------------------*
 *& Change Log:                                                         *
 *&                                                                     *
 *& Init. Who          Date         Text                                *
 *& VAD   VADTHDE1     25-02-2022   Initial version CD 1200006098       *
 *&---------------------------------------------------------------------*/

jQuery.sap.declare('com.novartis.uwf.inbox.template.detail.ICSI.template');
jQuery.sap.require('com.novartis.uwf.inbox.template.detail.generic');
jQuery.sap.require('sap.ui.core.format.DateFormat');

com.novartis.uwf.inbox.template.detail.generic.extend('com.novartis.uwf.inbox.template.detail.ICSI.template', {
	_controller: null,

	_commentTab: null,

	_logTab: null,

	_validICSTAXErrorMsg: null,

	_validICSError: false,

	_validICSTAXError: false,

	_headerFooterOptions: null,

	_errorElements: [],

	getEntitySetsToExpand: function (item) {
		return ['ZICSHeaderDetails', 'ZICSItems', 'ZICSCommentsDetails', 'ZICSChangeLogDet'];
	},

	getObjectHeader: function (controller) {
		return sap.ui.xmlfragment('com.novartis.uwf.inbox.template.detail.ICSI.ObjectHeader', controller);
	},

	destroy: function () {

		// Remove references
		this._headerFooterOptions = null;
		// Also destroy parent
		com.novartis.uwf.inbox.template.detail.generic.prototype.destroy.apply(this, arguments);
	},

	getInfoTab: function (controller) {
		// Extend controller
		this._controller = jQuery.extend(controller, {
			openRejectCommentDialog: jQuery.proxy(this.openRejectCommentDialog, this),
			onDialogCloseButton: jQuery.proxy(this.onDialogCloseButton, this),
			onDialogCancelButton: jQuery.proxy(this.onDialogCancelButton, this),
			handleResponsivePopoverPress: jQuery.proxy(this.handleResponsivePopoverPress, this),
			dateChange: jQuery.proxy(this.dateChange, this)
		});

		return sap.ui.xmlfragment(
			this._controller.getView().getId(),
			'com.novartis.uwf.inbox.template.detail.ICSI.InfoTabContent',
			this._controller
		);
	},

	beforeDataLoaded: function (controller) {
		var view = this._controller.getView(),
			i18nCustom = view.getModel('i18nCustom');

		//creating comments tab
		this._controller
			.getView()
			.setModel(new sap.ui.model.json.JSONModel({
				commentsLoading: true
			}), 'comments');

		// Already create risks tab
		if (!this._commentTab) {
			this._commentTab = new sap.m.IconTabFilter({
				key: 'COMMENTS',
				icon: 'sap-icon://comment',
				text: i18nCustom.getProperty('ZTAB_ICSI_COMMENTS'),
				content: sap.ui.xmlfragment('com.novartis.uwf.inbox.template.detail.ICSI.CommentTabContent', this._controller)
			});
		}

		// Indicates loading
		view.getModel('comments').setProperty('/commentsLoading', true);
		// end of comments tab code

		// adding LogTab
		this._controller
			.getView()
			.setModel(new sap.ui.model.json.JSONModel({
				logsLoading: true
			}), 'logs');

		if (!this._logTab) {
			this._logTab = new sap.m.IconTabFilter({
				key: 'LOGS',
				icon: 'sap-icon://tags',
				text: i18nCustom.getProperty('ZTAB_ICSI_LOGS'),
				content: sap.ui.xmlfragment('com.novartis.uwf.inbox.template.detail.ICSI.LogTabContent', this._controller)
			});
		}

		// Indicates loading
		view.getModel('logs').setProperty('/logsLoading', true);
		// End of Logs Tab

		//adding Additional Comments
		view.getModel('comments').setProperty('/additionalComments', "");

	},

	configureTabs: function (tabbar) {
		var tabs = tabbar.getItems();
		var alreadyCommentsAdded = false;
		var alreadyLogsAdded = false;

		for (var i = 0; i < tabs.length; i++) {
			if (tabs[i].getProperty('key') === 'OBJECTLINKS' || tabs[i].getProperty('key') === 'NOTES') {
				tabbar.removeItem(tabs[i]);
			}
			if (tabs[i].getProperty('key') === 'COMMENTS') {
				alreadyCommentsAdded = true;
			}
			if (tabs[i].getProperty('key') === 'LOGS') {
				alreadyLogsAdded = true;
			}

		}

		// adding Comments tab
		if (!alreadyCommentsAdded) {
			tabbar.addItem(this._commentTab);
		}

		if (!alreadyLogsAdded) {
			tabbar.addItem(this._logTab);
		}

	},

	configureButtons: function (buttonList, controller) {
		this._headerFooterOptions = controller._oHeaderFooterOptions;
	},

	handleResponsivePopoverPress: function (event) {
		var controller = this._controller,
			items = controller.getView().getModel('detail'),
			index = event.getSource().getParent().getBindingContextPath(),
			description = items.getProperty(index + '/SystemDesc');

		// Create popover with the system description as content
		var popover = new sap.m.Popover({
			showHeader: false
		});
		popover.addStyleClass('sapUiPopupWithPadding');
		popover.addStyleClass('novApvGRCSystemPopover');
		popover.addContent(new sap.m.Text({
			text: description
		}));
		popover.openBy(event.getSource());
	},

	showDecisionDialog: function (approve) {
		var decisionText = approve ? 'XBUT_APPROVE' : 'XBUT_REJECT',
			decision = approve ? 'Approve' : 'Reject',
			decisionTextI18n = this._controller.i18nBundle.getText(decisionText),
			mandatory = approve ? false : true,
			that = this;

		// Only mandatory for rejection
		sap.ca.ui.dialog.confirmation.open({
				question: this._controller.i18nBundle.getText('XMSG_DECISION_QUESTION', decisionTextI18n),
				showNote: true,
				title: this._controller.i18nBundle.getText('XTIT_SUBMIT_DECISION'),
				confirmButtonLabel: this._controller.i18nBundle.getText('XBUT_SUBMIT'),
				noteMandatory: mandatory
			},
			jQuery.proxy(function (result) {
				if (result.isConfirmed) {
					that.sNote = result.sNote;
					// Send action
					this.sendAction();
				}
			}, this)
		);
	},

	sendAction: function (oEvent) {

		// getting item context

		var that = this,
			controller = this._controller,
			view = controller.getView(),
			items = view.getModel("detail").getProperty('/ZICSItems').results,
			context = view.getBindingContext(),
			origin = 'LOCAL_GW',
			model = new sap.ui.model.odata.ODataModel(controller.oDataManager.oPostActionModel.sServiceUrl + origin),
			instanceId = context.getProperty('InstanceID'),

			//   itemsToSend = [],
			decision = oEvent ? "Approve" : "Reject",
			sNote = oEvent ? "P" : this.sNote;
		//this._SourceText = oEvent.getSource().getText();

		view.setBusy(true);

		setTimeout(addTimeOut, 5000, oEvent, that, controller, view, items, context, origin, model, instanceId, decision, sNote);

		function addTimeOut(oEvent, that, controller, view, items, context, origin, model, instanceId, decision, sNote) {
			view.setBusy(false);
			if (oEvent) {
				if (decision === "Approve") {
					// error message for Tax code
					if (controller._validICSTAXError) {
						sap.m.MessageBox.error(controller._validICSTAXErrorMsg);
						return false;
					}
					// error message for TaxCode as mandatory
					if (view.getBindingContext().getProperty("ZValue") === "3") {
						if (that.mandateTaxCode(controller)) {
							sap.m.MessageBox.error("Please fill Tax Code, as it is mandatory.");
							return false;
						}
					}
					if (that.mandatoryValidate(view, that) || controller._validICSError) {
						sap.m.MessageBox.error("Required Data to Approve Process is missing.");
						return true;
					}
				}
			}
			//view.setBusy(false);
			// if approve prepare payload
			// need to add data to payload
			// this.sNote;
			if (oEvent) {
				for (var i = 0; i < items.length; i++) {
					delete items[i]._metadata;
				}
				if (items) {
					sNote = JSON.stringify(items);
				}
			}

			if (sNote === undefined) {
				sNote = "";
			}
			// Prepare request
			var parameters = {
				SAP__Origin: origin,
				InstanceID: instanceId,
				Decision: decision, // Reject or Approve
				Payload: sNote, // payload items
				Comment: view.getModel("comments").getProperty("/additionalComments")
			};

			// Submit asynchronously
			that._controller.oDataManager.fnShowReleaseLoader(true);
			// model.callFunction(
			// 	'ZICSCoiDecision',
			// 	'POST',
			// 	parameters,
			// 	null,
			// 	function (data) {
			// 		that._controller.oDataManager.fnShowReleaseLoader(false);

			// 		// Remove the processed item from the list
			// 		that._controller.oDataManager.processListAfterAction(origin, instanceId);
			// 		that._controller.oDataManager.triggerRefresh('SENDACTION', this.ACTION_SUCCESS);
			// 		that._controller.oDataManager.fireActionPerformed();

			// 		jQuery.sap.delayedCall(500, that._controller, function () {
			// 			sap.ca.ui.message.showMessageToast(that._controller.i18nBundle.getText('dialog.success.complete'));
			// 		});
			// 	},
			// 	function (error) {
			// 		that._controller.oDataManager.fnShowReleaseLoader(false);

			// 		var customError = {
			// 			customMessage: {
			// 				message: jQuery(error.response.body).find('message:first').text(),
			// 				details: error.response.body
			// 			}
			// 		};

			// 		that._controller.oDataManager.oDataRequestFailed(customError, function () {});
			// 		//that._controller.oDataManager.processListAfterAction(origin, instanceId);
			// 	},
			// 	true
			// );

			model.create("/ZICSIDecisionSet", parameters, {
				success: function (data) {
					that._controller.oDataManager.fnShowReleaseLoader(false);

					// Remove the processed item from the list
					that._controller.oDataManager.processListAfterAction(origin, instanceId);
					that._controller.oDataManager.triggerRefresh('SENDACTION', this.ACTION_SUCCESS);
					that._controller.oDataManager.fireActionPerformed();

					jQuery.sap.delayedCall(500, that._controller, function () {
						sap.ca.ui.message.showMessageToast(that._controller.i18nBundle.getText('dialog.success.complete'));
					});
				},
				error: function (error) {
					that._controller.oDataManager.fnShowReleaseLoader(false);

					var customError = {
						customMessage: {
							message: jQuery(error.response.body).find('message:first').text(),
							details: error.response.body
						}
					};

					that._controller.oDataManager.oDataRequestFailed(customError, function () {});

				}
			});

		}
	},

	forward: function (controller, result) {

		if (this._validICSError) {
			//	sap.m.MessageToast.show("Please Provide Relavent Data");
			sap.m.MessageBox.error("Required Data to Approve Process is missing.");
			this._errorElements[0].focus();
			return true;
		}
		// Forward workflow
		if (result && result.bConfirmed) {
			var that = this,
				view = controller.getView(),
				items = view.getModel('detail').getProperty('/ZICSItems').results,
				context = view.getBindingContext(),
				origin = 'LOCAL_GW',
				instanceId = context.getProperty('InstanceID'),
				model = new sap.ui.model.odata.ODataModel(
					controller.oDataManager.oPostActionModel.sServiceUrl + origin
				),
				itemsToSend = [];

			// Prepare request
			var parameters = {
				SAP__Origin: origin,
				InstanceID: instanceId,
				Comment: result.sNote,
				Decision: "Forward",
				Agent: result.oAgentToBeForwarded.UniqueName,
				Payload: JSON.stringify(items)
			};

			// Submit asynchronously
			that._controller.oDataManager.fnShowReleaseLoader(true);
			/*model.callFunction(
				'ZICSCoiForward',
				'POST',
				parameters,
				null,
				function (data) {
					that._controller.oDataManager.fnShowReleaseLoader(false);

					// Remove the processed item from the list
					//  that._controller.oDataManager.oModel.bFullRefreshNeeded = true;
					//that._controller.oDataManager.processListAfterAction(origin, instanceId);

					that._controller.oDataManager.processListAfterAction(origin, instanceId);
					that._controller.oDataManager.triggerRefresh('SENDACTION', this.ACTION_SUCCESS);
					that._controller.oDataManager.fireActionPerformed();

					jQuery.sap.delayedCall(500, that._controller, function () {
						sap.ca.ui.message.showMessageToast(
							controller.i18nBundle.getText(
								'dialog.success.forward',
								result.oAgentToBeForwarded.DisplayName
							)
						);
					});
				},
				function (error) {
					that._controller.oDataManager.fnShowReleaseLoader(false);

					var customError = {
						customMessage: {
							message: jQuery(error.response.body).find('message:first').text(),
							details: error.response.body
						}
					};

					that._controller.oDataManager.oDataRequestFailed(customError, function () {});
					//that._controller.oDataManager.processListAfterAction(origin, instanceId);
				},
				true
			);
			*/
			model.create("/ZICSIDecisionSet", parameters, {
				success: function (data) {
					that._controller.oDataManager.fnShowReleaseLoader(false);

					that._controller.oDataManager.processListAfterAction(origin, instanceId);
					that._controller.oDataManager.triggerRefresh('SENDACTION', this.ACTION_SUCCESS);
					that._controller.oDataManager.fireActionPerformed();

					jQuery.sap.delayedCall(500, that._controller, function () {
						sap.ca.ui.message.showMessageToast(
							controller.i18nBundle.getText(
								'dialog.success.forward',
								result.oAgentToBeForwarded.DisplayName
							)
						);
					});
				},
				error: function (error) {
					that._controller.oDataManager.fnShowReleaseLoader(false);

					var customError = {
						customMessage: {
							message: jQuery(error.response.body).find('message:first').text(),
							details: error.response.body
						}
					};

					that._controller.oDataManager.oDataRequestFailed(customError, function () {});

				}
			});
		}
	},

	openRejectCommentDialog: function (event, rejectCommentDialog) {
		var controller = this._controller;
		//		element = event.getParameter('selectedItem');

		// Deselected?
		//	if (element.getKey() === 'Reject') {
		if (!this.rejectCommentDialog) {
			this.rejectCommentDialog = sap.ui.xmlfragment(
				'com.novartis.uwf.inbox.template.detail.ICSI.RejectCommentDialog',
				controller
			);
			controller.getView().addDependent(this.rejectCommentDialog);

			// Store element on dialog
			//	this.rejectCommentDialog.element = element;

			// Toggle compact style
			jQuery.sap.syncStyleClass('sapUiSizeCompact', controller.getView(), this.rejectCommentDialog);

			// Open dialog
			this.rejectCommentDialog.open();
		}
		// else {
		// 	// Approved again and thus the comment needs to be removed
		// 	var items = controller.getView().getModel('detail'),
		// 		index = element.getParent().getParent().getParent().getParent()
		// 		.getBindingInfo("selectedKey").binding.getContext().getPath(); // CD 1600003335

		// 	items.setProperty(index + '/Comment', '');
		// }
	},

	onDialogCloseButton: function (event) {
		//	var controller = this._controller,
		//	items = controller.getView().getModel('detail'),
		//rejectComment = sap.ui.getCore().byId('rejectDialogComment').getValue();
		this.rejectCommentDialog.close();
		this.sendAction();
	},

	onDialogCancelButton: function (event) {

		this.rejectCommentDialog.destroy();
		this.rejectCommentDialog = null;
	},

	descriptionFormatter: function (value) {
		var formattedText = value === '()' ? '' : value;

		if (value && value.indexOf(';') > 0) {
			// Remove duplicates
			var parts = value.split(';');
			parts = parts.filter(function (item, pos) {
				return parts.indexOf(item) == pos;
			});

			// Return "multiple" text if more than one ; is available
			if (parts.length > 1) {
				formattedText = this.getModel('i18nCustom').getProperty('ZTAB_GRC_DESC_MULTIPLE');
			} else {
				formattedText = parts[0];
			}
		}

		return formattedText;
	},

	dateValidityPeriodFormat: function (dateFrom, dateTo) {
		if (dateFrom == null) {
			dateFrom = '';
		}

		if (dateTo == null) {
			dateTo = '';
		}

		// Return nothing if both dates are initial
		if (!dateFrom && !dateTo) {
			return '';
		}

		return (
			com.novartis.uwf.lib.util.Formatter.dateFormat(dateFrom) +
			'  -  ' +
			com.novartis.uwf.lib.util.Formatter.dateFormat(dateTo)
		);
	},

	getStyleClassForDatePicker: function (value) {
		var styleClass = 'novInfoTabGRCTableGeneric novInfoTabGRCTableDateText';

		if (value) {
			styleClass = 'novInfoTabGRCTableGeneric novInfoTabGRCTableDateInput';
		}

		return styleClass;
	},

	afterDataLoaded: function (controller, detailData) {
		var that = this,
			view = this._controller.getView(),
			model = view.getModel('detail'),
			details = detailData.ZGRCHeaderDetails,
			context = view.getBindingContext(),
			items = model.getProperty('/ZICSItems');

		if (model.getProperty('/ZICSChangeLogDet').results.length === 0) {
			this._controller.oTabBar.removeItem(this._controller.oTabBar.getItems()[3]);
		}

		jQuery.extend(this._headerFooterOptions, {
			oPositiveAction: {
				sI18nBtnTxt: 'XBUT_APPROVE',
				onBtnPressed: $.proxy(this.sendAction, this)
			},
			oNegativeAction: {
				sI18nBtnTxt: 'XBUT_REJECT',
				//		onBtnPressed: $.proxy(this.showDecisionDialog, this, false) openRejectCommentDialog
				onBtnPressed: $.proxy(this.openRejectCommentDialog, this, false)
			}
		});
		// Update footer with buttons
		this._controller.setHeaderFooterOptions(this._headerFooterOptions);
	},
	removeLeadingZeros: function (value) {
		if (value === null) {
			return '';
		}

		if (!value) {
			return '';
		}
		return parseInt(value, 10);
	},

	onChange: function (event) {
		var view = this.getView();
		var oControl = event.getSource();
		oControl.setValue(oControl.getValue().toUpperCase());
		var value = oControl.getValue();
		var oModel = this.getView().getModel();
		var oController = this;

		//SrecvOrder
		var property = event.getSource().getBindingInfo("value").binding.sPath;

		//this.getView().getModel("detail").getProperty(event.getSource().getBindingInfo("value").binding.oContext.sPath+"/SrecvProf

		function dateConversionYYYYMMDD(dateTime) {
			if (dateTime !== undefined && dateTime !== null && dateTime !== "") {
				var dateFormat = sap.ui.core.format.DateFormat.getInstance({
					UTC: true,
					pattern: "MM/dd/yyyy"
				});
				var originalDate = dateFormat.format(new Date(dateTime));
				return originalDate;
			}
			return null;
		}
		var CompanyCode = '';
		if (view.getBindingContext().getProperty("ZValue") === "2") {
			CompanyCode = view.getModel("detail").getProperty("/ZICSHeaderDetails").SprovCompanyCode;
		} else {
			CompanyCode = view.getModel("detail").getProperty("/ZICSHeaderDetails").SrecvCompanyCode;
		}

		var oParent = event.getSource().getParent();
		var iIndex = oParent.getCells().indexOf(event.getSource());
		if ((oControl.getBindingInfo("value").binding.sPath === 'SprovCostCetner' ||
				oControl.getBindingInfo("value").binding.sPath === 'SrecvCostCetner') &&
			value === "") {
			var oServiceOrder = oParent.getCells()[iIndex - 1];
			if (oServiceOrder.getValue() !== "" && oServiceOrder.getEditable() == true && oServiceOrder.getValueState() == 'None') {
				oServiceOrder.fireChange();
				return;
			}

		}
		// var oObject =event.getSource().getBinding("value").getModel().getProperty(event.getSource().getBinding("value").getContext().getPath());
		// var zValue = event.getSource().getBindingContext().getObject().ZValue;
		// var sOrder =  zValue === '1'?oObject.SrecvOrder:( zValue === '2'?oObject.SprovOrder:"");
		var parameters = {
			InstanceID: view.getBindingContext().getProperty("InstanceID"),
			CompanyCode: CompanyCode,
			CostCenter: (property === 'SrecvCostCetner' || property === 'SprovCostCetner') ? value : '',
			EndDate: dateConversionYYYYMMDD(view.getModel("detail").getProperty("/ZICSHeaderDetails").ContractEndDate),
			Order: (property === 'SrecvOrder' || property === 'SprovOrder') ? value : '',
			ProfitCenter: (property === 'SrecvProfitCenter' || property === 'SprovProfitCenter') ? value : '',
			StartDate: dateConversionYYYYMMDD(view.getModel("detail").getProperty("/ZICSHeaderDetails").ContractStartDate),
			WbsElement: (property === 'SprovWbsElement' || property === 'SrecvWbsElement') ? value : ''

		};

		oModel.callFunction("/ZICSValidation", {
			method: "GET",
			urlParameters: parameters,
			success: function (data, response) {
				if (data.ZICSValidation.Type === "E") {
					oControl.setValueStateText(data.ZICSValidation.Message);
					oControl.setValueState(sap.ui.core.ValueState.Error);
					oController._validICSError = true;
				} else {
					oControl.setValueStateText(" ");
					oControl.setValueState(sap.ui.core.ValueState.None);
					oController._validICSError = false;
					// setting value to item model
					//oControl.getBindingInfo("value").binding.sPath
					oControl.getModel("detail").setProperty(oControl.getBindingContext("detail").getPath() + "/" + oControl.getBindingInfo("value").binding
						.sPath, oControl.getValue());
					//	oControl.getBindingContext("detail").setProperty("/ZICSItems/res"+oControl.getBindingInfo("value").binding.sPath, oControl.getValue());
					// Keep other controls non-editable
					var siblingCells = oControl.getParent().getCells();
					for (var i = 0; i < siblingCells.length; i++) {
						if (siblingCells[i].getMetadata().getName() === "sap.m.Input") {
							if (oControl.getBindingContext("detail").getProperty("SrecvGlAccountType") === "PL" && (view.getBindingContext().getProperty(
									"ZValue") === "1" || view.getBindingContext().getProperty("ZValue") === "3")) {
								//If PL
								if (oControl.getBindingInfo("value").binding.sPath !== siblingCells[i].getBindingInfo("value").binding.sPath) {
									if (siblingCells[i].getBindingInfo("value").binding.sPath === 'SrecvOrder' ||
										siblingCells[i].getBindingInfo("value").binding.sPath === 'SrecvCostCetner' ||
										siblingCells[i].getBindingInfo("value").binding.sPath === 'SrecvWbsElement' ||
										siblingCells[i].getBindingInfo("value").binding.sPath === 'SprovOrder' ||
										siblingCells[i].getBindingInfo("value").binding.sPath === 'SprovCostCetner' ||
										siblingCells[i].getBindingInfo("value").binding.sPath === 'SprovWbsElement') {

										if (data.ZICSValidation.Parameter == "ENABLE" &&
											(siblingCells[i].getBindingInfo("value").binding.sPath === 'SrecvCostCetner' ||
												siblingCells[i].getBindingInfo("value").binding.sPath === 'SprovCostCetner' ||
												siblingCells[i].getBindingInfo("value").binding.sPath === 'SprovOrder' ||
												siblingCells[i].getBindingInfo("value").binding.sPath === 'SrecvOrder')) {
											siblingCells[i].setEditable(true);
											if (siblingCells[i].getValue() == "" &&
												(siblingCells[i].getBindingInfo("value").binding.sPath === 'SrecvCostCetner' ||
													siblingCells[i].getBindingInfo("value").binding.sPath === 'SprovCostCetner')) {
												siblingCells[i].setValueState(sap.ui.core.ValueState.Error);
												siblingCells[i].setValueStateText("Cost Center is mandatory ");
												oController._validICSError = true;
											} else {
												siblingCells[i].setValueState(sap.ui.core.ValueState.None);
												oController._validICSError = false;
											}
										} else {
											if ((siblingCells[i].getBindingInfo("value").binding.sPath === 'SprovOrder' ||
													siblingCells[i].getBindingInfo("value").binding.sPath === 'SrecvOrder') &&
												siblingCells[i].getValue() !== "" && siblingCells[i].getValueState() === 'None') {
												siblingCells[i].setEditable(true);
											} else {
												siblingCells[i].setEditable(false);
												siblingCells[i].setValue("");
												siblingCells[i].setValueStateText(" ");
												siblingCells[i].setValueState(sap.ui.core.ValueState.None);
											}
										}

									}
								}
								// MAKING PROFIT CENTER empty on PL GL Account
								if (siblingCells[i].getBindingInfo("value").binding.sPath === 'SrecvProfitCenter') {
									siblingCells[i].setValue("");
									siblingCells[i].setValueStateText(" ");
									siblingCells[i].setValueState(sap.ui.core.ValueState.None);

									//get current object
								}
							} else if ((view.getBindingContext().getProperty("ZValue") === "1" || view.getBindingContext().getProperty("ZValue") === "3") &&
								oControl.getBindingContext("detail").getProperty("SrecvGlAccountType") === "BS") { // Account is BL
								if (siblingCells[i].getBindingInfo("value").binding.sPath === 'SrecvOrder' ||
									siblingCells[i].getBindingInfo("value").binding.sPath === 'SrecvCostCetner' ||
									siblingCells[i].getBindingInfo("value").binding.sPath === 'SrecvWbsElement' ||
									siblingCells[i].getBindingInfo("value").binding.sPath === 'SprovOrder' ||
									siblingCells[i].getBindingInfo("value").binding.sPath === 'SprovCostCetner' ||
									siblingCells[i].getBindingInfo("value").binding.sPath === 'SprovWbsElement') {
									siblingCells[i].setValue("");
									siblingCells[i].setValueStateText(" ");
									siblingCells[i].setValueState(sap.ui.core.ValueState.None);

								}
							} else if (oControl.getBindingContext("detail").getProperty("GlAccountType") === "PL" && view.getBindingContext().getProperty(
									"ZValue") === "2") {
								if (oControl.getBindingInfo("value").binding.sPath !== siblingCells[i].getBindingInfo("value").binding.sPath) {
									if (siblingCells[i].getBindingInfo("value").binding.sPath === 'SrecvOrder' ||
										siblingCells[i].getBindingInfo("value").binding.sPath === 'SrecvCostCetner' ||
										siblingCells[i].getBindingInfo("value").binding.sPath === 'SrecvWbsElement' ||
										siblingCells[i].getBindingInfo("value").binding.sPath === 'SprovOrder' ||
										siblingCells[i].getBindingInfo("value").binding.sPath === 'SprovCostCetner' ||
										siblingCells[i].getBindingInfo("value").binding.sPath === 'SprovWbsElement') {
										siblingCells[i].setEditable(false);
										siblingCells[i].setValue("");
										siblingCells[i].setValueStateText(" ");
										siblingCells[i].setValueState(sap.ui.core.ValueState.None);

									}
								}
								// MAKING PROFIT CENTER empty on PL GL Account
								if (siblingCells[i].getBindingInfo("value").binding.sPath === 'SrecvProfitCenter') {
									siblingCells[i].setValue("");

									//get current object
								}
							} else { // Account is BL
								if (siblingCells[i].getBindingInfo("value").binding.sPath === 'SrecvOrder' ||
									siblingCells[i].getBindingInfo("value").binding.sPath === 'SrecvCostCetner' ||
									siblingCells[i].getBindingInfo("value").binding.sPath === 'SrecvWbsElement' ||
									siblingCells[i].getBindingInfo("value").binding.sPath === 'SprovOrder' ||
									siblingCells[i].getBindingInfo("value").binding.sPath === 'SprovCostCetner' ||
									siblingCells[i].getBindingInfo("value").binding.sPath === 'SprovWbsElement') {
									siblingCells[i].setValue("");
								}
							}
						}
					}
				}
			},
			error: function (oError) {}
		});

	},
	debitCreditFormatter: function (itemCat) {
		switch (itemCat) {
		case "Z8M1":
		case "Z8M2":
		case "Z8M3":
		case "Z8M4":
			return "Invoice";
		case "Z8M6":
			return "Credit Memo";
		case "Z8M8":
			return "Debit";
		case "Z8M9":
			return "Credit";
		}
		return '';
	},

	mandatoryValidate: function (views, controller) {
		// if z =1 || z= 3

		var topFlag = false;
		var items = null;
		var view = views;
		var oController = controller;

		function addMandate(cellss, value) {
			var cells = cellss.getCells();
			for (var k = 0; k < cells.length; k++) {
				if ((cells[k].getMetadata().getName() === "sap.m.Input") && (cells[k].getEditable() === true)) {

					if (cells[k].getBindingInfo("value").binding.sPath === 'SrecvProfitCenter' ||
						cells[k].getBindingInfo("value").binding.sPath === 'SrecvOrder' ||
						cells[k].getBindingInfo("value").binding.sPath === 'SrecvCostCetner' ||
						cells[k].getBindingInfo("value").binding.sPath === 'SrecvWbsElement' ||
						cells[k].getBindingInfo("value").binding.sPath === 'SprovProfitCenter' ||
						cells[k].getBindingInfo("value").binding.sPath === 'SprovOrder' ||
						cells[k].getBindingInfo("value").binding.sPath === 'SprovCostCetner' ||
						cells[k].getBindingInfo("value").binding.sPath === 'SprovWbsElement'
					) {
						if (((cells[k].getBindingContext("detail").getProperty("SrecvGlAccountType") === "PL") && (value === "1" || value === "3")) || (
								cells[k].getBindingContext("detail").getProperty("GlAccountType") === "PL" && value === "2")) {
							cells[k].setValueState(sap.ui.core.ValueState.Error);
							cells[k].setValueStateText("One of Order,Cost Center, WBS is required");
							oController._errorElements.push(cells[k]);
						} else {
							cells[k].setValueState(sap.ui.core.ValueState.Error);
							cells[k].setValueStateText("Profit Center is required");

						}
					}

				}
			}
		}

		function tableCheck(itemSet, value) {
			topFlag = false;
			var itemFlag = false;
			for (var i = 0; i < itemSet.length; i++) {
				//item level
				var cells = itemSet[i].getCells();
				for (var j = 0; j < cells.length; j++) {
					if (cells[j].getMetadata().getName() === "sap.m.Input" && cells[j].getEditable() === true) {
						// logic for TaxCode validation

						if (cells[j].getBindingInfo("value").binding.sPath === 'SrecvProfitCenter' ||
							cells[j].getBindingInfo("value").binding.sPath === 'SrecvOrder' ||
							cells[j].getBindingInfo("value").binding.sPath === 'SrecvCostCetner' ||
							cells[j].getBindingInfo("value").binding.sPath === 'SrecvWbsElement' ||
							cells[j].getBindingInfo("value").binding.sPath === 'SprovProfitCenter' ||
							cells[j].getBindingInfo("value").binding.sPath === 'SprovOrder' ||
							cells[j].getBindingInfo("value").binding.sPath === 'SprovCostCetner' ||
							cells[j].getBindingInfo("value").binding.sPath === 'SprovWbsElement'
						) {
							if (cells[j].getValue().length > 0) {
								itemFlag = false;
								break;
							} else {
								itemFlag = true;

							}
						}
					}
					// Validation for 

				}
				if (itemFlag) {
					topFlag = true;
					// item should be notificed as mandatatory
					addMandate(itemSet[i], value);
				}
			}

			return topFlag;
		}

		if (view.getBindingContext().getProperty("ZValue") === "1") {
			items = view.byId("idtable1").getItems();
			return tableCheck(items, "1");

		} else if (view.getBindingContext().getProperty("ZValue") === "2") {
			items = view.byId("idtable2").getItems();
			return tableCheck(items, "2");

		} else {
			items = view.byId("idtable3").getItems();
			return tableCheck(items, "3");

		}

	},
	approvalLevelFormat: function (zvalue) {
		if (!zvalue) {
			return "";
		}
		if (zvalue === null) {
			return "";
		}
		if (zvalue === "1") {
			return "Approver Level : SRECV ID Approval";
		} else if (zvalue === "2") {
			return "Approver Level : SPROV FRA ID Approval";
		} else if (zvalue === "3") {
			return "Approver Level : SRECV FRA ID Approval";
		}
		return "";
	},
	commentUser: function (userID, level) {
		if (!userID || !level) {
			return "";
		}
		if (userID === null || level === null) {
			return "";
		}

		if (level === "01") {
			return userID + ": (SRECV ID Approval)";
		} else if (level === "02") {
			return userID + ": (SPROV FRA ID Approval)";
		} else if (level === "03") {
			return userID + ": (SRECV FRA ID Approval)";
		}
		return "";

	},
	commentDate: function (d, t) {

		if (d === null) {
			d = '';
		}

		if (t === null) {
			t = '';
		}

		// Return nothing if both dates are initial
		if (!d && !t) {
			return '';
		}

		// Parse if necessary
		if (typeof d == 'string') {
			d = new Date(d);
		}
		// millisecond to Time
		function msToTime(s) {
			var ms = s % 1000;
			s = (s - ms) / 1000;
			var secs = s % 60;
			s = (s - secs) / 60;
			var mins = s % 60;
			var hrs = (s - mins) / 60;

			return hrs + ':' + mins + ':' + secs;
		}

		return (
			com.novartis.uwf.lib.util.Formatter.dateFormat(d) +
			' - ' +
			msToTime(t.ms)
		);

	},
	onItemMore: function (oEvent) {
		oEvent.preventDefault();
		if (oEvent.getSource().getText() === "more") {
			oEvent.getSource().getParent().getItems()[0].setMaxLines(0);
			oEvent.getSource().setText("less");
		} else if (oEvent.getSource().getText() === "less") {
			oEvent.getSource().getParent().getItems()[0].setMaxLines(1);
			oEvent.getSource().setText("more");
		}
	},
	netAmountConversion: function (amount, decformat) {
		if (amount === null || amount === undefined || amount === "") {
			return "";
		}
		if (decformat === null || decformat === undefined || decformat === "") {
			return "";
		}
		if (amount.length > 0) {
			var value = parseFloat(amount);

			var oFromattre = sap.ui.core.format.NumberFormat.getCurrencyInstance({
				showMeasure: false,
				groupingSeparator: decformat.charAt(1),
				decimalSeparator: decformat.charAt(9),
				maxFractionDigits: 2
			});
			return oFromattre.format(value);
		}
		return "";
	},
	bsValidation: function (profitCenter) {
		if (profitCenter === null || profitCenter === undefined) {
			return "";
		}
		if (!this.getEditable()) {
			return "";
		} else {
			return profitCenter;
		}
		//{= ${detail>SrecvGlAccountType} === 'BS' ? ${detail>SrecvProfitCenter'} : ' '}
		//		if
	},
	onChangeTaxCodeValidate: function (oEvent) {
		var oControl = oEvent.getSource();
		var view = this.getView();
		var oController = this;
		var parameters = {
			InstanceID: view.getBindingContext().getProperty("InstanceID"),
			CompanyCode: view.getModel("detail").getProperty("/ZICSHeaderDetails").SrecvCompanyCode,
			TaxCode: oEvent.getSource().getValue(),
			CountryCode: view.getModel("detail").getProperty("/ZICSHeaderDetails").SrecvCountry
		};

		this.getView().getModel().callFunction("/ZICSTaxCodeValidation", {
			method: "GET",
			urlParameters: parameters,
			success: function (data, response) {

				if (data.ZICSTaxCodeValidation.Type === "E") {
					oControl.setValueStateText(data.ZICSTaxCodeValidation.Message);
					oControl.setValueState(sap.ui.core.ValueState.Error);
					oController._validICSTAXError = true;
					oController._validICSTAXErrorMsg = data.ZICSTaxCodeValidation.Message;
				} else {
					oControl.setValueStateText(" ");
					oControl.setValueState(sap.ui.core.ValueState.None);
					oController._validICSTAXError = false;
					oController._validICSTAXErrorMsg = '';
				}

				//

			},
			error: function (oError) {
				sap.m.MessageBox.error("Error Occcured, Please Contact Technical Team for Support");
			}
		});

	},
	mandateTaxCode: function (controller) {
			//		if(this._validICSTAXError){
			var bTaxCodeisBlank = false;
			var aItems = controller.getView().byId("idtable3").getItems();
			// Row level
			for (var i = 0; i < aItems.length; i++) {
				var aCells = aItems[i].getCells();
				for (var k = 0; k < aCells.length; k++) {
					if (aCells[k].getMetadata().getName() === "sap.m.Input")
						if (aCells[k].getBindingInfo("value").binding.sPath === 'SrecvTaxCode') {
							if (aCells[k].getValue().trim().length === 0) {
								aCells[k].setValueState(sap.ui.core.ValueState.Error);
								aCells[k].setValueStateText("Tax Code is required");
								bTaxCodeisBlank = true;
							} else {
								aCells[k].setValueState(sap.ui.core.ValueState.None);
								aCells[k].setValueStateText("");

							}

						}
				}
			} // End of for loop i
			return bTaxCodeisBlank;
		} // End of mandateTaxCode 

});