/*&- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
 *& Development ID: ZDDE-00019502                                       *
 *&                                                                     *
 *& Inbox                                                               *
 *&                                                                     *
 *&- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*
 *& Change Log:                                                         *
 *&                                                                     *
 *& Init. Who          Date         Text                                *
 *& LTS   TORRALU1     28-10-2015   Initial version CD 1200009167       *
 *& LTS   TORRALU1     15-12-2015   Changed Link tab links              *
 *& LTS   REDDYGA2     26-08-2024   CR 1500025173 / CD 1600015485       *
 *&									Add sign comments in approver tab   *
 *&- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

jQuery.sap.declare('com.novartis.uwf.inbox.template.detail.NOVASOL.template');
jQuery.sap.require('com.novartis.uwf.inbox.template.detail.generic');

com.novartis.uwf.inbox.template.detail.generic.extend('com.novartis.uwf.inbox.template.detail.NOVASOL.template', {
	_controller: null,

	headerLabelVisibilityFormatter: function (field) {
		return typeof field == 'string' && field.length > 0;
	},

	linkTableStatusFormatter: function (sStatus) {
		var oI18nModel = this.getModel('i18nCustom');
		if (oI18nModel) {
			var oResourceBundle = oI18nModel.getResourceBundle();
			if (oResourceBundle) {
				return oResourceBundle.getText("ZTAB_NOVASOL_LINKS_TBL_STATUS_" + sStatus);
			}
		}
		return "";
	},

	getEntitySetsToExpand: function (item) {
		return ['ZNSLHeaderDetails', 'ZNSLApprovers', 'ZNSLRisks', 'ZNSLLinks'];
	},

	getObjectHeader: function (controller) {
		return sap.ui.xmlfragment('com.novartis.uwf.inbox.template.detail.NOVASOL.ObjectHeader', controller);
	},

	getInfoTab: function (controller) {
		// Extend controller
		this._controller = jQuery.extend(controller, {
			onApprovePress: jQuery.proxy(this.onApprovePress, this),
			onRejectPress: jQuery.proxy(this.onRejectPress, this),
			onCancelSubmit: jQuery.proxy(this.onCancelSubmit, this),
			onActionPress: jQuery.proxy(this.onActionPress, this),
			onSubmitDecision: jQuery.proxy(this.onSubmitDecision, this),
			onDocumentLinkPress: jQuery.proxy(this.onDocumentLinkPress, this),
			onLinkPress: jQuery.proxy(this.onLinkPress, this),
			onShowComment: jQuery.proxy(this.onShowComment, this)
		});

		return sap.ui.xmlfragment(controller.getView().getId(), 'com.novartis.uwf.inbox.template.detail.NOVASOL.InfoTabContent', controller);
	},

	destroy: function () {
		/* Destroy approvers tab */
		if (this._oApproveTab) {
			this._oApproveTab.destroy();
		}
		/* Destroy risks tab */
		if (this._oRiskTab) {
			this._oRiskTab.destroy();
		}
		/* Destroy links tab */
		if (this._oLinkTab) {
			this._oLinkTab.destroy();
		}

		/* Show standard TaskObjects*/
		//  this._oStandardNoteTab.setVisible(true);
		//  this._oStandardAttachmentTab.setVisible(true);
		//    this._oStandardChainTab.setVisible(true);

		if (this._oStandardNoteTab) {
			this._oStandardNoteTab.setVisible(true);
		}
		if (this._oStandardAttachmentTab) {
			this._oStandardAttachmentTab.setVisible(true);
		}

		/* Destroy dialog */
		if (this._submitDialog) {
			this._submitDialog.destroy(true);
			this._submitDialog = null;
		}

		/* Remove references */
		this._headerFooterOptions = null;

		/* Also destroy parent */
		com.novartis.uwf.inbox.template.detail.generic.prototype.destroy.apply(this, arguments);
	},

	configureButtons: function (buttonList, controller) {
		this._headerFooterOptions = controller._oHeaderFooterOptions;
	},

	configureTabs: function (oTabBar) {
		var aItems = oTabBar.getItems(),
			bApproveAdded = false,
			bRiskAdded = false,
			bLinkAdded = false;

		/* Check if extra tabs already exist */
		for (var i = 0; i < aItems.length; i++) {

			if (aItems[i].getProperty('key') === 'approve') {
				bApproveAdded = true;
			}
			if (aItems[i].getProperty('key') === 'risks') {
				bRiskAdded = true;
			}
			if (aItems[i].getProperty('key') === 'doclinks') {
				bLinkAdded = true;
			}
			/* hide standard tabs*/
			if (aItems[i].getId().indexOf('MIBNoteIconTabFilter') != -1) {
				this._oStandardNoteTab = aItems[i];
				aItems[i].setVisible(false);
			} else if (aItems[i].getId().indexOf('MIBProcessingLogsTabFilter') != -1) {
				this._oStandardChainTab = aItems[i];
				aItems[i].setVisible(false);
			}
		}

		/* Add risk tab if necessary */
		if (!bRiskAdded) {
			oTabBar.addItem(this._oRiskTab);
		}
		/* Add risk tab if necessary */
		if (!bLinkAdded) {
			oTabBar.addItem(this._oLinkTab);
		}
		/* Add approve tab if necessary */
		if (!bApproveAdded) {
			oTabBar.addItem(this._oApproveTab);
		}

	},

	beforeDataLoaded: function (controller, detailData) {
		//Change link button look
		var i18nCustom = this._controller.getView().getModel('i18nCustom');

		//create local model
		this._controller.getView().setModel(new sap.ui.model.json.JSONModel(), "novasolModel");

		/* create Approve tab */
		if (!this._oApproveTab) {
			this._oApproveTab = new sap.m.IconTabFilter({
				key: 'approve',
				icon: 'sap-icon://work-history',
				text: i18nCustom.getProperty('ZTAB_NOVASOL_APPROVERS_TAB_TITLE'),
				content: sap.ui.xmlfragment('com.novartis.uwf.inbox.template.detail.NOVASOL.Approvers', this._controller)
			});
		}
		/* create Risk tab */
		if (!this._oRiskTab) {
			this._oRiskTab = new sap.m.IconTabFilter({
				key: 'risks',
				icon: 'sap-icon://alert',
				text: i18nCustom.getProperty('ZTAB_GRC_RISKS'),
				content: sap.ui.xmlfragment('com.novartis.uwf.inbox.template.detail.NOVASOL.Risks', this._controller)
			});
		}

		/* create Link tab */
		if (!this._oLinkTab) {
			this._oLinkTab = new sap.m.IconTabFilter({
				key: 'doclinks',
				icon: 'sap-icon://chain-link',
				text: i18nCustom.getProperty('ZTAB_NOVASOL_LINKS'),
				content: sap.ui.xmlfragment('com.novartis.uwf.inbox.template.detail.NOVASOL.Links', this._controller)
			});
		}
	},

	afterDataLoaded: function (controller, detailData) {
		/* Set Approvers tab count */
		if (detailData.ZNSLApprovers && detailData.ZNSLApprovers.results) {
			if (detailData.ZNSLApprovers.results.length > 0) {
				this._oApproveTab.setCount(detailData.ZNSLApprovers.results.length);
				this.setUserRole(detailData.ZNSLApprovers.results);
			} else {
				this._oApproveTab.setCount("");
			}
		}

		/* Set Risks tab count */
		if (detailData.ZNSLRisks && detailData.ZNSLRisks.results) {
			if (detailData.ZNSLRisks.results.length > 0) {
				this._oRiskTab.setCount(detailData.ZNSLRisks.results.length);
			} else {
				this._oRiskTab.setCount("");
			}
		}

		/* Set Links tab count */
		if (detailData.ZNSLLinks && detailData.ZNSLLinks.results) {
			if (detailData.ZNSLLinks.results.length > 0) {
				this._oLinkTab.setCount(detailData.ZNSLLinks.results.length);
			} else {
				this._oLinkTab.setCount("");
			}
		}

		/* Load footer buttons */
		jQuery.extend(this._headerFooterOptions, {
			oPositiveAction: {
				sI18nBtnTxt: 'XBUT_APPROVE',
				onBtnPressed: jQuery.proxy(this.onApprovePress, this)
			},
			oNegativeAction: {
				sI18nBtnTxt: 'XBUT_REJECT',
				onBtnPressed: jQuery.proxy(this.onRejectPress, this)
			},
			buttonList: {
				oEmailSettings: null,
				oJamOptions: null,
				bSuppressBookmarkButton: true
			}
		});

		/* Update footer with buttons */
		this._controller.setHeaderFooterOptions(this._headerFooterOptions);
	},

	setUserRole: function (aApprovers) {
		var oLocalModel = this._controller.getView().getModel('novasolModel');
		var sUserId = this._controller.getView().getBindingContext().getProperty('ZApprover1');

		for (var i = 0; i < aApprovers.length; i++) {
			if (aApprovers[i].Approver === sUserId) {
				oLocalModel.setProperty('/userRole', aApprovers[i].Apprrole);
				return;
			}
		}
	},

	onLinkPress: function (oEvent) {
		var oContext = oEvent.getSource().getBindingContext("detail");
		var oModel = oContext.getModel();
		var instanceId = oModel.getProperty('/InstanceID');
		var aAttachments = oModel.getProperty("/ZNSLLinks/results");
		// var aAttachments = oContext.getProperty("Attachments").map(function (path) { return oContext.getProperty('/' + path); });
		var sLinkPath = oContext.getPath();
		var aSplitPath = sLinkPath.split("/");

		if (aAttachments instanceof Array && aAttachments.length > 0 && aSplitPath.length > 0) {
			var iLinkPos = aSplitPath[aSplitPath.length - 1];
			var oLinkedDocument = aAttachments[iLinkPos];

			window.open("/sap/opu/odata/sap/ZUWF_TASKPROCESSING_V2_SRV;mo;v=2/AttachmentCollection(SAP__Origin='LOCAL_GW',InstanceID='" +
				instanceId + "',ID='" + oLinkedDocument.Dockey + "')/$value", "_blank");
		}
	},

	onDocumentLinkPress: function (oEvent) {
		var oContext = oEvent.getSource().getBindingContext();
		//	 var aAttachments = oContext.getProperty("Attachments/results");
		var aAttachments = oContext.getProperty("Attachments").map(function (path) {
			return oContext.getProperty('/' + path);
		});

		if (aAttachments instanceof Array && aAttachments.length > 0) {
			var oDocument = aAttachments[aAttachments.length - 1];

			if (oDocument.__metadata && oDocument.__metadata.uri && oDocument.__metadata.uri.length > 0) {
				window.open(oDocument.__metadata.uri + "/$value", "_blank");
			}
		}
	},

	onApprovePress: function (oEvent) {
		var oController = this._controller,
			oLocalModel = oController.getView().getModel("novasolModel"),
			oI18nModel = oController.getView().getModel("i18n"),
			oResourceBundle, sAction;

		if (oI18nModel) {
			oResourceBundle = oI18nModel.getResourceBundle();
			if (oResourceBundle) {
				sAction = oResourceBundle.getText("XBUT_APPROVE");
			}
		}

		if (typeof sAction == "string" && sAction.length > 0) {
			oLocalModel.setProperty("/submitTitle", sAction);
			oLocalModel.setProperty("/submitAction", "APPROVED");
			this.onActionPress();
		} else {
			oLocalModel.setProperty("/submitTitle", "");
			oLocalModel.setProperty("/submitAction", "");
		}
	},

	onRejectPress: function (oEvent) {
		var oController = this._controller,
			oLocalModel = oController.getView().getModel("novasolModel"),
			oI18nModel = oController.getView().getModel("i18n"),
			oResourceBundle, sAction;

		if (oI18nModel) {
			oResourceBundle = oI18nModel.getResourceBundle();
			if (oResourceBundle) {
				sAction = oResourceBundle.getText("XBUT_REJECT");
			}
		}

		if (typeof sAction == "string" && sAction.length > 0) {
			oLocalModel.setProperty("/submitTitle", sAction);
			oLocalModel.setProperty("/submitAction", "REJECTED");
			this.onActionPress();
		} else {
			oLocalModel.setProperty("/submitTitle", "");
			oLocalModel.setProperty("/submitAction", "");
		}
	},

	onActionPress: function () {
		var oController = this._controller;

		if (!this._submitDialog) {
			this._submitDialog = sap.ui.xmlfragment('com.novartis.uwf.inbox.template.detail.NOVASOL.SubmitDialog', oController);
			oController.getView().addDependent(this._submitDialog);
		}

		this._submitDialog.open();
	},

	onCancelSubmit: function (oEvent) {
		var oLocalModel = this._controller.getView().getModel('novasolModel');

		oLocalModel.setProperty("/passwordState", "None");
		oLocalModel.setProperty("/password", "");
		oLocalModel.setProperty("/commentState", "None");

		this._submitDialog.close();
	},

	onSubmitDecision: function () {
		var that = this,
			oController = this._controller,
			oContext = oController.getView().getBindingContext(),
			oLocalModel = oController.getView().getModel('novasolModel'),
			sOrigin = oContext.getProperty('SAP__Origin'),
			sInstanceId = oContext.getProperty('InstanceID'),
			// sWId = oContext.getProperty('ZObjectID'),
			// sDocKey = oContext.getProperty('ZKey'),
			// sUser = oContext.getProperty('ZApprover1'),
			sPassword = oLocalModel.getProperty('/password'), //"PASSWORD",
			sComment = oLocalModel.getProperty('/comment'),
			sDecision = oLocalModel.getProperty('/submitAction'); //"Test Comment",

		var iDummyPos = sInstanceId.indexOf("-DUMMY");

		if (iDummyPos != -1) {
			sInstanceId = sInstanceId.substring(0, iDummyPos);
		}

		if (!sPassword) {
			oLocalModel.setProperty("/passwordState", "Error");
			oLocalModel.setProperty("/password", "");
			return;
		} else if (!sComment) {
			oLocalModel.setProperty("/commentState", "Error");
			return;
		} else {
			oLocalModel.setProperty("/passwordState", "None");
			oLocalModel.setProperty("/password", "");
			oLocalModel.setProperty("/commentState", "None");
		}

		// Prepare request
		var oParameters = {
			SAP__Origin: sOrigin,
			InstanceID: sInstanceId,
			Password: sPassword,
			Comment: jQuery.sap.encodeURL(sComment),
			Decision: sDecision
		};

		this.oDataModel = new sap.ui.model.odata.ODataModel(oController.oDataManager.oPostActionModel.sServiceUrl + sOrigin);

		// Submit asynchronously
		this.oDataModel.callFunction('ZNSLItemDecision', 'POST', oParameters, null, function (oData) {
			// Remove the processed item from the list
			that._controller.oDataManager.processListAfterAction(sOrigin, sInstanceId);
			that._controller.oDataManager.triggerRefresh("SENDACTION", this.ACTION_SUCCESS);
			that._controller.oDataManager.fireActionPerformed();

			//that._controller.oDataManager.oModel.bFullRefreshNeeded = true;
			//that._controller.oDataManager.processListAfterAction(sOrigin, sInstanceId);

			that._submitDialog.close();
		}, function (oError) {
			oLocalModel.setProperty("/passwordState", "None");
			oLocalModel.setProperty("/password", "");
			oLocalModel.setProperty("/commentState", "None");
			that._submitDialog.close();

			var oCustomError = {
				customMessage: {
					message: jQuery(oError.response.body).find('message:first').text(),
					details: oError.response.body
				}
			};

			that._controller.oDataManager.oDataRequestFailed(oCustomError, function () {});
		}, true);
	},
	onShowComment: function (oSrc) {
		if (!this.oSignCommentDialog) {
			this.oSignCommentDialog = new sap.m.Dialog({
				title: "Signature Comments",
				beginButton: new sap.m.Button({
					text: "OK",
					press: function () {
						this.oSignCommentDialog.destroyContent();
						this.oSignCommentDialog.close();
					}.bind(this)
				})
			});
		}

		var sPath = oSrc.getSource().getBindingContext("detail").getPath().split("/")[3];
		var oApproversTable = oSrc.getSource().getParent().getParent().getModel("detail").getData().ZNSLApprovers.results;
		var oContent = new sap.m.Text({
			text: oApproversTable[sPath].Comment
		});
		//this.oSignCommentDialog.removeContent();
		this.oSignCommentDialog.addContent(oContent);
		this.oSignCommentDialog.open();

	}
});