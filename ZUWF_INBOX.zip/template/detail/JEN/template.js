jQuery.sap.declare('com.novartis.uwf.inbox.template.detail.JEN.template');
jQuery.sap.require('com.novartis.uwf.inbox.template.detail.generic');

com.novartis.uwf.inbox.template.detail.generic.extend('com.novartis.uwf.inbox.template.detail.JEN.template', {
	doNotFetchDataOnTabSelect: true,
	doNotFetchObjectLinks: true,

	getEntitySetsToExpand: function(item) {
		return [
			'ZXXXDetails'
		];
	},

	getObjectHeader: function(controller) {
		return sap.ui.xmlfragment('com.novartis.uwf.inbox.template.detail.JEN.ObjectHeader', controller);
	},

	getInfoTab: function(controller) {
		return sap.ui.xmlfragment(controller.getView().getId(), 'com.novartis.uwf.inbox.template.detail.JEN.InfoTabContent', controller);
	},

	afterDataLoaded: function(controller, detailData) {
		var view = controller.getView();
		var model = view.getModel();
		var detailModel = view.getModel('detail');
		
		// Store controller
		this._controller = controller;

		// Bind attachments
		var attachments = view.getModel('JSONDetails').getProperty('/ATTACHMENTS');
		if (attachments) {
			var linkAttachmentId = 'LINK';
			var link = attachments.filter(function(attachment) {
				return attachment.ID === linkAttachmentId;
			})[0];
			if (link) {
				detailModel.setProperty('/ObjectLinks', {
					results: [
						{
							InstanceID: detailModel.getProperty('/InstanceID'),
							Label: 'Open request details in Back-End',
							ObjectLink: model.sServiceUrl + "/AttachmentCollection(SAP__Origin='LOCAL_GW',InstanceID='" + detailModel.getProperty('/InstanceID') + "',ID='" + linkAttachmentId + "')/$value"
						}
					]
				});
				detailModel.setProperty('/ObjectLinksCount', 1);
			}
		
			var preparedAttachments = attachments.filter(function(attachment) {
				return attachment.ID !== linkAttachmentId;
			}).map(function(attachment) {
				return {
					InstanceID: detailModel.getProperty('/InstanceID'),
					ID: attachment.ID,
					FileName: attachment.FILENAME,
					CreatedAt: '',
					CreatedBy: '',
					CreatedByName: '',
					mime_type: '',
					FileSize: null,
					FileDisplayName: attachment.FILENAME,
					AttachmentSupports: true,
					__metadata: {
						media_src: model.sServiceUrl + "/AttachmentCollection(SAP__Origin='LOCAL_GW',InstanceID='" + detailModel.getProperty('/InstanceID') + "',ID='" + attachment.ID + "')/$value"
					}
				};
			});
			detailModel.setProperty('/Attachments/results', preparedAttachments);
			detailModel.setProperty('/AttachmentsCount', preparedAttachments.length);
		}
	},

	configureButtons: function(buttonList, controller) {
		var data = controller.oModel2.getData();
		
		// Remove extra buttons
		buttonList.aButtonList.length = 0;

    // Change button behaviour
    buttonList.oNegativeAction.onBtnPressed = jQuery.proxy(this.onRejectPress, this);
    buttonList.oPositiveAction.onBtnPressed = jQuery.proxy(controller.sendAction, controller, 'Decision', {
			SAP__Origin: data.SAP__Origin,
			InstanceID: data.InstanceID,
			DecisionKey: '01'
		}, '');
	},

  configureTabs: function(oTabBar) {
		var aItems = oTabBar.getItems();

		/* hide standard tabs */
    for (var i = 0; i < aItems.length; i++) {
      if (aItems[i].getId().indexOf('MIBNoteIconTabFilter') != -1) {
        aItems[i].setVisible(false);
      }
    }
	},
	
	onRejectPress: function() {
		var controller = this._controller;
		
		if (!this._submitDialog) {
			var model = new sap.ui.model.json.JSONModel({
				submitEnabled: false,
				comment: '',
				commentState: 'None',
				reason: '',
				reasonState: 'None'
			});
			var submitDialog = sap.ui.xmlfragment('com.novartis.uwf.inbox.template.detail.JEN.RejectDialog', {
				handleCancel: function() {
					submitDialog.close();
				},
				
				handleSubmit: function() {
					var context = controller.getView().getBindingContext();
					var origin = context.getProperty('SAP__Origin');
					var instanceId = context.getProperty('InstanceID');
					var decisionKey = '02';
					var payload = {
						key: parseInt(decisionKey, 10),
						comment: model.getProperty('/comment'),
						code: model.getProperty('/reason')
					};
					
					submitDialog.close();
					
					// Submit asynchronously
					controller.oDataManager.sendAction(
						controller.oDataManager.FUNCTION_IMPORT_DECISION,
						{
							SAP__Origin: origin,
							InstanceID: instanceId,
							DecisionKey: decisionKey
						},
						JSON.stringify(payload)
					);
				},
				
				handleChangeReason: function(event) {
					var selectedItem = event.getParameter('selectedItem');
					var key = selectedItem.getKey();
					var state = key ? 'None' : 'Error';
					
					model.setProperty('/reason', key);
					model.setProperty('/reasonState', state);
					
					this.handleUpdateSubmitEnabled();
				},
				
				handleChangeComment: function(event) {
					var value = event.getParameter('value');
					var state = value.length ? 'None' : 'Error';
					
					model.setProperty('/comment', value);
					model.setProperty('/commentState', state);
					
					this.handleUpdateSubmitEnabled();
				},
				
				handleUpdateSubmitEnabled: function() {
					model.setProperty('/submitEnabled', !!model.getProperty('/comment') && !!model.getProperty('/reason'));
				}
			});
			controller.getView().addDependent(submitDialog);
			
			// Set local model for validations
			submitDialog.setModel(model);
			
			// Set JSON details model from parent controller
			submitDialog.setModel(controller.getView().getModel('JSONDetails'), 'JSONDetails');

			// Toggle compact style
			jQuery.sap.syncStyleClass('sapUiSizeCompact', controller.getView(), submitDialog);
		
			// Store for later usage
			this._submitDialog = submitDialog;
		}

		// Open dialog
		this._submitDialog.open();
	},

  destroy: function() {
		if (this._submitDialog) {
			this._submitDialog.destroy();
			this._submitDialog = null;
		}
		
		this._controller = null;
	}
});
