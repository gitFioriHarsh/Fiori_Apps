/*&---------------------------------------------------------------------*
*& Development ID: ZDDE-00019502                                       *
*&                                                                     *
*& Inbox                                                               *
*&                                                                     *
*&---------------------------------------------------------------------*
*& Change Log:                                                         *
*&                                                                     *
*& Init. Who          Date         Text                                *
*& JHU   HUNDEJU1     24-06-2015   Initial version CD 1200006098       *
*& JHU   HUNDEJU1     23-07-2015   Initial version CD 1200006975       *
*& FMU   FATIHMU1     09-02-2016   Fix for hour and days issue         *
*&                                 CD 1200013141                       *
*& SHA   SHAHRSH3     29-02-2016   Initial development for HR COI      *
*& SRKPR SIVARPR3	  04-06-2018   Initial version CD 1200041805       *
*&---------------------------------------------------------------------*/

jQuery.sap.declare('com.novartis.uwf.inbox.template.detail.HR.template');
jQuery.sap.require('com.novartis.uwf.inbox.template.detail.generic');
jQuery.sap.require('com.novartis.uwf.inbox.template.master.HR.template');


com.novartis.uwf.inbox.template.detail.generic.extend('com.novartis.uwf.inbox.template.detail.HR.template', {
    _controller : null,


  _coi : {
    tabs : {
      initialize : function(oTabBar, self) {
        //'this' now refers to self._coi.tabs
        var aItems = oTabBar.getItems();
        var i18nCustom = self._controller.getView().getModel('i18nCustom');

        var aIndexedTabs = {};
        aItems.forEach(function(element){
          aIndexedTabs[element.getProperty('key')] = element;
        });

        this.additionalInfo = new sap.m.IconTabFilter({
                      key: 'ADDITIONALINFO',
                      icon: 'sap-icon://document-text',
                      text: i18nCustom.getProperty('ZTAB_HR_COI_INFO_ADDITIONAL_INFO'),
                      content: sap.ui.xmlfragment('com.novartis.uwf.inbox.template.detail.HR.COI.AdditionalInfo', self._controller)
                    });
        this.opmDecision =    new sap.m.IconTabFilter({
                      key: 'OPMDECISION',
                      icon: 'sap-icon://comment',
                      text: i18nCustom.getProperty('ZTAB_HR_COI_INFO_OPM_DECISION'),
                      content: sap.ui.xmlfragment('com.novartis.uwf.inbox.template.detail.HR.COI.OpmDecision', self._controller)
                    });

        aIndexedTabs['NOTES'].setVisible(false);
        aIndexedTabs['ATTACHMENTS'].setVisible(false);
        aIndexedTabs['OBJECTLINKS'].setVisible(false);
 if (!(typeof aIndexedTabs['PROCESSINGLOGS'] === "undefined")){aIndexedTabs['PROCESSINGLOGS'].setVisible(false);}
          if ( !aIndexedTabs['ADDITIONALINFO'] ) { oTabBar.addItem(this.additionalInfo); }
        if ( !aIndexedTabs['OPMDECISION'] ) { oTabBar.addItem(this.opmDecision); }
      }
    },
    buttons : {
      controller : null,
      initialized : false,
      onRequestInfoPress : function (event){

        if (!this.buttonRequestInfo.dialog) {
          this.buttonRequestInfo.dialog = sap.ui.xmlfragment('com.novartis.uwf.inbox.template.detail.HR.COI.BackToAuthorCommentDialog', this);
          this.buttonRequestInfo.dialog.attachAfterClose(function() {
            var input = sap.ui.getCore().byId('requestInfoDialogComment');
            if (input) {
              input.setValue('');
            }
          });
          this.controller.getView().addDependent(this.buttonRequestInfo.dialog);
        }
        this.currentDialog = this.buttonRequestInfo.dialog;
        this.currentDialog.open();
      },
      onDialogRequestInfoButton : function(event) {
        var oContext = this.controller.getView().getBindingContext();
      //  var sOrigin = oContext.getProperty('SAP__Origin');
        var sInstanceId = oContext.getProperty('InstanceID');

        var sNote = sap.ui.getCore().byId('requestInfoDialogComment').getValue();
        var oParameters = {
          InstanceID : sInstanceId,
          CommentMandatory : "",
          DecisionKey : "0003",
          DecisionText : "Request for more info",
          Nature : "NEGATIVE",
          SAP__Origin : "LOCAL_GW"
        };
        this.controller.sendAction("Decision",oParameters,sNote);
       // this.controller.oDataManager.oModel.bFullRefreshNeeded = true;
   //    this.controller.oDataManager.processListAfterAction(sOrigin, sInstanceId);
    //   this.controller.oDataManager.triggerRefresh("SENDACTION", this.ACTION_SUCCESS);
    //   this.controller.oDataManager.fireActionPerformed();
       this.currentDialog.close();

        var oController = this.controller;
        jQuery.sap.delayedCall(500, oController, function() {
          sap.ca.ui.message.showMessageToast(oController.i18nBundle.getText('dialog.success.complete'));
        });

        /*
        function (f,d,s){
          sap.ca.ui.dialog.confirmation.open({
              question:this.i18nBundle.getText("XMSG_DECISION_QUESTION",d.DecisionText),
              showNote:s,
              title:this.i18nBundle.getText("XTIT_SUBMIT_DECISION"),
              confirmButtonLabel:this.i18nBundle.getText("XBUT_SUBMIT"),
              noteMandatory:d.CommentMandatory,
            },jQuery.proxy(function(d,r){
              if(r.isConfirmed){this.sendAction(f,d,r.sNote);}
            },this,d)
          );
        }
        */
      },
      onApprovePress : function () {
        //'this' now refers to self._coi.buttons
        var oContext = this.controller.getView().getBindingContext();
        var oObject = this.controller.getView().getModel().getProperty(oContext.getPath());

        if ( oObject.hasOwnProperty('ZHRCCoiDetail') ) {
          if ( oObject.ZHRCCoiDetail.Process === 'YPAXX_XF_PR_COI_REMOVE' ) {
            if ( !this.buttonEnterDecision.dialog ) {
              this.buttonEnterDecision.dialog = sap.ui.xmlfragment('com.novartis.uwf.inbox.template.detail.HR.COI.RemoveCommentDialog', this);
              this.controller.getView().addDependent(this.buttonEnterDecision.dialog);
            }
            this.currentDialog = this.buttonEnterDecision.dialog;
            this.currentDialog.open();
            return;
          }
        }

        this.initialOpmDecision = this.controller.getView().getModel("detail").getProperty("/ZHRCCoiDetail/OpmDecision");
        if (!this.buttonEnterDecision.dialog) {
          this.buttonEnterDecision.dialog = sap.ui.xmlfragment('com.novartis.uwf.inbox.template.detail.HR.COI.ApprovalCommentDialog', this);
          this.buttonEnterDecision.dialog.attachAfterClose(function() {
            this.controller.getView().getModel("detail").setProperty("/ZHRCCoiDetail/OpmDecision", this.initialOpmDecision);
          }.bind(this));
          this.controller.getView().addDependent(this.buttonEnterDecision.dialog);
        }
        this.currentDialog = this.buttonEnterDecision.dialog;
        this.currentDialog.open();
        sap.ui.getCore().byId('OpmDecisionTextArea').setVisible(!sap.ui.getCore().byId('OpmDecisionCheckBox').getSelected());


      },
      onDialogApproveButton : function(event) {
        var oContext = this.controller.getView().getBindingContext();
        var sOrigin = oContext.getProperty('SAP__Origin');
        var sInstanceId = oContext.getProperty('InstanceID');
        this.oDataModel = new sap.ui.model.odata.ODataModel(this.controller.oDataManager.oPostActionModel.sServiceUrl + sOrigin);

        //var oPayload = oContext.getProperty('ZHRCCoiDetail');
        var oPayload = this.controller.getView().getModel("detail").getProperty("/ZHRCCoiDetail");

        var i18nCustom = this.controller.getView().getModel('i18nCustom');
        if ( oPayload.OpmDecision === "" && !oPayload.NoAction) {
          sap.ui.getCore().byId('approvalDialogCommentMissing').setText(i18nCustom.getProperty('ZTAB_HR_COI_TBL_APPROVE_DIA_COMMENT_MISSING'));
          return;
        } else { 
          sap.ui.getCore().byId('approvalDialogCommentMissing').setText('');
        }
        var oParameters = {
          InstanceID : sInstanceId,
          Payload : JSON.stringify(oPayload),
          Decision: '0001'
        };

        var that = this;
        that.controller.oDataManager.fnShowReleaseLoader(true);
        this.oDataModel.callFunction('ZHRCCoiDecision', {
          method : 'POST', 
          urlParameters : oParameters, 
          success : function(oData) {
            that.controller.oDataManager.fnShowReleaseLoader(false);
            // Remove the processed item from the list


             jQuery.sap.delayedCall(2000, that.controller, function() {
         //    that.controller.oDataManager.oModel.bFullRefreshNeeded = true;
         //     that.controller.oDataManager.processListAfterAction(sOrigin, sInstanceId);


         that.controller.oDataManager.processListAfterAction(sOrigin, sInstanceId);
         that.controller.oDataManager.triggerRefresh("SENDACTION", this.ACTION_SUCCESS);
          that.controller.oDataManager.fireActionPerformed();


              that.currentDialog.close();
            });

            //that.controller.oDataManager.processListAfterAction(sOrigin, sInstanceId);


            jQuery.sap.delayedCall(500, that.controller, function() {
              sap.ca.ui.message.showMessageToast(that.controller.i18nBundle.getText('dialog.success.complete'));
            });
          },
          error : function(error) {
            that.controller.oDataManager.fnShowReleaseLoader(false);
            var customError = {
              customMessage: {
                message: jQuery(error.response.body).find('message:first').text(),
                details: error.response.body
              }
            };

            that.controller.oDataManager.oDataRequestFailed(customError, function() {});
          }
        });
      },
      onDialogCancelButton : function(event) {
        this.currentDialog.close();
      },
      initialize : function(buttonList, controller, self){
        //'this' now refers to self._coi.buttons
        this.controller = self._controller;

        if ( !this.buttonEnterDecision ) {
          this.buttonEnterDecision = { 
            sBtnTxt : "Enter decision",
            onBtnPressed : jQuery.proxy(self._coi.buttons.onApprovePress, self._coi.buttons)
          };
        }
        if ( !this.buttonRequestInfo ) {
          this.buttonRequestInfo = {
            sBtnTxt : "Request info",
            onBtnPressed : jQuery.proxy(self._coi.buttons.onRequestInfoPress, self._coi.buttons)
          };
        }
        
        buttonList.oPositiveAction = this.buttonEnterDecision;
        buttonList.oNegativeAction = this.buttonRequestInfo;
      }
    }
  },

    getEntitySetsToExpand: function(item) {
        switch (item.ZObjectType) {
            case 'LRQ':
                return ['ZHRCHeaderDetails'];
            case '3PA':
                return ['ZHRCHeaderDetails,ZHRCItems'];
            case 'OEEM':
                return ['ZHRCHeaderDetails'];
      case 'COI' :
        return ['ZHRCCoiDetail'];
        }
    },

    getObjectHeader: function(controller) {
    var oModel = controller.getView().getModel();
    var currentPath = "/TaskCollection(SAP__Origin='" + controller._origin + "',InstanceID='" + controller._instanceId + "')";
    var oObject = oModel.getProperty(currentPath);

//

    try {
         var sFragmentPath = 'com.novartis.uwf.inbox.template.detail.HR.' + oObject.ZObjectType + '.ObjectHeader';
      // Try to get the ObjectHeader fragment from the sub folder of the ZObjectType and return
      var oHeaderFragment = sap.ui.xmlfragment(sFragmentPath, controller);
      return oHeaderFragment;
    } catch( err ) {
      // In case the file is not found in the ZObjectType subfolder, use the ObjectHeader in the parent folder (HR)
      return sap.ui.xmlfragment('com.novartis.uwf.inbox.template.detail.HR.ObjectHeader', controller);
    }

    /*if (oObject.ZObjectType == 'COI') {
      // COI will use a different header
      return sap.ui.xmlfragment('com.novartis.uwf.inbox.template.detail.HR.COI.COIObjectHeader', controller);
    }
    else {
      return sap.ui.xmlfragment('com.novartis.uwf.inbox.template.detail.HR.ObjectHeader', controller);
    } */
    },

    getInfoTab: function(controller) {
        // Extend controller
        this._controller = jQuery.extend(controller, {});

        var oModel = controller.getView().getModel();

    var currentPath = "/TaskCollection(SAP__Origin='" + controller._origin + "',InstanceID='" + controller._instanceId + "')";
    var oObject = oModel.getProperty(currentPath);

    if ( oObject && oObject.ZObjectType && ( oObject.ZObjectType === 'COI' ) ) {

      if (oObject.ZValue) {
        var sFilePath = 'com.novartis.uwf.inbox.template.detail.HR.COI.InfoTabContent' + oObject.ZValue;

        return sap.ui.xmlfragment(controller.getView().getId(), sFilePath, controller);
      } else {
        return null;
      }

    } else {

      return sap.ui.xmlfragment(controller.getView().getId(), 'com.novartis.uwf.inbox.template.detail.HR.InfoTabContent', controller);
    }
    },

    configureButtons: function(buttonList, controller) {
    var data = controller.oModel2.getData();

    if ( data.ZObjectType === 'COI' ) {
      this._coi.buttons.initialize(buttonList, controller,this);
    } else {

      // Directly send action without confirmation
      if (buttonList.oPositiveAction) {
        buttonList.oPositiveAction.onBtnPressed = $.proxy(controller.sendAction, controller, 'Decision', {
          SAP__Origin: data.SAP__Origin,
          InstanceID: data.InstanceID,
          DecisionKey: '0001'
        }, '');
      }
    }
    },

  configureTabs: function(oTabBar) {
     var oModel = this._controller.getView().getBindingContext();
  if (!(typeof oModel === "undefined")){
  var zObjectType = oModel.getProperty('ZObjectType');
   if ( zObjectType === 'COI' ) {
     this._coi.tabs.initialize(oTabBar,this);
  }
  }
  },
    periodFormatter: function(from, to) {
        var period = '',
            fullDate = sap.ui.core.format.DateFormat.getDateInstance({ style: 'long' }),
            dayDate = sap.ui.core.format.DateFormat.getDateInstance({ pattern: 'EEEE' });
			
	/* Add one day due to Time conversion issue  for TimeZones in US Region  */		
	if ( to ){
	var TZOffsetMs = new Date().getTimezoneOffset();
 if ( TZOffsetMs >= 0 ) {
   to = new Date( to.getTime() + ( 3600 * 24 * 1000 ) );
	}
	}
	
	if ( from ){
	var TZOffsetMs = new Date().getTimezoneOffset();
 if (TZOffsetMs >= 0) {
   from = new Date(from.getTime() + ( 3600 * 24 * 1000 ));
	}
	}
        if ( from ) {
            period = dayDate.format(from) + ', ' + fullDate.format(from);
        }

        if (to && from && from.toDateString() !== to.toDateString()) {
            period += ' - ' + dayDate.format(to) + ', ' + fullDate.format(to);
        }

        return period;
    },

    isTypeLRQ: function(type) {
    return (type === 'LRQ');
    },

    isType3PA: function(type) {
        return (type === '3PA');
    },

    isNotTypeOEEM: function(type) {
        return (type !== 'OEEM');
    },

    isTypeOEEM: function(type) {
        return (type === 'OEEM');
    },

  isTypeCOI: function(type) {
        return (type === 'COI');
    },

    notAppl: function(localChar) {
        if (!localChar) {
            return this.getModel('i18nCustom').getProperty('ZTAB_HR_INFO_NA');
        } else {
            return localChar;
        }
    },

    uomFormatter: function (unit, uom ) {
        if (uom != null) {
            if (unit <= 1) {
                return this.getModel('i18nCustom').getProperty('ZTAB_HR_UNIT_' + uom + '_SINGLE');
            } else {
                return this.getModel('i18nCustom').getProperty('ZTAB_HR_UNIT_' + uom);
            }
        } else {
            return '';
        }
    },

    // Formatter for RequestDay Property
    requestdayFormatter: function (unit, uom ) {
        if (uom != null) {
            if (unit <= 1) {
                return unit + ' ' + this.getModel('i18nCustom').getProperty('ZTAB_HR_UNIT_' + uom + '_SINGLE');
            } else {
                return unit + ' ' + this.getModel('i18nCustom').getProperty('ZTAB_HR_UNIT_' + uom);
            }
        } else {
            return '';
        }
    },

  booleanFormatter: function(booleanValue) {
    if (booleanValue) {
      return this.getModel('i18nCustom').getProperty('ZTAB_HR_CONST_YES');
    } else {
      return this.getModel('i18nCustom').getProperty('ZTAB_HR_CONST_NO');
    }
  },

  dateStatusTextFormatter: function(date) {
    return com.novartis.uwf.inbox.template.master.HR.template.prototype.dateStatusTextFormatter(date);
  },

  dateStatusStateFormatter: function(date) {
    return com.novartis.uwf.inbox.template.master.HR.template.prototype.dateStatusStateFormatter(date);
  },

  isNotEmpty: function(value) {
    if (value) {
      return true;
    } else {
      return false;
    }
  },

  noActionSelect: function(event) {
    var oTextArea = sap.ui.getCore().byId('OpmDecisionTextArea');
    if (oTextArea) {
      if (event.getParameter('selected')) {
        oTextArea.setVisible(false);
      } else {
        oTextArea.setVisible(true);
      }
    }
  },

  convertTypeChkboxToText: function(){
    var aItems = [];
    for ( var i = 0; i < arguments.length; i += 2 ) {
      if ( arguments[ i ] && arguments[ i + 1 ] ) {
        aItems.push(arguments[ i + 1 ]);
      }
    }
    return aItems.join(', ');
  },

  destroy: function() {
    if (this._coi.tabs.additionalInfo) {
      this._coi.tabs.additionalInfo.destroy();
    }
    if (this._coi.tabs.opmDecision) {
      this._coi.tabs.opmDecision.destroy();
    }
  }
});