jQuery.sap.declare('com.novartis.uwf.inbox.template.detail.CONCUR.template');
jQuery.sap.require('com.novartis.uwf.inbox.template.detail.generic');

com.novartis.uwf.inbox.template.detail.generic.extend('com.novartis.uwf.inbox.template.detail.CONCUR.template', {
	_controller: null,
	doNotFetchDataOnTabSelect: true,
	doNotFetchObjectLinks: false,

	_attendeesTab: null,

	formatAmountDueEmployee: function (expenses, currency) {
		if (!expenses) {
			return '';
		}

		// Manually calculate amount due because the value from Concur seems to be wrong sometimes
		var value = expenses.reduce(function (cumulatedValue, expense) {
			if (expense.IsCreditCardCharge === 'Y' || expense.IsPersonal === 'Y') {
				return cumulatedValue;
			}

			var number = parseFloat(expense.ApprovedAmount);
			return cumulatedValue + number;
		}, 0);

		return new sap.ui.model.type.Currency({ minFractionDigits: 2, maxFractionDigits: 99 }).formatValue([value, currency], 'string');
	},

	getEntitySetsToExpand: function (item) {
		return [
			'ZXXXDetails'
		];
	},

	getObjectHeader: function (controller) {
		return sap.ui.xmlfragment('com.novartis.uwf.inbox.template.detail.CONCUR.ObjectHeader', controller);
	},

	getInfoTab: function (controller) {
		return sap.ui.xmlfragment(controller.getView().getId(), 'com.novartis.uwf.inbox.template.detail.CONCUR.InfoTabContent', controller);
	},

	beforeDataLoaded: function (controller) {
		var view = controller.getView(),
			i18nCustom = view.getModel('i18nCustom');

		// Set generic model
		controller
			.getView()
			.setModel(new sap.ui.model.json.JSONModel({ attendees: [] }), 'concur');

		// Already create attendees tab
		if (!this._attendeesTab) {
			this._attendeesTab = new sap.m.IconTabFilter({
				visible: {
					path: "detail>/TaskDefinitionID",
					formatter: function (taskDefinitionID) {
						return taskDefinitionID === 'EXPENSE_REPORT';
					}
				},
				key: 'attendees',
				icon: 'sap-icon://group',
				text: i18nCustom.getProperty('ZTAB_CON_TAB_ATTENDEES'),
				count: { path: "concur>/attendeesCount" },
				content: sap.ui.xmlfragment('com.novartis.uwf.inbox.template.detail.CONCUR.Attendees', this._controller)
			});
		}
	},

	afterDataLoaded: function (controller, detailData) {
		var view = controller.getView();
		var detailModel = view.getModel('detail');
		var concurModel = view.getModel('concur');
		var taskDefinitionID = detailModel.getProperty('/TaskDefinitionID');

		// Store controller
		this._controller = controller;

		// Prepare attendees
		var attendees = [];
		var attendeesCount = 0;
		var filterDeletedAttendees = function (attendee) {
			return attendee.IsDeleted === 'N';
		};
		if (taskDefinitionID === 'EXPENSE_REPORT') {
			var expenseEntryList = view.getModel('JSONDetails').getProperty('/ExpenseEntriesList');
			var expenseEntries = [];
			for (var i = 0; i < expenseEntryList.length; i++) {
				var expenseEntry = expenseEntryList[i];
				var itemizations = expenseEntry.ItemizationsList;
				var approvedAmount = 0;

				for (var j = 0; j < itemizations.length; j++) {
					var itemization = itemizations[j];
					var attendeesList = itemization.AttendeesList.filter(filterDeletedAttendees);
					approvedAmount = approvedAmount + parseFloat(itemization.ApprovedAmount);

					var itemAttendees = [];
					for (var k = 0; k < attendeesList.length; k++) {
						var attendee = attendeesList[k];

						attendee.AttendeeTypeName = {
							BUSGUEST: 'Business Guest',
							SYSEMP: 'Employee',
							EMPLOYEE: 'Employee (not in Concur)',
							HCP: 'Healthcare Professional',
							NOSHOWS: 'No Shows',
							SPOUSE: 'Spouse/Partner',
							CNHCP: 'China Healthcare Professional',
							UNDEF: 'Undefined'
						}[attendee.AttendeeType] || attendee.AttendeeType;
						attendee.AttendeeAmount = parseFloat(expenseEntry.PostedAmount) / attendeesList.length;
						itemAttendees.push(attendee);
						attendeesCount++;
					}

					if (itemAttendees.length > 0) {
						attendees.push({
							expenseEntry: expenseEntry,
							attendees: itemAttendees
						});
					}
				}

				expenseEntry.ApprovedAmount = /*expenseEntry.ApprovedAmount || */approvedAmount;
				expenseEntries.push(expenseEntry);
			}
		}
		concurModel.setProperty('/attendeesCount', attendeesCount);
		concurModel.setProperty('/attendees', attendees);
		concurModel.setProperty('/expenseEntries', expenseEntries);

		// Bind attachments
		var attachmentURL = view.getModel('JSONDetails').getProperty('/ReportImageURL');
		if (attachmentURL) {
			detailModel.setProperty('/Attachments/results', [
				{
					SAP__Origin: 'LOCAL_GW',
					InstanceID: detailModel.getProperty('/InstanceID'),
					ID: 'RECEIPTS',
					FileName: 'Receipts',
					CreatedAt: '',
					CreatedBy: '',
					CreatedByName: '',
					mime_type: '',
					FileSize: null,
					FileDisplayName: 'Receipts',
					AttachmentSupports: true,
					__metadata: {
						media_src: attachmentURL
					}
				}
			]);
			detailModel.setProperty('/AttachmentsCount', 1);
		}

		// Bind comments
		var comments = view.getModel('JSONDetails').getProperty('/CommentsList');
		if (comments) {
			const latestComments = comments.filter(function (comment) {
				return comment.IsLatest === true;
			});
			detailModel.setProperty('/Comments/results', latestComments.map(function (comment, index) {
				return {
					SAP__Origin: 'LOCAL_GW',
					InstanceID: detailModel.getProperty('/InstanceID'),
					ID: index,
					Text: comment.Comment,
					CreatedBy: comment.FirstName + ' ' + comment.LastName,
					CreatedByName: comment.FirstName + ' ' + comment.LastName,
					CreatedAt: new Date(comment.DateTime)
				};
			}));
			detailModel.setProperty('/CommentsCount', latestComments.length);
		}

		// Hide tabs
		var oTabBar = view.byId('tabBar');
		var aItems = oTabBar.getItems();
		for (var i = 0; i < aItems.length; i++) {
			if (aItems[i].getId().indexOf('MIBAttachmentIconTabFilter') != -1) {
				aItems[i].setVisible(taskDefinitionID === 'EXPENSE_REPORT');
			}
			if (aItems[i].getId().indexOf('MIBNoteIconTabFilter') != -1) {
				aItems[i].setVisible(taskDefinitionID !== 'EXPENSE_REPORT');
			}
		}
	},

	configureButtons: function (buttonList, controller) {
		// Remove Forward button
		buttonList.aButtonList = [];
	},

	configureTabs: function (tabbar) {
		var tabs = tabbar.getItems(),
			alreadyAdded = false;

		// Check if attendeess tab already exists
		for (var i = 0; i < tabs.length; i++) {
			if (tabs[i].getProperty('key') === 'attendeess') {
				alreadyAdded = true;
			}

			if (tabs[i].getId().indexOf('MIBObjectLinksTabFilter') != -1) {
				tabs[i].setText('Concur');
			}
		}

		// Add attendeess tab if necessary
		if (!alreadyAdded) {
			tabbar.addItem(this._attendeesTab);
		}
	},

	destroy: function () {
		// Destroy attendeess tab
		if (this._attendeesTab) {
			this._attendeesTab.destroy();
		}
	}
});
