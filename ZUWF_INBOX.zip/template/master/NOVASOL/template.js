/*&---------------------------------------------------------------------*
*& Development ID: ZDDE-00019502                                       *
*&                                                                     *
*& Inbox                                                               *
*&                                                                     *
*&---------------------------------------------------------------------*
*& Change Log:                                                         *
*&                                                                     *
*& Init. Who          Date         Text                                *
*& LTS   TORRALU1     28-10-2015   Initial version CD 1200009167       *
*& LTS   TORRALU1     28-10-2015   Add CSS style to remove uppercase   *
*&---------------------------------------------------------------------*/

jQuery.sap.declare('com.novartis.uwf.inbox.template.master.NOVASOL.template');
jQuery.sap.require('com.novartis.uwf.inbox.template.master.generic');

com.novartis.uwf.inbox.template.master.generic.extend('com.novartis.uwf.inbox.template.master.NOVASOL.template', {
	getListItem: function(controller) {
		//create special style for Novasol Object List Item template
		var oStyle = document.createElement('style');
		var oElement = document.getElementById('NovasolItemStyle');

		// Always delete style element first because it can lead to errors in IE
		if (oElement) {
			oElement.parentNode.removeChild(oElement);
		}

		// Create style tag
		document.head.appendChild(oStyle);
		oStyle.id = 'NovasolItemStyle';
		oStyle.type = 'text/css';

		//style for mixed case list item attributes
		oStyle.innerHTML = ".sapUShellApplicationContainer[id^=application-ZUWF-myapprovals] .sapMSplitContainerMaster .sapMObjLItem .sapMObjLAttrRow .novasolListAttribute.sapMObjectAttributeDiv .sapMText, .sapUShellApplicationContainer[id^=application-ZUWF-myapprovals] .sapMSplitContainerMobile .sapMObjLItem .sapMObjLAttrRow .novasolListAttribute.sapMObjectAttributeDiv .sapMText, .sapUShellApplicationContainer[id^=application-ZUWF-inbox] .sapMSplitContainerMaster .sapMObjLItem .sapMObjLAttrRow .novasolListAttribute.sapMObjectAttributeDiv .sapMText, .sapUShellApplicationContainer[id^=application-ZUWF-inbox] .sapMSplitContainerMobile .sapMObjLItem .sapMObjLAttrRow .novasolListAttribute.sapMObjectAttributeDiv .sapMText{text-transform: none!important;}";

		return sap.ui.xmlfragment('com.novartis.uwf.inbox.template.master.NOVASOL.ObjectListItem', controller);
	},

	uomFormatter: function (unit, uom) {
		if (uom != null) {
			if (unit <= 1) {
				return this.getModel('i18nCustom').getProperty('ZTAB_HR_UNIT_' + uom + '_SINGLE');
			} else {
				return this.getModel('i18nCustom').getProperty('ZTAB_HR_UNIT_' + uom);
			}
		} else {
			return '';
		}
	},

	scenarioNameFormatter: function (objtype) {
		if (objtype != null) {
			return this.getModel('i18nCustom').getProperty('ZTAB_HR_INFO_OBJTYPE_' + objtype);
		} else {
			return '';
		}
	},

	periodFormatter: function(from, to) {
		var period = '';

		if (from) {
			period = com.novartis.uwf.lib.util.Formatter.dateFormat(from);
		}

		if (to && from && from.toDateString() !== to.toDateString()) {
			period += ' - ' + com.novartis.uwf.lib.util.Formatter.dateFormat(to);
		}

		return period;
	}
});
