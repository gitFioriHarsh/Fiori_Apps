/*&---------------------------------------------------------------------*
*& Development ID: ZDDE-00019502                                       *
*&                                                                     *
*& Inbox                                                               *
*&                                                                     *
*&---------------------------------------------------------------------*
*& Change Log:                                                         *
*&                                                                     *
*& Init. Who          Date         Text                                *
*& JCP   COSTAJOJ     20-10-2015   Initial version CD 1200005515       *
*&---------------------------------------------------------------------*/

jQuery.sap.declare('com.novartis.uwf.inbox.template.master.AP4SAP.template');
jQuery.sap.require('com.novartis.uwf.inbox.template.master.generic');

com.novartis.uwf.inbox.template.master.generic.extend('com.novartis.uwf.inbox.template.master.AP4SAP.template', {
	getListItem: function(controller) {
		return sap.ui.xmlfragment('com.novartis.uwf.inbox.template.master.AP4SAP.ObjectListItem', controller);
	},

	scenarioNameFormatter: function (objtype) {  	
		if (objtype != null) {
			return this.getModel('i18nCustom').getProperty('ZTAB_AP4_INFO_OBJTYPE_' + objtype);
		} else {
			return '';
		}
	},

	periodFormatter: function(from, to) {
		var period = '';

		if (from) {
			period = com.novartis.uwf.lib.util.Formatter.dateFormat(from);
		}

		if (to && from && from.toDateString() !== to.toDateString()) {
			period += ' - ' + com.novartis.uwf.lib.util.Formatter.dateFormat(to);
		}

		return period;
	}
});
