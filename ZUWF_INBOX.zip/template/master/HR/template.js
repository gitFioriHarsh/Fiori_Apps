/*&---------------------------------------------------------------------*
*& Development ID: ZDDE-00019502                                       *
*&                                                                     *
*& Inbox                                                               *
*&                                                                     *
*&---------------------------------------------------------------------*
*& Change Log::                                                        *
*&                                                                     *
*& Init. Who          Date         Text                                *
*& JHU   HUNDEJU1     24-06-2015   Initial version CD 1200006098       *
*& JHU   HUNDEJU1     23-07-2015   Initial version CD 1200006975       *
*& SRKPR SIVARPR3	  04-06-2018   Initial version CD 1200041805       *
*&---------------------------------------------------------------------*/

jQuery.sap.declare('com.novartis.uwf.inbox.template.master.HR.template');
jQuery.sap.require('com.novartis.uwf.inbox.template.master.generic');

com.novartis.uwf.inbox.template.master.generic.extend('com.novartis.uwf.inbox.template.master.HR.template', {
  getListItem: function(controller) {
    return sap.ui.xmlfragment('com.novartis.uwf.inbox.template.master.HR.ObjectListItem', controller);
  },

  numberFormatter: function(number, objectType) {
    if ( objectType === 'COI' ) {
      return '';
    }

    return number;
  },

  uomFormatter: function (unit, uom) {
    if (uom && uom != null) {
      if (unit <= 1) {
        return this.getModel('i18nCustom').getProperty('ZTAB_HR_UNIT_' + uom + '_SINGLE');
      } else {
        return this.getModel('i18nCustom').getProperty('ZTAB_HR_UNIT_' + uom);
      }
    } else {
      return '';
    }
  },

  scenarioNameFormatter: function (objtype) {
    if (objtype != null) {
      return this.getModel('i18nCustom').getProperty('ZTAB_HR_INFO_OBJTYPE_' + objtype);
    } else {
      return '';
    }
  },

  periodFormatter: function(from, to) {

	  /* Add one day due to Time conversion issue  for TimeZones in US Region  */

	/*  Commented&nbsp;
    var period = '';

    if (from) {
      period = com.novartis.uwf.lib.util.Formatter.dateFormat(from);
    }

    if (to && from && from.toDateString() !== to.toDateString()) {
      period += ' - ' + com.novartis.uwf.lib.util.Formatter.dateFormat(to);
    }

    return period; */
	
	
	    var period = '';

    if (from) {
	var TZOffsetMs = new Date().getTimezoneOffset();
 if (TZOffsetMs >= 0) {
   from  = new Date(from.getTime() + ( 3600 * 24 * 1000 ));
     }
    }
	
	period =  com.novartis.uwf.lib.util.Formatter.dateFormat(from);
	
	if (to){
	var TZOffsetMs = new Date().getTimezoneOffset();
 if (TZOffsetMs >= 0) {
   to = new Date(to.getTime() + ( 3600 * 24 * 1000));
	}
	}
	
	
    if (to && from && from.toDateString() !== to.toDateString()) {
      period += ' - ' + com.novartis.uwf.lib.util.Formatter.dateFormat(to);
    }

    return period;
	
	
	
  }


});