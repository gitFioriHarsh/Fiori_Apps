/*&---------------------------------------------------------------------*
*& Development ID: ZDDE-00019502                                       *
*&                                                                     *
*& Inbox                                                               *
*&                                                                     *
*&---------------------------------------------------------------------*
*& Change Log:                                                         *
*&                                                                     *
*& Init. Who          Date         Text                                *
*& JHU   HUNDEJU1     24-06-2015   Initial version CD 1200006098       *
*& JHU   HUNDEJU1     23-07-2015   Initial version CD 1200006975       *
*&---------------------------------------------------------------------*/

jQuery.sap.declare('com.novartis.uwf.inbox.template.master.generic');

sap.ui.base.Object.extend('com.novartis.uwf.inbox.template.master.generic', {
	models: [],

	destroy: function() {
		for (var i = 0; i < this.models.length; i++) {
			this.models[i].destroy();
		}
	},

	getListItem: function(controller) {
		return sap.ui.xmlfragment('com.novartis.uwf.inbox.template.master.ObjectListItem', controller);
	}
});
