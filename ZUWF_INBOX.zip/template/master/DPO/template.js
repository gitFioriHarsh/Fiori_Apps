/*&---------------------------------------------------------------------*
*& Development ID: <ZDDE-00019502>                                       *
*&                                                                     *
*& Inbox                                                               *
*&                                                                     *
*&---------------------------------------------------------------------*
*& Change Log:                                                         *
*&                                                                     *
*& Init. Who          Date         Text                                *
*& DEV   VADTHDE1     14-07-2022   Initial version CD <1200006098>       *
*&---------------------------------------------------------------------*/

jQuery.sap.declare('com.novartis.uwf.inbox.template.master.DPO.template');
jQuery.sap.require('com.novartis.uwf.inbox.template.master.generic');

com.novartis.uwf.inbox.template.master.generic.extend('com.novartis.uwf.inbox.template.master.DPO.template', {
	getListItem: function(controller) {
		return sap.ui.xmlfragment('com.novartis.uwf.inbox.template.master.DPO.ObjectListItem', controller);
	},

	descriptionFormatter : function(value) {
		var formattedText = value === '()' ? '' : value;

		if (value && value.indexOf(';') > 0) {
			// Remove duplicates
			var parts = value.split(';');
			parts = parts.filter(function(item, pos) {
				return parts.indexOf(item) == pos;
			});

			// Return "multiple" text if more than one ; is available
			if (parts.length > 1) {
				// formattedText = this.getModel('i18nCustom').getProperty('ZTAB_GRC_DESC_MULTIPLE');
			} else {
				formattedText = parts[0];
			}
		}

		return formattedText;
	}
});
