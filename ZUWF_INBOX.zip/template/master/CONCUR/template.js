jQuery.sap.declare('com.novartis.uwf.inbox.template.master.CONCUR.template');
jQuery.sap.require('com.novartis.uwf.inbox.template.master.generic');

com.novartis.uwf.inbox.template.master.generic.extend('com.novartis.uwf.inbox.template.master.CONCUR.template', {
	getListItem: function(controller) {
		return sap.ui.xmlfragment('com.novartis.uwf.inbox.template.master.CONCUR.ObjectListItem', controller);
	}
});
