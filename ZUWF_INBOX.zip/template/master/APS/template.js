/*&---------------------------------------------------------------------*
*& Development ID: ZDDE-00019502                                       *
*&                                                                     *
*& Inbox                                                               *
*&                                                                     *
*&---------------------------------------------------------------------*
*& Change Log:                                                         *
*&                                                                     *
*& Init. Who          Date         Text                                *
*& JHU   HUNDEJU1     24-06-2015   Initial version CD 1200006098       *
*& JHU   HUNDEJU1     23-07-2015   Initial version CD 1200006975       *
*&---------------------------------------------------------------------*/

jQuery.sap.declare('com.novartis.uwf.inbox.template.master.APS.template');
jQuery.sap.require('com.novartis.uwf.inbox.template.master.generic');

com.novartis.uwf.inbox.template.master.generic.extend('com.novartis.uwf.inbox.template.master.APS.template', {
	getListItem: function(controller) {
		return sap.ui.xmlfragment('com.novartis.uwf.inbox.template.master.APS.ObjectListItem', controller);
	}
});
