/*&--------------------------------------------------------------------------*
 *& DD ID  : DDW-00032142 - Contract Workflow Approval                       *
 *& FS ID  : FSW-00032141 - Contract Workflow Approval                       *
 *&--------------------------------------------------------------------------*
 *& Inbox                                    								 *
 *&--------------------------------------------------------------------------*
 *& Change Log:                                                              *
 *&--------------------------------------------------------------------------*
 *& Author      ¦ Date           ¦ Comment                                   *
 *&--------------------------------------------------------------------------*
 *& REDDYRO5      10/Jan/2024        Initial Version                         *
 *&                                  CR# 1500022032 CD# 1600013449           *
 *&--------------------------------------------------------------------------*/

jQuery.sap.declare('com.novartis.uwf.inbox.template.master.OLA.template');
jQuery.sap.require('com.novartis.uwf.inbox.template.master.generic');

com.novartis.uwf.inbox.template.master.generic.extend('com.novartis.uwf.inbox.template.master.OLA.template', {
	getListItem: function(controller) {
		return sap.ui.xmlfragment('com.novartis.uwf.inbox.template.master.OLA.ObjectListItem', controller);
	},

	descriptionFormatter : function(value) {
		var formattedText = value === '()' ? '' : value;

		if (value && value.indexOf(';') > 0) {
			// Remove duplicates
			var parts = value.split(';');
			parts = parts.filter(function(item, pos) {
				return parts.indexOf(item) == pos;
			});

			// Return "multiple" text if more than one ; is available
			if (parts.length > 1) {
				// formattedText = this.getModel('i18nCustom').getProperty('ZTAB_GRC_DESC_MULTIPLE');
			} else {
				formattedText = parts[0];
			}
		}

		return formattedText;
	}
});
