/*&--------------------------------------------------------------------------*
 *& FS ID  : FSW-00009407 - Credit Debit Memo Workflow Approval          *
 *&--------------------------------------------------------------------------*
 *& Inbox                                    								 *
 *&--------------------------------------------------------------------------*
 *& Change Log:                                                              *
 *&--------------------------------------------------------------------------*
 *& Author      ¦ Date           ¦ Comment                                   *
 *&--------------------------------------------------------------------------*
 *& VADTHDE1      25-10-2022       Initial Version                         *
 *&                                  CR# 1500017375  CD# 1600010195           *
 *&--------------------------------------------------------------------------*/

jQuery.sap.declare('com.novartis.uwf.inbox.template.master.CDM.template');
jQuery.sap.require('com.novartis.uwf.inbox.template.master.generic');

com.novartis.uwf.inbox.template.master.generic.extend('com.novartis.uwf.inbox.template.master.CDM.template', {
	getListItem: function(controller) {
		return sap.ui.xmlfragment('com.novartis.uwf.inbox.template.master.CDM.ObjectListItem', controller);
	},

	descriptionFormatter : function(value) {
		var formattedText = value === '()' ? '' : value;

		if (value && value.indexOf(';') > 0) {
			// Remove duplicates
			var parts = value.split(';');
			parts = parts.filter(function(item, pos) {
				return parts.indexOf(item) == pos;
			});

			// Return "multiple" text if more than one ; is available
			if (parts.length > 1) {
				// formattedText = this.getModel('i18nCustom').getProperty('ZTAB_GRC_DESC_MULTIPLE');
			} else {
				formattedText = parts[0];
			}
		}

		return formattedText;
	}
});
