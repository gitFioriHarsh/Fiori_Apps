/*&---------------------------------------------------------------------*
*& Development ID: ZDDE-00019502                                       *
*&                                                                     *
*& Inbox                                                               *
*&                                                                     *
*&---------------------------------------------------------------------*
*& Change Log:                                                         *
*&                                                                     *
*& Init. Who          Date         Text                                *
*& JHU   HUNDEJU1     24-06-2015   Initial version CD 1200006098       *
*& JHU   HUNDEJU1     23-07-2015   Initial version CD 1200006975       *
*&---------------------------------------------------------------------*/

jQuery.sap.declare("com.novartis.uwf.inbox.Configuration");
jQuery.sap.require('cross.fnd.fiori.inbox.Configuration');
jQuery.sap.require('com.novartis.uwf.lib.model.TaskProcessing');

jQuery.extend(cross.fnd.fiori.inbox.Configuration.prototype, {
    oServiceParams: {
        serviceList: [
            {
                name: 'TASKPROCESSING',
                masterCollection: 'TaskCollection',
                serviceUrl: com.novartis.uwf.lib.model.TaskProcessing.getServiceURL(true),
                isDefault: true,
                mockedDataSource: '/cross.fnd.fiori.inbox/model/metadata.xml',
                useBatch: true,
                useV2ODataModel:true,
                noBusyIndicator:true
            },
            {
                name: 'POSTACTION',
                masterCollection: 'TaskCollection',
                serviceUrl: com.novartis.uwf.lib.model.TaskProcessing.getServiceURL(true),
                isDefault: false,
                useBatch: true,
                useV2ODataModel:true,
                noBusyIndicator:true
            }
        ]
    }
});