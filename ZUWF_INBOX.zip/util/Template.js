/*&---------------------------------------------------------------------*
*& Development ID: ZDDE-00019502                                       *
*&                                                                     *
*& Inbox                                                               *
*&                                                                     *
*&---------------------------------------------------------------------*
*& Change Log:                                                         *
*&                                                                     *
*& Init. Who          Date         Text                                *
*& JHU   HUNDEJU1     24-06-2015   Initial version CD 1200006098       *
*& JHU   HUNDEJU1     23-07-2015   Initial version CD 1200006975       *
*&---------------------------------------------------------------------*/

jQuery.sap.declare('com.novartis.uwf.inbox.util.Template');
jQuery.sap.require('com.novartis.uwf.inbox.template.master.generic');
jQuery.sap.require('com.novartis.uwf.inbox.template.master.AIS.template');
jQuery.sap.require('com.novartis.uwf.inbox.template.master.AP4SAP.template');
jQuery.sap.require('com.novartis.uwf.inbox.template.master.APS.template');
jQuery.sap.require('com.novartis.uwf.inbox.template.master.CONCUR.template');
jQuery.sap.require('com.novartis.uwf.inbox.template.master.ETRAVEL.template');
jQuery.sap.require('com.novartis.uwf.inbox.template.master.GRC.template');
jQuery.sap.require('com.novartis.uwf.inbox.template.master.HR.template');
jQuery.sap.require('com.novartis.uwf.inbox.template.master.JEN.template');
jQuery.sap.require('com.novartis.uwf.inbox.template.master.NOVASOL.template');
jQuery.sap.require('com.novartis.uwf.inbox.template.master.SOX.template');
jQuery.sap.require('com.novartis.uwf.inbox.template.master.SRM.template');
jQuery.sap.require('com.novartis.uwf.inbox.template.master.ICSI.template');
jQuery.sap.require('com.novartis.uwf.inbox.template.master.DPO.template');
jQuery.sap.require('com.novartis.uwf.inbox.template.master.CDM.template');
jQuery.sap.require('com.novartis.uwf.inbox.template.master.CLMD.template');
jQuery.sap.require('com.novartis.uwf.inbox.template.master.OLA.template');

jQuery.sap.require('com.novartis.uwf.inbox.template.detail.generic');
jQuery.sap.require('com.novartis.uwf.inbox.template.detail.AIS.template');
jQuery.sap.require('com.novartis.uwf.inbox.template.detail.AP4SAP.template');
jQuery.sap.require('com.novartis.uwf.inbox.template.detail.APS.template');
jQuery.sap.require('com.novartis.uwf.inbox.template.detail.CONCUR.template');
jQuery.sap.require('com.novartis.uwf.inbox.template.detail.ETRAVEL.template');
jQuery.sap.require('com.novartis.uwf.inbox.template.detail.GRC.template');
jQuery.sap.require('com.novartis.uwf.inbox.template.detail.HR.template');
jQuery.sap.require('com.novartis.uwf.inbox.template.detail.JEN.template');
jQuery.sap.require('com.novartis.uwf.inbox.template.detail.NOVASOL.template');
jQuery.sap.require('com.novartis.uwf.inbox.template.detail.SOX.template');
jQuery.sap.require('com.novartis.uwf.inbox.template.detail.SRM.template');
jQuery.sap.require('com.novartis.uwf.inbox.template.detail.ICSI.template');
jQuery.sap.require('com.novartis.uwf.inbox.template.detail.DPO.template');
jQuery.sap.require('com.novartis.uwf.inbox.template.detail.CDM.template');
jQuery.sap.require('com.novartis.uwf.inbox.template.detail.CLMD.template');
jQuery.sap.require('com.novartis.uwf.inbox.template.detail.OLA.template');

com.novartis.uwf.inbox.util.Template = {
  loadMaster: function(name) {
    return this.load(name, 'master');
  },

  loadDetail: function(name) {
    return this.load(name, 'detail');
  },

  load: function(name, type) {
    var template = null;
    try {
      jQuery.sap.require('com.novartis.uwf.inbox.template.' + type + '.' + name + '.template');
      template = com.novartis.uwf.inbox.template[type][name].template;
    } catch(e) {
      jQuery.sap.log.error('Template ' + name + ' does not exist.');
      template = com.novartis.uwf.inbox.template[type].generic;
    }

    return new template();
  }
};