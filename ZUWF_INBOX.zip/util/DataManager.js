/*&---------------------------------------------------------------------*
*& Development ID: ZDDE-00019502                                       *
*&                                                                     *
*& Inbox                                                               *
*&                                                                     *
*&---------------------------------------------------------------------*
*& Change Log:                                                         *
*&                                                                     *
*& Init. Who          Date         Text                                *
*& JHU   HUNDEJU1     24-06-2015   Initial version CD 1200006098       *
*& JHU   HUNDEJU1     23-07-2015   Initial version CD 1200006975       *
*& JHU   HUNDEJU1     23-07-2015   Changed function name of            *
*&                                                                 readDataOn...Options CD 1200007843  *
*& JHU   HUNDEJU1     18-08-2015   Refresh on error CD 1200007843      *
*& JHU   HUNDEJU1     20-08-2015   Hide loading indicator CD 1200007843*
*& SSA   SHIVASA2     23-09-2015   Removal of invalid parameters in    *
*&                                 searchUsers Function CD 1200008904  *
*& SRKP  SIVARPR3     11-06-2018   Initial version CD 1200041834       *

*&---------------------------------------------------------------------*/

jQuery.sap.declare('com.novartis.uwf.inbox.util.DataManager');
jQuery.sap.require('cross.fnd.fiori.inbox.util.DataManager');

// Set default sort property
cross.fnd.fiori.inbox.util.DataManager.prototype.sDefaultSortBy = 'InstanceID';

/*
// Read details with expand instead of a batch
cross.fnd.fiori.inbox.util.DataManager.prototype.readDataOnTaskSelectionWithDecisionOptions = function(ctxPath, expandEntitySets, origin, instanceID, success) {
    var that = this;

    if (!ctxPath || !origin || !instanceID) {
        return null;
    }

    // Show loader
    this.fnShowReleaseLoader(true);

    // Decision options
    var decisionOptions = null;
    if (!this.oDecisionOptions[origin + instanceID]) {
        // Not in the cache yet
        expandEntitySets.unshift('ZDecisionOptions');
        that.bDecisionOptionsCached = false;
    } else {
        // Result from the cache
        decisionOptions = this.oDecisionOptions[origin + instanceID];
        that.bDecisionOptionsCached = true;
    }

    var errorCallback = function(error) {
        that.fnShowReleaseLoader(false);

        // If only responseText is returned the actual error is not displayed in the UI
        if (!error.response) {
            error.response = {
                body: error.responseText
            };
        }

        that.oDataRequestFailed(error);

        // Refresh
        that.oModel.bFullRefreshNeeded = true;

      // In case of phone, remove the stored context path and navigate to master
      if (sap.ui.Device.system.phone) {
          that.oBaseController.sBindingContextPath = undefined;
          that.oBaseController.oRouter.navTo('master', {}, true);
      } else {
        that.oBaseController.findNextVisibleItem(origin, instanceID);
      }

      // Refresh
        that.oModel.refresh();
    };

    var successCallback = function(data, response) {
        // Merge data
        var taskData = that.oModel.getProperty(ctxPath);
        jQuery.extend(taskData, data);

        // Were decisions read?
        if (decisionOptions === null) {
            decisionOptions = taskData.ZDecisionOptions.results || [];
        }

        // Return with original callback
        success(taskData, decisionOptions);
        that.bDetailPageLoaded = true;
        that.fnShowReleaseLoader(false);
    };

    return this._doReadDetail.apply(this, [ctxPath, expandEntitySets, true, successCallback, errorCallback]);
};

// Try to read count from local cache rather than creating a new request
/*
removed as upgrade
var fnGetDataWithCountSupport = cross.fnd.fiori.inbox.util.DataManager.prototype.fnGetDataWithCountSupport;
cross.fnd.fiori.inbox.util.DataManager.prototype.fnGetDataWithCountSupport = function(origin, instanceID, getCount, successCallback, entity) {
    var contextPath = '/' + 'TaskCollection' + '(SAP__Origin=\'' + jQuery.sap.encodeURL(origin) + '\',InstanceID=\'' + jQuery.sap.encodeURL(instanceID) + '\')';

    // Get model and entity from local cache
    var model = this.oModel.getData(contextPath);

    if (model && model[entity] && model[entity].results) {
        if (getCount) {
            return successCallback(model[entity].results.length || 0);
        } else {
            return successCallback(model[entity] || []);
        }
    }

    // Otherwise try to run the standard function
    return fnGetDataWithCountSupport.apply(this, arguments);
}; */

// InstanceID was also added to the search parameters
cross.fnd.fiori.inbox.util.DataManager.prototype.searchUsers = function(origin, searchPattern, maxResults, success) {
	var that = this,
		componentUtil = new com.novartis.uwf.lib.util.Component(this),
		s3Controller = componentUtil.getController('cross.fnd.fiori.inbox.view.S3'),
		params = {
			SAP__Origin: "'" + s3Controller._origin + "'",
			InstanceID: "'" + s3Controller._instanceId + "'",
			SearchPattern: "'" + searchPattern + "'",
			MaxResults: maxResults
		};

	//added as upgrade

	// Modified by SHIVASA2, Removed the null and false parameters
	this.fnShowReleaseLoader(true);
	this.oDataRead(
		'/SearchUsers',
		params,
		function(data, response) {
			that.fnShowReleaseLoader(false);

			if (data && data.results) {
				if (success) {
					success(data.results);
				}
			}
		},
		function(error) {
			that.fnShowReleaseLoader(false);
			that.oDataRequestFailed(error);
		}
	);
};

cross.fnd.fiori.inbox.util.DataManager.prototype.getErrorMessage = function(oError) {
	/*			if (oError.response && oError.response.body != "") {
				return oError.response.body;
			}*/
	if (oError.response && oError.response.body && oError.response.body != '') {
		try {
			var oMessage = JSON.parse(oError.response.body);
			return oMessage.error.message.value ? oMessage.error.message.value : null;
		} catch (e) {
			return oError.response.body;
		}
	} else if (oError.responseText && oError.responseText != '') {
		try {
			var oMessage = JSON.parse(oError.responseText);
			return oMessage.error.message.value ? oMessage.error.message.value : null;
		} catch (e) {
			return oError.responseText;
		}
	} else if (oError.getParameter && (oError.getParameter('responseText') || oError.getParameter('response').body)) {
		return oError.getParameter('responseText')
			? oError.getParameter('responseText')
			: oError.getParameter('response').body;
	} else {
		return null;
	}
};

var showLocalErrorMessage = cross.fnd.fiori.inbox.util.DataManager.prototype.showLocalErrorMessage;
cross.fnd.fiori.inbox.util.DataManager.prototype.showLocalErrorMessage = function(oError, fnError) {
	if (!fnError) {
		jQuery.sap.log.error('showLocalErrorMessage was skipped since the error argument was empty.');
		return;
	}
	fnError();

	// Otherwise try to run the standard function
	return showLocalErrorMessage.apply(this, arguments);
};

var oDataRequestFailed = cross.fnd.fiori.inbox.util.DataManager.prototype.oDataRequestFailed;
cross.fnd.fiori.inbox.util.DataManager.prototype.oDataRequestFailed = function(oError, fnError) {
	if (oError && oError.message === 'Request aborted') {
		jQuery.sap.log.error('oDataRequestFailed was skipped since the request was intentionally aborted.');
		return;
	}

	// Otherwise try to run the standard function
	return oDataRequestFailed.apply(this, arguments);
};

// Redefinition in order to avoid batch requests for counts (should avoid timeouts for AP4SAP)
cross.fnd.fiori.inbox.util.DataManager.prototype.fnGetCount = function(
	sOrigin,
	sInstanceID,
	fnSuccessCallback,
	sEntity
) {
	// var that = this;
	var sContextPath = this._getTaskContextPath(sOrigin, sInstanceID) + '/' + sEntity + '/$count';

	// var fnErrorCallback = function( oError ) {
	//                         that.oDataRequestFailed( oError );
	//      };

	// Pass entity name as group id in order to avoid batch requests
	this.oDataRead(
		sContextPath,
		null,
		function(oData) {
			fnSuccessCallback(oData);
		},
		function() {},
		sEntity
	);
};
cross.fnd.fiori.inbox.util.DataManager.prototype.triggerRefresh = function() {
	// Do nothing
};

var fireBatch = cross.fnd.fiori.inbox.util.DataManager.prototype.fireBatch;
cross.fnd.fiori.inbox.util.DataManager.prototype.fireBatch = function(mParameters) {
	if (mParameters.sBatchGroupId === 'DetailWithDecisionOptions') {
		mParameters.aUrlParameters[0]['$select'] = mParameters.aUrlParameters[0]['$select'] + ',TaskSupports';
	}

	return fireBatch.apply(this, arguments);
};

// Redefinition in order to pass on error after closing pop up
cross.fnd.fiori.inbox.util.DataManager.prototype.sendAction = function(sFIName, oDecision, sNote, fnSuccess, fnError) {
	this.fnShowReleaseLoader(true);
	var sErrorMessage = this.oi18nResourceBundle.getText(this.getErrorMessageKey(sFIName));

	var oUrlParams = {
		SAP__Origin: "'" + encodeURIComponent(oDecision.SAP__Origin) + "'",
		InstanceID: "'" + oDecision.InstanceID + "'"
	};

	if (oDecision.DecisionKey) {
		oUrlParams.DecisionKey = "'" + oDecision.DecisionKey + "'";
	}

	if (sNote && sNote.length > 0) {
		oUrlParams.Comments = "'" + sNote + "'";
	}

	this._performPost(
		'/' + sFIName,
		oDecision.SAP__Origin,
		oUrlParams,
		$.proxy(
			function(oDecision, fnSuccess) {
				this.fnShowReleaseLoader(false);
				// remove the processed item from the list
				this.processListAfterAction(oDecision.SAP__Origin, oDecision.InstanceID);
				this.triggerRefresh('SENDACTION', this.ACTION_SUCCESS);
				this.fireActionPerformed();
				// call the original success function
				if (fnSuccess) {
					fnSuccess();
				}
			},
			this,
			oDecision,
			fnSuccess
		),
		$.proxy(function(oError) {
			this.fnShowReleaseLoader(false);
			// call the original error function
			if (fnError) {
				fnError(oError);
			}
			//refresh the list after error and select a task accordingly
			this.processListAfterAction(oDecision.SAP__Origin, oDecision.InstanceID, true);
			this.fireActionPerformed();
			this.triggerRefresh('SENDACTION', this.ACTION_FAILURE);
		}, this),
		sErrorMessage
	);
};
// Redefinition in order to not refresh model in case of errors
cross.fnd.fiori.inbox.util.DataManager.prototype._refreshListOnError = function(sOrigin, sInstanceID) {
	this.oModel.bFullRefreshNeeded = true;
	jQuery.sap.delayedCall(500, this, function() {
		sap.ca.ui.message.showMessageToast(this.oi18nResourceBundle.getText('dialog.info.task_completed'));
	});
	// in case of phone, remove the stored context path and navigate to master
	if (sap.ui.Device.system.phone) {
		this.oEventBus.publish('cross.fnd.fiori.inbox.dataManager', 'refreshOnError');
	} else {
		// in case of devices other than phone, select the next item from the list
		this.processListAfterAction(sOrigin, sInstanceID);
	}
	// refresh the list
	// Custom: do not refresh whole model
	// this.oModel.refresh();
};
cross.fnd.fiori.inbox.util.DataManager.prototype.handleRequestCompleted = function() {};
