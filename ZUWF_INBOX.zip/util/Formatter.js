jQuery.sap.declare('com.novartis.uwf.inbox.util.Formatter');

com.novartis.uwf.inbox.util.Formatter = {
  convertStringToDate: function (string) {
    // ISO Date?
    var date = new Date(string);
    if (!isNaN(date.getTime())) {
      return date;
    }
    
    try {
      if (string) {
        // Something like 1-1-2019 or 1/1/2019
        if (string.length > 6) {
          var delimiter = '';
          if (string.indexOf('-') > -1) {
            delimiter = '-';
          } else if (string.indexOf('/') > -1) {
            delimiter = '/';
          }

          if (delimiter) {
            var parts = string.split(delimiter);
            if (parts.length === 3) {
              var year = parseInt(parts[0].length === 4 ? parts[0] : parts[2], 10);
              var month = parseInt(parts[0].length === 4 ? parts[2] : parts[0], 10);
              var day = parseInt(parts[1], 10);

              return new Date(year, month - 1, day, 0, 0, 0, 0);
            }
          }
        }
      
        return new Date(string.substr(0, 4), parseInt(string.substr(4, 2), 10) - 1, string.substr(6, 2), 0, 0, 0, 0);
      }
    } catch (error) {
      return new Date(0);
    }
    
    return new Date(0);
  },

  createdAtTextFormatter: function(createdAt, explicitDueDate) {
    var text = '';
    if (!createdAt) {
      return text;
    }
    
    // Intermediate workaround to convert string to date here; actually this should come as a date from the OData service but it dumps
    if (explicitDueDate === '0000-00-00') {
      explicitDueDate = null;
    }
    if (explicitDueDate && explicitDueDate.length === 10) {
      explicitDueDate = com.novartis.uwf.inbox.util.Formatter.convertStringToDate(explicitDueDate);
    }
    
    var dueDate = explicitDueDate ? new Date(explicitDueDate) : new Date();
    if (!explicitDueDate) {
      dueDate.setTime(createdAt.getTime() + (7 * 24 * 60 * 60 * 1000));
    }
    
    return new Date() > dueDate ? 'overdue' : com.novartis.uwf.lib.util.Formatter.dateFormat(createdAt);
  },

  createdAtStateFormatter: function(createdAt, explicitDueDate) {
    var state = 'None';
    if (!createdAt) {
      return state;
    }
    
    // Intermediate workaround to convert string to date here; actually this should come as a date from the OData service but it dumps
    if (explicitDueDate === '0000-00-00') {
      explicitDueDate = null;
    }
    if (explicitDueDate && explicitDueDate.length === 10) {
      explicitDueDate = com.novartis.uwf.inbox.util.Formatter.convertStringToDate(explicitDueDate);
    }
    
    var dueDate = explicitDueDate ? new Date(explicitDueDate) : new Date();
    if (!explicitDueDate) {
      dueDate.setTime(createdAt.getTime() + (7 * 24 * 60 * 60 * 1000));
    }

    return new Date() > dueDate ? 'Error' : 'None';
  },

  dateFormat: function(date) {
    if (!date) {
      return;
    }

    if (typeof date === 'string') {
      date = com.novartis.uwf.inbox.util.Formatter.convertStringToDate(date);
    }

    return com.novartis.uwf.lib.util.Formatter.dateFormat(date);
  },

  boolFormat: function(string) {
    var yes = 'yes';
    var no = 'no';
    
    string = string ? string.toLowerCase() : '';
    if (!string) {
      return no;
    } else if (string === 'y') {
      return yes;
    } else if (string === 'n') {
      return no;
    }

    return '';
  },

  currencyFormat: function(string, currency) {
    var number = parseFloat(string);
    var value = new sap.ui.model.type.Currency({ minFractionDigits: 2, maxFractionDigits: 99 });

    return value.formatValue([number, currency], "string");  
  },

  trimFormat: function(value) {
    if (!value) {
      return value;
    }

    return value.trim();
  }
};