jQuery.sap.declare('com.novartis.uwf.inbox.util.TaskStatusFilterProvider');
jQuery.sap.require('cross.fnd.fiori.inbox.util.TaskStatusFilterProvider');

cross.fnd.fiori.inbox.util.TaskStatusFilterProvider.getAllFilters = function() {
	var filters = [];
	filters.push('READY');
	filters.push('RESERVED');
	filters.push('IN_PROGRESS');
	filters.push('EXECUTED');
	filters.push('COMMITTED');
	filters.push('STARTED');
	filters.push('SELECTED');

	return filters.map(function(filter) {
		return new sap.ui.model.Filter({
			path: 'Status',
			operator: sap.ui.model.FilterOperator.EQ,
			value1: filter
		});
	});
};
