/*&---------------------------------------------------------------------*
*& Development ID: ZDDE-00019502                                       *
*&                                                                     *
*& Inbox                                                               *
*&                                                                     *
*&---------------------------------------------------------------------*
*& Change Log:                                                         *
*&                                                                     *
*& Init. Who          Date         Text                                *
*& JHU   HUNDEJU1     24-06-2015   Initial version CD 1200006098       *
*& JHU   HUNDEJU1     23-07-2015   Initial version CD 1200006975       *
*&---------------------------------------------------------------------*/

jQuery.sap.declare('com.novartis.uwf.inbox.view.Forward');
jQuery.sap.require('com.novartis.uwf.lib.util.Component');

sap.ui.controller('com.novartis.uwf.inbox.view.Forward', {
    onInit: function() {
        // Remove detail button
        var view = this.getView(),
            listItem = view.byId('ITM_AGENT');

        listItem.setType('Active');
        listItem.detachDetailPress(this.handleDetailPress);
    }
});
