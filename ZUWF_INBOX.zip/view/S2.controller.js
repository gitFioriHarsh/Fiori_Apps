/*&---------------------------------------------------------------------*
*& Development ID: ZDDE-00019502                                       *
*&                                                                     *
*& Inbox                                                               *
*&                                                                     *
*&---------------------------------------------------------------------*
*& Change Log:
                                                   *
*&                                                                     *
*& Init. Who          Date         Text                                *
*& JHU   HUNDEJU1     24-06-2015   Initial version CD 1200006098       *
*& JHU   HUNDEJU1     23-07-2015   Initial version CD 1200006975       *
*& JHU   HUNDEJU1     28-07-2015   Implemented Filter button for       *
*&                                                                 scenarios CD 1200007577                   *
*& JHU   HUNDEJU1     06-08-2015   Opt. scenario determination         *
*&                                                                 CD 1200007843                       *
*& JHU   HUNDEJU1     18-08-2015   Disable busy mode CD 1200007843     *
*& JHU   HUNDEJU1     19-08-2015   Prevent flickering CD 1200007843    *
*&---------------------------------------------------------------------*/

jQuery.sap.declare('com.novartis.uwf.inbox.view.S2');
jQuery.sap.require('com.novartis.uwf.lib.util.Component');
jQuery.sap.require('com.novartis.uwf.lib.util.Misc');
jQuery.sap.require('com.novartis.uwf.lib.util.Formatter');
jQuery.sap.require('com.novartis.uwf.inbox.util.Template');
jQuery.sap.require('sap.m.Bar');
jQuery.sap.require('sap.ui.core.ws.SapPcpWebSocket');

sap.ui.controller('com.novartis.uwf.inbox.view.S2', {
	_componentUtil: null,

	_firstLoad: true,

	_scenarioConfig: {},

	_state: {},
	
	_websocket: null,

	onInit: function() {
		// Instantiate component utils
		this._componentUtil = new com.novartis.uwf.lib.util.Component(this);

		// Clear footer
		var page = this.getView().byId('page');
		page.destroyAggregation('footer');
		page.setAggregation('footer', new sap.m.Bar());

		// Hide multi select button
		var customHeader = page.getAggregation('customHeader'),
			contentRight = customHeader.getAggregation('contentRight');

		if (contentRight.length > 0) {
			customHeader.destroyContentRight();
		}

		// Get current scenario customizing
		var rootComponent = this._componentUtil.getRootComponent(),
			scenariosModel = rootComponent.getModel('scenarios');

		if (scenariosModel) {
			var data = scenariosModel.getData();

			for (var i = 0; i < data.length; i++) {
				var scenario = data[i];
				this._scenarioConfig[scenario.UniqueName] = scenario;
			}
		}

		// Hide back button
		if (jQuery.device.is.phone) {
			this._oControlStore.oBackButton.setVisible(false);
		}
		
		// Increase size limit (mostly used for development)
		this.getView().getModel().setSizeLimit(1000);

		// Remove item once processed
		var processListAfterAction = this.oDataManager.processListAfterAction;
		var that = this;
		this.oDataManager.processListAfterAction = function(origin, instanceId, isError) {
			if (isError) {
				return ;
			}

			// Find item
			var items = that.getList().getItems();

			var selectedItem = jQuery.grep(items, function(item) {
				var bindingContext = item.getBindingContext();
				return bindingContext
					? bindingContext.getProperty('InstanceID') === instanceId &&
						bindingContext.getProperty('SAP__Origin') === origin
					: false;
			})[0];

			var nextItem = null;
			if (selectedItem) {
				var selectedItemContextPath = selectedItem.getBindingContextPath();
				var index = items.indexOf(selectedItem);

				// Set current item to completed
				that.getList().getModel().setProperty(selectedItemContextPath + '/Status', 'COMPLETED');

				// Find next visible item
				var nextItems = items.slice(index);

               nextItem = jQuery.grep(nextItems, function(item) {
                if (item instanceof sap.m.GroupHeaderListItem) {
            return false;
          }

          var bindingContextPath = item.getBindingContextPath();
         return bindingContextPath ? bindingContextPath !== selectedItemContextPath : false;
        })[0];
			}
			// Take first one if no next items were found
			if (!nextItem) {
				nextItem = jQuery.grep(items, function(item) {
					return item instanceof sap.m.GroupHeaderListItem ? false : true;
				   })[0];
			}
			// Pass on next visible item
			if (nextItem) {
				origin = nextItem.getBindingContext().getProperty('SAP__Origin');
				instanceId = nextItem.getBindingContext().getProperty('InstanceID');
			}

			//processListAfterAction.apply(this, [origin, instanceId]);
			if (sap.ui.Device.system.phone) {
				that.oRouter.navTo('master', {}, true);
			} else {
				processListAfterAction.apply(this, [ origin, instanceId ]);
			}
		};

		// Highlight selected items
		this.oRouter.attachRoutePatternMatched(this.handleNavToDetail, this);

		// Expose refresh function
		window.refresh = function() {
			this.getList().getBinding('items').refresh(true);
		}.bind(this);

		// Connect to web sockets
		this.connectToWebsocket();
		setInterval(function() {
			this._websocket.send("ping");
			
			if (this._websocket._oWs.readyState === 3) {
				this.connectToWebsocket();
			}
		}.bind(this), 20 * 1000);
	},

	onAfterRendering: function() {
		if (window.erpapps) {
			return null;
		}
		
		if (!this._firstLoad) {
			return null;
		}
		this._firstLoad = false;

		// Add expandable/collapsable behavior to headers
		var list = this.getList();
		var state = this._state;
		var onBeforeRendering = list.onBeforeRendering;
		list.onBeforeRendering = function() {
					onBeforeRendering.apply(this, arguments);

					// Make all items visible
					this.getItems().forEach(function (item) {
					  if (item instanceof sap.m.GroupHeaderListItem) {
								item.setVisible(true);
								item.setVisible = function() {};
					  }
					});                        };
		var onAfterRendering = list.onAfterRendering;
		list.onAfterRendering = function() {
			onAfterRendering.apply(this, arguments);

			// Loop through all headers
			var totalCount = 0;
			var $headers = this.$().find('.sapMGHLI');
			$headers.each(function() {
				var $header = $(this);
				var id = $header.find('.sapMGHLITitle').text();

				// Count items and add badge to headers
				var $items = $header.nextUntil('.sapMGHLI');
				var count = $items.not('.sapUiHiddenPlaceholder').length;
				var hasErrors = $items.find('.sapMObjStatusError').length > 0;
				var hasWarnings = $items.find('.sapMObjStatusWarning').length > 0;
				var status = '';
				if (hasErrors) {
					status = 'error';
				} else if (hasWarnings) {
					status = 'warning';
				}
				$header.find('.sapMLIBContent').append('<span class="badge ' + status + '">&nbsp;(' + count + ')&nbsp;</span>');
				$items.wrapAll('<div class="items" />');
				totalCount += count;

				// Get icon for expanding
				var icon = new sap.ui.core.Icon({ src: 'sap-icon://navigation-down-arrow' });
				var rm = new sap.ui.core.RenderManager();

				// Add click behaviour
				$header.find('.sapMLIBContent').append('<div class="expander">' + rm.getHTML(icon) + '</div>');
				$header.click(function() {
					if (state[id] === true) {
						$header.next('.items').slideUp();
						$header.removeClass('expanded');
						state[id] = false;
					} else {
						$header.next('.items').slideDown();
						$header.addClass('expanded');
						state[id] = true;
					}
				});

				// Check if it's the first rendering or if we need to hide the list items
				if (!state[id]) {
					if ($headers.length === 1) {
						$header.next('.items').slideDown(0);
						$header.addClass('expanded');
						state[id] = true;
					} else {
						$header.next('.items').slideUp(0);
						state[id] = false;
					}
				} else {
					$header.addClass('expanded');
				}
			});

			// Notify any listener
			if (window.setBadge) {
				window.setBadge(totalCount);
			}
		};

		// Notify any listener to be ready
		if (window.ready) {
			window.ready();
		}
	},

	connectToWebsocket: function() {
		this._websocket = new sap.ui.core.ws.SapPcpWebSocket('/sap/bc/apc/sap/zgl_push');

		var list = this.getList();
		var handleMessage = function(event) {
			var fields = event.getParameter('pcpFields');
			if (!fields || fields.errorText) {
				return;
			}

			// Notify any listener
			var data = event.getParameter('data');
			if (window.notify && data) {
				window.notify(data);
			}

			// Try to update badge
			try {
				if (parseInt(fields.badge, 10) !== list.$().find('.sapMLIB:not(.sapMGHLI):not(.sapMListNoData)').length) {
					window.refresh();
				}
			} catch(error) {
				jQuery.sap.log.warning(error.message);
			}
		};
		this._websocket.attachOpen(handleMessage);
		this._websocket.attachMessage(handleMessage);
	},

	handleNavToDetail: function(oEvent) {
		if (oEvent.getParameter('name') === 'detail' || oEvent.getParameter('name') === 'detail_deep') {
			var contextPath = oEvent.getParameters().arguments.contextPath;

			var itemInDetails = jQuery.grep(this.getList().getItems(), function(item) {
				var path = item.getBindingContext() && item.getBindingContext().getPath();
				return path === '/' + contextPath;
			});

			if (itemInDetails.length > 0) {
				this.getList().setSelectedItem(itemInDetails[0], true, false);
				this.getList().rerender();
			}
		}
	},

	// Use back end search
	isBackendSearch: function() {
		return true;
	},

	getTasks: function() {
		var model = this.getView().getModel().getProperty('/');
		var keys = Object.keys(model);
		return keys
			.map(function(key) {
				return key.indexOf('TaskCollection') === 0 ? model[key] : null;
			})
			.filter(Boolean);
	},

	extHookGetPropertiesToSelect: function() {
		return [
			'ZTemplateDetail',
			'ZTemplateMaster',
			'ZObjectID',
			'ZObjectType',
			'ZRequester',
			'ZRequesterName',
			'ZApprover1',
			'ZApprover1Name',
			'ZApprover2',
			'ZApprover2Name',
			'ZRequestedBy',
			'ZRequestedByName',
			'ZValue',
			'ZUOM',
			'ZNrItems',
			'ZHasHistory',
			'ZUrgency',
			'ZColor',
			'ZSearchTerm',
			'ZUrgencyText',
			'ZDateFrom',
			'ZDateTo',
			'ZDescription',
			'ZKey',
			'ZDate',
			'ZScenarioID',
			'ZJSON',
			'ZDueDate'
		];
	},

  // Override title for empty view
  showEmptyView: function(viewTitle, languageKey, infoText) {
    return cross.fnd.fiori.inbox.view.S2.prototype.showEmptyView.apply(this, [ ' ', languageKey, infoText ]);
  },
	
	extHookChangeGroupConfig: function() {
		var that = this;
		this.oGroupConfigItem = {
			key: 'ZScenarioID',
			formatter: function(event) {
				var scenarioId = event.oModel.getProperty(event.sPath + '/ZScenarioID');
				var scenario = that._scenarioConfig[scenarioId];
				return scenario ? scenario.DisplayName : event.oModel.getProperty(event.sPath + '/ZScenarioID');
			}
		};
	},
	
	extHookChangeSortConfig: function(oSortConfig) {
		oSortConfig[this._SORT_INSTANCEID].descending = true;
	}
});
