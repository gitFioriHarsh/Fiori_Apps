/* eslint-disable no-undef */
/* eslint-disable block-scoped-var */
/*&---------------------------------------------------------------------*
*& Development ID: ZDDE-00019502                                       *
*&                                                                     *
*& Inbox                                                               *
*&                                                                     *
*&---------------------------------------------------------------------*
*& Change Log:                                                         *
*&                                                                     *
*& Init. Who          Date         Text                                *
*& JHU   HUNDEJU1     24-06-2015   Initial version CD 1200006098       *
*& JHU   HUNDEJU1     23-07-2015   Initial version CD 1200006975       *
*& JHU   HUNDEJU1     20-08-2015   Color of header  CD 1200007843 *
*&---------------------------------------------------------------------*/

jQuery.sap.declare('com.novartis.uwf.inbox.view.S3');
jQuery.sap.require('com.novartis.uwf.lib.util.Component');
jQuery.sap.require('com.novartis.uwf.lib.util.Formatter');
jQuery.sap.require('com.novartis.uwf.lib.util.Misc');
jQuery.sap.require('com.novartis.uwf.inbox.util.Template');

sap.ui.controller('com.novartis.uwf.inbox.view.S3', {
  _componentUtil: null,

  _scenarios: {},

  _instanceId: null,

  _origin: null,

  _isTracking: false,

  onInit: function() {
    // Instantiate component utils
    this._componentUtil = new com.novartis.uwf.lib.util.Component(this);

    // Get scenario customizing
    var rootComponent = this._componentUtil.getRootComponent(),
      scenariosModel = rootComponent.getModel('scenarios');

    // Unset "Item" text in title
    var propertyFiles = this.i18nBundle.aPropertyFiles;
    if (this.i18nBundle && propertyFiles.length) {
      for (var i = 0; i < propertyFiles.length; i++) {
        if (propertyFiles[i].setProperty) {
          propertyFiles[i].setProperty('ITEM_DETAIL_DISPLAY_NAME', '');
        }
      }
    }

    // Hide generic container
    this.getView().byId('genericComponentContainer').unbindProperty('visible').setVisible(false);

    // Prepare scenarios
    if (scenariosModel) {
      var data = scenariosModel.getData();

      // Store customizing by scenario name so it can be better accessed
      for (var i = 0; i < data.length; i++) {
        var id = data[i].UniqueName;

        // View all scenario does not need to be stored
        if (id === '*') {
          continue;
        }
        this._scenarios[id] = data[i];
      }
    }
  },

  onBeforeRendering: function() {
    // Already configure tabs
    this.configureTabs();
  },

  onAfterRendering: function() {
    // Add click to scroll behaviour to tab header
    var tabBar = this.getView().byId('tabBar');
    var header = tabBar.getAggregation('_header');

    var ontouchend = header.ontouchend;
    header.ontouchend = function() {
      var desktop = sap.ui.Device.system.desktop;
      sap.ui.Device.system.desktop = true;
      ontouchend.apply(this, arguments);
      sap.ui.Device.system.desktop = desktop;
    };
  },

  handleNavToDetail: function(event) {
    // Correct event?
    if (event.getParameter('name') !== 'detail') {
      return cross.fnd.fiori.inbox.view.S3.prototype.handleNavToDetail.apply(this, arguments);
    }

    var parameters = event.getParameters(),
      args = parameters.arguments,
      instanceId = args.InstanceID,
      origin = parameters.arguments.SAP__Origin;

    // Do we need to reload details?
    if (instanceId.split(':').join('') === this._instanceId && origin === this._origin) {
      return null;
    }

    // Cancel pending requests
    this.getView().getModel().aPendingRequestHandles.forEach(function(request) {
      request.abort();
    });
    // Identifier must consist of 4 parts
    var parts = instanceId.split('-');
    if (parts.length != 4) {
      return cross.fnd.fiori.inbox.view.S3.prototype.handleNavToDetail.apply(this, arguments);
    }
    this._instanceId = instanceId;
    this._origin = origin;

    // Template is first part
    var template = parts[0];

    // Track In-App Navigation
    try {
      if (typeof ADRUM !== 'undefined') {
        this._isTracking = true;
        ADRUM.markVirtualPageBegin(template + ' (V)', true);
      }

      window.com.novartis.Analytics
        .measurement(window.com.novartis.Analytics.events.INAPP_NAVIGATION, null, 'Details ' + template)
        .start();
    } catch (e) {
      // Do nothing
    }

    // Destroy old template
    if (this.getView().getModel('detail')) {
      this.getView().getModel('detail').setProperty('/', { showGenericComponent: false });
    }
    this.getView().setModel(null, 'JSONHeader');
    this.getView().setModel(null, 'JSONDetails');

    if (this.template) {
      this.template.destroy(this);
      this.template = null;
    }

    // Restore all tabs
    var tabbar = this.getView().byId('tabBar');
    var items = tabbar.getItems();
    var defaultItems = [
      'DescriptionContent',
      'MIBNoteIconTabFilter',
      'MIBAttachmentIconTabFilter',
      'MIBObjectLinksTabFilter'
    ];

    for (var i = 0; i < items.length; i++) {
      var item = items[i];
      var id = item.getId().split('--').pop();
      item.setVisible(true);

      // Remove item if it's not part of the default items
      if (defaultItems.indexOf(id) === -1) {
        tabbar.removeItem(item);
      }
    }

    // Load new template
    this.template = com.novartis.uwf.inbox.util.Template.loadDetail(template);

    // Recreate detail view
    var view = this.getView();
    var infoTabContent = view.byId('InfoTabContent');
    var objectHeader = view.byId('ObjectHeader');

    if (infoTabContent) {
      // Set content for info tab
      infoTabContent.destroyAggregation('content');
      infoTabContent.addAggregation('content', this.template.getInfoTab(this));
      infoTabContent.invalidate();
    }

    if (objectHeader) {
      // Set content for object header
      objectHeader.destroyAggregation('content');
      objectHeader.addAggregation('content', this.template.getObjectHeader(this));
      objectHeader.invalidate();
    }

    // Proceed with standard logic
    cross.fnd.fiori.inbox.view.S3.prototype.handleNavToDetail.apply(this, arguments);

    // Notify template that data will be loaded
    this.onShowReleaseLoader(null, null, {
      bValue: true
    });
    this.template.beforeDataLoaded(this);
  },

  // Load additional entity sets
  extHookGetEntitySetsToExpand: function() {
    var entitySets = [ 'Attachments', 'Comments', 'ProcessingLogs', 'TaskObjects', 'ZDecisionOptions' ];

    if (this.template) {
      var modelData = this.oDataManager.oModel.getProperty(this.sCtxPath.replace('-DUMMY', '')),
        expand = this.template.getEntitySetsToExpand(modelData);

      // If it is not an array
      if (Object.prototype.toString.call(expand) !== '[object Array]') {
        expand = [];
      }

      entitySets = entitySets.concat(expand);
    }

    return entitySets;
  },

  // When data is loaded
  extHookOnDataLoaded: function(detailData) {
    var that = this;
    var task = this.getView().getBindingContext().getProperty('');

    // Custom attributes need to be set
    detailData.CustomAttributeData = {};

    /*// Prevent template specific rerendering
        var detailModel = this.getView().getModel('detail');
        if (detailModel && detailModel.getProperty('/InstanceID') === this.oModel2.getProperty('/InstanceID')) {
      that.oDataManager.fnShowReleaseLoader(false);
            return null;
        }*/

    this.getView().setModel(this.oModel2, 'detail');

    // Set JSON header
    var jsonHeader = this.oModel2.getProperty('/ZJSON') || '{}';
    var jsonHeaderSanitized = jsonHeader.replace(/\\\\u003c/g, '<').replace(/\\\\u003e/g, '>').replace(/\\\\u0026/g, '&');
      this.getView().setModel(new sap.ui.model.json.JSONModel(JSON.parse(jsonHeaderSanitized)), 'JSONHeader');

    // Set JSON details
    var jsonDetails = detailData.ZXXXDetails ? detailData.ZXXXDetails.JSON || '{}' : '{}';
    var jsonDetailsSanitized = jsonDetails.replace(/\\\\u003c/g, '<').replace(/\\\\u003e/g, '>').replace(/\\\\u0026/g, '&');
      this.getView().setModel(new sap.ui.model.json.JSONModel(JSON.parse(jsonDetailsSanitized)), 'JSONDetails');

    // Get current scenario customizing
    var rootComponent = this._componentUtil.getRootComponent();
    var scenariosModel = rootComponent.getModel('scenarios');

    scenariosModel.getData().forEach(
      function(scenario) {
        if (scenario.UniqueName === task.ZScenarioID) {
          this._updateHeaderTitle({ TaskDefinitionName: scenario.DisplayName });
        }
      }.bind(this)
    );

    // Configure tabs
    this.configureTabs();

    // Set counters
    if (detailData.Comments) {
      this.oModel2.setProperty("/CommentsCount", detailData.Comments.results.length);
    }
    if (detailData.Attachments) {
      this.oModel2.setProperty("/AttachmentsCount", detailData.Attachments.results.length);
    }
    if (detailData.TaskObjects) {
      this.oModel2.setProperty("/ObjectLinksCount", detailData.TaskObjects.results.length);
    }

    // Delay the data loaded event a bit
    setTimeout(function() {
      // Notify template that data is loaded
      that.template.afterDataLoaded(that, detailData);

      // Release loader
      that.oDataManager.fnShowReleaseLoader(false);
    }, 0);
  },

  // Configure tabs
  configureTabs: function() {
    var tabbar = this.getView().byId('tabBar');
    var items = tabbar.getItems();
    var i18n = this.getView().getModel('i18nCustom');

    // Info tab
    items[0].setText(i18n.getProperty('ZTAB_INFO_TITLE'));

    // Add tooltips to the standard icons
    for (var j = 0; j < items.length; j++) {
      var item = items[j];
      var id = item.getId();

      if (id.indexOf('MIBNoteIconTabFilter') != -1) {
        item.setText(i18n.getProperty('ZTAB_NOTES_TITLE'));
        item.unbindProperty('visible');
      } else if (id.indexOf('MIBAttachmentIconTabFilter') != -1) {
        item.setText(i18n.getProperty('ZTAB_ATTACH_TITLE'));
        item.unbindProperty('visible');
      } else if (id.indexOf('MIBProcessingLogsTabFilter') != -1) {
        item.setText(i18n.getProperty('ZTAB_CHAIN_TITLE'));
        item.setIcon('sap-icon://work-history');
        item.unbindProperty('visible');
      } else if (id.indexOf('MIBObjectLinksTabFilter') != -1) {
        linksTab = item;
        item.setText(i18n.getProperty('ZTAB_LINK_TITLE'));
      }
    }

    // Configure additional tabs
    if (this.template) {
      this.template.configureTabs(tabbar);
    }

    // Move links to the end
    var tabbar = this.getView().byId('tabBar'),
      items = tabbar.getItems(),
      linksTab = null;
    if (linksTab) {
      items.push(linksTab);
      tabbar.removeAllItems();
      for (var i = 0; i < items.length; i++) {
        tabbar.addItem(items[i]);
      }
    }
  },

  createDecisionButtons: function(decisionOptions, origin) {
    // Change the default text for buttons to standard texts
    for (var i = 0; i < decisionOptions.length; i++) {
      var decisionOption = decisionOptions[i];

      if (decisionOption.Nature === 'POSITIVE') {
        decisionOption.DecisionText = decisionOption.DecisionText || this.i18nBundle.getText('XBUT_APPROVE');
      } else if (decisionOption.Nature === 'NEGATIVE') {
        decisionOption.DecisionText = decisionOption.DecisionText || this.i18nBundle.getText('XBUT_REJECT');
      }
    }

    // Call parent
    cross.fnd.fiori.inbox.view.S3.prototype.createDecisionButtons.apply(this, arguments);
  },

  addShareOnJamAndEmail: function() {},

  extHookChangeFooterButtons: function(buttonList) {
    // Disable share buttons
    this.disableShareButtons(buttonList);

    // Remove certain buttons
    var additionalButtons = buttonList.aButtonList;
    for (var i = 0; i < additionalButtons.length; i++) {
      var button = additionalButtons[i];

      // Open task
      if (button.sI18nBtnTxt === 'XBUT_OPEN') {
        additionalButtons.splice(i, 1);
        i--;
      }
    }

    // Let the template change the buttons
    if (this.template) {
      this.template.configureButtons(buttonList, this);
    }
  },

  disableShareButtons: function(buttonList) {
    buttonList.oEmailSettings = null;
    buttonList.oJamOptions = null;
    buttonList.bSuppressBookmarkButton = true;
  },

  setHeaderFooterOptions: function(options) {
    // Disable share buttons
    this.disableShareButtons(options);

    // Set empty default title (i18n does not work in the standard)
    this._oHeaderFooterOptions.sDetailTitle = this._oHeaderFooterOptions.sDetailTitle || ' ';

    // Call super
    cross.fnd.fiori.inbox.view.S3.prototype.setHeaderFooterOptions.apply(this, arguments);
  },

  // Do not execute search on first open
  onForwardPopUp: function() {
    cross.fnd.fiori.inbox.util.Forward.open(
      jQuery.proxy(this.startForwardFilter, this),
      jQuery.proxy(this.closeForwardPopUp, this)
    );
  },

  // Allow redefinition of forward logic
  closeForwardPopUp: function(result) {
    if (this.template) {
      this.template.forward(this, result);
    }
  },

  // Link to attachment URL
  buildFileDescriptorObject: function(value) {
    // Call parent
    var file = cross.fnd.fiori.inbox.view.S3.prototype.buildFileDescriptorObject.apply(this, arguments);

    // Fall back to standard if ZURL is empty
    if (value.ZURL) {
      file.url = value.ZURL;
    }

    return file;
  },

  onShowReleaseLoader: function(sChannelId, sEventId, oValue) {
    this.getView().setBusyIndicatorDelay(0);
    this.getView().setBusy(oValue.bValue);

    if (this._isTracking && !oValue.bValue) {
      // Track In-App Navigation
      try {
        window.com.novartis.Analytics.measurement(window.com.novartis.Analytics.events.INAPP_NAVIGATION).stop();
      } catch (e) {
        // Do nothing
      }
      if (typeof ADRUM !== 'undefined') {
        ADRUM.markVirtualPageEnd();
        this._isTracking = false;
      }
    }
  },

  onTabSelect: function(controlEvent) {
    var selectedTab = controlEvent.getParameters().selectedKey;

    switch (selectedTab) {
      // Fix attachment issue in standard (is already solved in 1.28.6)
      case 'ATTACHMENTS':
        sap.m.UploadCollection.prototype._triggerLink = function(event, context) {
          var iLine = null;
          var aId = event.oSource.getId().split('-');
          iLine = aId[aId.length - 2];
          sap.m.URLHelper.redirect(context.getProperty('url'), true);
          event.preventDefault();
          return false;
        };

        break;
    }

    return cross.fnd.fiori.inbox.view.S3.prototype.onTabSelect.apply(this, arguments);
  },

  fnFetchDataOnTabSelect: function() {
    // Do not fetch data on tab select
    if (this.template && this.template.doNotFetchDataOnTabSelect) {
      return;
    }

    return cross.fnd.fiori.inbox.view.S3.prototype.fnFetchDataOnTabSelect.apply(this, arguments);
  },

  fnFetchObjectLinks: function() {
    // Do not fetch data on tab select
    if (this.template && this.template.doNotFetchObjectLinks) {
      return;
    }

    return cross.fnd.fiori.inbox.view.S3.prototype.fnFetchObjectLinks.apply(this, arguments);
  }
});