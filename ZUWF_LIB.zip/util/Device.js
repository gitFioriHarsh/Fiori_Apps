/*&---------------------------------------------------------------------*
*& Development ID: ZDDE-00019502                                       *
*&                                                                     *
*& Device                                                              *
*&                                                                     *
*&---------------------------------------------------------------------*
*& Change Log:                                                         *
*&                                                                     *
*& Init. Who          Date         Text                                *
*& JHU   HUNDEJU1     08-09-2015   Initial version CD 1200005515       *
*&---------------------------------------------------------------------*/

jQuery.sap.declare('com.novartis.uwf.lib.util.Device');

com.novartis.uwf.lib.util.Device = {
  setModel: function(component) {
    var model = new sap.ui.model.json.JSONModel();

    model.setData({
      isTouch: sap.ui.Device.support.touch,
      isNoTouch: !sap.ui.Device.support.touch,
      isPhone: sap.ui.Device.system.phone,
      isNoPhone: !sap.ui.Device.system.phone,
      listMode: sap.ui.Device.system.phone ? 'None' : 'SingleSelectMaster',
      listItemType: sap.ui.Device.system.phone ? 'Active' : 'Inactive'
    });
    model.setDefaultBindingMode(sap.ui.model.BindingMode.OneWay);

    component.setModel(model, 'device');
    return model;
  }
};
