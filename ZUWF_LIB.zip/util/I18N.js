/*&---------------------------------------------------------------------*
*& Development ID: ZDDE-00019502                                       *
*&                                                                     *
*& I18N                                                                *
*&                                                                     *
*&---------------------------------------------------------------------*
*& Change Log:                                                         *
*&                                                                     *
*& Init. Who          Date         Text                                *
*& JHU   HUNDEJU1     08-09-2015   Initial version CD 1200005515       *
*&---------------------------------------------------------------------*/

jQuery.sap.declare('com.novartis.uwf.lib.util.I18N');
jQuery.sap.require('sap.ui.model.resource.ResourceModel');

com.novartis.uwf.lib.util.I18N = {
  setModel: function(component, name) {
    var name = name || 'i18nCustom';
    var path = jQuery.sap.getModulePath(component.getMetadata().getComponentName());
    var model = component.getModel(name);

    if (!model) {
      model = new sap.ui.model.resource.ResourceModel({
        bundleUrl: [path, 'i18n/i18n.properties'].join('/')
        //async: true
      });
      component.setModel(model, name);
    }

    return model;
  }
};
