/*&---------------------------------------------------------------------*
*& Development ID: ZDDE-00019502                                       *
*&                                                                     *
*& Shared Library                                                      *
*&                                                                     *
*&---------------------------------------------------------------------*
*& Change Log:                                                         *
*&                                                                     *
*& Init. Who          Date         Text                                *
*& JHU   HUNDEJU1     24-06-2015   Initial version CD 1200006098       *
*& JHU   HUNDEJU1     23-07-2015   Initial version CD 1200006975       *
*& JHU   HUNDEJU1     08-09-2015   Outsource i18n and device 					 *
*&																 CD 1200005515       								 *
*&---------------------------------------------------------------------*/

jQuery.sap.declare('com.novartis.uwf.lib.util.Component');
jQuery.sap.require('com.novartis.uwf.lib.util.Device');
jQuery.sap.require('com.novartis.uwf.lib.util.I18N');

var rootComponent = null,
	rootPath = null;

com.novartis.uwf.lib.util.Component = function(controller, forceRoot) {
	if (!controller) {
		return;
	}

	// Root component has already been set?
	if (rootComponent && rootPath && !forceRoot) {
		if (controller.getMetadata) {
			this.addController(controller.getMetadata().getName(), controller);
		}
		return;
	}

	// Otherwise root component must be set
	var component = controller.getMetadata().getParent();
	while (component && component.getClass() != sap.ui.core.UIComponent) {
		component = component.getClass().getMetadata().getParent();
	}

	if (!component) {
		throw new Error('Please provide a UI component as the root component.');
	}

	// Store root component
	rootComponent = controller;
	rootPath = jQuery.sap.getModulePath(controller.getMetadata().getLibraryName());
};

com.novartis.uwf.lib.util.Component.prototype = {
	controllers: {},

	getRootComponent: function() {
		return rootComponent;
	},

	getConfig: function() {
		return this.getRootComponent().getMetadata().getConfig();
	},

	getRootPath: function() {
		return rootPath;
	},

	getLibraryPath: function() {
		return jQuery.sap.getModulePath('com.novartis.uwf.lib');
	},

	addController: function(name, object) {
		this.controllers[name] = object;
	},

	getController: function(name) {
		return this.controllers[name];
	},

	setDeviceModel: function() {
		return com.novartis.uwf.lib.util.Device.setModel(this.getRootComponent());
	},

	setI18NModel: function() {
		return com.novartis.uwf.lib.util.I18N.setModel(this.getRootComponent());
	}
};
