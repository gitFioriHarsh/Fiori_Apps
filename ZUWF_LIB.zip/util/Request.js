/*&---------------------------------------------------------------------*
*& Development ID: ZDDE-00019502                                       *
*&                                                                     *
*& Shared Library                                                      *
*&                                                                     *
*&---------------------------------------------------------------------*
*& Change Log:                                                         *
*&                                                                     *
*& Init. Who          Date         Text                                *
*& JHU   HUNDEJU1     24-06-2015   Initial version CD 1200006098       *
*& JHU   HUNDEJU1     23-07-2015   Initial version CD 1200006975       *
*&---------------------------------------------------------------------*/

jQuery.sap.declare('com.novartis.uwf.lib.util.Request');

com.novartis.uwf.lib.util.Request = {
	waitFor: function() {
		// If arguments are empty or only a callback is given
		if (arguments.length === 0 || arguments.length === 1) {
			throw new Error('Specify at least one model and one callback');
		}

		// If there is only a callback
		var callback = arguments[arguments.length - 1];

		if (!jQuery.isFunction(callback)) {
			throw new Error('Last argument must be a function');
		}

		// Get models
		var models = [];

		for (var i = 0; i < arguments.length - 1; i++) {
			models.push(arguments[i]);
		}

		// Prepare callbacks
		var counter = {
			failed: 0,
			completed: 0
		};

		var callbacks = {
			failed: function() {
				counter.failed++;

				if (counter.failed === 1) {
					callback(new Error('One of the requests failed.'));
				}
			},

			completed: function() {
				counter.completed++;

				if (counter.completed === models.length) {
					callback.apply(callback, [null].concat(models));
				}
			}
		};

		// Attach callbacks
		for (var j = 0; j < models.length; j++) {
			models[j].attachRequestFailed(callbacks.failed);
			models[j].attachRequestCompleted(callbacks.completed);
		}

		return callbacks;
	}
};
