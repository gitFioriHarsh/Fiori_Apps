/*&---------------------------------------------------------------------*
*& Development ID: ZDDE-00019502                                       *
*&                                                                     *
*& Shared Library                                                      *
*&                                                                     *
*&---------------------------------------------------------------------*
*& Change Log:                                                         *
*&                                                                     *
*& Init. Who          Date         Text                                *
*& JHU   HUNDEJU1     24-06-2015   Initial version CD 1200006098       *
*& JHU   HUNDEJU1     23-07-2015   Initial version CD 1200006975       *
*&---------------------------------------------------------------------*/

jQuery.sap.declare('com.novartis.uwf.lib.util.Formatter');
jQuery.sap.require('com.novartis.uwf.lib.util.Component');
jQuery.sap.require('sap.ui.core.format.DateFormat');
jQuery.sap.require('sap.ui.core.format.NumberFormat');

com.novartis.uwf.lib.util.Formatter = {
	isNotEmpty: function(object) {
		if (object === null) {
			return false;
		}

		if (object === undefined) {
			return false;
		}

		if (object.toString && object.toString() == '') {
			return false;
		}

		return true;
	},

	shortToLongLanguage: function(short) {
		var languages = new com.novartis.uwf.lib.util.Component(this).getRootComponent().getModel('languages').getData();

		// Return if languages where not loaded
		if (!languages || !languages.LanguageCollection) {
			return short;
		}

		// Convert language object to array
		if (!this.languages) {
			var that = this;

			this.languages = [];
			jQuery.each(languages.LanguageCollection, function(key, language) {
				that.languages[language.short] = language.long;
			});
		}

		return this.languages[short];
	},

	decimalFormat: function(decimal, format) {
		if (!decimal && decimal !== 0)  {
			return '';
		}
		
		// Any format required?
		var formatter = null;
		switch (format) {
		case 'X':
			// 1,234,567.89
			formatter = sap.ui.core.format.NumberFormat.getFloatInstance({
				maxFractionDigits : 2,
				groupingEnabled : true,
				groupingSeparator : ',',
				decimalSeparator : '.'
			});

			break;
		case 'Y':
			// 1 234 567,89
			formatter = sap.ui.core.format.NumberFormat.getFloatInstance({
				maxFractionDigits : 2,
				groupingEnabled : true,
				groupingSeparator : ' ',
				decimalSeparator : ','
			});

			break;
		}
		
		if (formatter) {
			return formatter.format(decimal).toString();
		}
		
		return sap.ui.core.format.NumberFormat.getFloatInstance().format(decimal);
	},

	timeFormat: function(time, format) {
		if (!time) {
			return '';
		}
		
		// Any format required?
		var result = null;
		switch (format) {
		case '0':
			// 24 hour
			var hours = time.getHours(), minutes = time.getMinutes();

			minutes = minutes < 10 ? '0' + minutes : minutes;

			result = hours + ':' + minutes;
			break;
		case '1':
			// 12 hour (uppercase)
			var hours = time.getHours(), minutes = time.getMinutes(), ampm = hours >= 12 ? 'PM' : 'AM';

			hours = hours % 12;
			hours = hours ? hours : 12; // the hour '0' should be '12'
			hours = hours < 10 ? '0' + hours : hours;
			minutes = minutes < 10 ? '0' + minutes : minutes;

			result = hours + ':' + minutes + ' ' + ampm;
			break;
		case '2':
			// 12 hour (lowercase)
			var hours = time.getHours(), minutes = time.getMinutes(), ampm = hours >= 12 ? 'pm' : 'am';

			hours = hours % 12;
			hours = hours ? hours : 12; // the hour '0' should be '12'
			hours = hours < 10 ? '0' + hours : hours;
			minutes = minutes < 10 ? '0' + minutes : minutes;

			result = hours + ':' + minutes + ' ' + ampm;
			break;
		case '3':
			// 11 hour (uppercase)
			var hours = time.getHours(), minutes = time.getMinutes(), ampm = hours >= 12 ? 'PM' : 'AM';

			hours = hours % 12;
			hours = hours < 10 ? '0' + hours : hours;
			minutes = minutes < 10 ? '0' + minutes : minutes;

			result = hours + ':' + minutes + ' ' + ampm;
			break;
		case '4':
			// 11 hour (lowercase)
			var hours = time.getHours(), minutes = time.getMinutes(), ampm = hours >= 12 ? 'pm' : 'am';

			hours = hours % 12;
			hours = hours < 10 ? '0' + hours : hours;
			minutes = minutes < 10 ? '0' + minutes : minutes;

			result = hours + ':' + minutes + ' ' + ampm;
			break;
			
		default:
			result = sap.ui.core.format.DateFormat.getTimeInstance({ style: 'short' }).format(time);
		}

		return result;
	},

	dateFormat: function(date, format) {
		if (!date) {
			return '';
		}
		
		// Any format required?
		var pattern = com.novartis.uwf.lib.util.Formatter.dateFormatPattern(format);
		
		return sap.ui.core.format.DateFormat.getDateInstance({
			pattern : pattern
		}).format(date);
	},

	dateFormatPattern: function(format) {
		var pattern = null;

		// Depending on SAP format return pattern
		switch (format) {
		case '1':
			pattern = 'dd.MM.yyyy';
			break;
		case '2':
			pattern = 'MM/dd/yyyy';
			break;
		case '3':
			pattern = 'MM-dd-yyyy';
			break;
		case '4':
			pattern = 'yyyy.MM.dd';
			break;
		case '5':
			pattern = 'yyyy/MM/dd';
			break;
		case '6':
			pattern = 'yyyy-MM-dd';
			break;
		default:
			// Otherwise return current pattern
			pattern = sap.ui.core.format.DateFormat.getDateInstance().oFormatOptions.pattern;
		}

		return pattern;
	},

	stringToInt: function(string) {
		if (string == null) {
			return 0;
		}

		return parseInt(string, 10);
	},

	intToString: function(int) {
		if (int == null) {
			return '0';
		}

		return int.toString();
	},

	booleanToString: function(boolean) {
		if (boolean == null) {
			return 'false';
		}

		return boolean.toString();
	},

	invert: function(boolean) {
		if (boolean == null) {
			boolean = false;
		}

		return !boolean;
	},
	
	formatterIsZero: function (value) {
		return !value;
	},
	
	formatterIsNotZero: function (value) {
		return !!value;
	},
	
	isUndefined: function(value) {
		return value === undefined;
	},

	urgencyToState: function(urgency) {
		if (!urgency) {
			return 'None';
		}

		urgency = urgency.toString();
		if (urgency == '1') {
			return 'Success';
		}
		if (urgency == '2') {
			return 'Error';
		}

		return 'None';
	},

	integerToBooleanForModelLength: function(int) {
		if (int == null) {
			return false;
		} else if (int >= 2) {
			// only if model contains more than one entry, the link should be shown
			return true;
		} else {
			return false;
		}
	},

	formatterOnlyVisibleOnDesktop: function(isNoPhone) {
		if (isNoPhone) {
			// var runningOnPhone = sap.ui.Device.system.phone;
			//var runningOnTablet = sap.ui.Device.system.tablet;
			// var runningOnDesktop = sap.ui.Device.system.desktop;
			if (sap.ui.Device.system.tablet) {
					return false;
			}else {
				return true;
			}
		}
		
		return isNoPhone;
	}
};
