/*&---------------------------------------------------------------------*
*& Development ID: ZDDE-00019502                                       *
*&                                                                     *
*& Shared Library                                                      *
*&                                                                     *
*&---------------------------------------------------------------------*
*& Change Log:                                                         *
*&                                                                     *
*& Init. Who          Date         Text                                *
*& JHU   HUNDEJU1     24-06-2015   Initial version CD 1200006098       *
*& JHU   HUNDEJU1     23-07-2015   Initial version CD 1200006975       *
*&---------------------------------------------------------------------*/

jQuery.sap.declare('com.novartis.uwf.lib.control.ObjectListItem');
jQuery.sap.require('sap.m.library');
jQuery.sap.require('sap.m.ObjectListItem');

sap.m.ObjectListItem.extend('com.novartis.uwf.lib.control.ObjectListItem', {
  metadata : {
    properties : {
      color : {
        type : 'string'
      }
    },

    library : 'sap.m'
  },

  renderer : {
    render : function(rm, control) {
      // Call super renderer
      sap.m.ObjectListItem.prototype.getRenderer().render.apply(this, arguments);
    }
  }
});