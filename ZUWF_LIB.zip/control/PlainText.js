/*&---------------------------------------------------------------------*
*& Development ID: ZDDE-00019502                                       *
*&                                                                     *
*& Shared Library                                                      *
*&                                                                     *
*&---------------------------------------------------------------------*
*& Change Log:                                                         *
*&                                                                     *
*& Init. Who          Date         Text                                *
*& JHU   HUNDEJU1     24-06-2015   Initial version CD 1200006098       *
*& JHU   HUNDEJU1     23-07-2015   Initial version CD 1200006975       *
*&---------------------------------------------------------------------*/

jQuery.sap.declare('com.novartis.uwf.lib.control.PlainText');

sap.ui.core.Control.extend('com.novartis.uwf.lib.control.PlainText', {
	metadata: {
		properties: {
			text: {
				type: 'string'
			}
		},

		library: 'sap.m'
	},

	init: function() {},

	onBeforeRendering: function() {},

	onAfterRendering: function() {},

	renderer: {
		render: function(rm, control) {
			rm.write('<div ');
			rm.writeControlData(control);
			rm.writeClasses();
			rm.write('>');

			rm.write(control.getProperty('text'));

			rm.write('</div>');
		}
	}
});
