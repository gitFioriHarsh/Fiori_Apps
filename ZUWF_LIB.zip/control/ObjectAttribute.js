/*&---------------------------------------------------------------------*
*& Development ID: ZDDE-00019502                                       *
*&                                                                     *
*& Shared Library                                                      *
*&                                                                     *
*&---------------------------------------------------------------------*
*& Change Log:                                                         *
*&                                                                     *
*& Init. Who          Date         Text                                *
*& JHU   HUNDEJU1     24-06-2015   Initial version CD 1200006098       *
*& JHU   HUNDEJU1     23-07-2015   Initial version CD 1200006975       *
*&---------------------------------------------------------------------*/

jQuery.sap.declare('com.novartis.uwf.lib.control.ObjectAttribute');
jQuery.sap.require('sap.ui.core.Control');
jQuery.sap.require('sap.m.ObjectAttribute');

sap.m.ObjectAttribute.extend('com.novartis.uwf.lib.control.ObjectAttribute', {
	metadata: {
		properties: {
			state: {
				type: 'string'
			}
		},

		library: 'sap.m'
	},

	renderer: {
		render: function(rm, control) {
			if (control.getState()) {
				rm.addClass('sapMObjStatus');
				rm.addClass('sapMObjStatus' + control.getState());
			}

			sap.m.ObjectAttribute.prototype.getRenderer().render.apply(this, arguments);
		}
	}
});
