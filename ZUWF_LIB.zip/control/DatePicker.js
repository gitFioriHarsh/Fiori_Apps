/*&---------------------------------------------------------------------*
*& Development ID: ZDDE-00019502                                       *
*&                                                                     *
*& Shared Library                                                      *
*&                                                                     *
*&---------------------------------------------------------------------*
*& Change Log:                                                         *
*&                                                                     *
*& Init. Who          Date         Text                                *
*& JHU   HUNDEJU1     24-06-2015   Initial version CD 1200006098       *
*& JHU   HUNDEJU1     23-07-2015   Initial version CD 1200006975       *
*&---------------------------------------------------------------------*/

jQuery.sap.declare('com.novartis.uwf.lib.control.DatePicker');
jQuery.sap.require('com.novartis.uwf.lib.util.Component');
jQuery.sap.require('com.novartis.uwf.lib.util.Misc');

jQuery.sap.require('sap.m.library');
jQuery.sap.require('sap.m.DatePicker');
jQuery.sap.require('sap.m.InputBase');

sap.m.DatePicker.extend('com.novartis.uwf.lib.control.DatePicker', {
	metadata : {
		properties : {
			validFrom : {
				type : 'object'
			}
		}
	},

	_fillDateRange : function() {

		var oDate = this.getDateValue();

		if (oDate) {
			// Check if date contains year 9999. if this is the case the popup
			// for selection the date should be set to the start date of the role
			// otherwise it may crash
			if (oDate.toString().indexOf("9999") > -1) {
				oDate = this.getValidFrom();
			}
			this._oCalendar.focusDate(new Date(oDate.getTime()));
			if (!this._oDateRange.getStartDate() || this._oDateRange.getStartDate().getTime() != oDate.getTime()) {
				this._oDateRange.setStartDate(new Date(oDate.getTime()));
			}
		} else if (this._oDateRange.getStartDate()) {
			this._oDateRange.setStartDate(undefined);
		}

	},

	setValidFrom : function(oDate) {
		if (jQuery.sap.equal(this.getValidFrom(), oDate)) {
			return this;
		}

		if (oDate && !(oDate instanceof Date)) {
			throw new Error("Date must be a JavaScript date object; " + this);
		}

		if (oDate && (oDate.getTime() < this._oMinDate.getTime() || oDate.getTime() > this._oMaxDate.getTime())) {
			this._bValid = false;
			jQuery.sap.assert(this._bValid, "Date must be in valid range");
		} else {
			this._bValid = true;
			this.setProperty("validFrom", oDate, true); // no rerendering
		}
	},

	renderer : {}

});
