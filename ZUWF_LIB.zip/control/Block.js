/*&---------------------------------------------------------------------*
*& Development ID: ZDDE-00019502                                       *
*&                                                                     *
*& Shared Library                                                      *
*&                                                                     *
*&---------------------------------------------------------------------*
*& Change Log:                                                         *
*&                                                                     *
*& Init. Who          Date         Text                                *
*& JHU   HUNDEJU1     24-06-2015   Initial version CD 1200006098       *
*& JHU   HUNDEJU1     23-07-2015   Initial version CD 1200006975       *
*&---------------------------------------------------------------------*/

jQuery.sap.declare('com.novartis.uwf.lib.control.Block');
jQuery.sap.require('sap.ui.core.Control');

sap.ui.core.Control.extend('com.novartis.uwf.lib.control.Block', {
	metadata: {
		properties: {
			div: {
				type : 'boolean', 
				defaultValue : true
			}
		},

		library: 'sap.m',

		defaultAggregation: 'content',

		aggregations: {
			content: {
				type: 'sap.ui.core.Control',
				multiple: true
			}
		}
	},

	init: function() {},

	onBeforeRendering: function() {},

	onAfterRendering: function() {},

	renderer: {
		render: function(rm, control) {
			if (control.getDiv()) {
				rm.write('<div ');
				rm.writeControlData(control);
				rm.addClass('block');
				rm.writeClasses();
	
				if (control._invisible) {
					rm.addStyle('visibility', 'hidden');
					rm.writeStyles();
				}
				rm.write('>');
			}

			var controls = control.getAggregation('content');
			if (controls) {
				controls.forEach(function(control) {
					rm.renderControl(control);
				});
			}

			if (control.getDiv()) {
				rm.write('</div>');
			}
		}
	}
});
