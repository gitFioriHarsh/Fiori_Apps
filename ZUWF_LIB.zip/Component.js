/*&---------------------------------------------------------------------*
*& Development ID: ZDDE-00019502                                       *
*&                                                                     *
*& Fiori Launchpad Enhancement                                         *
*&                                                                     *
*&---------------------------------------------------------------------*
*& Change Log:                                                         *
*&                                                                     *
*& Init. Who          Date         Text                                *
*& JHU   HUNDEJU1     24-06-2015   Initial version CD 1200006098       *
*& JHU   HUNDEJU1     23-07-2015   Initial version CD 1200006975       *
*&---------------------------------------------------------------------*/

jQuery.sap.declare("com.novartis.uwf.lib.Component");

sap.ui.core.UIComponent.extend("com.novartis.uwf.lib.Component", {
	metadata: {
		name: 'Universal Workflow - Library',
		version: '1.0',
		includes: [],
		dependencies: {
			libs: ['sap.m', 'sap.ui.layout'],
			components: []
		},

		config: {}
	}
});
