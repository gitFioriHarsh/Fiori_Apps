/*&---------------------------------------------------------------------*
*& Development ID: ZDDE-00019502                                       *
*&                                                                     *
*& Shared Library                                                      *
*&                                                                     *
*&---------------------------------------------------------------------*
*& Change Log:                                                         *
*&                                                                     *
*& Init. Who          Date         Text                                *
*& JHU   HUNDEJU1     24-06-2015   Initial version CD 1200006098       *
*& JHU   HUNDEJU1     23-07-2015   Initial version CD 1200006975       *
*&---------------------------------------------------------------------*/

jQuery.sap.declare('com.novartis.uwf.lib.model.TaskProcessing');

var taskProcessing = null;

com.novartis.uwf.lib.model.TaskProcessing = {
    getServiceURL: function(multiOrigin) {
        // Is multi origin?
        var origin = 'LOCAL_GW';
        if (multiOrigin) {
            origin = 'mo';
        }
        
        // Concatenate service
        var service = '/sap/opu/odata/sap/ZUWF_TASKPROCESSING_V2_SRV;' + origin + ';v=2/';
        
        return service;
    },

    load: function() {
        if (!taskProcessing) {
            taskProcessing = new sap.ui.model.odata.ODataModel(this.getServiceURL(), true);
            taskProcessing.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);
            taskProcessing.setUseBatch(true);
        }

        return taskProcessing;
    },
    
    read: function(collections, opt, callback) {
        var options = {
                async: true
            },
            batchReads = [];

        // Prepare options
        if (!callback) {
            callback = opt;
        } else {
            $.extend(options, opt);
        }
        
        // Create if necessary
        if (!taskProcessing) {
            com.novartis.uwf.lib.model.TaskProcessing.load();
        }
        
        // Add batch operations
        jQuery.each(collections, function(index, collection) {
          batchReads.push(taskProcessing.createBatchOperation(collection, 'GET'));
        });
        taskProcessing.addBatchReadOperations(batchReads);

        // Read everything at once
        taskProcessing.submitBatch(function(data) {
            callback.apply(this, [data, taskProcessing].concat(data.__batchResponses));
        }, function() {
            jQuery.sap.log.fatal('Error while loading model');
        }, options.async);
    }
};
