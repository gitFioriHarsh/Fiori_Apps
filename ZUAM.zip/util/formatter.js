sap.ui.define([], function () {
	"use strict";
	return {
		formateButtonType:function(val){
			if(val === "X"){
				return "Reject";
			}
			return "Accept";
		},
		shouldVisible: function (val) {
			if (val === "WFP" || val === "R&D") {
				return true;
			} 
				return false;
		},
		shouldEnabled: function (val) {
			if (val == "X") {
				return true;
			} else {
				return false;
			}

		},
		buttonTxtEntity: function (val) {
			if (val !== undefined && val !== null && val.includes("E")) {
				return "Entity";
			}
		},
		buttonTxtMarket: function (val) {
			if (val !== undefined && val !== null && val.includes("M")) {
				return "Market";
			}
		},
		buttonTxtCompany: function (val) {
			if (val !== undefined && val !== null && val.includes("B")) {
				return "Company Code";
			}
		},
		buttonTxtCost: function (val) {
			if (val !== undefined && val !== null && val.includes("C")) {
				return "Cost Center";
			}
		},

		buttonTxtProfit: function (val) {
			if (val !== undefined && val !== null && val.includes("P")) {
				return "Profit Center";
			}
		},

		formatApplication: function (value) {
			return value.split("~")[0];
		},
		formatSubApplication: function (value) {
			return value.split("~")[1];
		},
		formatUamRole: function (value) {
			return value.split("~")[2];
		},
		availableState: function (status) {
			if (status !== null && status !== undefined) {
				var statusLower = status.toLowerCase();

				switch (statusLower) {
				case "approved":
					return 7;
				case "cancelled":
					return 1;
				case "decision pending":
					return 6;
				case "error":
					return 1;
				case "rejected":
					return 8;
				case "partially approved":
					return 5;
				default:
					return 10;
				}
			}

		},
		workdayState: function(Status){
			if (Status !== null && Status !== undefined) {
				var statusLower = Status.toLowerCase();

				switch (statusLower) {
				case "open":
					return 6;
				case "nda pending":
					return 6;
				case "completed":
					return 7;
				case "nda accepted":
					return 7;
				case "expired":
					return 8;
				case "discontinued":
					return 8;
				default:
					return 10;
				}
			}	
		}
	};

});