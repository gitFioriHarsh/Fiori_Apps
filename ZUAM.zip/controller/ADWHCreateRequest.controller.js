sap.ui.define([
	"com/alcon/UAM/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageBox",
	"sap/m/MessageToast",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/core/Fragment",
	"sap/ui/model/odata/v2/ODataModel",
	"sap/ui/core/routing/History",
	"com/alcon/UAM/util/formatter",
	"sap/m/GroupHeaderListItem"
], function (BaseController, JSONModel, MessageBox, MessageToast, Filter, FilterOperator, Fragment, ODataModel, History, formatter,
	GroupHeaderListItem) {
	"use strict";
	var a;
	var busyDialog = new sap.m.BusyDialog();
	var selMarketModel = new JSONModel();
	var selEntityModel = new JSONModel();
	var addSel = false,
		removeSel = false;
	var uamSelPath = "";
	var treeSelValMarket = "",
		treeSelValEntity = "";
	var hierSelEntityArray = [];
	var hierSelMarketArray = [];
	var hierField = ["Application", "CHILDID", "Consolidated_View", "Department_Role", "DrillState", "EMflag", "HEIR_NAME", "HIEID", "ID",
		"NAME", "NODEID", "OBJ", "PARENTID", "PID", "Segregation", "Subapplication", "System_ID", "TLEVEL", "TXT", "UAM_Role", "User_ID",
		"selected"
	];

	return BaseController.extend("com.alcon.UAM.controller.ADWHCreateRequest", {
		formatter: formatter,
		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.alcon.UAM.view.createRequest
		 */
		onInit: function () {
			jQuery.sap.includeStyleSheet("/sap/bc/ui5_ui5/sap/zuam/css/style.css");
			var sRootPath = jQuery.sap.getModulePath("zuam");
			var location = $(location).attr('href');

			this.getOwnerComponent().getRouter().getRoute("ADWHCreateRequest").attachMatched(this._onRouteMatched, this);
			this.getView().addStyleClass(this.getContentDensityClass());
			this._wizard = this.byId("UserRoleAccessWizard");
			this._oNavContainer = this.byId("navContainer");
			this._oDynamicPage = this.getView();

			var oModel = this.getOwnerComponent().getModel("ZAL_CREATE_REQUEST_SRV_01");
			oModel.setSizeLimit(100000);
			this.getView().setModel(oModel);
			var flagModel = new JSONModel({
				flag: "false"
			});
			sap.ui.getCore().setModel(flagModel, "flagModel");

		},

		_onRouteMatched: function (oEvent) {
			var error = ["", null, undefined];
			if (error.includes(this.getOwnerComponent().applId)) {
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("RouteMain");
			} else {
				this.byId("cbSystem").setSelectedKey("PF1");
				this.byId("cbDepartment").setSelectedKey("");

				this.byId("cbSegregation").setSelectedKey("");
				this.byId("cbCons").setSelectedKey("");
				this.byId("cbSegregation").setEnabled(false);

				this.byId("cbCons").setEnabled(false);
				this.byId("taReason").setValue("");
				this.byId("txtApp").setText(this.getOwnerComponent().applName);

				this.getOwnerComponent().getModel("OtherUserModel1").setData({});
				this.clearModelData(); //this is to clear all the model data
				var currentStep = this.getView().byId("UserRoleAccessWizard").getAssociation("currentStep");
				if (currentStep.includes("roleSelection")) {
					this.getView().byId('UserRoleAccessWizard').previousStep();
					this.getView().byId('UserRoleAccessWizard').previousStep();
				} else if (currentStep.includes("departmentSelection")) {
					this.getView().byId('UserRoleAccessWizard').previousStep();
				}
			}
		},
		onNavBack: function () {

			MessageBox.warning("Your data may be lost. Are you sure to continue?", {
				actions: [MessageBox.Action.YES, MessageBox.Action.NO],
				onClose: function (oAction) {

					if (oAction === MessageBox.Action.YES) {
						this.clearModelData();
						var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
						oRouter.navTo("RouteMain");
					} else if (oAction === MessageBox.Action.NO) {
						return;
					}
				}.bind(this)
			});

		},

		resetCreateReqModel: function () {
			var oMod = sap.ui.getCore().getModel("createReqModel");
			oMod.setProperty("/selfFlag", "true");
			oMod.setProperty("/user_id", "");
			oMod.setProperty("/application_id", "");
			oMod.setProperty("/aaplication_desc", "");
			oMod.setProperty("/system_id", "PF1");
			oMod.setProperty("/start_date", "");
			oMod.setProperty("/end_date", "");
			oMod.setProperty("/job_title", "");
			oMod.setProperty("/segr_level", "");
			oMod.setProperty("/reason", "");
			oMod.setProperty("/consolidation_flag", "");

		},
		liveChangeFunction: function (event) {
			var str = event.getSource().getValue().toUpperCase();
			event.getSource().setValue(str);

		},

		onAfterRendering: function () {
			var that = this;
			var getDetailsrv = this.getOwnerComponent().getModel("ZAL_CREATE_REQUEST_SRV_01");
			sap.ui.getCore().getModel("createReqModel");

			this.byId("txtApp").setText(this.getOwnerComponent().applName);

			this.byId("cbSystem").setSelectedKey("PF1");
		},

		onForSelfSelect: function (oEvent) {
			if (oEvent !== "" && oEvent.getParameters()["selected"]) {
				this.byId("cbRTForOther").setSelected(false);
				this.byId("lbl521MgrId").setVisible(true);
				this.byId("in521MgrNameId").setVisible(true);
				this.byId("lbl521Id").setVisible(false);
				this.byId("in521Id").setVisible(false);
				this.byId("in521Id").setValue("");
				sap.ui.getCore().getModel("createReqModel").setProperty("/selfFlag", "true");
				this.byId("idOtherDet").setVisible(false);

			} else {
				this.byId("cbRTForOther").setSelected(false);
				this.byId("cbRTForSelf").setSelected(true);
				this.byId("lbl521Id").setVisible(false);
				this.byId("in521Id").setVisible(false);
				this.byId("in521Id").setValue("");
				this.byId("idOtherDet").setVisible(false);

			}
			this.onChangeSystem();

		},
		onForOtherSelect: function (oEvent) {
			if (oEvent.getParameters()["selected"]) {
				this.byId("cbRTForSelf").setSelected(false);
				this.byId("lbl521MgrId").setVisible(false);
				this.byId("in521MgrNameId").setVisible(false);
				this.byId("lbl521Id").setVisible(true);
				this.byId("in521Id").setVisible(true);
				this.byId("in521Id").setValue("");
				sap.ui.getCore().getModel("createReqModel").setProperty("/selfFlag", "false");
			} else {
				this.byId("cbRTForOther").setSelected(true);
			}
			this.onChangeSystem();

		},
		getList: function (data) {
			var list = [];

			for (var i in data) {
				list.push({
					"value": data[i].getAggregation("cells")[0].getText()
				});
			}
			return list;
		},
		onReasonChange: function () {
			if (this.byId("taReason").getValue() != "") {
				this.byId("taReason").setValueState("None");
			}
		},
		completedHandler: function () {
			var checkSubAppl = false,
				checkUamrole = false;
			var key = this.byId("itbAdwhRole").getSelectedKey();
			var apps, uamModel, subApplModel;
			if (key === "addRole") {
				apps = this.byId("liApplication").getSelectedItems();
				uamModel = this.getOwnerComponent().getModel("UamRoleModel");
				subApplModel = this.getOwnerComponent().getModel("SubApplicationModel");
			} else if (key === "removeRole") {
				apps = this.byId("liApplicationRemove").getSelectedItems();
				uamModel = this.getOwnerComponent().getModel("UamRoleRemoveModel");
				subApplModel = this.getOwnerComponent().getModel("SubApplicationRemoveModel");
			}

			//front end validation
			//check any sub application is selected
			for (let m in subApplModel.getData()) {
				if (subApplModel.getData()[m].selected === true) {
					checkSubAppl = true;
				}
			}
			for (let m in uamModel.getData()) {
				if (uamModel.getData()[m].selected === true) {
					checkUamrole = true;
				}
			}

			if (this.byId("taReason").getValue() === "") {
				this.byId("taReason").setValueState("Error");
				return;
			}
			if (apps.length == 0) {
				MessageToast.show("Please select any one application atleast");
				return;
			}
			if (!checkSubAppl) {
				MessageToast.show("Please select any one subapplication atleast");
				return;
			}
			if (!checkUamrole) {
				MessageToast.show("Please select any one role atleast");
				return;
			}
			var data = {};

			var hierSelArrVal = [];

			if (key === "addRole") {
				//getting the selected Hierachy value for both market and entity
				for (let k in uamModel.getData()) {
					for (let m in uamModel.getData()[k]["entity"]) {
						data = {};
						for (let i in hierField) {
							if (hierField[i] !== "selected" && hierField[i] !== "selectedPath") {
								data[hierField[i]] = uamModel.getData()[k]["entity"][m][hierField[i]];
							}
						}
						hierSelArrVal.push(data);
					}

				}
				for (let j in uamModel.getData()) {
					for (let m in uamModel.getData()[j]["market"]) {
						data = {};
						for (let i in hierField) {
							if (hierField[i] !== "selected" && hierField[i] !== "selectedPath") {
								data[hierField[i]] = uamModel.getData()[j]["market"][m][hierField[i]];
							}
						}
						hierSelArrVal.push(data);
					}
				}
			} else if (key === "removeRole") {
				let oHierModel = this.getOwnerComponent().getModel("HiearchyRemoveModel").getData();
				let sysId = this.getView().byId("cbSystem").getSelectedKey();
				let deptId = this.getView().byId("cbDepartment").getSelectedKey();
				let segId = this.getView().byId("cbSegregation").getSelectedKey();
				let consId = this.getView().byId("cbCons").getSelectedKey();
				let requestedUser = (this.byId("cbRTForSelf").getSelected()) ? this.getOwnerComponent().getModel("LogInUserModel").getData().User_ID :
					this
					.byId("in521Id").getValue();
				for (let item of oHierModel) {
					if (item.selected) {
						let dat = {
							"Application": item.hier.split(" / ")[0],
							"Subapplication": item.hier.split(" / ")[1],
							"UAM_Role": item.hier.split(" / ")[2],
							"HEIR_NAME": item.hier.split(" / ")[3],
							"Consolidated_View": consId,
							"Department_Role": deptId,
							"ID": item.node,
							"OBJ": item.obj,
							"Segregation": segId,
							"System_ID": sysId,
							"User_ID": requestedUser
						}
						hierSelArrVal.push(dat);
					}
				}
			}
			sap.ui.getCore().getModel("createReqModel").setProperty("/selType", (key === "addRole") ? "Add Role" : "Remove Role");
			sap.ui.getCore().getModel("createReqModel").setProperty("/application", uamModel.getData());

			sap.ui.getCore().getModel("createReqModel").setProperty("/hier", hierSelArrVal);
			sap.ui.getCore().getModel("createReqModel").setProperty("/reason", this.byId("taReason").getValue());

			sap.ui.getCore().getModel("createReqModel").setProperty("/system_id", this.byId("cbSystem").getSelectedKey());
			sap.ui.getCore().getModel("createReqModel").setProperty("/start_date", this.byId("DP1").getValue());
			sap.ui.getCore().getModel("createReqModel").setProperty("/end_date", this.byId("DP2").getValue());

			var check = sap.ui.getCore().getModel("createReqModel").getProperty("/selfFlag");
			sap.ui.getCore().getModel("createReqModel").setProperty("/requestor_id", this.byId("selfUserID").getText());
			if (check == "false") {
				sap.ui.getCore().getModel("createReqModel").setProperty("/full_name", this.byId("otherName").getText());
				sap.ui.getCore().getModel("createReqModel").setProperty("/line_manager_name", this.byId("managerfieldval").getValue());
				sap.ui.getCore().getModel("createReqModel").setProperty("/user_dept", this.byId("otherDept").getText());
				sap.ui.getCore().getModel("createReqModel").setProperty("/user_country", this.byId("otherCountry").getText());
				sap.ui.getCore().getModel("createReqModel").setProperty("/user_jobtitle", this.byId("otherJobTitle").getText());

			} else {
				sap.ui.getCore().getModel("createReqModel").setProperty("/full_name", this.byId("selfName").getTitle());
				sap.ui.getCore().getModel("createReqModel").setProperty("/line_manager_name", this.byId("selfLineManager").getText());
				sap.ui.getCore().getModel("createReqModel").setProperty("/user_dept", this.byId("selfDept").getText());
				sap.ui.getCore().getModel("createReqModel").setProperty("/user_country", this.byId("selfCountry").getText());
				sap.ui.getCore().getModel("createReqModel").setProperty("/user_jobtitle", this.byId("selfJobTitle").getText());
			}

			Fragment.load({
				name: "com.alcon.UAM.view.fragments.ADWHReviewPage",
				controller: this
			}).then(function (oWizardReviewPage) {
				this._oWizardReviewPage = oWizardReviewPage;
				this._oNavContainer.addPage(this._oWizardReviewPage);

				sap.ui.getCore().byId("wizardBranchingReviewPage").setModel(sap.ui.getCore().getModel("createReqModel"), "createReqModel");
				var details = sap.ui.getCore().getModel('createReqModel').oData.selType;
				sap.ui.getCore().byId('tblHierTable').setHeaderText(details);
				this._oNavContainer.to(this._oWizardReviewPage); ////to bechecked
			}.bind(this));

		},
		_handleMessageBoxOpen: function (sMessage, sMessageBoxType) {
			MessageBox[sMessageBoxType](sMessage, {
				actions: [MessageBox.Action.YES, MessageBox.Action.NO],
				onClose: function (oAction) {

					if (oAction === MessageBox.Action.YES) {
						this._wizard.discardProgress(this._wizard.getSteps()[0]);
						this.handleNavBackToList();
					}
				}.bind(this)
			});
		},
		toCancel: function () {
			this.closeAction();

		},
		handleNavBackToList: function () {
			this._navBackToStep(this.byId("userSelection"));
			this.resetCreateReqModel();
		},

		_navBackToStep: function (step) {
			var fnAfterNavigate = function () {
				this._wizard.goToStep(step);
				this._oNavContainer.detachAfterNavigate(fnAfterNavigate);
			}.bind(this);

			this._oNavContainer.attachAfterNavigate(fnAfterNavigate);
			this._oNavContainer.to(this._oDynamicPage);
		},

		onChangeRequestType: function () {

			if (this.byId("cbRequestType").getValue() === "Other User") {
				this.byId("lbl521Id").setVisible(true);
				this.byId("in521Id").setVisible(true);
			}
		},
		changeDateValueState: function (event) {
			var selKey = event.getSource().getValue();
			sap.ui.getCore().getModel("createReqModel").setProperty("/start_date", selKey);
			if (selKey != "") {
				event.getSource().setValueState("None");
			}
		},
		handleChange: function (event) {
			var selKey = event.getSource().getValue();
			sap.ui.getCore().getModel("createReqModel").setProperty("/end_date", selKey);
			if (selKey != "") {
				event.getSource().setValueState("None");
			}
		},

		changeValueState: function (event) {
			var selKey = event.getSource().getSelectedKey();
			var currentStep = this.getView().byId("UserRoleAccessWizard").getAssociation("currentStep");
			if (currentStep.includes("roleSelection")) {
				this.byId("itbAdwhRole").setSelectedKey("addRole");
				this.getView().byId('UserRoleAccessWizard').previousStep();
			}
			if (selKey != "") {
				event.getSource().setValueState("None");
				this.byId("itbAdwhRole").setSelectedKey("addRole");
			}
			var sId = event.getSource().sId;
			if (sId.includes("cbDepartment")) {
				sap.ui.getCore().getModel("createReqModel").setProperty("/job_title", selKey);
				this.byId("cbSegregation").setEnabled(true);
				this.byId("cbSegregation").setSelectedKey("");
				this.byId("cbCons").setEnabled(false);
				this.byId("cbCons").setSelectedKey("");
				this.filterSegregation(selKey);
				this.byId("itbAdwhRole").setSelectedKey("addRole");

			}
			if (sId.includes("cbSegregation")) {
				sap.ui.getCore().getModel("createReqModel").setProperty("/segr_level", selKey);
				this.byId("cbCons").setEnabled(true);
				this.byId("cbCons").setSelectedKey("");
				this.filterConsolidation(this.byId("cbDepartment").getSelectedKey(), selKey);
				this.byId("itbAdwhRole").setSelectedKey("addRole");
			}
			if (sId.includes("cbCons")) {
				sap.ui.getCore().getModel("createReqModel").setProperty("/consolidation_flag", selKey);
				this.byId("itbAdwhRole").setSelectedKey("addRole");
			}
		},
		setBtnVisible() {
			sap.ui.getCore().byId("id1--btOK").setVisible(true);
		},

		onListApplChange: function (oEvent) {
			//flag to know which section is selected
			addSel = true;
			removeSel = false;
			this.onApplicationChange(oEvent.getParameter("listItem").getAggregation("cells")[0].getText(), oEvent.getParameter("selected"));
		},
		onListApplChangeRemove: function (oEvent) {
			//flag to know which section is selected
			addSel = false;
			removeSel = true;
			this.onApplicationChangeRemove(oEvent.getParameter("listItem").getAggregation("cells")[0].getText(), oEvent.getParameter("selected"));
		},

		onSubApplChange: function (oEvent) {
			var selPath = oEvent.getSource().getBindingInfo("selected")["binding"].getContext().getPath();
			var subApplName = this.getOwnerComponent().getModel("SubApplicationModel").getProperty(selPath).SubApplication
			this.onSubApplicationChange(subApplName, oEvent.getParameter("selected"), "ADWH");
		},
		onSubApplChangeRemove: function (oEvent) {
			var selPath = oEvent.getSource().getBindingInfo("selected")["binding"].getContext().getPath();
			var subApplName = this.getOwnerComponent().getModel("SubApplicationRemoveModel").getProperty(selPath).SubApplication
			this.onSubApplicationChangeRemove(subApplName, oEvent.getParameter("selected"), "ADWH");
		},
		onUamRoleChange: function (oEvent) {
			var selPath = oEvent.getSource().getBindingInfo("selected")["binding"].getContext().getPath();
			var uamRoleName = this.getOwnerComponent().getModel("UamRoleModel").getProperty(selPath).UamRole;
			this.onBusRoleChange(selPath, oEvent.getParameter("selected"), "ADWH");
		},
		onUamRoleChangeRemove: function (oEvent) {
			var selPath = oEvent.getSource().getBindingInfo("selected")["binding"].getContext().getPath();
			var uamRoleName = this.getOwnerComponent().getModel("UamRoleRemoveModel").getProperty(selPath).UamRole;
			this.onBusRoleChangeRemove(selPath, oEvent.getParameter("selected"), "ADWH");
		},
		onHierarchyChangeRemove: function (oEvent) {
			var selPath = oEvent.getSource().getBindingInfo("selected")["binding"].getContext().getPath();
		},
		onReadWriteSelect: function (oEvent) {
			console.log(oEvent);
			var selPath = oEvent.getSource().getBindingInfo("selected")["binding"].getContext().getPath();
			var value = this.getOwnerComponent().getModel("UamRoleModel").getProperty(selPath);
			var selValue = oEvent.getSource().getProperty("text");
			if (oEvent.getParameter("selected")) {
				value.ReadWriteSelect = true;
				value.ReadOnlySelect = false;
			} else {
				value.ReadWriteSelect = false;
			}
			this.getOwnerComponent().getModel("UamRoleModel").refresh(true);
		},
		onReadOnlySelect: function (oEvent) {
			console.log(oEvent);
			var selPath = oEvent.getSource().getBindingInfo("selected")["binding"].getContext().getPath();
			var value = this.getOwnerComponent().getModel("UamRoleModel").getProperty(selPath);
			var selValue = oEvent.getSource().getProperty("text");
			if (oEvent.getParameter("selected")) {
				value.ReadOnlySelect = true;
				value.ReadWriteSelect = false;
			} else {
				value.ReadOnlySelect = false;
			}
			this.getOwnerComponent().getModel("UamRoleModel").refresh(true);
		},

		onChange521Id: function (User_ID) {
			var getDetailsrv = this.getOwnerComponent().getModel("ZAL_CREATE_REQUEST_SRV_01");
			var that = this;
			var selUser = User_ID;

			sap.ui.getCore().getModel("createReqModel").setProperty("/user_id", selUser);
			var oFilter = new Array();
			var usrFilter = new Filter("User_ID", FilterOperator.EQ, selUser);
			oFilter.push(usrFilter);

			var omod = this.getView().getModel("List521Model");
			this.getView().setModel(omod, "List521Model");

			getDetailsrv.read("/User_DetailsSet(User_ID='" + selUser + "')", {

				success: function (oData) {
					that.getOwnerComponent().getModel("OtherUserModel1").setData(oData);
					sap.ui.getCore().getModel("createReqModel").setProperty("/line_manager_name", oData.Line_Manager);
					sap.ui.getCore().getModel("createReqModel").setProperty("/line_manager_id", oData.Line_Manager_ID);
				},
				error: function (oError) {
					var errorMsg = that.errorMsgParse(oError);
					MessageBox.error(errorMsg);
					busyDialog.close();
				}
			});
			var usr_name = this.getOwnerComponent().getModel("OtherUserModel1").getProperty("/Name");

			this.byId("managerfield").setVisible(true);
			this.byId("managerfieldval").setVisible(true);

			this.byId("idOtherDet").setVisible(true);
		},

		toOpenHierarchy: function (oEvent) {
			uamSelPath = oEvent.getSource().getParent()["oPropagatedProperties"]["oBindingContexts"]["UamRoleModel"].getPath();
			var rowValue = this.getOwnerComponent().getModel("UamRoleModel").getProperty(uamSelPath);
			var sysId = this.getView().byId("cbSystem").getSelectedKey();
			var appId = this.getOwnerComponent().applId;
			var deptId = this.getView().byId("cbDepartment").getSelectedKey();
			var segId = this.getView().byId("cbSegregation").getSelectedKey();
			var consId = this.getView().byId("cbCons").getSelectedKey();
			var appl = rowValue.Id.split("~")[0];;
			var subAppl = rowValue.Id.split("~")[1];
			var role = rowValue.Id.split("~")[2];
			var flag = rowValue.EmFlag; //the value can be EM(Entity & Market), E(Entity) & M(Market) 
			var src = (oEvent.getSource().getProperty("text") === "Entity") ? "ENTITY" : "MARKET";

			this.getHierarchy(sysId, appId, deptId, segId, consId, appl, subAppl, role, flag, uamSelPath, src);
		},

		onChangeMarketType: function (oEvent) {
			let key = oEvent.getSource().mProperties.selectedKey;
			if (key !== "ws" && key !== "cs") {
				this.byId("sfMarketSearchType").setSelectedKey("ws");
			}
		},
		onChangeEntityType: function (oEvent) {
			let key = oEvent.getSource().mProperties.selectedKey;
			if (key !== "ws" && key !== "cs") {
				this.byId("sfEntitySearchType").setSelectedKey("ws");
			}
		},
		onSearchMarket: function (oEvent) {
			const val = oEvent.getParameter("query").trim();
			var filter;
			let type = sap.ui.getCore().byId("sfMarketSearchType").getSelectedKey();

			if (type === "ws") {
				filter = new Filter({
					filters: [
						new Filter("ID", FilterOperator.Contains, val),
						new Filter("TXT", FilterOperator.Contains, val),
					],
					and: false,
				});
			} else if (type === "cs") {
				filter = new Filter({
					filters: [
						new Filter("ID", FilterOperator.EQ, val),
						new Filter("TXT", FilterOperator.EQ, val),
					],
					and: false,
				});
			}

			sap.ui.getCore().byId("treeHierMarket").getBinding("rows").filter(val ? filter : null);
			sap.ui.getCore().byId("treeHierMarket").expandToLevel(val ? 13 : 1);
		},
		onSearchEntity: function (oEvent) {
			const val = oEvent.getParameter("query").trim();
			var filter;
			let type = sap.ui.getCore().byId("sfEntitySearchType").getSelectedKey();

			if (type === "ws") {
				filter = new Filter({
					filters: [
						new Filter("ID", FilterOperator.Contains, val),
						new Filter("TXT", FilterOperator.Contains, val),
					],
					and: false,
				});
			} else if (type === "cs") {
				filter = new Filter({
					filters: [
						new Filter("ID", FilterOperator.EQ, val),
						new Filter("TXT", FilterOperator.EQ, val),
					],
					and: false,
				});
			}

			sap.ui.getCore().byId("treeHierEntity").getBinding("rows").filter(val ? filter : null);
			sap.ui.getCore().byId("treeHierEntity").expandToLevel(val ? 13 : 0);
		},

		onNextStep: function (oEvent) {
			var that = this;
			var busApplName = "ADWH";

			if (oEvent.getParameters()["index"] === 2) {

				var sysId = this.getView().byId("cbSystem").getSelectedKey();
				var appId = this.getOwnerComponent().applId;
				var sDate = this.getView().byId("DP1").getValue();
				var eDate = this.getView().byId("DP2").getValue();
				var startDate = new Date(sDate.split("-")[2], sDate.split("-")[1], sDate.split("-")[0]);
				var endDate = new Date(eDate.split("-")[2], eDate.split("-")[1], eDate.split("-")[0]);
				if (this.byId("cbRTForOther").getSelected() && this.byId("in521Id").getValue() === "") {
					this.getView().byId("in521Id").setValueState("Error");
					return;
				}
				if ((sysId !== "" && appId != "") && (sDate !== "" && eDate !== "") && (this.isValidDate(startDate) && this.isValidDate(endDate)) &&
					(startDate <= endDate)) {
					this.getDepartSeg(sysId, appId, busApplName);
				} else {
					if (sysId == "") {
						this.getView().byId("cbSystem").setValueState("Error");
					}

					if (sDate == "" || !(this.isValidDate(startDate))) {
						this.getView().byId("DP1").setValueState("Error");
					}
					if (eDate == "" || !(this.isValidDate(endDate))) {
						this.getView().byId("DP2").setValueState("Error");
					}
					if (startDate > endDate) {
						this.getView().byId("DP2").setValueState("Error");
					}
					this.getView().byId('UserRoleAccessWizard').previousStep();
				}
			} else if (oEvent.getParameters()["index"] === 3) {
				this.byId("taReason").setValue("");
				var sysId = this.getView().byId("cbSystem").getSelectedKey();
				var appId = this.getOwnerComponent().applId;
				var deptId = this.getView().byId("cbDepartment").getSelectedKey();
				var segId = this.getView().byId("cbSegregation").getSelectedKey();
				var consId = this.getView().byId("cbCons").getSelectedKey();
				var requestedUser = (this.byId("cbRTForSelf").getSelected()) ? this.getOwnerComponent().getModel("LogInUserModel").getData().User_ID :
					this
					.byId("in521Id").getValue();
				if (((sysId != "" && appId != "") && (deptId != "" && segId != "")) && consId != "") {
					sap.ui.getCore().getModel("createReqModel").setProperty("/job_title", deptId);
					sap.ui.getCore().getModel("createReqModel").setProperty("/segr_level", segId);
					sap.ui.getCore().getModel("createReqModel").setProperty("/consolidation_flag", consId);
					this.clearApplicationModelData();
					this.getApplSubApplList(sysId, appId, deptId, segId, consId, busApplName, requestedUser);

				} else {
					if (sysId == "") {
						this.getView().byId("cbSystem").setValueState("Error");
					}

					if (deptId == "") {
						this.getView().byId("cbDepartment").setValueState("Error");
					}
					if (segId == "") {
						this.getView().byId("cbSegregation").setValueState("Error");
					}
					if (consId == "") {
						this.getView().byId("cbCons").setValueState("Error");
					}
					this.getView().byId('UserRoleAccessWizard').previousStep();
				}
			}
		},
		userListDialog: function (oEvent) {
			var id = oEvent.mParameters.id;
			var check = id.includes("521");
			this.exemptUser = "";

			if (!this._oValueHelpDialog) {
				this._oValueHelpDialog = sap.ui.xmlfragment("id1", "com.alcon.UAM.view.fragments.ValueHelpUser", this);
			}
			this.getView().addDependent(this._oValueHelpDialog);

			if (check) {
				sap.ui.getCore().getModel("flagModel").setProperty("/flag", "true");
				this._oValueHelpDialog.setTitle("Search User");
				this.exemptUser = this.getOwnerComponent().getModel("LogInUserModel").getData().User_ID;
			} else {
				sap.ui.getCore().getModel("flagModel").setProperty("/flag", "false");
				this._oValueHelpDialog.setTitle("Search Line Manager");
				this.exemptUser = this.byId("in521Id").getValue();
			}
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._oValueHelpDialog);
			this._oValueHelpDialog.open();
		},

		onValueHelpOkPress: function (oEvent) {
			if (sap.ui.getCore().byId("id1--tblUserList").getSelectedItem() == null) {
				MessageBox.error("Please select One User");
			} else {
				var id521 = sap.ui.getCore().byId("id1--tblUserList").getSelectedItem().mAggregations.cells[0].getText();
				var first = sap.ui.getCore().byId("id1--tblUserList").getSelectedItem().mAggregations.cells[1].getText()
				var last = sap.ui.getCore().byId("id1--tblUserList").getSelectedItem().mAggregations.cells[2].getText()
				var full = first + ' ' + last;
				var check = sap.ui.getCore().getModel("flagModel").getProperty("/flag");
				if (check == "true") {
					if (this.byId("in521Id").getVisible()) {
						this.byId("in521Id").setValue(id521);
						this.onChange521Id(id521);
					} else if (this.byId("in521MgrNameId").getVisible()) {
						this.byId("in521MgrNameId").setValue(full);
						this.byId("in521MgrId").setValue(id521);
						sap.ui.getCore().getModel("createReqModel").setProperty("/line_manager_name", full);
						sap.ui.getCore().getModel("createReqModel").setProperty("/line_manager_id", id521);
					}

				} else {
					this.byId("managerfieldval").setValue(full);
					sap.ui.getCore().getModel("createReqModel").setProperty("/line_manager_name", full);
					sap.ui.getCore().getModel("createReqModel").setProperty("/line_manager_id", id521);

				}
				if (check == "true") {
					console.log(this.byId("otherDept").getText());
				}
				this._oValueHelpDialog.close();
				this._oValueHelpDialog.destroy(true);
				this._oValueHelpDialog = null;

			}
		},

		onValueHelpCancelPress: function () {
			this._oValueHelpDialog.close();
			this._oValueHelpDialog.destroy(true);
			this._oValueHelpDialog = null;
		},
		onClose: function () {},

		onUserSearch: function () {
			var getDetailsrv = this.getOwnerComponent().getModel("ZAL_CREATE_REQUEST_SRV_01");
			var that = this;

			var oFilter = [];
			if (sap.ui.getCore().byId("id1--in521").getValue() !== "" || sap.ui.getCore().byId("id1--inFirstName").getValue() !== "" || sap.ui
				.getCore()
				.byId(
					"id1--inLastName").getValue() !== "") {
				busyDialog.open();
				busyDialog.setText("Fetching");
				oFilter.push(new Filter("ID_521", FilterOperator.EQ, sap.ui.getCore().byId("id1--in521").getValue()));
				oFilter.push(new Filter("Firstname", FilterOperator.EQ, sap.ui.getCore().byId("id1--inFirstName").getValue()));
				oFilter.push(new Filter("Lastname", FilterOperator.EQ, sap.ui.getCore().byId("id1--inLastName").getValue()));
			} else {
				MessageToast.show("Please enter a value in any of the fields to search user");
				return;
			}
			var list521Id = new JSONModel();
			getDetailsrv.read("/User_ListSet", {
				filters: oFilter,
				success: function (oData) {
					//this loop is to exempt some user details that the user is not supposed to select
					for (let m in oData.results) {
						if (oData.results[m].ID_521 === that.exemptUser) {
							oData.results.splice(m, 1);
						}
					}

					list521Id.setData(oData);
					that.getView().setModel(list521Id, "List521Model");
					sap.ui.getCore().byId("id1--tblUserList").setVisible(true);
					busyDialog.close();
				},
				error: function (oError) {
					var errorMsg = that.errorMsgParse(oError);
					MessageBox.error(errorMsg);
					busyDialog.close();
				}
			});
		},

		onItemSelectionEntity1: function (oEvent) {
			var oModel = this.getOwnerComponent().getModel("HierEntityModel");
			var selPath = oEvent.getSource().getBindingInfo("selected")["binding"].getContext().getPath();
			var data = {};
			var tempArray = [];
			hierSelEntityArray = this.getOwnerComponent().getModel("UamRoleModel").getProperty(uamSelPath)["entity"];

			//if condition to add the selected items to an array
			if (oEvent.getParameter("selected")) {
				for (var i in hierField) {
					data[hierField[i]] = oModel.getProperty(selPath)[hierField[i]];
				}
				data["selectedPath"] = selPath;
				hierSelEntityArray.push(data);
			}
			//else condition to remove the unselected items from an array
			else {
				for (let m in hierSelEntityArray) {
					if (hierSelEntityArray[m].selectedPath === selPath) {
						hierSelEntityArray.splice(m, 1);
					}
				}
			}
			for (let n in hierSelEntityArray) {
				tempArray.push({
					"ID": hierSelEntityArray[n]["ID"],
					"TXT": hierSelEntityArray[n]["TXT"]
				});
			}
			selEntityModel.setData(tempArray);
			sap.ui.getCore().byId("tblSelValueEntity").setModel(selEntityModel, "selEntityModel");
			sap.ui.getCore().byId("tblSelValueEntity").getModel("selEntityModel").refresh(true);
			this.getOwnerComponent().getModel("UamRoleModel").getProperty(uamSelPath)["entity"] = hierSelEntityArray;
		},

		onItemSelectionMarket1: function (oEvent) {
			var oModel = this.getOwnerComponent().getModel("HierMarketModel");
			var selPath = oEvent.getSource().getBindingInfo("selected")["binding"].getContext().getPath();
			var data = {};
			var tempArray = [];
			hierSelMarketArray = this.getOwnerComponent().getModel("UamRoleModel").getProperty(uamSelPath)["market"];

			//if condition to add the selected items to an array
			if (oEvent.getParameter("selected")) {
				for (var i in hierField) {
					data[hierField[i]] = oModel.getProperty(selPath)[hierField[i]];
				}
				data["selectedPath"] = selPath;
				hierSelMarketArray.push(data);
			}
			//else condition to remove the unselected items from an array
			else {
				for (let m in hierSelMarketArray) {
					if (hierSelMarketArray[m].selectedPath === selPath) {
						hierSelMarketArray.splice(m, 1);
					}
				}
			}
			for (let n in hierSelMarketArray) {
				tempArray.push({
					"ID": hierSelMarketArray[n]["ID"],
					"TXT": hierSelMarketArray[n]["TXT"]
				});
			}

			selMarketModel.setData(tempArray);
			sap.ui.getCore().byId("tblSelValueMarket").setModel(selMarketModel, "selMarketModel");
			sap.ui.getCore().byId("tblSelValueMarket").getModel("selMarketModel").refresh(true);
			this.getOwnerComponent().getModel("UamRoleModel").getProperty(uamSelPath)["market"] = hierSelMarketArray;
		},

		onHierClose: function () {

			this._oDialog.close();
		},

		onChangeSystem: function () {
			var getDetailsrv = this.getOwnerComponent().getModel("ZAL_CREATE_REQUEST_SRV_01");
			var currentStep = this.getView().byId("UserRoleAccessWizard").mAssociations.currentStep;
			if (currentStep.includes("departmentSelection")) {
				this.getView().byId('UserRoleAccessWizard').previousStep();
			}
			if (currentStep.includes("roleSelection")) {
				this.getView().byId('UserRoleAccessWizard').previousStep();
				this.getView().byId('UserRoleAccessWizard').previousStep();
			}

			this.byId("cbDepartment").setSelectedKey("");

			this.byId("cbSegregation").setSelectedKey("");

			this.byId("cbCons").setSelectedKey("");
			this.byId("cbSegregation").setEnabled(false);

			this.byId("cbCons").setEnabled(false);

		},
		onHierCancelPress: function () {
			this._oDialog.close();
		},

		getHierarchy: function (sysId, appId, deptId, segId, consId, appl, subAppl, role, flag, uamSelPath, src) {
			var that = this;
			var uamModel = this.getOwnerComponent().getModel("UamRoleModel");
			var entityArray = [],
				marketArray = [];
			hierSelEntityArray = []; //make this global array empty
			hierSelMarketArray = []; //make this global array empty
			var getDetailsrv = this.getOwnerComponent().getModel("ZAL_CREATE_REQUEST_SRV_01");
			busyDialog.open();
			busyDialog.setText("Loading");
			var oFilter = [];
			this.getOwnerComponent().getModel("HierMarketModel").setData({});
			this.getOwnerComponent().getModel("HierEntityModel").setData({});
			oFilter.push(new Filter("System_ID", FilterOperator.EQ, sysId));
			oFilter.push(new Filter("Department_Role", FilterOperator.EQ, deptId));
			oFilter.push(new Filter("Segregation", FilterOperator.EQ, segId));
			oFilter.push(new Filter("Consolidated_View", FilterOperator.EQ, consId));
			oFilter.push(new Filter("Application", FilterOperator.EQ, appl));
			oFilter.push(new Filter("Subapplication", FilterOperator.EQ, subAppl));
			oFilter.push(new Filter("UAM_Role", FilterOperator.EQ, role));
			oFilter.push(new Filter("EMflag", FilterOperator.EQ, src));
			getDetailsrv.read("/HierarchySet", {
				filters: [oFilter],
				success: function (oData) {
					var dataMarket = [],
						dataEntity = [];
					var val = {
						"NODEID": oData.results[0].PARENTID,
						"PARENTID": null
					};

					if (src === "MARKET") {
						var marketArrayTemp = [];
						for (let item of oData.results) {
							item.selected = false;
							item.editable = true;

							if (item.Default_Node) {
								item.selected = true;
								item.editable = false;
								item.selectedPath = "";
								marketArrayTemp.push(item);
							}
						}
						dataMarket = oData.results;
						dataMarket.unshift(val);
						var dataMarketMod1 = JSON.parse(JSON.stringify(dataMarket));
						that.getOwnerComponent().getModel("HierMarketModel").setData(that.createTreeStructMarket(dataMarketMod1));
						if (uamModel.getProperty(uamSelPath)["market"].length > 0) {
							for (let item of uamModel.getProperty(uamSelPath)["market"]) {
								if (item.selectedPath !== "") {
									that.getOwnerComponent().getModel("HierMarketModel").getProperty(item.selectedPath)
										.selected = true
									marketArray.push(item);
								}

							}
						}
					} else if (src === "ENTITY") {
						var entityArrayTemp = [];
						for (let item of oData.results) {
							item.selected = false;
							item.editable = true;

							if (item.Default_Node) {
								item.selected = true;
								item.editable = false;
								item.selectedPath = "";
								entityArrayTemp.push(item);
							}
						}

						dataEntity = oData.results;
						dataEntity.unshift(val);
						var dataEntityMod1 = JSON.parse(JSON.stringify(dataEntity));
						that.getOwnerComponent().getModel("HierEntityModel").setData(that.createTreeStructEntity(dataEntityMod1));
						if (uamModel.getProperty(uamSelPath)["entity"].length > 0) {
							for (let item of uamModel.getProperty(uamSelPath)["entity"]) {
								if (item.selectedPath !== "") {
									that.getOwnerComponent().getModel("HierEntityModel").getProperty(item.selectedPath)
										.selected = true

									entityArray.push(item);
								}

							}
						}
					}
					var oView = that.getView();

					if (!that._oDialog) {
						Fragment.load({
							name: "com.alcon.UAM.view.fragments.Hierarchy",
							controller: that
						}).then(function (oDialog) {
							that._oDialog = oDialog;
							that._oDialog.addStyleClass(this.getContentDensityClass())
							that.getView().addDependent(that._oDialog);
							that._oDialog.setModel({});
							sap.ui.getCore().byId("hierVerticallay1").setVisible(false);
							sap.ui.getCore().byId("hierVerticallay2").setVisible(false);
							sap.ui.getCore().byId("sfMarketSearch").setValue("");
							sap.ui.getCore().byId("sfEntitySearch").setValue("");
							sap.ui.getCore().byId("sfMarketSearchType").setSelectedKey("ws");
							sap.ui.getCore().byId("sfEntitySearchType").setSelectedKey("ws");
							if (dataMarket.length > 1) {
								that._oDialog.setModel(that.getOwnerComponent().getModel("HierMarketModel"));
								sap.ui.getCore().byId("hierVerticallay1").setVisible(true);
								selMarketModel.setData(marketArrayTemp.concat(marketArray));
								uamModel.getProperty(uamSelPath)["market"] = marketArrayTemp.concat(marketArray);
								sap.ui.getCore().byId("tblSelValueMarket").setModel(selMarketModel, "selMarketModel");
								sap.ui.getCore().byId("tblSelValueMarket").getModel("selMarketModel").refresh(true);
								if (uamModel.getProperty(uamSelPath)["market"].length === 0) {
									sap.ui.getCore().byId("treeHierMarket").expandToLevel(0);
								}
							}
							if (dataEntity.length > 1) {
								that._oDialog.setModel(that.getOwnerComponent().getModel("HierEntityModel"));
								sap.ui.getCore().byId("hierVerticallay2").setVisible(true);
								selEntityModel.setData(entityArrayTemp.concat(entityArray));
								uamModel.getProperty(uamSelPath)["entity"] = entityArrayTemp.concat(entityArray);
								sap.ui.getCore().byId("tblSelValueEntity").setModel(selEntityModel, "selEntityModel");
								sap.ui.getCore().byId("tblSelValueEntity").getModel("selEntityModel").refresh(true);
								if (uamModel.getProperty(uamSelPath)["entity"].length === 0) {
									sap.ui.getCore().byId("treeHierEntity").expandToLevel(0);
								}
							}
							that._oDialog.open();
						}.bind(that));
					} else {
						that._oDialog.setModel({});
						that._oDialog.setModel(that.getOwnerComponent().getModel("HierMarketModel"));
						that._oDialog.setModel(that.getOwnerComponent().getModel("HierEntityModel"));
						that.getView().addDependent(that._oDialog);
						sap.ui.getCore().byId("hierVerticallay1").setVisible(false);
						sap.ui.getCore().byId("hierVerticallay2").setVisible(false);
						sap.ui.getCore().byId("sfMarketSearch").setValue("");
						sap.ui.getCore().byId("sfEntitySearch").setValue("");
						sap.ui.getCore().byId("sfMarketSearchType").setSelectedKey("ws");
						sap.ui.getCore().byId("sfEntitySearchType").setSelectedKey("ws");
						if (dataMarket.length > 1) {
							sap.ui.getCore().byId("hierVerticallay1").setVisible(true);
							sap.ui.getCore().byId("treeHierMarket").setVisible(true);
							selMarketModel.setData(marketArrayTemp.concat(marketArray));
							uamModel.getProperty(uamSelPath)["market"] = marketArrayTemp.concat(marketArray);
							sap.ui.getCore().byId("tblSelValueMarket").setModel(selMarketModel, "selMarketModel");
							sap.ui.getCore().byId("tblSelValueMarket").getModel("selMarketModel").refresh(true);
							if (uamModel.getProperty(uamSelPath)["market"].length === 0) {
								sap.ui.getCore().byId("treeHierMarket").expandToLevel(0);
							}
						}
						if (dataEntity.length > 1) {
							sap.ui.getCore().byId("hierVerticallay2").setVisible(true);
							sap.ui.getCore().byId("treeHierEntity").setVisible(true);
							selEntityModel.setData(entityArrayTemp.concat(entityArray));
							uamModel.getProperty(uamSelPath)["entity"] = entityArrayTemp.concat(entityArray);
							sap.ui.getCore().byId("tblSelValueEntity").setModel(selEntityModel, "selEntityModel");
							sap.ui.getCore().byId("tblSelValueEntity").getModel("selEntityModel").refresh(true);
							if (uamModel.getProperty(uamSelPath)["entity"].length === 0) {
								sap.ui.getCore().byId("treeHierEntity").expandToLevel(0);
							}
						}
						that._oDialog.open();
					}
					busyDialog.close();
				},
				error: function (oError) {
					var errorMsg = that.errorMsgParse(oError);
					MessageBox.error(errorMsg);
					busyDialog.close();
				}
			});
		},

		createTreeStructEntity: function (data) {
			const idMapping = data.reduce((acc, el, i) => {
				acc[el.NODEID] = i;
				return acc;
			}, {});
			let modData;
			data.forEach(el => {
				// Handle the root element
				if (el.PARENTID === null) {
					modData = el;
					return;
				}
				// Use our mapping to locate the parent element in our data array
				const parentEl = data[idMapping[el.PARENTID]];
				// Add our current el to its parent's `children` array
				parentEl.children = [...(parentEl.children || []), el];
			});
			return modData;
		},
		createTreeStructMarket: function (data) {
			const idMapping1 = data.reduce((acc, el, i) => {
				acc[el.NODEID] = i;
				return acc;
			}, {});
			let modData1;
			data.forEach(el => {
				// Handle the root element
				if (el.PARENTID === null) {
					modData1 = el;
					return;
				}
				// Use our mapping to locate the parent element in our data array
				const parentEl1 = data[idMapping1[el.PARENTID]];
				// Add our current el to its parent's `children` array
				parentEl1.children = [...(parentEl1.children || []), el];
			});
			return modData1;
		},

		toSubmit: function () {
			var key = this.byId("itbAdwhRole").getSelectedKey();
			var applsubData = "";
			var requestedUser = (this.byId("cbRTForSelf").getSelected()) ? this.getOwnerComponent().getModel("LogInUserModel").getData().User_ID :
				this
				.byId("in521Id").getValue();

			var hierVal = sap.ui.getCore().getModel("createReqModel").getProperty("/hier");
			if (key === "addRole") {
				applsubData = this.getOwnerComponent().getModel("UamRoleModel").getData();
			} else if (key === "removeRole") {
				applsubData = this.getOwnerComponent().getModel("UamRoleRemoveModel").getData();
			}

			var headerAppl = [];
			for (var j in hierVal) {
				hierVal[j].User_ID = requestedUser;
			}

			for (var k in applsubData) {
				var data = {
					"User_ID": requestedUser,
					"System_ID": this.byId("cbSystem").getSelectedKey(),
					"Department_Role": this.byId("cbDepartment").getSelectedKey(),
					"Segregation": this.byId("cbSegregation").getSelectedKey(),
					"Consolidated_View": this.byId("cbCons").getSelectedKey(),
					"Application": applsubData[k].Id.split("~")[0],
					"Subapplication": applsubData[k].Id.split("~")[1],
					"UAM_Role": applsubData[k].UamRole,
					"Read_Only": applsubData[k].ReadOnlySelect,
					"Read_Write": applsubData[k].ReadWriteSelect
				}
				headerAppl.push(data);
			}
			var dateFrom = this.byId("DP1").getValue().split("-");
			var dateTo = this.byId("DP2").getValue().split("-");
			var type = (this.byId("itbAdwhRole").getSelectedKey() === "addRole") ? "NEW" : "REMOVE";

			var payload = {
				"User_ID": requestedUser,
				"Line_Manager": (this.byId("cbRTForSelf").getSelected()) ? this.byId("in521MgrId").getValue() : sap
					.ui.getCore().getModel("createReqModel").getProperty("/line_manager_id"),
				"request_type": type,
				"Division": this.getOwnerComponent().getModel("LogInUserModel").getData().Division,
				"DATE_FROM": dateFrom[2] + dateFrom[1] + dateFrom[0],
				"DATE_TO": dateTo[2] + dateTo[1] + dateTo[0],
				"Appl_ID": "002",
				"System_ID": this.byId("cbSystem").getSelectedKey(),
				"Creator_ID": this.getOwnerComponent().getModel("LogInUserModel").getData().User_ID,
				"Reason": this.byId("taReason").getValue(),
				"Nav_Header_To_Appl": headerAppl,
				"Nav_Header_To_Hier": hierVal,
				"Nav_Header_To_Ret": [{}]
			}
			var that = this;

			var getDetailsrv = this.getOwnerComponent().getModel("ZAL_CREATE_REQUEST_SRV_01");
			busyDialog.open();

			getDetailsrv.create("/User_DetailsSet", payload, {
				success: function (oData) {
					busyDialog.close();
					that.showMessage(oData);
				},
				error: function (Error) {
					var errorMsg = that.errorMsgParse(Error);
					MessageBox.error(errorMsg);
					busyDialog.close();
				}
			});
		},
		showMessage: function (oData) {
			var data = oData.Nav_Header_To_Ret.results[0];
			MessageBox[(data.MsgType === "S") ? "success" : "error"](data.MsgText, {
				actions: [MessageBox.Action.CLOSE],
				onClose: function (oAction) {
					this.closeAction();
				}.bind(this)
			});
		},
		closeAction: function () {
			this.clearModelData();
			this._oWizardReviewPage.destroy();
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("RouteMain");
		},
		backToWizardContent: function () {
			this._oWizardReviewPage.destroy();

		},
		clearModelData: function () {
			this.resetCreateReqModel();
			this.onForSelfSelect("");
			this.dateSetter();

			this.getOwnerComponent().getModel("OtherUserModel1").setData({});
			this.getOwnerComponent().getModel("DepartmentModel").setData({});
			this.getOwnerComponent().getModel("SegregationModel").setData({});
			this.clearApplicationModelData();
		},

		clearApplicationModelData: function () {
			this.byId("liApplication").removeSelections();
			this.byId("liSubApplication").removeSelections();
			this.byId("liBusRole").removeSelections();
			this.byId("liApplicationRemove").removeSelections();
			this.byId("liSubApplicationRemove").removeSelections();
			this.byId("liBusRoleRemove").removeSelections();
			this.byId("liHierRemove").removeSelections();
			this.getOwnerComponent().getModel("ApplicationModel1").setData({});
			this.getOwnerComponent().getModel("SubApplicationModel").setData({});
			this.getOwnerComponent().getModel("UamRoleModel").setData({});
			this.getOwnerComponent().getModel("HierEntityModel").setData({});
			this.getOwnerComponent().getModel("HierMarketModel").setData({});
			this.getOwnerComponent().getModel("HierButtonModel").setData({});
			this.getOwnerComponent().getModel("ApplicationModel1").refresh(true);
			this.getOwnerComponent().getModel("SubApplicationModel").refresh(true);
			this.getOwnerComponent().getModel("UamRoleModel").refresh(true);
			this.getOwnerComponent().getModel("HierEntityModel").refresh(true);
			this.getOwnerComponent().getModel("HierMarketModel").refresh(true);
			this.getOwnerComponent().getModel("HierButtonModel").refresh(true);
			this.getOwnerComponent().getModel("ApplicationModel2").setData({});
			this.getOwnerComponent().getModel("SubApplicationRemoveModel").setData({});
			this.getOwnerComponent().getModel("UamRoleRemoveModel").setData({});
			this.getOwnerComponent().getModel("HiearchyRemoveModel").setData({});
			this.getOwnerComponent().getModel("ApplicationModel2").refresh(true);
			this.getOwnerComponent().getModel("SubApplicationRemoveModel").refresh(true);
			this.getOwnerComponent().getModel("UamRoleRemoveModel").refresh(true);
			this.getOwnerComponent().getModel("HiearchyRemoveModel").refresh(true);
		},

		onExit: function () {
			if (this._oWizardReviewPage) {
				this._oWizardReviewPage.destroy(true);
			}

			if (this._oValueHelpDialog) {
				this._oValueHelpDialog.destroy(true);
			}

		},
		onSelectRoleSection: function (oEvent) {
			var key = oEvent.getParameter("key");
			if ((key === "removeRole" && this.byId("liApplication").getSelectedItems().length !== 0) ||
				(key === "addRole" && this.byId("liApplicationRemove").getSelectedItems().length !== 0)) {
				removeSel = true;
				if (key === "addRole" && removeSel) {
					this.byId("itbAdwhRole").setSelectedKey("removeRole");
					MessageBox.warning("Your changes in Remove Role section will be removed, if you click on Yes", {
						actions: [MessageBox.Action.YES, MessageBox.Action.NO],
						onClose: function (oAction) {

							if (oAction === MessageBox.Action.YES) {
								this.byId("itbAdwhRole").setSelectedKey("addRole");
								this.byId("liApplicationRemove").removeSelections();
								this.getOwnerComponent().getModel("SubApplicationRemoveModel").setData({});
								this.getOwnerComponent().getModel("UamRoleRemoveModel").setData({});
								this.getOwnerComponent().getModel("HiearchyRemoveModel").setData({});
							} else if (oAction === MessageBox.Action.NO) {
								return;
							}
						}.bind(this)
					});
				} else if (key === "removeRole") {
					this.byId("itbAdwhRole").setSelectedKey("addRole");
					if (this.getOwnerComponent().getModel("ApplicationModel2").getData().length === 0) {
						MessageToast.show("No role is assigned to the selected user");
						return;
					} else if (addSel) {
						MessageBox.warning("Your changes in Add Role will be removed, if you click on Yes", {
							actions: [MessageBox.Action.YES, MessageBox.Action.NO],
							onClose: function (oAction) {

								if (oAction === MessageBox.Action.YES) {
									this.byId("itbAdwhRole").setSelectedKey("removeRole");
									this.byId("liApplication").removeSelections();
									this.getOwnerComponent().getModel("SubApplicationModel").setData({});
									this.getOwnerComponent().getModel("UamRoleModel").setData({});

								} else if (oAction === MessageBox.Action.NO) {
									return;
								}
							}.bind(this)
						});
					} else {
						this.byId("itbAdwhRole").setSelectedKey("removeRole");
					}
				}
			}
		}

	});

});