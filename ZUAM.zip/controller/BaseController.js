sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/Device",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/core/Fragment",
	"sap/m/MessageBox",
	"sap/m/GroupHeaderListItem"
], function (Controller, JSONModel, Device, Filter, FilterOperator, Fragment, MessageBox, GroupHeaderListItem) {
	"use strict";

	var busyDialog = new sap.m.BusyDialog();
	var tempSubApplModel = new JSONModel();
	var tempSubApplRemoveModel = new JSONModel();
	return Controller.extend("com.alcon.UAM.controller.BaseController", {
		 bValidationError: false,
		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.alcon.UAM.view.createRequest
		 */
		onInit: function () {
			jQuery.sap.includeStyleSheet("/sap/bc/ui5_ui5/sap/zuam/css/style.css");
			var sRootPath = jQuery.sap.getModulePath("zuam");
			var location = $(location).attr('href');

		},
		createReq: function () {
			return this.getOwnerComponent().getModel("ZAL_CREATE_REQUEST_SRV_01");
		},
		createWorkdayReq: function () {
			return this.getOwnerComponent().getModel("Z8CZ_WORKDAY_SRV");
		},
		getContentDensityClass: function () {
			if (!this._sContentDensityClass) {
				if (!Device.support.touch) {
					this._sContentDensityClass = "sapUiSizeCompact";
				} else {
					this._sContentDensityClass = "sapUiSizeCozy";
				}
			}
			return this._sContentDensityClass;
		},
		errorMsgParse: function (error) {
			var xmlParser, xmlDoc, responseText, jsonParser;
			var i18nModel = this.getOwnerComponent().getModel("i18n");
			var errorCodes = [500, 501, 502, 503, 504];

			try {
				responseText = error.responseText;
				if (responseText && responseText.substring(0, 1) === "<") { // consider it as xml error message
					xmlParser = new DOMParser();
					xmlDoc = xmlParser.parseFromString(responseText, "text/xml");
					if (xmlDoc.getElementsByTagName("message").length > 0) {
						return xmlDoc.getElementsByTagName("message")[0].innerHTML;
					} else if (xmlDoc.getElementsByTagName("body").length > 0) {
						return xmlDoc.getElementsByTagName("body")[0].innerHTML;
					}
				} else if (responseText && responseText.substring(0, 1) === "{") { //consider it as json error message
					jsonParser = JSON.parse(responseText);
					return jsonParser.error.message.value;
				} else if (responseText) {
					return responseText;
				} else if (error.response) {
					xmlParser = new DOMParser();
					xmlDoc = xmlParser.parseFromString(error.response, "text/xml");
					if (xmlDoc.getElementsByTagName("body").length > 0) {
						return xmlDoc.getElementsByTagName("body")[0].innerHTML;
					}
				} else if (errorCodes.includes(error.statusCode)) {
					return "HTTP Connection timed out or refused connection error" + i18nModel.getProperty("errorMessage1");
				} else {
					return "Error occured: " + i18nModel.getProperty("errorMessage1");
				}
			} catch (err) {
				return "Some error happened:Unable to parse the error message";
			}
		},

		/*Common methods used in ADWH, Alcon DCT, Alcon BI
		 *
		 *
		 *****************************************************/

		dateSetter: function () {
			var date = new Date();
			var day = (date.getDate() < 10) ? "0" + date.getDate() : date.getDate();
			var month = ((date.getMonth() + 1) < 10) ? "0" + (date.getMonth() + 1) : date.getMonth() + 1;
			var year = date.getFullYear();
			var startDate = day + "-" + month + "-" + year;
			var endDate = "31-12-9999";
			this.getOwnerComponent().getModel("DateModel").setData({
				"startDate": startDate,
				"endDate": endDate,
				"minDate": date
			});
		},
		isValidDate: function (date) {
			return date && Object.prototype.toString.call(date) === "[object Date]" && !isNaN(date);
		},

		getApplList: function () {
			var that = this;

			var getDetailsrv = this.getOwnerComponent().getModel("ZAL_CREATE_REQUEST_SRV_01");
			busyDialog.open();
			busyDialog.setText("Loading");
			getDetailsrv.read("/APPL_TYPESet", {
				success: function (oData) {
					that.applList = oData;
					that.getOwnerComponent().getModel("ApplicationModel").setData(that.getUniqueValues(oData, "Appl_ID", "Application_Type"));
					busyDialog.close();
				},
				error: function (Error) {
					var errorMsg = that.errorMsgParse(Error);
					MessageBox.error(errorMsg);
					busyDialog.close();
				}
			});
		},

		getDepartSeg: function (sysId, appId, busApplName) {
			var that = this;
			busyDialog.open();
			busyDialog.setTitle("Loading");
			var oFilter = [];
			var getDetailsrv = this.getOwnerComponent().getModel("ZAL_CREATE_REQUEST_SRV_01");
			oFilter.push(new Filter("Appl_ID", FilterOperator.EQ, appId));
			oFilter.push(new Filter("System_ID", FilterOperator.EQ, sysId));
			getDetailsrv.read("/DepartmentSet", {
				filters: oFilter,
				success: function (oData) {
					that.departSegData = oData;
					that.getOwnerComponent().getModel("DepartmentModel").setData(that.getUniqueValues(oData, "Department_Role",
						"Department_Role"));
					that.getOwnerComponent().getModel("SegregationModel").setData(that.getUniqueValues(oData, "Segregation", "Segregation"));
					if (busApplName === "ADWH") {
						that.getOwnerComponent().getModel("ConsolidationModel").setData(that.getUniqueValues(oData, "Consolidated_View",
							"Consolidated_View"));
					}

					busyDialog.close();
				},
				error: function (oError) {
					var errorMsg = that.errorMsgParse(oError);
					MessageBox.error(errorMsg);
					busyDialog.close();
				}
			});
		},

		filterSegregation: function (selKey) {
			var array = [],
				data = {};
			for (var rowVal of this.departSegData.results) {
				if (rowVal.Department_Role === selKey) {
					array.push(rowVal);
				}
			}
			data = {
				"results": array
			};
			this.getOwnerComponent().getModel("SegregationModel").setData(this.getUniqueValues(data, "Segregation", "Segregation"));
		},

		filterConsolidation: function (departValue, segregationValue) {
			var array = [],
				data = {};
			for (var rowVal of this.departSegData.results) {
				if (rowVal.Department_Role === departValue && rowVal.Segregation === segregationValue) {
					array.push(rowVal);
				}
			}
			data = {
				"results": array
			};
			this.getOwnerComponent().getModel("ConsolidationModel").setData(this.getUniqueValues(data, "Consolidated_View", "Consolidated_View"));
		},
		getApplSubApplList: function (sysId, appId, deptId, segId, consId, busApplName, requestedUser) {

			//reseting the Models
			this.getOwnerComponent().getModel("ApplicationModel1").setData({});
			this.getOwnerComponent().getModel("SubApplicationModel").setData({});
			this.getOwnerComponent().getModel("UamRoleModel").setData({});

			this.getOwnerComponent().getModel("ApplicationModel2").setData({});

			tempSubApplModel.setData({});
			tempSubApplRemoveModel.setData({});
			var that = this;
			busyDialog.open();
			busyDialog.setTitle("Loading");
			var oFilter = [],
				getDetailsrv = "";
			if (busApplName === "ADWH") {
				getDetailsrv = this.getOwnerComponent().getModel("ZAL_CREATE_REQUEST_SRV_01");
				oFilter.push(new Filter("Segregation", FilterOperator.EQ, segId));
				oFilter.push(new Filter("Consolidated_View", FilterOperator.EQ, consId));
			} else if (busApplName === "APMR") {
				getDetailsrv = this.getOwnerComponent().getModel("ZUAM_ALCON_DCT_SRV");
			} else if (busApplName === "ALCONBI") {
				getDetailsrv = this.getOwnerComponent().getModel("Z8C_UAM_ALCON_BI_SRV");
				oFilter.push(new Filter("Segregation", FilterOperator.EQ, segId));
			}

			oFilter.push(new Filter("Appl_ID", FilterOperator.EQ, appId));
			// Trying filters provided by Arati for hierarchy set

			oFilter.push(new Filter("System_ID", FilterOperator.EQ, sysId));
			oFilter.push(new Filter("Department_Role", FilterOperator.EQ, deptId));

			getDetailsrv.read("/ApplicationSet", {
				async: false,
				filters: [oFilter],
				success: function (oData) {
					that.applData = oData;
					oFilter.push(new Filter("User_ID", FilterOperator.EQ, requestedUser));
					if (busApplName === "ADWH") {
						that.getOwnerComponent().getModel("ApplicationModel1").setData(that.getUniqueValues(oData, "Application",
							"Application"));

						getDetailsrv.read("/Remove_RolesSet", {
							async: false,
							filters: [oFilter],
							success: function (oData) {
								that.applDataRemove = oData;
								that.getOwnerComponent().getModel("ApplicationModel2").setData(that.getUniqueValues(oData, "Application",
									"Application"));

							},
							error: function (oError) {

							}
						});
					} else if (busApplName === "APMR") {
						that.getOwnerComponent().getModel("ApplicationModel1").setData(oData);
						that.getOwnerComponent().getModel("SubApplicationModel").setData(that.getUniqueValues(oData, "Subapplication",
							"Subapplication"));

						//calling Removal roles entity 

						getDetailsrv.read("/Remove_RolesSet", {
							async: false,
							filters: [oFilter],
							success: function (oData) {
								that.getOwnerComponent().getModel("ApplicationModel2").setData(oData);
								that.getOwnerComponent().getModel("SubApplicationRemoveModel").setData(that.getUniqueValues(oData, "Subapplication",
									"Subapplication"));
							},
							error: function (oError) {

							}
						});
					} else if (busApplName === "ALCONBI") {
						that.getOwnerComponent().getModel("ApplicationModel1").setData(that.getUniqueValues(oData, "Application",
							"Application"));

						//calling Removal roles entity
						getDetailsrv.read("/Remove_RolesSet", {
							async: false,
							filters: [oFilter],
							success: function (oData) {
								that.applDataRemove = oData;
								that.getOwnerComponent().getModel("ApplicationModel2").setData(that.getUniqueValues(oData, "Application",
									"Application"));
							},
							error: function (oError) {}
						});
					}

					busyDialog.close();
				},
				error: function (oError) {
					var errorMsg = that.errorMsgParse(oError);
					busyDialog.close();
					MessageBox.error(errorMsg, {
						onClose: function () {
							sap.ui.getCore().byId('__xmlview1--UserRoleAccessWizard').previousStep();
						}
					});
				}
			});
		},

		onApplicationChange: function (selVal, selStatus) { //selStatus can be true if selected , false if unselected
			if (selStatus) {
				var applID = [];
				var data;
				this.subApplData = [];

				for (var j in this.applData.results) {
					data = {
						"subApplication": "",
						"uamRole": "",
						"hier": "",
						"emflag": "",
						"readWrite": false,
						"readOnly": false,
						"selected": false
					};
					if (selVal === this.applData.results[j].Application) {
						data = {
							"subApplication": this.applData.results[j].Subapplication,
							"uamRole": this.applData.results[j].UAM_Role,
							"hier": this.applData.results[j].Application + "~" + this.applData.results[j].Subapplication,
							"emflag": this.applData.results[j].EMflag,
							"readWrite": this.applData.results[j].Read_Write,
							"readOnly": this.applData.results[j].Read_Only,
							"selected": false
						};
						this.subApplData.push(data);
					}

				}
				if (tempSubApplModel.getData().length === undefined) {
					tempSubApplModel.setData(this.subApplData);
				} else if (tempSubApplModel.getData().length > 0) {
					let array1 = tempSubApplModel.getData();
					let newArray = array1.concat(this.subApplData);
					tempSubApplModel.setData(newArray);
				}
				var appSubAppData = this.getUniqueValues({
					"results": this.subApplData
				}, "hier", "hier");
				for (var k in appSubAppData) {
					appSubAppData[k]["Application"] = appSubAppData[k]["Value"].split("~")[0];
					appSubAppData[k]["SubApplication"] = appSubAppData[k]["Value"].split("~")[1];
					appSubAppData[k]["selected"] = false;
				}
				//merge tow arrays.
				let array1 = [];
				if (this.getOwnerComponent().getModel("SubApplicationModel").getData().length !== undefined) {
					array1 = this.getOwnerComponent().getModel("SubApplicationModel").getData();
				}

				let newArray = array1.concat(appSubAppData);

				this.getOwnerComponent().getModel("SubApplicationModel").setData(newArray);
			} else {
				var data = this.getOwnerComponent().getModel("SubApplicationModel").getData();
				var newArray = [];
				for (let m = 0; m < data.length; m++) {
					if (data[m]["Application"] !== selVal) {
						newArray.push(data[m]);
					} else {
						this.onSubApplicationChange(data[m]["SubApplication"], false);
					}
				}
				this.getOwnerComponent().getModel("SubApplicationModel").setData(newArray);
			}
		},

		onApplicationChangeRemove: function (selVal, selStatus) { //selStatus can be true if selected , false if unselected
			if (selStatus) {
				var applID = [];

				var data;
				this.subApplDataRemove = [];

				for (var j in this.applDataRemove.results) {
					data = {
						"subApplication": "",
						"uamRole": "",
						"hier": "",
						"emflag": "",
						"node": ""
					};
					if (selVal === this.applDataRemove.results[j].Application) {
						data = {
							"subApplication": this.applDataRemove.results[j].Subapplication,
							"uamRole": this.applDataRemove.results[j].UAM_Role,
							"hier": this.applDataRemove.results[j].Application + "~" + this.applDataRemove.results[j].Subapplication,
							"emflag": this.applDataRemove.results[j].EMflag,
							"node": this.applDataRemove.results[j].TCTNODEb
						};
						this.subApplDataRemove.push(data);
					}
				}
				if (tempSubApplRemoveModel.getData().length === undefined) {
					tempSubApplRemoveModel.setData(this.subApplDataRemove);
				} else if (tempSubApplRemoveModel.getData().length > 0) {
					let array1 = tempSubApplRemoveModel.getData();
					let newArray = array1.concat(this.subApplDataRemove);
					tempSubApplRemoveModel.setData(newArray);
				}

				var appSubAppData = this.getUniqueValues({
					"results": this.subApplDataRemove
				}, "hier", "hier");
				for (var k in appSubAppData) {
					appSubAppData[k]["Application"] = appSubAppData[k]["Value"].split("~")[0];
					appSubAppData[k]["SubApplication"] = appSubAppData[k]["Value"].split("~")[1];
					appSubAppData[k]["selected"] = false;
				}
				//merge tow arrays.
				let array1 = [];
				if (this.getOwnerComponent().getModel("SubApplicationRemoveModel").getData().length !== undefined) {
					array1 = this.getOwnerComponent().getModel("SubApplicationRemoveModel").getData();
				}

				let newArray = array1.concat(appSubAppData);

				this.getOwnerComponent().getModel("SubApplicationRemoveModel").setData(newArray);
			} else {
				var data = this.getOwnerComponent().getModel("SubApplicationRemoveModel").getData();
				var newArray = [];
				for (let m = 0; m < data.length; m++) {
					if (data[m]["Application"] !== selVal) {
						newArray.push(data[m]);
					} else {
						this.onSubApplicationChangeRemove(data[m]["SubApplication"], false);
					}
				}
				this.getOwnerComponent().getModel("SubApplicationRemoveModel").setData(newArray);
			}

		},
		onSubApplicationChange: function (selVal, selStatus, applName) {
			if (selStatus) {
				var subApplID = [];
				var data;
				this.uamRoleData = [];
				var subApplData = tempSubApplModel.getData();

				for (var j in subApplData) {
					data = {
						"uamRole": "",
						"hier1": "",
						"emflag": "",
						"readWrite": false,
						"readOnly": false,
						"selected": false
					};
					if (selVal === subApplData[j].subApplication) {
						data = {
							"uamRole": subApplData[j].uamRole,
							"hier1": subApplData[j].hier + "~" + subApplData[j].uamRole,
							"emflag": subApplData[j].emflag,
							"readWrite": subApplData[j].readWrite,
							"readOnly": subApplData[j].readOnly,
							"selected": false
						};
						this.uamRoleData.push(data);
					}

				}

				var appSubRoleData = this.getUniqueValuesForRole({
					"results": this.uamRoleData
				}, "hier1", "emflag")

				for (var k in appSubRoleData) {
					appSubRoleData[k]["ApplSubAppl"] = appSubRoleData[k]["Id"].split("~")[0] + " / " + appSubRoleData[k]["Id"].split("~")[1];
					appSubRoleData[k]["UamRole"] = appSubRoleData[k]["Id"].split("~")[2];
					appSubRoleData[k]["EmFlag"] = appSubRoleData[k]["Flag"];

					appSubRoleData[k]["ReadWrite"] = appSubRoleData[k]["ReadWrite"];
					appSubRoleData[k]["ReadOnly"] = appSubRoleData[k]["ReadOnly"];
					appSubRoleData[k]["selected"] = false;
					if (applName === "ADWH") {
						appSubRoleData[k]["market"] = [];
						appSubRoleData[k]["entity"] = [];
						appSubRoleData[k]["marketPressed"] = false;
						appSubRoleData[k]["entityPressed"] = false;
						appSubRoleData[k]["BtnVisibleEntity"] = false;
						appSubRoleData[k]["BtnVisibleMarket"] = false;
						appSubRoleData[k]["ReadWriteSelect"] = false;
						appSubRoleData[k]["ReadOnlySelect"] = false;
					} else if (applName === "ALCONBI") {
						if (appSubRoleData[k]["Flag"] === "B") {
							appSubRoleData[k]["ApplSubApplType"] = appSubRoleData[k]["Id"].split("~")[0] + " / " + appSubRoleData[k]["Id"].split("~")[1] +
								" / " + "Retraction";
						} else if (appSubRoleData[k]["Flag"] === "CP") {
							appSubRoleData[k]["ApplSubApplType"] = appSubRoleData[k]["Id"].split("~")[0] + " / " + appSubRoleData[k]["Id"].split("~")[1] +
								" / " + "CCP";
						}

						appSubRoleData[k]["cost"] = [];
						appSubRoleData[k]["profit"] = [];
						appSubRoleData[k]["company"] = [];
						appSubRoleData[k]["costPressed"] = false;
						appSubRoleData[k]["profitPressed"] = false;
						appSubRoleData[k]["companyPressed"] = false;

						appSubRoleData[k]["BtnVisibleCompany"] = false;
						appSubRoleData[k]["BtnVisibleCost"] = false;
						appSubRoleData[k]["BtnVisibleCProfit"] = false;
					}

				}

				//merge tow arrays.
				let array1 = [];
				if (this.getOwnerComponent().getModel("UamRoleModel").getData().length !== undefined) {
					array1 = this.getOwnerComponent().getModel("UamRoleModel").getData();
				}

				let newArray = array1.concat(appSubRoleData);

				this.getOwnerComponent().getModel("UamRoleModel").setData(newArray);
			} else {
				var data = this.getOwnerComponent().getModel("UamRoleModel").getData();
				var newArray = [];
				for (let m = 0; m < data.length; m++) {
					if (data[m]["ApplSubAppl"].split(" / ")[1] !== selVal) {
						newArray.push(data[m]);
					}
				}
				this.getOwnerComponent().getModel("UamRoleModel").setData(newArray);
			}

		},

		onSubApplicationChangeRemove: function (selVal, selStatus, applName) {
			if (selStatus) {
				var subApplID = [];

				var data;
				this.uamRoleDataRemove = [];
				var subApplData = tempSubApplRemoveModel.getData();

				for (var j in subApplData) {
					data = {
						"uamRole": "",
						"hier1": "",
						"emflag": "",
						"node": ""
					};
					if (selVal === subApplData[j].subApplication) {
						data = {
							"uamRole": subApplData[j].uamRole,
							"hier1": subApplData[j].hier + "~" + subApplData[j].uamRole,
							"emflag": subApplData[j].emflag,
							"node": subApplData[j].node
						};
						this.uamRoleDataRemove.push(data);
					}
				}

				var appSubRoleData = this.getUniqueValuesForRole({
					"results": this.uamRoleDataRemove
				}, "hier1", "emflag");

				for (var k in appSubRoleData) {
					appSubRoleData[k]["ApplSubAppl"] = appSubRoleData[k]["Id"].split("~")[0] + " / " + appSubRoleData[k]["Id"].split("~")[1];
					appSubRoleData[k]["UamRole"] = appSubRoleData[k]["Id"].split("~")[2];
					appSubRoleData[k]["EmFlag"] = appSubRoleData[k]["Flag"];
					appSubRoleData[k]["node"] = appSubRoleData[k]["node"];
				}

				//merge tow arrays.
				let array1 = [];
				if (this.getOwnerComponent().getModel("UamRoleRemoveModel").getData().length !== undefined) {
					array1 = this.getOwnerComponent().getModel("UamRoleRemoveModel").getData();
				}

				let newArray = array1.concat(appSubRoleData);

				this.getOwnerComponent().getModel("UamRoleRemoveModel").setData(newArray);
			} else {
				var data = this.getOwnerComponent().getModel("UamRoleRemoveModel").getData();
				var newArray = [];
				for (let m = 0; m < data.length; m++) {
					if (data[m]["ApplSubAppl"].split(" / ")[1] !== selVal) {
						newArray.push(data[m]);
					}
				}
				this.getOwnerComponent().getModel("UamRoleRemoveModel").setData(newArray);

				let data1 = this.getOwnerComponent().getModel("HiearchyRemoveModel").getData();
				newArray = [];
				for (let m = 0; m < data1.length; m++) {
					if (data1[m]["hier"].split(" / ")[1] !== selVal) {
						newArray.push(data1[m]);
					}
				}
				this.getOwnerComponent().getModel("HiearchyRemoveModel").setData(newArray);

			}

		},
		onBusRoleChange: function (selPath, selStatus, src, roleType) {
			///First make the buttons invisible
			var oModel = this.getOwnerComponent().getModel("UamRoleModel");
			oModel.getProperty(selPath).BtnVisibleEntity = false;
			oModel.getProperty(selPath).BtnVisibleMarket = false;

			oModel.getProperty(selPath).BtnVisibleCompany = false;
			oModel.getProperty(selPath).BtnVisibleCost = false;
			oModel.getProperty(selPath).BtnVisibleCProfit = false;

			if (src === "ADWH") {
				if (selStatus) {

					oModel.getProperty(selPath).BtnVisibleEntity = (oModel.getProperty(selPath).EmFlag.includes("E")) ? true : false;
					oModel.getProperty(selPath).BtnVisibleMarket = (oModel.getProperty(selPath).EmFlag.includes("M")) ? true : false;

				} else {

					oModel.getProperty(selPath).BtnVisibleEntity = false;
					oModel.getProperty(selPath).BtnVisibleMarket = false;
				}
			} else if (src === "ALCONBI") {
				if (selStatus) {

					//As this table is single select remove the other selections manually..
					for (var item of oModel.getData()) {
						if (roleType === "Retraction" && item.EmFlag === "B") {
							item.selected = false;
							item.BtnVisibleCompany = false;
							item.company = [];
						} else if (roleType === "CCP" && item.EmFlag === "CP") {
							item.selected = false;
							item.BtnVisibleCost = false;
							item.BtnVisibleCProfit = false;
							item.cost = [];
							item.profit = [];

						}

					}
					oModel.getProperty(selPath).selected = true;

					if ((oModel.getProperty(selPath).EmFlag.includes("B")) == true) {
						oModel.getProperty(selPath).BtnVisibleCompany = (oModel.getProperty(selPath).EmFlag.includes("B")) ? true : false;;
					}
					if ((oModel.getProperty(selPath).EmFlag.includes("C")) == true) {
						oModel.getProperty(selPath).BtnVisibleCost = (oModel.getProperty(selPath).EmFlag.includes("C")) ? true : false;;
					}
					if ((oModel.getProperty(selPath).EmFlag.includes("P")) == true) {
						oModel.getProperty(selPath).BtnVisibleCProfit = (oModel.getProperty(selPath).EmFlag.includes("P")) ? true : false;
					}

				} else {
					oModel.getProperty(selPath).BtnVisibleCompany = false;
					oModel.getProperty(selPath).BtnVisibleCost = false;
					oModel.getProperty(selPath).BtnVisibleCProfit = false;
				}
			}
			oModel.refresh(true);
		},

		onBusRoleChangeRemove: function (selPath, selStatus, src, roleType) {
			///First make the buttons invisible
			let oModel = this.getOwnerComponent().getModel("UamRoleRemoveModel");
			let oHierModel = this.getOwnerComponent().getModel("HiearchyRemoveModel")
			let dataArray = [];
			if (selStatus) {
				for (var item of this.applDataRemove.results) {
					if (oModel.getProperty(selPath).Id === item.Application + "~" + item.Subapplication + "~" + item.UAM_Role) {
						let data = {
							"hier": oModel.getProperty(selPath).ApplSubAppl + " / " + oModel.getProperty(selPath).UamRole + " / " + item.EMflag,
							"node": item.TCTNODE,
							"obj": item.TCTNIOBJNM
						}
						if (oHierModel.getData().length === undefined) {
							dataArray.push(data);
							oHierModel.setData(dataArray);
						} else {
							dataArray = oHierModel.getData();
							dataArray.push(data);
							oHierModel.setData(dataArray);
						}
					}
				}
			} else {
				const regex = /~/ig;
				dataArray = oHierModel.getData();
				var setVal = dataArray;
				const dataRemoved = setVal.filter((el) => {
					return el.hier.indexOf(oModel.getProperty(selPath).Id.replaceAll(regex, " / ")) < 0;
				});
				oHierModel.setData(dataRemoved);
			}
			oHierModel.refresh(true);

		},

		getUniqueValues: function (odata, key, value) {
			var data, dataArray = [],
				tempArray = [];
			for (var i in odata.results) {
				data = {
					"Id": "",
					"Value": ""
				}

				if (i === 0) {
					data = {
						"Id": odata.results[i][key],
						"Value": odata.results[i][value],
					}
					dataArray.push(data);
					tempArray.push(odata.results[i][key])
				} else if (!tempArray.includes(odata.results[i][key])) {
					data = {
						"Id": odata.results[i][key],
						"Value": odata.results[i][value]
					}
					dataArray.push(data);
					tempArray.push(odata.results[i][key]);
				}
			}
			return dataArray;
		},
		getUniqueValuesForRole: function (odata, key, flag) {
			var data, dataArray = [],
				tempArray = [];
			for (var i in odata.results) {
				data = {
					"Id": "",
					"Flag": "",
					"ReadWrite": false,
					"ReadOnly": false
				}

				if (i === 0) {
					data = {
						"Id": odata.results[i][key],
						"Flag": odata.results[i][flag],
						"ReadWrite": odata.results[i]["readWrite"],
						"ReadOnly": odata.results[i]["readOnly"]
					}
					dataArray.push(data);
					tempArray.push(odata.results[i][key])
				} else if (!tempArray.includes(odata.results[i][key])) {
					data = {
						"Id": odata.results[i][key],
						"Flag": odata.results[i][flag],
						"ReadWrite": odata.results[i]["readWrite"],
						"ReadOnly": odata.results[i]["readOnly"]
					}
					dataArray.push(data);
					tempArray.push(odata.results[i][key]);
				}
			}
			return dataArray;
		},
		getGroupHeader: function (oGroup) {
			return new GroupHeaderListItem({
				title: oGroup.key.split(" / ")[2] + " / " + oGroup.key.split(" / ")[3]
			}).addStyleClass("ow-anywhere");
		},

		/*End of Common methods used in ADWH, Alcon DCT, Alcon BI **/
		getWorkdayInstance: function (sysId) {
			var that = this;
			var urlParams = {
				"$expand": "Nav_Header_To_Instance,Nav_Header_To_Permission,Nav_Header_To_Seglevel,Nav_Header_To_Country"
			}
			var oFilter = [];
			var oModel = this.getOwnerComponent().getModel("Z8CZ_WORKDAY_ADAPTIVE_SRV");
			oFilter.push(new Filter("System_ID", FilterOperator.EQ, sysId));
			oModel.read("/User_DetailsSet", {
				filters: oFilter,
				urlParameters: urlParams,
				success: function (oData) {
					that.workdayData = oData;
					that.getView().setModel(new JSONModel(), "JobDetailsWorkdayModel");
					that.getView().getModel("JobDetailsWorkdayModel").setData(oData.results[0]);
					//setting default value to Instance
					if (sysId === "DEV") {
                    that.getView().byId("cbInstance").setSelectedKey("ALCONLABS2");
					} else if (sysId === "PROD") {
                    that.getView().byId("cbInstance").setSelectedKey("ALCONLABS1");
					}
					//setting default value to permission set
					var selectedPermisionName = that.getView().getModel("JobDetailsWorkdayModel").getData().Nav_Header_To_Permission.results.filter(
						function (
							oItem) {
							return oItem.INSTANCE === "WFP"
						});
					that.getView().getModel("JobDetailsWorkdayModel").setProperty("/Nav_To_Permission", selectedPermisionName);
					
				},
				error: function (oError) {
					var errorMsg = that.errorMsgParse(oError);
					MessageBox.error(errorMsg);
				}
			});
		},
		getSubapplWorkdayInstance: function (sysId, InstId, permId) {
			var that = this;

			var urlParams = {
				"$expand": "Nav_Access_To_FRA,Nav_Access_To_FA,Nav_Access_To_CN,Nav_Access_To_LOC,Nav_Access_To_GWA,Nav_Access_To_BS"
			}
			var oFilter = [];
			var oModel = this.getOwnerComponent().getModel("Z8CZ_WORKDAY_ADAPTIVE_SRV");
			oFilter.push(new Filter("System_ID", FilterOperator.EQ, sysId));
			oFilter.push(new Filter("INSTANCE", FilterOperator.EQ, InstId));
			oFilter.push(new Filter("Permission_ID", FilterOperator.EQ, permId)); // passed and filter for Permission ID

			oModel.read("/Access_RulesSet", {
				filters: oFilter,
				urlParameters: urlParams,
				success: function (oData) {
					that.workdaysubData = oData;
					that.getView().setModel(new JSONModel(), "ApplicationAccessModel");
					that.getView().getModel("ApplicationAccessModel").setData(that.getUniqueValues(oData.results[0].Nav_Access_To_GWA,
						"ACCESS_TYPE",
						"ACCESS_TYPE"));
					that.getView().setModel(new JSONModel(), "FunctionModel");
					that.getView().setModel(new JSONModel(), "FranchiseModel");
					that.getView().setModel(new JSONModel(), "CountryModel");
					that.getView().setModel(new JSONModel(), "LocationModel");
					that.getView().setModel(new JSONModel(), "BussinessModel"); // added bussiness site Model
					that.getView().getModel("FunctionModel").setSizeLimit(oData.results[0].Nav_Access_To_FA.results.length);
					that.getView().getModel("CountryModel").setSizeLimit(oData.results[0].Nav_Access_To_CN.results.length);
					that.getView().getModel("FranchiseModel").setSizeLimit(oData.results[0].Nav_Access_To_FRA.results.length);
					that.getView().getModel("LocationModel").setSizeLimit(oData.results[0].Nav_Access_To_LOC.results.length);
					that.getView().getModel("BussinessModel").setSizeLimit(oData.results[0].Nav_Access_To_BS.results.length);
					that.getView().getModel("FunctionModel").setData(oData.results[0].Nav_Access_To_FA.results);
					that.getView().getModel("CountryModel").setData(oData.results[0].Nav_Access_To_CN.results);
					that.getView().getModel("FranchiseModel").setData(oData.results[0].Nav_Access_To_FRA.results);
					that.getView().getModel("LocationModel").setData(oData.results[0].Nav_Access_To_LOC.results);
					that.getView().getModel("BussinessModel").setData(oData.results[0].Nav_Access_To_BS.results); // setting bussiness site Model
				},
				error: function (oError) {
					var errorMsg = that.errorMsgParse(oError);
					MessageBox.error(errorMsg);
				}
			});
		},
		getSubappliRemoveInstance: function (sysId, InstId, requestedUser) {
			var that = this;
			var oFilter = [];
			var getDetailsrv = this.getOwnerComponent().getModel("Z8CZ_WORKDAY_ADAPTIVE_SRV");
			oFilter.push(new Filter("System_ID", FilterOperator.EQ, sysId));
			oFilter.push(new Filter("INSTANCE", FilterOperator.EQ, InstId));
			oFilter.push(new Filter("User_ID", FilterOperator.EQ, requestedUser));
			busyDialog.open();
			busyDialog.setText("Loading");
			getDetailsrv.read("/Access_RulesSet", {
				filters: oFilter,
				success: function (oData) {
					that.RemoveAccessData = oData,
						that.getOwnerComponent().getModel("UamRoleRemoveModel").setData(that.getUniqueValues(oData, "ENT_VALUE", "ENT_VALUE"));
					busyDialog.close();
				},
				error: function (Error) {
					var errorMsg = that.errorMsgParse(Error);
					MessageBox.error(errorMsg);
					busyDialog.close();
				}
			});

		},
		onApplicationChange1: function (selVal, selStatus) { //selStatus can be true if selected , false if unselected
			var selectedAccessType = this.workdaysubData.results[0].Nav_Access_To_GWA.results.filter(function (oItem) {
				return oItem.ACCESS_TYPE === selVal
			});
			if (selStatus) {
				//Added for Capex instance
				if (selectedAccessType[0].INSTANCE === "CAP") {
					var capData = [{
						"market": selectedAccessType[0].MARKET,
						"costCenter": selectedAccessType[0].COST_CENTER,
						"businessSuit": selectedAccessType[0].BSITE,
						"ApplSubAppl": selectedAccessType[0].ACCESS_TYPE,
						"tech": selectedAccessType[0].TECH_1,
						"value": selVal,
						"aMarket": [],
						"aCostCenter": [],
						"hideDelBtn": true
					}];

					let array1 = [];
					if (this.getOwnerComponent().getModel("UamRoleModel").getData().length !== undefined) {
						array1 = this.getOwnerComponent().getModel("UamRoleModel").getData();
					}
				

					let newArray = array1.concat(capData);
					
					this.getView().getModel("CapexModel").setProperty("/InstanceType", this.workdaysubData.results[0].Nav_Access_To_GWA.results[0].INSTANCE);
					this.getView().getModel("CapexModel").refresh();

					this.getOwnerComponent().getModel("UamRoleModel").setData(newArray);
					this.getOwnerComponent().getModel("UamRoleModel").refresh();

				} else if (selectedAccessType[0].INSTANCE === "R&D") { //Added for Capex instance
					var RandDData = [{
						"market": selectedAccessType[0].MARKET,
						"costCenter": selectedAccessType[0].COST_CENTER,
						"businessSuit": selectedAccessType[0].BSITE,
						"ApplSubAppl": selectedAccessType[0].ACCESS_TYPE,

						"hideDelBtn": true,
						"value": selVal,
						"aMarket": [],
						"aCostCenter": [],
					}];

					let array1 = [];
					if (this.getOwnerComponent().getModel("UamRoleModel").getData().length !== undefined) {
						array1 = this.getOwnerComponent().getModel("UamRoleModel").getData();
					}
				

					let newArray = array1.concat(RandDData);
				
					this.getView().getModel("CapexModel").setProperty("/InstanceType", this.workdaysubData.results[0].Nav_Access_To_GWA.results[0].INSTANCE);
					this.getView().getModel("CapexModel").refresh();

					this.getOwnerComponent().getModel("UamRoleModel").setData(newArray);
					this.getOwnerComponent().getModel("UamRoleModel").refresh();
				} else {
					var applID = [];
					var data;
					var data1;
					this.subApplData = [];

					for (var j in this.workdaysubData.results) {
						data1 = {
							"selected": false
						}
						for (var k in this.workdaysubData.results[j].Nav_Access_To_GWA.results) {
							data = {
								"subApplication": "",
								"hier": "",
								"country": "",
								"location": "",
								"franchise": "",
								"funcArea": "",
								"market": "",
								"costCenter": "",
								"nda": "",
								"selected": false
							};
							if (selVal === this.workdaysubData.results[j].Nav_Access_To_GWA.results[k].ACCESS_TYPE) {
								data = {
									"subApplication": this.workdaysubData.results[j].Nav_Access_To_GWA.results[k].GWA,
									"country": this.workdaysubData.results[j].Nav_Access_To_GWA.results[k].COUNTRY,
									"location": this.workdaysubData.results[j].Nav_Access_To_GWA.results[k].LOCATION,
									"hier": this.workdaysubData.results[j].Nav_Access_To_GWA.results[k].ACCESS_TYPE + "~" + this.workdaysubData.results[j].Nav_Access_To_GWA
										.results[k].GWA,
									"franchise": this.workdaysubData.results[j].Nav_Access_To_GWA.results[k].FRANCHISE,
									"funcArea": this.workdaysubData.results[j].Nav_Access_To_GWA.results[k].FUNC_AREA,
									"market": this.workdaysubData.results[j].Nav_Access_To_GWA.results[k].MARKET,
									"costCenter": this.workdaysubData.results[j].Nav_Access_To_GWA.results[k].COST_CENTER,

									"selected": false
								};
								this.subApplData.push(data);
							}
						}

					}
					if (tempSubApplModel.getData().length === undefined) {
						tempSubApplModel.setData(this.subApplData);
					} else if (tempSubApplModel.getData().length > 0) {
						let array1 = tempSubApplModel.getData();
						let newArray = array1.concat(this.subApplData);
						tempSubApplModel.setData(newArray);
					}
					var appSubAppData = this.getUniqueValues({
						"results": this.subApplData
					}, "hier", "hier");
					for (var k in appSubAppData) {
						appSubAppData[k]["Application"] = appSubAppData[k]["Value"].split("~")[0];
						appSubAppData[k]["SubApplication"] = appSubAppData[k]["Value"].split("~")[1];
						appSubAppData[k]["selected"] = false;
					}
					//merge tow arrays.
					let array1 = [];
					if (this.getOwnerComponent().getModel("SubApplicationModel").getData().length !== undefined) {
						array1 = this.getOwnerComponent().getModel("SubApplicationModel").getData();
					}

					let newArray = array1.concat(appSubAppData);

					this.getOwnerComponent().getModel("SubApplicationModel").setData(newArray);
				}
			} else {
				//deselect added for Cap
				if (this.workdaysubData.results[0].Nav_Access_To_GWA.results[0].INSTANCE === "CAP") {
					var data = this.getOwnerComponent().getModel("UamRoleModel").getData();
					var newArray = [];
					for (let m = 0; m < data.length; m++) {
						if (data[m].value !== selVal) {
							newArray.push(data[m]); //
						}
					}
					this.getOwnerComponent().getModel("UamRoleModel").setData(newArray);
				} else if (selectedAccessType[0].INSTANCE === "R&D") { //Deselect added for R&D
					var data = this.getOwnerComponent().getModel("UamRoleModel").getData();
					var newArray = [];
					for (let m = 0; m < data.length; m++) {
						if (data[m].value !== selVal) {
							newArray.push(data[m]); //
						}
					}
					this.getOwnerComponent().getModel("UamRoleModel").setData(newArray);
				} else {
					var data = this.getOwnerComponent().getModel("SubApplicationModel").getData();
					var newArray = [];
					for (let m = 0; m < data.length; m++) {
						if (data[m]["Application"] !== selVal) {
							newArray.push(data[m]);
						} else {
							this.onSubApplicationChange1(data[m]["Id"], false);
						}

					}
					this.getOwnerComponent().getModel("SubApplicationModel").setData(newArray);
				}
			}
		},
		onSubApplicationChange1: function (selVal, selStatus, applName) {
			if (selStatus) {
				var InstanceType = this.workdaysubData.results[0].Nav_Access_To_GWA.results[0].INSTANCE;
				var subApplID = [];
				var data;
				this.uamRoleData = [];
				var subApplData = tempSubApplModel.getData();

				for (var j in subApplData) {
					data = {
						"country": "",
						"location": "",
						"franchise": "",
						"funcArea": "",
						"market": "",
						"costCenter": "",
						"nda": "",
						"hier1": "",
						//	"emflag": "",
						"selected": false,
						"hideDelBtn": true,
						"aMarket": [],
						"aCostCenter": []

					};
					// subApplication
					if (selVal === subApplData[j].hier) {
						data = {

							"country": subApplData[j].country,
							"location": subApplData[j].location,
							"franchise": subApplData[j].franchise,
							"funcArea": subApplData[j].funcArea,
							"market": subApplData[j].market,
							"costCenter": subApplData[j].costCenter,
							"hier1": subApplData[j].hier, //+ "~" + subApplData[j].selVal,
							//	"emflag": subApplData[j].emflag,
							"selected": false,
							"hideDelBtn": true,
							"index": Math.floor(Math.random() * (10000 - 1 + 1)) + 1,
							"aMarket": [],
							"aCostCenter": [],
						};
						this.uamRoleData.push(data);
					}
				}

				var appSubRoleData = this.getUniqueValuesForRole1({
					"results": this.uamRoleData
				}, "hier1")

				for (var k in appSubRoleData) {
					appSubRoleData[k]["ApplSubAppl"] = appSubRoleData[k]["Id"].split("~")[0] + " / " + appSubRoleData[k]["Id"].split("~")[1];
					appSubRoleData[k]["UamRole"] = appSubRoleData[k]["Id"].split("~")[2];
					//	appSubRoleData[k]["EmFlag"] = appSubRoleData[k]["Flag"];
					appSubRoleData[k]["selected"] = false;
					appSubRoleData[k]["hideDelBtn"] = true;
					appSubRoleData[k]["country"] = this.uamRoleData[k].country;
					appSubRoleData[k]["location"] = this.uamRoleData[k].location;
					appSubRoleData[k]["franchise"] = this.uamRoleData[k].franchise;
					appSubRoleData[k]["market"] = this.uamRoleData[k].market;
					appSubRoleData[k]["costCenter"] = this.uamRoleData[k].costCenter;
					appSubRoleData[k]["funcArea"] = this.uamRoleData[k].funcArea;

					appSubRoleData[k]["aMarket"] = [];
					appSubRoleData[k]["aCostCenter"] = [];

				}
				//merge tow arrays.
				let array1 = [];
				if (this.getOwnerComponent().getModel("UamRoleModel").getData().length !== undefined) {
					array1 = this.getOwnerComponent().getModel("UamRoleModel").getData();
				}
				//	array1 =this.uamRoleData;

				let newArray = array1.concat(appSubRoleData);
				//  let newArray = array1
				this.getView().getModel("CapexModel").setProperty("/InstanceType", InstanceType);
				this.getView().getModel("CapexModel").refresh();

				this.getOwnerComponent().getModel("UamRoleModel").setData(newArray);
				this.getOwnerComponent().getModel("UamRoleModel").refresh();
			} else {
				var data = this.getOwnerComponent().getModel("UamRoleModel").getData();
				var newArray = [];
				for (let m = 0; m < data.length; m++) {
					if (data[m].Id !== selVal) {
						newArray.push(data[m]);
					}
				}
				this.getOwnerComponent().getModel("UamRoleModel").setData(newArray);
			}

		},
		onApplicationChangeRemove1: function (selVal, selStatus) { //selStatus can be true if selected , false if unselected
			if (selStatus) {
				var applID = [];

				var data;
				this.subApplDataRemove = [];

				for (var j in this.RemoveAccessData.results) {
					data = {
						"subApplication": "",
						"hier": "",
						"country": "",
						"location": "",
						"franchise": "",
						"funcArea": "",
						"market": "",
						"costCenter": "",
						"nda": "",
					};
					if (selVal === this.RemoveAccessData.results[j].ACCESS_TYPE) {
						data = {
							"subApplication": this.RemoveAccessData.results[j].GWA,
							"hier": this.RemoveAccessData.results[j].ACCESS_TYPE + "~" + this.RemoveAccessData.results[j].GWA,
							"country": this.RemoveAccessData.results[j].COUNTRY,
							"location": this.RemoveAccessData.results[j].LOCATION,
							"franchise": this.RemoveAccessData.results[j].FRANCHISE,
							"funcArea": this.RemoveAccessData.results[j].FUNC_AREA,
							"market": this.RemoveAccessData.results[j].MARKET,
							"costCenter": this.RemoveAccessData.results[j].COST_CENTER

						};
						this.subApplDataRemove.push(data);
					}
				}
				if (tempSubApplRemoveModel.getData().length === undefined) {
					tempSubApplRemoveModel.setData(this.subApplDataRemove);
				} else if (tempSubApplRemoveModel.getData().length > 0) {
					let array1 = tempSubApplRemoveModel.getData();
					let newArray = array1.concat(this.subApplDataRemove);
					tempSubApplRemoveModel.setData(newArray);
				}

				var appSubAppData = this.getUniqueValues({
					"results": this.subApplDataRemove
				}, "hier", "hier");
				for (var k in appSubAppData) {
					appSubAppData[k]["Application"] = appSubAppData[k]["Value"].split("~")[0];
					appSubAppData[k]["SubApplication"] = appSubAppData[k]["Value"].split("~")[1];
					appSubAppData[k]["selected"] = false;
				}
				//merge tow arrays.
				let array1 = [];
				if (this.getOwnerComponent().getModel("SubApplicationRemoveModel").getData().length !== undefined) {
					array1 = this.getOwnerComponent().getModel("SubApplicationRemoveModel").getData();
				}

				let newArray = array1.concat(appSubAppData);

				this.getOwnerComponent().getModel("SubApplicationRemoveModel").setData(newArray);
			} else {
				var data = this.getOwnerComponent().getModel("SubApplicationRemoveModel").getData();
				var newArray = [];
				for (let m = 0; m < data.length; m++) {
					if (data[m]["Application"] !== selVal) {
						newArray.push(data[m]);
					} else {
						this.onSubApplicationChangeRemove(data[m]["SubApplication"], false);
					}
				}
				this.getOwnerComponent().getModel("SubApplicationRemoveModel").setData(newArray);
			}

		},
		onAttriRoleChangeRemove: function (selVal, selStatus, applName) {
			if (selStatus) {
				var subApplID = [];

				var data;
				this.uamRoleDataRemove = [];
				var subApplData = tempSubApplRemoveModel.getData();

				for (var j in subApplData) {
					data = {
						"country": "",
						"location": "",
						"franchise": "",
						"funcArea": "",
						"market": "",
						"costCenter": "",
						"nda": "",
						"hier1": "",
						"subApplication": "",
					};
					if (selVal === subApplData[j].subApplication) {
						data = {
							"country": subApplData[j].country,
							"location": subApplData[j].location,
							"franchise": subApplData[j].franchise,
							"funcArea": subApplData[j].funcArea,
							"market": subApplData[j].market,
							"costCenter": subApplData[j].costCenter,
							"hier1": subApplData[j].hier + "~" + subApplData[j].subApplication,
						};
						this.uamRoleDataRemove.push(data);
					}
				}

				var appSubRoleData = this.getUniqueValuesForRole1({
					"results": this.uamRoleDataRemove
				}, "hier1", "emflag");

				for (var k in appSubRoleData) {
					appSubRoleData[k]["ApplSubAppl"] = appSubRoleData[k]["Id"].split("~")[0] + " / " + appSubRoleData[k]["Id"].split("~")[1];
					appSubRoleData[k]["UamRole"] = appSubRoleData[k]["Id"].split("~")[2];

					appSubRoleData[k]["country"] = this.uamRoleDataRemove[k].country;
					appSubRoleData[k]["location"] = this.uamRoleDataRemove[k].location;
					appSubRoleData[k]["franchise"] = this.uamRoleDataRemove[k].franchise;
					appSubRoleData[k]["market"] = this.uamRoleDataRemove[k].market;
					appSubRoleData[k]["costCenter"] = this.uamRoleDataRemove[k].costCenter;
					appSubRoleData[k]["funcArea"] = this.uamRoleDataRemove[k].funcArea;
				}

				//merge tow arrays.
				let array1 = [];
				if (this.getOwnerComponent().getModel("UamRoleRemoveModel").getData().length !== undefined) {
					array1 = this.getOwnerComponent().getModel("UamRoleRemoveModel").getData();
				}

				let newArray = array1.concat(appSubRoleData);

				this.getOwnerComponent().getModel("UamRoleRemoveModel").setData(newArray);
			} else {
				var data = this.getOwnerComponent().getModel("UamRoleRemoveModel").getData();
				var newArray = [];
				for (let m = 0; m < data.length; m++) {
					if (data[m]["ApplSubAppl"].split(" / ")[1] !== selVal) {
						newArray.push(data[m]);
					}
				}
				//	this.getOwnerComponent().getModel("UamRoleRemoveModel").oData;
				this.getOwnerComponent().getModel("UamRoleRemoveModel").setData(newArray);

			}

		},

		getUniqueValuesForRole1: function (odata, key) {
			var data, dataArray = [],
				tempArray = [];
			for (var i in odata.results) {
				data = {
					"Id": "",

				}

				if (i === 0) {
					data = {
						"Id": odata.results[i][key],

					}
					dataArray.push(data);
					tempArray.push(odata.results[i][key])
				} else if (!tempArray.includes(odata.results[i][key])) {
					data = {
						"Id": odata.results[i][key],

					}
					dataArray.push(data);
					tempArray.push(odata.results[i][key]);
				}
			}
			return dataArray;
		}

	});

});