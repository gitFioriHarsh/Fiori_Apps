 sap.ui.define([
 	"com/alcon/UAM/controller/BaseController",
 	"sap/ui/model/json/JSONModel",
 	"sap/m/MessageBox",
 	"sap/ui/model/Filter",
 	"sap/ui/model/FilterOperator",
 	"com/alcon/UAM/util/formatter",
 	"sap/ui/core/Fragment",
 	"sap/m/PDFViewer"
 ], function (BaseController, JSONModel, MessageBox, Filter, FilterOperator, formatter, Fragment, PDFViewer) {
 	"use strict";
 	var gSkipValue = 0,
 		gTopValue = 25;
 	var busyDialog = new sap.m.BusyDialog();
 	return BaseController.extend("com.alcon.UAM.controller.Main", {
 		formatter: formatter,
 		onInit: function () {
 			jQuery.sap.includeStyleSheet("/sap/bc/ui5_ui5/sap/zuam/css/style.css");
 			var sRootPath = jQuery.sap.getModulePath("zuam");
 			var location = $(location).attr('href');

 			var searchType = [{
 				key: "cs",
 				value: "Complete Search"
 			}, {
 				key: "ws",
 				value: "Wildcard Search"
 			}];
 			this.getOwnerComponent().getModel("SearchTypeModel").setData(searchType);

 			this.getOwnerComponent().getRouter().getRoute("RouteMain").attachMatched(this._onRouteMatched, this);

 			this.getView().addStyleClass(this.getContentDensityClass());
 			//model for create request 
 			var createReqModel = new JSONModel();
 			sap.ui.getCore().setModel(createReqModel, "createReqModel");

 			var grcModel = new JSONModel();
 			sap.ui.getCore().setModel(grcModel, "grcModel");
 			sap.ui.getCore().getModel("grcModel").setSizeLimit(100000);

 			var concatModel = new JSONModel();
 			sap.ui.getCore().setModel(concatModel, "concatModel");

 			var mytaskModel = new JSONModel();
 			sap.ui.getCore().setModel(mytaskModel, "myTaskModel");
 			sap.ui.getCore().getModel("myTaskModel").setSizeLimit(100000);

 			var workdayModel = new JSONModel();
 			sap.ui.getCore().setModel(workdayModel, "WorkdayModel");
 			sap.ui.getCore().getModel("WorkdayModel").setSizeLimit(100000);

 			this.getView().setModel(new JSONModel(), "MyTaskEntitlementModel");

 			var ndaModel = new JSONModel();
 			sap.ui.getCore().setModel(ndaModel, "ndaReviewModel");
 			// 	this._oNavContainer = this.byId("navContainer");ndaReviewModel

 		},

 		_onRouteMatched: function () {
 			this.fetchGrcandUserDetails();
 			this.fetchworkdayDetails();
 			this.fetchTaskDetails();

 		},
 		//1600009153: Incident: Load more(Fiori)
 		onselectmyTaskTab: function () {
 			var sTab = this.byId("iconTabBar").getSelectedKey();
 			if (sTab === "GRC Request") {
 				this.byId("idNext").setVisible(true);
 				this.byId("idBack").setVisible(true);
 			} else if (sTab === "Workday Adaptive") {
 				this.byId("idNext").setVisible(false);
 				this.byId("idBack").setVisible(false);
 			} else if (sTab === "My Tasks") {
 				this.byId("idNext").setVisible(false);
 				this.byId("idBack").setVisible(false);
 			}
 		},
 		fetchworkdayDetails: function () {
 			var that = this;
 			var workdayModel = sap.ui.getCore().getModel("WorkdayModel");
 			var getDetailsrv = this.getOwnerComponent().getModel("Z8CZ_WORKDAY_ADAPTIVE_SRV");

 			busyDialog.open();
 			busyDialog.setText("Loading");

 			getDetailsrv.read("/Saviynt_ReqSet", {
 				success: function (oData) {
 					that.myworkday = oData;
 					workdayModel.setData(oData.results);
 					that.byId("idWorkdayTable").setModel(workdayModel, "WorkdayModel");
 					that.getView().byId("idWorkdayTable").getAggregation("headerToolbar").getAggregation("content")[0].setText(
 						"Saviynt Requests(" +
 						oData.results.length + ")");
 					busyDialog.close();

 				},
 				error: function (Error) {
 					var errorMsg = that.errorMsgParse(Error);
 					MessageBox.error(errorMsg);
 					busyDialog.close();
 				}
 			});
 		},
 		fetchTaskDetails: function () {
 			var that = this;
 			var mytaskModel = sap.ui.getCore().getModel("myTaskModel");
 			var uname = (sap.ushell) ? sap.ushell.Container.getUser().getId() : "SGO1";
 			var getDetailsrv = this.getOwnerComponent().getModel("Z8CZ_WORKDAY_ADAPTIVE_SRV");

 			var oFilter = [];

 			oFilter.push(new Filter("User_ID", FilterOperator.EQ, uname));
 			busyDialog.open();
 			busyDialog.setText("Loading");

 			getDetailsrv.read("/My_TaskSet", {
 				filters: oFilter,
 				success: function (oData) {
 					that.mytaskData = oData;
 					sap.ui.getCore().getModel("myTaskModel").setData(oData.results);
 					that.byId("idTaskTable").setModel(mytaskModel, "myTaskModel");
 					that.getView().byId("idTaskTable").getAggregation("headerToolbar").getAggregation("content")[0].setText("UAM Requests(" +
 						oData.results.length + ")");
 					busyDialog.close();

 				},
 				error: function (Error) {
 					var errorMsg = that.errorMsgParse(Error);
 					MessageBox.error(errorMsg);
 					busyDialog.close();
 				}
 			});
 		},
 		onUamlinkPress: function (oEvent) {
 			var that = this;
 			var aEntitleValue = [];
 			var uamReq = oEvent.getSource().getProperty("text");
 			var urlParams = {
 				"$expand": "Nav_Submit_To_Item,Nav_Submit_To_Review"
 			};
 			var oFilter = [];
 			var getDetailsrv = this.getOwnerComponent().getModel("Z8CZ_WORKDAY_ADAPTIVE_SRV");
 			oFilter.push(new Filter("UAM_REQ", FilterOperator.EQ, uamReq));
 			getDetailsrv.read("/SubmitButtonSet", {
 				filters: oFilter,
 				urlParameters: urlParams,
 				success: function (oData) {
 					that.myTaskLinkData = oData;
 					that.getView().setModel(new JSONModel(), "myTaskReviewModel");
 					that.getView().getModel("myTaskReviewModel").setData(oData.results[0]);
 					var oResults = that.myTaskLinkData.results[0].Nav_Submit_To_Item.results;
 					var data = {};
 					for (var i in oResults) {
 						data = {
 							"entitlementtype": oResults[i].entitlementtype,
 							"entitlementvalue": oResults[i].entitlementvalue,
 							"displayname": oResults[i].displayname
 						};
 						aEntitleValue.push(data);
 					}
 					that.getView().getModel("MyTaskEntitlementModel").setData(aEntitleValue);

 					that.loadReviewPage();
 				},
 				error: function (Error) {
 					var errorMsg = that.errorMsgParse(Error);
 					MessageBox.error(errorMsg);
 					busyDialog.close();
 				}
 			});
 		},

 		loadReviewPage: function () {
 			var that = this;
 			var oView = this.getView();
 			sap.ui.getCore().getModel("ndaReviewModel").setProperty("/NDABtnText", "NDA Declaration");
 			sap.ui.getCore().getModel("ndaReviewModel").setProperty("/NDABtnPressed", false);
 			sap.ui.getCore().getModel("ndaReviewModel").setProperty("/SubmitBtnEnabled", false);
 			if (!this.byId("dialogID")) {
 				Fragment.load({
 					name: "com.alcon.UAM.view.fragments.MyTaskReviewPage",
 					controller: that,
 					id: oView.getId()
 				}).then(function (oDialog) {
 					oDialog.setModel(that.getView().getModel("myTaskReviewModel"), "myTaskReviewModel");
 					oDialog.open();
 				});
 			} else {
 				this.byId("dialogID").setModel(that.getView().getModel("myTaskReviewModel"), "myTaskReviewModel");
 				this.byId("dialogID").open();
 			}

 		},
 		onPressNdaButton: function () {
 			var that = this;
 			var sSource;
 			var sServiceURL;
 			var oController = this.getView();

 			var opdfViewer = new PDFViewer();
 			this.getView().addDependent(opdfViewer);

 			sServiceURL = '/sap/opu/odata/sap/Z8CZ_WORKDAY_ADAPTIVE_SRV/';

 			sSource = sServiceURL + "NDASet(DOC_NAME='NDA')/$value";
 			opdfViewer.setSource(sSource);
 			opdfViewer.setTitle("Non Disclosure Agreement");
 			opdfViewer.setDisplayType("Embedded");
 			opdfViewer.addPopupButton(new sap.m.Button({
 				text: "Accept",
 				type: "Accept",
 				press: function (oEvent) {
 					that.onAcceptNDA(oEvent, opdfViewer);
 				}

 			}));
 			opdfViewer.addPopupButton(new sap.m.Button({
 				text: "Reject",
 				type: "Reject",
 				press: function (oEvent) {
 					that.onRejectNDA(oEvent, opdfViewer);
 				}

 			}));
 			opdfViewer.addPopupButton(new sap.m.Button({
 				text: "Close",
 				type: "Emphasized",
 				press: function (oEvent) {
 					that.onCloseNDA(oEvent, opdfViewer);
 				}

 			}));
 			opdfViewer._objectsRegister.getPopupCloseButton().setVisible(false);
 			oController.addDependent(opdfViewer);
 			opdfViewer.open();

 		},
 		onAcceptNDA: function (oEvent, opdfViewer) {
 			var p = opdfViewer._objectsRegister.getPopup();
 			p.removeAllContent();
 			p.oPopup.close();

 			sap.ui.getCore().getModel("ndaReviewModel").setProperty("/SubmitBtnEnabled", true);
 			sap.ui.getCore().getModel("ndaReviewModel").setProperty("/NDABtnPressed", true);
 			sap.ui.getCore().getModel("ndaReviewModel").setProperty("/NDABtnText", "NDA Declaration Accepted");
 		},
 		onRejectNDA: function (oEvent, opdfViewer) {
 			var reject = opdfViewer._objectsRegister.getPopup();
 			reject.removeAllContent();
 			reject.oPopup.close();

 			sap.ui.getCore().getModel("ndaReviewModel").setProperty("/SubmitBtnEnabled", false);
 			sap.ui.getCore().getModel("ndaReviewModel").setProperty("/NDABtnPressed", true);
 			sap.ui.getCore().getModel("ndaReviewModel").setProperty("/NDABtnText", "NDA Declaration Rejected");
 		},
 		onCloseNDA: function (oEvent, opdfViewer) {
 			var closeNDA = opdfViewer._objectsRegister.getPopup();
 			closeNDA.removeAllContent();
 			closeNDA.oPopup.close();

 			sap.ui.getCore().getModel("ndaReviewModel").setProperty("/NDABtnVisible", true);
 			sap.ui.getCore().getModel("ndaReviewModel").setProperty("/NDABtnPressed", false);

 		},
 		onCancelDialog: function () {
 			this.byId("dialogID").close();
 			this.byId("dialogID").destroy();
 		},
 		onSubmitMyTask: function () {
 			var that = this;
 			var InstId = that.myTaskLinkData.results[0].INSTANCE_ID; //pasing instID in endpoint
 			var payload = {
 				"requesttype": "ADD",
 				"username": that.myTaskLinkData.results[0].EMP_ID,
 				"endpoint": InstId, 
 				"accountname": that.myTaskLinkData.results[0].Email,
 				"comments": that.myTaskLinkData.results[0].comments,
 				"requestor": that.myTaskLinkData.results[0].Nav_Submit_To_Review.results[0].BATCH_ID,
 				"createaccountifnotexists": "false",
 				"dynamicattr": {
 					"Permissionset": that.myTaskLinkData.results[0].Permission_ID,
 					"Permissionset_Name": that.myTaskLinkData.results[0].Permission_Name,
 					"seglevel": that.myTaskLinkData.results[0].Seglevel,
 					"seglvlcr": that.myTaskLinkData.results[0].CONTRY
 				},
 				"entitlement": that.getView().getModel("MyTaskEntitlementModel").getData(),
 				"checksod": "false"
 			};
 			busyDialog.open();
 			busyDialog.setText("Loading");
 			$.ajax({
 				type: 'POST',
 				contentType: "application/json",
 				dataType: 'json',
 				headers: {
 					"Access-Control-Allow-Origin": "*",
 					"Access-Control-Allow-Headers": "*",
 					"Access-Control-Allow-Credentials": "true",
 					"Access-Control-Allow-Methods": "*",
 					//	"contentType": "application/json; charset=utf-8",
 					"Accept": "application/json, text/html"
 				},
 				url: that.myTaskLinkData.results[0].Nav_Submit_To_Review.results[0].URL,
 				data: JSON.stringify(payload),
 				async: true,
 				cache: false,
 				success: function (data) {
 					busyDialog.close();
 					if (data.errorCode === "0") {
 						that.onSaveTaskSaviyantDetails(data);
 					} else {
 						MessageBox.error(data.message);
 					}
 				},
 				error: function (oError) {
 					MessageBox.error("Create request failed");
 				},
 				beforeSend: function (req) {
 					req.setRequestHeader("Authorization", "Basic " + btoa(that.myTaskLinkData.results[0].Nav_Submit_To_Review.results[0].RFC_ID +
 						":" + that.myTaskLinkData.results[0].Nav_Submit_To_Review.results[0].Password)); // <<<<----- USED HERE
 				}
 			});
 		},
 		onSaveTaskSaviyantDetails: function (data) {
 			var that = this;
 			var oDataPayload = {
 				"User_ID": that.myTaskLinkData.results[0].User_ID,
 				"SAV_REQ": data.requestkey,
 				"SAV_REQ_ID": data.RequestId,
 				"NDA": "X",
 				"REQ_FOR": that.myTaskLinkData.results[0].REQ_FOR,
 				"UAM_REQ": that.myTaskLinkData.results[0].UAM_REQ,
 				"Nav_Submit_To_Item": [{
 					"System_ID": "PROD"
 				}]
 			};

 			var saveDetailsSrv = this.getOwnerComponent().getModel("Z8CZ_WORKDAY_ADAPTIVE_SRV");
 			busyDialog.open();

 			saveDetailsSrv.create("/SubmitButtonSet", oDataPayload, {
 				success: function (oData) {
 					busyDialog.close();
 					var dataMsg = {
 						"MsgType": "S",
 						"MsgText": "Saviynt Request " + oDataPayload.SAV_REQ + " created successfully."
 					};
 					that.showMessage(dataMsg);
 				},
 				error: function (Error) {
 					var errorMsg = that.errorMsgParse(Error);
 					MessageBox.error(errorMsg);
 					busyDialog.close();
 				}
 			});

 		},
 		showMessage: function (oResult) {

 			MessageBox[(oResult.MsgType === "S") ? "success" : "error"](oResult.MsgText, {
 				actions: [MessageBox.Action.CLOSE],
 				onClose: function (oAction) {
 					this.closeAction();
 				}.bind(this)
 			});
 		},
 		closeAction: function () {
 			this.byId("dialogID").close();
 			this.byId("dialogID").destroy();
 			
 		},
 		onFilterChangeUAM: function (oEvent) {
 			this.toCallFilter(oEvent, "GRC_ID", "idGrcTable")
 		},
 		onFilterChangeWorkDay: function (oEvent) {
 			this.toCallFilter(oEvent, "SAV_REQ", "idWorkdayTable");
 		},
 		onFilterChangeMyTask: function (oEvent) {
 			this.toCallFilter(oEvent, "UAM_REQ", "idTaskTable")
 		},
 		toCallFilter: function (oEvent, ctrlId, tableId) {
 			var sId = oEvent.getSource().sId;
 			var fill = oEvent.getSource().getValue();
 			var that = this;
 			var oFilter = [],
 				oFilter1 = [],
 				oFilter2 = [];
 			//condition to filter the UAM, Saviyant and My Task requests
 			if (sId.includes("idFilterID")) {
 				oFilter.push(new Filter(ctrlId, FilterOperator.Contains, fill));
 			}
 			if (sId.includes("idFilterName")) {
 				oFilter.push(new Filter({
 					filters: [
 						new Filter("USER_NAME", FilterOperator.Contains, fill),
 						new Filter("REQUESTED_FOR_ID", FilterOperator.Contains, fill),
 					],
 					and: false,
 				}));
 			}

 			this.getView().byId(tableId).getBinding("items").filter(oFilter);

 		},
 		liveChangeFunction: function (event) {
 			var str = event.getSource().getValue().toUpperCase();
 			event.getSource().setValue(str);

 		},

 		onAfterRendering: function () {

 			this.byId("page").scrollTo(0);
 			this.fetchGrcandUserDetails();
 			this.fetchTaskDetails();
 			this.fetchworkdayDetails();

 		},

 		onPressBack: function () {
 			this.byId("page").scrollTo(0);
 		},

 		onPressNext: function () {
 			var that = this;
 			var mData = [],
 				concatData = [];
 			var grcModel = sap.ui.getCore().getModel("grcModel");
 			gSkipValue = gTopValue;
 			gTopValue = gTopValue + 25;
 			busyDialog.open();
 			var getUserDetailservice = this.getOwnerComponent().getModel("ZAL_CREATE_REQUEST_SRV_01");
 			getUserDetailservice.read("/GRC_HEADER_TSet", {
 				urlParameters: {
 					"$top": gTopValue,
 					"$skip": gSkipValue
 				},
 				success: function (oData) {
 					busyDialog.close();
 					mData = that.byId("idGrcTable").getModel("GRCModel").getData();
 					concatData = mData.concat(oData.results);
 					if (oData.results.length !== 0) {
 						sap.ui.getCore().getModel("grcModel").setData(concatData);
 						that.byId("idGrcTable").setModel(grcModel, "GRCModel");
 						that.byId("idGrcTable").getModel("GRCModel").refresh(true);
 						that.getView().byId("idGrcTable").getAggregation("headerToolbar").getAggregation("content")[0].setText("GRC Requests(" +
 							oData.results.length + ")");
 					} else {
 						that.byId("idNext").setEnabled(false);
 						return;
 					}
 				},
 				error: function (oError) {
 					var errorMsg = that.errorMsgParse(oError);
 					MessageBox.error(errorMsg);
 					busyDialog.close();
 				}
 			});
 		},

 		// onUpdateFinished: function (oEvent) {
 		// 	this.getView().byId("idGrcTable").getAggregation("headerToolbar").getAggregation("content")[0].setText("GRC Requests(" + oEvent.getParameters()[
 		// 		"total"] + ")");

 		// },
 		//application 4 filter
 		fetchGrcandUserDetails: function () {
 			var that = this;
 			var grcModel = sap.ui.getCore().getModel("grcModel");
 			var getUserDetailsrv = this.getOwnerComponent().getModel("ZAL_CREATE_REQUEST_SRV_01");
 			getUserDetailsrv.setDeferredGroups(["HomePage"]);
 			this.byId("cbApp").setSelectedKey("");

 			var uname = (sap.ushell) ? sap.ushell.Container.getUser().getId() : "REDDYRO5";
 			var oFilter = [];

 			oFilter.push(new Filter("REQUESTOR_ID", FilterOperator.EQ, uname));

 			getUserDetailsrv.read("/User_DetailsSet(User_ID='" + uname + "')", {
 				groupId: "HomePage"
 			});

 			getUserDetailsrv.read("/APPL_TYPESet", {
 				groupId: "HomePage"
 			});

 			getUserDetailsrv.submitChanges({
 				groupId: "HomePage",
 				success: function (oData) {
 					that.getOwnerComponent().getModel("LogInUserModel").setData(oData.__batchResponses[0].data); //logged user in details

 					// System combo box data
 					that.applList = oData.__batchResponses[1].data;
 					/*  This line has to be enabled when all the applications are in place	*/
 					that.getOwnerComponent().getModel("ApplicationModel").setData(that.getUniqueValues(oData.__batchResponses[1].data, "Appl_ID",
 						"Application_Type"));
 					busyDialog.open();
 					getUserDetailsrv.read("/GRC_HEADER_TSet", {
 						urlParameters: {
 							"$top": 25,
 							"$skip": 0
 						},
 						success: function (oData) {
 							busyDialog.close();
 							sap.ui.getCore().getModel("grcModel").setData(oData.results);
 							that.byId("idGrcTable").setModel(grcModel, "GRCModel");
 							that.getView().byId("idGrcTable").getAggregation("headerToolbar").getAggregation("content")[0].setText("GRC Requests(" +
 								oData.results.length + ")"); //GRC Count
 						},
 						error: function (oError) {
 							var errorMsg = that.errorMsgParse(oError);
 							MessageBox.error(errorMsg);
 							busyDialog.close();
 						}
 					});
 				},
 				error: function (oError) {
 					var errorMsg = that.errorMsgParse(oError);
 					MessageBox.error(errorMsg);
 					busyDialog.close();
 				}
 			});

 		},
 		//application drop down
 		toCreateRequest: function () {

 			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
 			if (this.byId("cbApp").getSelectedKey() !== "") {
 				var id = this.byId("cbApp").getSelectedKey();
 				var selText = this.byId("cbApp")._getSelectedItemText();
 				sap.ui.getCore().getModel("createReqModel").setProperty("/application_id", id);
 				sap.ui.getCore().getModel("createReqModel").setProperty("/aaplication_desc", selText);

 				if (this.byId("cbApp").getSelectedKey() === "002") {
 					this.getOwnerComponent().applName = selText;
 					this.getOwnerComponent().applId = "002";
 					oRouter.navTo("ADWHCreateRequest");
 				} else if (this.byId("cbApp").getSelectedKey() === "003") {
 					this.getOwnerComponent().applName = selText;
 					this.getOwnerComponent().applId = "003";
 					oRouter.navTo("APMRCreateRequest");
 				} else if (this.byId("cbApp").getSelectedKey() === "004") {
 					this.getOwnerComponent().applName = selText;
 					this.getOwnerComponent().applId = "004";
 					oRouter.navTo("AlconBICreateRequest");
 				} else if (this.byId("cbApp").getSelectedKey() === "005") { //Added work Adaptive on 21/03/2022
 					this.getOwnerComponent().applName = selText;
 					this.getOwnerComponent().applId = "005";
 					oRouter.navTo("WorkAdaptive");
 				}
 			} else {
 				this.byId("cbApp").setValueState("Error");
 				return;
 			}

 		},
 		handleLinkPress: function () {
 			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
 			oRouter.navTo("Detail");
 		},
 		onChangeApplication: function (oEvent) {
 			var appKey = oEvent.getSource().getSelectedKey();
 			var data, dataArray = [];
 			for (var j in this.applList.results) {
 				data = {
 					"Id": "",
 					"Value": ""
 				};
 				if (this.applList.results[j].Appl_ID === appKey) {
 					data = {
 						"Id": this.applList.results[j].System_ID,
 						"Value": this.applList.results[j].System_ID
 					};
 					dataArray.push(data);
 				}

 			}
 			this.getOwnerComponent().getModel("SystemModel").setData(dataArray);

 		},
 		//Status column colour change
 		handleStatusSelectionChange: function (oEvent) {
 			var aFilters = this.byId("idGrcTable").getBinding("items").aFilters;
 			var i = aFilters.length;
 			while (i--) {
 				if (aFilters[i].sPath === "STATUS") {
 					aFilters.splice(i, 1);
 				}
 			}
 			this.selectAllItems(oEvent);
 			var keys = oEvent.getSource().getProperty("selectedKeys");
 			for (var li in keys) {
 				if (!keys.includes("Select All") && !keys.includes("")) {
 					aFilters.push(new Filter("STATUS", "EQ", keys[li]));
 				}
 			}
 			this.byId("idGrcTable").getBinding("items").filter(aFilters);
 		},
 		//This event for the Status filter in Workday adaptive
 		handleStatusSelectionChangeForWork: function (oEvent) {
 			var aFilters = this.byId("idWorkdayTable").getBinding("items").aFilters;
 			var i = aFilters.length;
 			while (i--) {
 				if (aFilters[i].sPath === "Status") {
 					aFilters.splice(i, 1);
 				}
 			}
 			this.selectAllItems(oEvent);
 			var keys = oEvent.getSource().getProperty("selectedKeys");
 			for (var li in keys) {
 				if (!keys.includes("Select All") && !keys.includes("")) {
 					aFilters.push(new Filter("Status", "EQ", keys[li]));
 				}
 			}
 			this.byId("idWorkdayTable").getBinding("items").filter(aFilters);
 		},
 		//Status check box functionalty 
 		selectAllItems: function (oEvent) {

 			var changedItem = oEvent.getParameter("changedItem");
 			var isSelected = oEvent.getParameter("selected");
 			var selectedKeys = oEvent.getSource().getSelectedKeys();
 			var state = "Selected";

 			if (!isSelected) {
 				state = "Deselected";
 			}

 			//Check if "Selected All is selected
 			if (changedItem.getProperty("text").trim() == "Select All") {
 				var oName, res;

 				//If it is Selected
 				if (state == "Selected") {

 					var oItems = oEvent.getSource().getAggregation("items");
 					for (var i = 0; i < oItems.length; i++) {
 						if (i == 0) {
 							oName = oItems[i].getProperty("text");
 							if (oName === "Select All") {
 								oName = "Select All";
 							}
 						} //If i == 0	
 						else {
 							oName = oName + '~!' + oItems[i].getProperty("key");
 						}

 					} //End of For Loop

 					res = oName.split("~!");
 					oEvent.oSource.setSelectedKeys(res);

 				} else {

 					res = null;
 					oEvent.getSource().setSelectedKeys(res);
 				}
 			} else if (changedItem.getProperty("text").trim() !== "Select All" && state === "Deselected") {
 				if (selectedKeys.includes("Select All")) {
 					var index = selectedKeys.findIndex(getAll);
 					selectedKeys.splice(index, 1);
 					oEvent.getSource().setSelectedKeys(selectedKeys);
 				}
 			} else if (changedItem.getProperty("text").trim() !== "Select All" && state === "Selected") {
 				if (selectedKeys.length === oEvent.getSource().mAggregations.items.length - 1) {
 					selectedKeys.push("Select All");
 					oEvent.getSource().setSelectedKeys(selectedKeys);
 				}
 			}

 			function getAll(value) {
 				return value === "Select All";
 			}
 		}

 	});
 });