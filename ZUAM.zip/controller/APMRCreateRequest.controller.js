// var key; 
sap.ui.define([
	"com/alcon/UAM/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageBox",
	"sap/m/MessageToast",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/core/Fragment",
	"sap/ui/model/odata/v2/ODataModel",
	"sap/ui/core/routing/History",
	"com/alcon/UAM/util/formatter"
], function (BaseController, JSONModel, MessageBox, MessageToast, Filter, FilterOperator, Fragment, ODataModel, History, formatter) {
	"use strict";
	var busyDialog = new sap.m.BusyDialog();
	var addSel = false,
		removeSel = false;
	return BaseController.extend("com.alcon.UAM.controller.APMRCreateRequest", {
		formatter: formatter,
		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.alcon.UAM.view.createRequest
		 */
		onInit: function () {
			jQuery.sap.includeStyleSheet("/sap/bc/ui5_ui5/sap/zuam/css/style.css");
			var sRootPath = jQuery.sap.getModulePath("zuam");
			var location = $(location).attr('href');

			this.getOwnerComponent().getRouter().getRoute("APMRCreateRequest").attachMatched(this._onRouteMatched, this);
			this.getView().addStyleClass(this.getContentDensityClass());
			this._wizard = this.byId("UserRoleAccessWizard");
			this._oNavContainer = this.byId("navContainer");
			this._oDynamicPage = this.getView();

			var oModel = this.getOwnerComponent().getModel("ZAL_CREATE_REQUEST_SRV_01");
			oModel.setSizeLimit(100000);
			this.getView().setModel(oModel);
			var flagModel = new JSONModel({
				flag: "false"
			});
			sap.ui.getCore().setModel(flagModel, "flagModel");

		},

		_onRouteMatched: function (oEvent) {
			var error = ["", null, undefined];
			if (error.includes(this.getOwnerComponent().applId)) {
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("RouteMain");
			} else {
				this.byId("cbSystem").setSelectedKey("PF3");
				this.byId("taReason").setValue("");
				this.byId("txtApp").setText(this.getOwnerComponent().applName);
				this.getOwnerComponent().getModel("OtherUserModel1").setData({});

				this.clearModelData(); //this is to clear all the model data
				var currentStep = this.getView().byId("UserRoleAccessWizard").getAssociation("currentStep");
				if (currentStep.includes("roleSelection")) {
					this.getView().byId('UserRoleAccessWizard').previousStep();
					this.getView().byId('UserRoleAccessWizard').previousStep();
				} else if (currentStep.includes("departmentSelection")) {
					this.getView().byId('UserRoleAccessWizard').previousStep();
				}
			}
		},
		onNavBack: function () {
			MessageBox.warning("Your data may be lost. Are you sure to continue?", {
				actions: [MessageBox.Action.YES, MessageBox.Action.NO],
				onClose: function (oAction) {

					if (oAction === MessageBox.Action.YES) {
						this.clearModelData();
						var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
						oRouter.navTo("RouteMain");
					} else if (oAction === MessageBox.Action.NO) {
						return;
					}
				}.bind(this)
			});

		},

		resetCreateReqModel: function () {
			var oMod = sap.ui.getCore().getModel("createReqModel");
			oMod.setProperty("/selfFlag", "true");
			oMod.setProperty("/user_id", "");
			oMod.setProperty("/line_manager", "");
			oMod.setProperty("/application_id", "");
			oMod.setProperty("/aaplication_desc", "");
			oMod.setProperty("/system_id", "PF3");
			oMod.setProperty("/start_date", "");
			oMod.setProperty("/end_date", "");
			oMod.setProperty("/job_title", "");
			oMod.setProperty("/segr_level", "");
			oMod.setProperty("/reason", "");
			oMod.setProperty("/consolidation_flag", "false");
			oMod.setProperty("/selType", "");

		},
		liveChangeFunction: function (event) {
			var str = event.getSource().getValue().toUpperCase();
			event.getSource().setValue(str);

		},

		onAfterRendering: function () {
			var that = this;
			var getDetailsrv = this.getOwnerComponent().getModel("ZAL_CREATE_REQUEST_SRV_01");
			sap.ui.getCore().getModel("createReqModel");

			this.byId("txtApp").setText(this.getOwnerComponent().applName);

			this.byId("cbSystem").setSelectedKey("PF3");

		},

		onForSelfSelect: function (oEvent) {
			if (oEvent !== "" && oEvent.getParameters()["selected"]) {
				this.byId("cbRTForOther").setSelected(false);
				this.byId("lbl521MgrId").setVisible(true);
				this.byId("in521MgrNameId").setVisible(true);
				this.byId("lbl521Id").setVisible(false);
				this.byId("in521Id").setVisible(false);
				this.byId("in521Id").setValue("");
				sap.ui.getCore().getModel("createReqModel").setProperty("/selfFlag", "true");
				this.byId("idOtherDet").setVisible(false);

			} else {
				this.byId("cbRTForOther").setSelected(false);
				this.byId("cbRTForSelf").setSelected(true);
				this.byId("lbl521Id").setVisible(false);
				this.byId("in521Id").setVisible(false);
				this.byId("in521Id").setValue("");
				this.byId("idOtherDet").setVisible(false);

			}
			this.onChangeSystem();

		},
		onForOtherSelect: function (oEvent) {
			if (oEvent.getParameters()["selected"]) {
				this.byId("cbRTForSelf").setSelected(false);
				this.byId("lbl521MgrId").setVisible(false);
				this.byId("in521MgrNameId").setVisible(false);
				this.byId("lbl521Id").setVisible(true);
				this.byId("in521Id").setVisible(true);
				this.byId("in521Id").setValue("");
				sap.ui.getCore().getModel("createReqModel").setProperty("/selfFlag", "false");
			} else {
				this.byId("cbRTForOther").setSelected(true);
			}
			this.onChangeSystem();

		},
		getList: function (data) {
			var list = [];

			for (var i in data) {
				list.push({
					"value": data[i].getAggregation("cells")[0].getText()
				});
			}
			return list;
		},
		onReasonChange: function () {
			if (this.byId("taReason").getValue() != "") {
				this.byId("taReason").setValueState("None");
			}
		},
		completedHandler: function () {
			this.subApplRole = [];
			var data = {},
				subApps, busRolesPath = [],
				key = this.byId("itbApmrRole").getSelectedKey();
			if (key === "addRole") {
				subApps = this.byId("liSubApplication").getSelectedItem();
				busRolesPath = this.byId("liBusRole").getSelectedContextPaths();
			} else if (key === "removeRole") {
				subApps = this.byId("liSubApplicationRemove").getSelectedItem();
				busRolesPath = this.byId("liBusRoleRemove").getSelectedContextPaths();
			}

			//Consolidate the list of selected sub Application and roel
			for (let i in busRolesPath) {
				if (this.byId("itbApmrRole").getSelectedKey() === "addRole") {
					data = {
						"subApplication": subApps.getAggregation("cells")[0].getText(),
						"uamRoles": this.getOwnerComponent().getModel("UamRoleModel").getProperty(busRolesPath[i]).Value
					}
				} else if (this.byId("itbApmrRole").getSelectedKey() === "removeRole") {
					data = {
						"subApplication": subApps.getAggregation("cells")[0].getText(),
						"uamRoles": this.getOwnerComponent().getModel("UamRoleRemoveModel").getProperty(busRolesPath[i]).Value
					}
				}

				this.subApplRole.push(data);
			}
			if (this.byId("taReason").getValue() === "") {
				this.byId("taReason").setValueState("Error");
				return;
			}
			if (busRolesPath.length === 0) {
				MessageToast.show("Select atleast one reporting unit");
				return;
			}
			sap.ui.getCore().getModel("createReqModel").setProperty("/selType", (key === "addRole") ? "Add Role" : "Remove Role");
			sap.ui.getCore().getModel("createReqModel").setProperty("/subApplication", this.subApplRole);

			sap.ui.getCore().getModel("createReqModel").setProperty("/reason", this.byId("taReason").getValue());

			sap.ui.getCore().getModel("createReqModel").setProperty("/system_id", this.byId("cbSystem").getSelectedKey());
			sap.ui.getCore().getModel("createReqModel").setProperty("/start_date", this.byId("DP1").getValue());
			sap.ui.getCore().getModel("createReqModel").setProperty("/end_date", this.byId("DP2").getValue());

			var check = sap.ui.getCore().getModel("createReqModel").getProperty("/selfFlag");
			sap.ui.getCore().getModel("createReqModel").setProperty("/requestor_id", this.byId("selfUserID").getText());
			if (check == "false") {
				sap.ui.getCore().getModel("createReqModel").setProperty("/full_name", this.byId("otherName").getText());
				sap.ui.getCore().getModel("createReqModel").setProperty("/line_manager_name", this.byId("managerfieldval").getValue());
				sap.ui.getCore().getModel("createReqModel").setProperty("/user_dept", this.byId("otherDept").getText());
				sap.ui.getCore().getModel("createReqModel").setProperty("/user_country", this.byId("otherCountry").getText());
				sap.ui.getCore().getModel("createReqModel").setProperty("/user_jobtitle", this.byId("otherJobTitle").getText());

			} else {
				sap.ui.getCore().getModel("createReqModel").setProperty("/full_name", this.byId("selfName").getTitle());
				sap.ui.getCore().getModel("createReqModel").setProperty("/line_manager_name", this.byId("selfLineManager").getText());
				sap.ui.getCore().getModel("createReqModel").setProperty("/user_dept", this.byId("selfDept").getText());
				sap.ui.getCore().getModel("createReqModel").setProperty("/user_country", this.byId("selfCountry").getText());
				sap.ui.getCore().getModel("createReqModel").setProperty("/user_jobtitle", this.byId("selfJobTitle").getText());
			}

			Fragment.load({
				name: "com.alcon.UAM.view.fragments.APMRReviewPage",
				controller: this
			}).then(function (oWizardReviewPage) {
				this._oWizardReviewPage = oWizardReviewPage;
				this._oNavContainer.addPage(this._oWizardReviewPage);

				sap.ui.getCore().byId("wizardBranchingReviewPage").setModel(sap.ui.getCore().getModel("createReqModel"), "createReqModel");
				var details = sap.ui.getCore().getModel('createReqModel').oData.selType;
				sap.ui.getCore().byId('tblApplication').setHeaderText(details);
				this._oNavContainer.to(this._oWizardReviewPage); ////to bechecked
			}.bind(this));

		},
		_handleMessageBoxOpen: function (sMessage, sMessageBoxType) {
			MessageBox[sMessageBoxType](sMessage, {
				actions: [MessageBox.Action.YES, MessageBox.Action.NO],
				onClose: function (oAction) {

					if (oAction === MessageBox.Action.YES) {
						this._wizard.discardProgress(this._wizard.getSteps()[0]);
						this.handleNavBackToList();
					}
				}.bind(this)
			});
		},
		toCancel: function () {
			this.closeAction();

		},
		handleNavBackToList: function () {
			this._navBackToStep(this.byId("userSelection"));
			this.resetCreateReqModel();
		},

		_navBackToStep: function (step) {
			var fnAfterNavigate = function () {
				this._wizard.goToStep(step);
				this._oNavContainer.detachAfterNavigate(fnAfterNavigate);
			}.bind(this);

			this._oNavContainer.attachAfterNavigate(fnAfterNavigate);
			this._oNavContainer.to(this._oDynamicPage);
		},

		onChangeRequestType: function () {

			if (this.byId("cbRequestType").getValue() === "Other User") {
				this.byId("lbl521Id").setVisible(true);
				this.byId("in521Id").setVisible(true);
			}
		},
		changeDateValueState: function (event) {
			var selKey = event.getSource().getValue();
			sap.ui.getCore().getModel("createReqModel").setProperty("/start_date", selKey);
			if (selKey != "") {
				event.getSource().setValueState("None");
			}
		},
		handleChange: function (event) {
			var selKey = event.getSource().getValue();
			sap.ui.getCore().getModel("createReqModel").setProperty("/end_date", selKey);
			if (selKey != "") {
				event.getSource().setValueState("None");
			}
		},

		changeValueState: function (event) {
			var selKey = event.getSource().getSelectedKey();
			var currentStep = this.getView().byId("UserRoleAccessWizard").getAssociation("currentStep");
			if (currentStep.includes("roleSelection")) {
				this.getView().byId('UserRoleAccessWizard').previousStep();
			}
			if (selKey != "") {
				event.getSource().setValueState("None");
			}
			var sId = event.getSource().sId;
			if (sId.includes("cbDepartment")) {
				sap.ui.getCore().getModel("createReqModel").setProperty("/job_title", selKey);
			}
		},
		setBtnVisible() {
			sap.ui.getCore().byId("id2--btOK").setVisible(true);
		},

		onSubApplChange: function (oEvent) {
			//flag to know which section is selected
			addSel = true;
			removeSel = false;
			var selSubAppItem = this.byId("liSubApplication").getSelectedItem().getAggregation("cells")[0].getText();

			var data;
			this.uamRoleData = [];

			for (var j in this.getOwnerComponent().getModel("ApplicationModel1").getData().results) {

				if (selSubAppItem === this.getOwnerComponent().getModel("ApplicationModel1").getData().results[j].Subapplication) {
					data = {

						"uamRole": this.getOwnerComponent().getModel("ApplicationModel1").getData().results[j].UAM_Role
					};
					this.uamRoleData.push(data);
				}

			}

			var appSubRoleData = this.getUniqueValues({
				"results": this.uamRoleData
			}, "uamRole", "uamRole")
			this.byId("liBusRole").removeSelections();
			this.getOwnerComponent().getModel("UamRoleModel").setSizeLimit(appSubRoleData.length);
			this.getOwnerComponent().getModel("UamRoleModel").setData(appSubRoleData);

		},
		onUamRoleChange: function (oEvent) {
			this.onBusRoleChange(oEvent);
		},

		onSubApplRemoveChange: function (oEvent) {
			//flag to know which section is selected
			addSel = false;
			removeSel = true;
			var selSubAppItem = this.byId("liSubApplicationRemove").getSelectedItem().getAggregation("cells")[0].getText();

			var data;
			this.uamRoleData = [];

			for (var j in this.getOwnerComponent().getModel("ApplicationModel2").getData().results) {

				if (selSubAppItem === this.getOwnerComponent().getModel("ApplicationModel2").getData().results[j].Subapplication) {
					data = {

						"uamRole": this.getOwnerComponent().getModel("ApplicationModel2").getData().results[j].UAM_Role
					};
					this.uamRoleData.push(data);
				}

			}

			var appSubRoleData = this.getUniqueValues({
				"results": this.uamRoleData
			}, "uamRole", "uamRole")
			this.byId("liBusRoleRemove").removeSelections();
			this.getOwnerComponent().getModel("UamRoleRemoveModel").setData(appSubRoleData);

		},

		onChange521Id: function (User_ID) {
			var getDetailsrv = this.getOwnerComponent().getModel("ZAL_CREATE_REQUEST_SRV_01");
			var that = this;
			var selUser = User_ID;

			sap.ui.getCore().getModel("createReqModel").setProperty("/user_id", selUser);
			var oFilter = new Array();
			var usrFilter = new Filter("User_ID", FilterOperator.EQ, selUser);
			oFilter.push(usrFilter);

			var omod = this.getView().getModel("List521Model");
			this.getView().setModel(omod, "List521Model");

			getDetailsrv.read("/User_DetailsSet(User_ID='" + selUser + "')", {

				success: function (oData) {
					that.getOwnerComponent().getModel("OtherUserModel1").setData(oData);
					sap.ui.getCore().getModel("createReqModel").setProperty("/line_manager_name", oData.Line_Manager);
					sap.ui.getCore().getModel("createReqModel").setProperty("/line_manager_id", oData.Line_Manager_ID);
				},
				error: function (oError) {
					var errorMsg = that.errorMsgParse(oError);
					MessageBox.error(errorMsg);
					busyDialog.close();
				}
			});
			var user_name = this.getOwnerComponent().getModel("OtherUserModel1").getProperty("/Name");

			this.byId("managerfield").setVisible(true);
			this.byId("managerfieldval").setVisible(true);

			this.byId("idOtherDet").setVisible(true);
		},

		onNextStep: function (oEvent) {
			var that = this;
			var busApplName = "APMR";

			if (oEvent.getParameters()["index"] === 2) {

				var sysId = this.getView().byId("cbSystem").getSelectedKey();
				var appId = this.getOwnerComponent().applId;
				var sDate = this.getView().byId("DP1").getValue();
				var eDate = this.getView().byId("DP2").getValue();
				var startDate = new Date(sDate.split("-")[2], sDate.split("-")[1], sDate.split("-")[0]);
				var endDate = new Date(eDate.split("-")[2], eDate.split("-")[1], eDate.split("-")[0]);

				var lMan = this.byId("managerfieldval").getValue();
				if (this.byId("cbRTForOther").getSelected() && this.byId("in521Id").getValue() === "") {
					this.getView().byId("in521Id").setValueState("Error");
					return;
				}
				if ((sysId !== "" && appId != "") && (sDate !== "" && eDate !== "") && (this.isValidDate(startDate) && this.isValidDate(endDate)) &&
					(startDate <= endDate)) {
					this.getDepartSeg(sysId, appId, busApplName);
				} else {
					if (sysId == "") {
						this.getView().byId("cbSystem").setValueState("Error");
					}

					if (sDate == "" || !(this.isValidDate(startDate))) {
						this.getView().byId("DP1").setValueState("Error");
					}
					if (eDate == "" || !(this.isValidDate(endDate))) {
						this.getView().byId("DP2").setValueState("Error");
					}
					if (startDate > endDate) {
						this.getView().byId("DP2").setValueState("Error");
					}
					this.getView().byId('UserRoleAccessWizard').previousStep();
				}
			} else if (oEvent.getParameters()["index"] === 3) {
				this.byId("apmrRepUnitTit").addStyleClass("reportTitle");
				this.byId("taReason").setValue("");
				this.byId("itbApmrRole").setSelectedKey("addRole");
				var sysId = this.getView().byId("cbSystem").getSelectedKey();
				var appId = this.getOwnerComponent().applId;
				var deptId = this.getView().byId("cbDepartment").getSelectedKey();
				var requestedUser = (this.byId("cbRTForSelf").getSelected()) ? this.getOwnerComponent().getModel("LogInUserModel").getData().User_ID :
					this
					.byId("in521Id").getValue();

				if ((sysId != "" && appId != "") && (deptId != "")) {
					sap.ui.getCore().getModel("createReqModel").setProperty("/job_title", deptId);

					this.clearApplicationModelData();
					this.getApplSubApplList(sysId, appId, deptId, "", "", busApplName, requestedUser);
				} else {
					if (sysId == "") {
						this.getView().byId("cbSystem").setValueState("Error");
					}

					if (deptId == "") {
						this.getView().byId("cbDepartment").setValueState("Error");
					}

					this.getView().byId('UserRoleAccessWizard').previousStep();
				}
			}
		},
		userListDialog: function (oEvent) {
			var id = oEvent.mParameters.id;
			var check = id.includes("521");
			this.exemptUser = "";

			if (!this._oValueHelpDialog) {
				this._oValueHelpDialog = sap.ui.xmlfragment("id2", "com.alcon.UAM.view.fragments.ValueHelpUser", this);
			}
			this.getView().addDependent(this._oValueHelpDialog);

			if (check) {
				sap.ui.getCore().getModel("flagModel").setProperty("/flag", "true");
				this._oValueHelpDialog.setTitle("Search User");
				this.exemptUser = this.getOwnerComponent().getModel("LogInUserModel").getData().User_ID;
			} else {
				sap.ui.getCore().getModel("flagModel").setProperty("/flag", "false");
				this._oValueHelpDialog.setTitle("Search Line Manager");
				this.exemptUser = this.byId("in521Id").getValue();
			}
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._oValueHelpDialog);
			this._oValueHelpDialog.open();
		},

		onValueHelpOkPress: function (oEvent) {
			if (sap.ui.getCore().byId("id2--tblUserList").getSelectedItem() == null) {
				MessageBox.error("Please select One User");
			} else {
				var id521 = sap.ui.getCore().byId("id2--tblUserList").getSelectedItem().mAggregations.cells[0].getText();
				var first = sap.ui.getCore().byId("id2--tblUserList").getSelectedItem().mAggregations.cells[1].getText()
				var last = sap.ui.getCore().byId("id2--tblUserList").getSelectedItem().mAggregations.cells[2].getText()
				var full = first + ' ' + last;
				var check = sap.ui.getCore().getModel("flagModel").getProperty("/flag");
				if (check == "true") {
					if (this.byId("in521Id").getVisible()) {
						this.byId("in521Id").setValue(id521);
						this.onChange521Id(id521);
					} else if (this.byId("in521MgrNameId").getVisible()) {
						this.byId("in521MgrNameId").setValue(full);
						this.byId("in521MgrId").setValue(id521);
						sap.ui.getCore().getModel("createReqModel").setProperty("/line_manager_name", full);
						sap.ui.getCore().getModel("createReqModel").setProperty("/line_manager_id", id521);
					}
				} else {
					this.byId("managerfieldval").setValue(full);
					sap.ui.getCore().getModel("createReqModel").setProperty("/line_manager_name", full);
					sap.ui.getCore().getModel("createReqModel").setProperty("/line_manager_id", id521);

				}
				if (check == "true") {
					console.log(this.byId("otherDept").getText());
				}
				this._oValueHelpDialog.close();
				this._oValueHelpDialog.destroy(true);
				this._oValueHelpDialog = null;

			}
		},

		onValueHelpCancelPress: function () {
			this._oValueHelpDialog.close();
			this._oValueHelpDialog.destroy(true);
			this._oValueHelpDialog = null;
		},
		onClose: function () {},

		onUserSearch: function () {
			var getDetailsrv = this.getOwnerComponent().getModel("ZAL_CREATE_REQUEST_SRV_01");
			var that = this;

			var oFilter = [];
			if (sap.ui.getCore().byId("id2--in521").getValue() !== "" || sap.ui.getCore().byId("id2--inFirstName").getValue() !== "" || sap.ui.getCore()
				.byId(
					"id2--inLastName").getValue() !== "") {
				busyDialog.open();
				busyDialog.setText("Fetching");
				oFilter.push(new Filter("ID_521", FilterOperator.EQ, sap.ui.getCore().byId("id2--in521").getValue()));
				oFilter.push(new Filter("Firstname", FilterOperator.EQ, sap.ui.getCore().byId("id2--inFirstName").getValue()));
				oFilter.push(new Filter("Lastname", FilterOperator.EQ, sap.ui.getCore().byId("id2--inLastName").getValue()));
			} else {
				MessageToast.show("Please enter a value in any of the fields to search user");
				return;
			}
			var list521Id = new JSONModel();
			getDetailsrv.read("/User_ListSet", {
				filters: oFilter,
				success: function (oData) {
					list521Id.setData(oData);
					that.getView().setModel(list521Id, "List521Model");
					sap.ui.getCore().byId("id2--tblUserList").setVisible(true);
					busyDialog.close();
				},
				error: function (oError) {
					var errorMsg = that.errorMsgParse(oError);
					MessageBox.error(errorMsg);
					busyDialog.close();
				}
			});
		},

		onChangeSystem: function () {
			var getDetailsrv = this.getOwnerComponent().getModel("ZAL_CREATE_REQUEST_SRV_01");
			var currentStep = this.getView().byId("UserRoleAccessWizard").mAssociations.currentStep;
			if (currentStep.includes("departmentSelection")) {
				this.getView().byId('UserRoleAccessWizard').previousStep();
			}
			if (currentStep.includes("roleSelection")) {
				this.getView().byId('UserRoleAccessWizard').previousStep();
				this.getView().byId('UserRoleAccessWizard').previousStep();
			}

			this.byId("cbDepartment").setValue("");

		},

		toSubmit: function () {

			var requestedUser = (this.byId("cbRTForSelf").getSelected()) ? this.getOwnerComponent().getModel("LogInUserModel").getData().User_ID :
				this
				.byId("in521Id").getValue();

			var applData = [];
			var subAppl = sap.ui.getCore().getModel("createReqModel").getProperty("/subApplication");

			for (var k in subAppl) {
				var data = {
					"User_ID": requestedUser,
					"System_ID": this.byId("cbSystem").getSelectedKey(),
					"Department_Role": this.byId("cbDepartment").getSelectedKey(),
					"Application": this.getOwnerComponent().applName,
					"Subapplication": subAppl[k].subApplication,
					"UAM_Role": subAppl[k].uamRoles,
					"Application_Type": "",
					"Appl_ID": "003"
				}
				applData.push(data);
			}

			var dateFrom = this.byId("DP1").getValue().split("-");
			var dateTo = this.byId("DP2").getValue().split("-");
			var type = (this.byId("itbApmrRole").getSelectedKey() === "addRole") ? "NEW" : "REMOVE";

			var payload = {
				"User_ID": requestedUser,
				"Line_Manager": (this.byId("cbRTForSelf").getSelected()) ? this.byId("in521MgrId").getValue() : sap
					.ui.getCore().getModel("createReqModel").getProperty("/line_manager_id"),
				"request_type": type,
				"Division": this.getOwnerComponent().getModel("LogInUserModel").getData().Division,
				"DATE_FROM": dateFrom[2] + dateFrom[1] + dateFrom[0],
				"DATE_TO": dateTo[2] + dateTo[1] + dateTo[0],
				"Appl_ID": "003",
				"System_ID": this.byId("cbSystem").getSelectedKey(),
				"Creator_ID": this.getOwnerComponent().getModel("LogInUserModel").getData().User_ID,
				"Reason": this.byId("taReason").getValue(),
				"Nav_Header_To_Appl": applData,
				"Nav_Header_To_Ret": [{}]
			};

			var that = this;

			var getDetailsrv = this.getOwnerComponent().getModel("ZUAM_ALCON_DCT_SRV");
			busyDialog.open();
			busyDialog.setText("Loading");
			getDetailsrv.create("/User_DetailsSet", payload, {
				success: function (oData) {
					busyDialog.close();
					that.showMessage(oData);
				},
				error: function (Error) {
					var errorMsg = that.errorMsgParse(Error);
					MessageBox.error(errorMsg);
					busyDialog.close();
				}
			});
		},
		showMessage: function (oData) {
			var data = oData.Nav_Header_To_Ret.results[0];
			MessageBox[(data.MsgType === "S") ? "success" : "error"](data.MsgText, {
				actions: [MessageBox.Action.CLOSE],
				onClose: function (oAction) {
					this.closeAction();
				}.bind(this)
			});
		},
		closeAction: function () {
			this.clearModelData();
			this._oWizardReviewPage.destroy();
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("RouteMain");
		},
		backToWizardContent: function () {
			this._oWizardReviewPage.destroy();

		},
		clearModelData: function () {
			this.resetCreateReqModel();
			this.onForSelfSelect("");
			this.dateSetter();

			this.getOwnerComponent().getModel("OtherUserModel1").setData({});
			this.getOwnerComponent().getModel("DepartmentModel").setData({});
			this.getOwnerComponent().getModel("SegregationModel").setData({});
			this.clearApplicationModelData();
		},
		onSearchReportingUnit: function (oEvent) {
			var val = oEvent.getSource().getValue();
			var oFilter = [];
			oFilter.push(new Filter("Value", FilterOperator.Contains, val));
			this.getView().byId("liBusRole").getBinding("items").filter(oFilter);
		},
		onSearchRemReportingUnit: function (oEvent) {
			var val = oEvent.getSource().getValue();
			var oFilter = [];
			oFilter.push(new Filter("Value", FilterOperator.Contains, val));
			this.getView().byId("liBusRoleRemove").getBinding("items").filter(oFilter);
		},

		clearApplicationModelData: function () {

			this.byId("liSubApplication").removeSelections();
			this.byId("liBusRole").removeSelections();
			this.getOwnerComponent().getModel("ApplicationModel1").setData({});
			this.getOwnerComponent().getModel("SubApplicationModel").setData({});
			this.getOwnerComponent().getModel("UamRoleModel").setData({});
			this.getOwnerComponent().getModel("ApplicationModel2").setData({});
			this.getOwnerComponent().getModel("SubApplicationRemoveModel").setData({});
			this.getOwnerComponent().getModel("UamRoleRemoveModel").setData({});
			this.getOwnerComponent().getModel("HierEntityModel").setData({});
			this.getOwnerComponent().getModel("HierMarketModel").setData({});
			this.getOwnerComponent().getModel("HierButtonModel").setData({});
		},
		onSelectRoleSection: function (oEvent) {
			var key = oEvent.getParameter("key");

			if (key === "addRole" && removeSel) {
				this.byId("itbApmrRole").setSelectedKey("removeRole");
				MessageBox.warning("Your changes in Remove Role section will be removed, if you click on Yes", {
					actions: [MessageBox.Action.YES, MessageBox.Action.NO],
					onClose: function (oAction) {

						if (oAction === MessageBox.Action.YES) {
							this.byId("itbApmrRole").setSelectedKey("addRole");
							this.byId("liBusRoleRemove").removeSelections();
							this.getOwnerComponent().getModel("UamRoleModel").setData({});
							this.byId("liSubApplicationRemove").removeSelections();

						} else if (oAction === MessageBox.Action.NO) {
							return;
						}
					}.bind(this)
				});

			} else if (key === "removeRole") {
				this.byId("itbApmrRole").setSelectedKey("addRole");
				if (this.getOwnerComponent().getModel("SubApplicationRemoveModel").getData().length === 0) {
					MessageToast.show("No role is assigned to the selected user");
					return;
				} else if (addSel) {
					MessageBox.warning("Your changes in Add Role will be removed, if you click on Yes", {
						actions: [MessageBox.Action.YES, MessageBox.Action.NO],
						onClose: function (oAction) {

							if (oAction === MessageBox.Action.YES) {
								this.byId("itbApmrRole").setSelectedKey("removeRole");
								this.byId("liBusRole").removeSelections();
								this.getOwnerComponent().getModel("UamRoleModel").setData({});
								this.byId("liSubApplication").removeSelections();

							} else if (oAction === MessageBox.Action.NO) {
								return;
							}
						}.bind(this)
					});
				} else {
					this.byId("itbApmrRole").setSelectedKey("removeRole");
				}
			}
		},
		onExit: function () {
			if (this._oWizardReviewPage) {
				this._oWizardReviewPage.destroy(true);
			}
			if (this._oValueHelpDialog) {
				this._oValueHelpDialog1.destroy(true);
			}
		},

	});

});