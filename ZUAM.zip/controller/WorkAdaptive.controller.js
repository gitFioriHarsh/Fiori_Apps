/*
 *&---------------------------------------------------------------------*
 *& Fiohttps://webidecp-qa4lewefrx.dispatcher.us4.hana.ondemand.com/ri Application Workday Adaptive
 *&---------------------------------------------------------------------*
 *& DD ID  : ZDDE-00058866                                              *
 *& FS ID  : ZFSE-00058865                                              *
 *&---------------------------------------------------------------------*
 *& Workday Adaptive                                                    *
 *&---------------------------------------------------------------------*
 *& Change Log:                                                        *
 *&---------------------------------------------------------------------*
 *& Author      ¦ Date           ¦ Comment                              *
 *&---------------------------------------------------------------------*
 *  SGO1         29-Mar-2022     CD 1600002813   Initial                *
 *  SGO1         01-Jun-2022     CD 1600009041   Bug fix, duplciate hier*
 *  SGO1         22-Jun-2022     CD 1600009113   Capex/R&D              *
 *  REDDYRO5	 31-Oct-2023     CD 1600013654   Validation for not allowing 
 *												 same attribute values in
 *                                               Edit and FullView      *
 *&---------------------------------------------------------------------*
 */

sap.ui.define([
	"com/alcon/UAM/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageBox",
	"sap/m/MessageToast",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/core/Fragment",
	"sap/ui/model/odata/v2/ODataModel",
	"sap/ui/core/routing/History",
	"com/alcon/UAM/util/formatter",
	"sap/m/GroupHeaderListItem",
	"sap/m/PDFViewer",
	"sap/ui/dom/includeStylesheet"
], function (BaseController, JSONModel, MessageBox, MessageToast, Filter, FilterOperator, Fragment, ODataModel, History,
	formatter, GroupHeaderListItem, PDFViewer, includeStylesheet) {
	"use strict";
	var busyDialog = new sap.m.BusyDialog();
	var tempSubApplModel = new JSONModel();
	var tempSubApplRemoveModel = new JSONModel();
	var selMarketWorkDayModel = new JSONModel();
	var selCostCenterWorkDayModel = new JSONModel();
	var uamSelPath = "";
	var sPath = "";
	var addSel = false,
		removeSel = false;
	var hierSelCostCenterArray = [];
	var hierSelMarketArray = [];
	var hierField = ["Application", "CHILDID", "Consolidated_View", "Department_Role", "DrillState", "EMflag", "HEIR_NAME", "HIEID", "ID",
		"NAME", "NODEID", "OBJ", "PARENTID", "PID", "Segregation", "Subapplication", "System_ID", "TLEVEL", "TXT", "UAM_Role", "User_ID",
		"selected", "INSTANCE", "Permission_Name", "Application"
	];
	var oTable;
	return BaseController.extend("com.alcon.UAM.controller.WorkAdaptive", {
		formatter: formatter,

		onInit: function () {
			//jQuery.sap.includeStyleSheet("/sap/bc/ui5_ui5/sap/zuam/css/style.css");
			includeStylesheet("/sap/bc/ui5_ui5/sap/zuam/css/style.css");
			var sRootPath = jQuery.sap.getModulePath("zuam");
			var location = $(location).attr('href');

			this.getOwnerComponent().getRouter().getRoute("WorkAdaptive").attachMatched(this._onRouteMatched, this);
			//	this.getView().addStyleClass(this.getContentDensityClass());
			this._wizard = this.byId("UserRoleAccessWizard1");
			this._oNavContainer = this.byId("navContainer");
			this._oDynamicPage = this.getView();

			var oModel = this.getOwnerComponent().getModel("ZAL_CREATE_REQUEST_SRV_01");
			oModel.setSizeLimit(100000);
			this.getView().setModel(oModel);
			var flagModel = new JSONModel({
				flag: "false"
			});
			sap.ui.getCore().setModel(flagModel, "flagModel");
			this.getView().setModel(new JSONModel(), "EntitlementModel");

			$(window).scroll(function () {
				console.log("scrolled")
			});

			this.getView().setModel(new JSONModel(), "CapexModel");

		},

		_onRouteMatched: function (oEvent) {
			var error = ["", null, undefined];
			if (error.includes(this.getOwnerComponent().applId)) {
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("RouteMain");
			} else {
				this.byId("cbSystem").setSelectedKey("PROD");
				this.byId("cbCountry").setVisible(false);
				this.byId("lbl521MgrId").setVisible(false);
				this.byId("in521MgrNameId").setVisible(false);
				this.byId("dpSection").setVisible(false);

				this.byId("taReason").setValue("");
				this.byId("txtApp").setText(this.getOwnerComponent().applName);
				this.getOwnerComponent().getModel("OtherUserModel1").setData({});
				this.clearModelData(); //this is to clear all the model data
				var currentStep = this.getView().byId("UserRoleAccessWizard1").getAssociation("currentStep");
				if (currentStep.includes("roleSelection")) {
					this.getView().byId('UserRoleAccessWizard1').previousStep();
					this.getView().byId('UserRoleAccessWizard1').previousStep();
				} else if (currentStep.includes("departmentSelection")) {
					this.getView().byId('UserRoleAccessWizard1').previousStep();
				}
			}
		},
		onNavBack: function () {
			MessageBox.warning("Your data may be lost. Are you sure to continue?", {
				actions: [MessageBox.Action.YES, MessageBox.Action.NO],
				onClose: function (oAction) {

					if (oAction === MessageBox.Action.YES) {
						this.clearModelData();
						var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
						oRouter.navTo("RouteMain");
					} else if (oAction === MessageBox.Action.NO) {
						return;
					}
				}.bind(this)
			});

		},
		closeAction: function () {
			this.clearModelData();
			this._oWizardReviewPage.destroy();
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("RouteMain");
		},

		clearModelData: function () {
			this.resetCreateReqModel();
			this.onForSelfSelect("");

			this.getOwnerComponent().getModel("DepartmentModel").setData({});
			this.getOwnerComponent().getModel("SegregationModel").setData({});
			this.clearApplicationModelData();
		},
		resetCreateReqModel: function () {
			var oMod = sap.ui.getCore().getModel("createReqModel");
			oMod.setProperty("/selfFlag", "true");
			oMod.setProperty("/user_id", "");
			oMod.setProperty("/application_id", "");
			oMod.setProperty("/aaplication_desc", "");
			oMod.setProperty("/system_id", "PF1");
			oMod.setProperty("/start_date", "");
			oMod.setProperty("/end_date", "");
			oMod.setProperty("/job_title", "");
			oMod.setProperty("/segr_level", "");
			oMod.setProperty("/reason", "");
			oMod.setProperty("/consolidation_flag", "");
			oMod.setProperty("/INSTANCE_ID", "");
			oMod.setProperty("/INSTANCE", "");
			oMod.setProperty("/Permission_ID", "");
			oMod.setProperty("/Permission_Name", "");
			oMod.setProperty("/Seglevel", "");
			oMod.setProperty("/CONTRY", "");

		},
		backToWizardContent: function () {
			this._oWizardReviewPage.destroy();

		},

		toCancel: function () {
			this.closeAction();

		},
		onExit: function () {
			if (this._oWizardReviewPage) {
				this._oWizardReviewPage.destroy(true);
			}

			if (this._oValueHelpDialog) {
				this._oValueHelpDialog.destroy(true);
			}

		},
		changeValueState: function (event) {
			var selKey = event.getSource().getSelectedKey();
			var selKeyValue = event.getSource().getSelectedItem().mProperties.text;
			//added for Instance code
			var selKeyCode = this.getView().getModel("JobDetailsWorkdayModel").getData().Nav_Header_To_Instance.results.filter(function (
				oItem) {
				return oItem.INSTANCE_ID === selKey
			});

			var currentStep = this.getView().byId("UserRoleAccessWizard1").getAssociation("currentStep");
			if (currentStep.includes("roleSelection")) {
				this.byId("itbWorkdayRole").setSelectedKey("addRole");
				this.getView().byId('UserRoleAccessWizard1').previousStep();
			}

			if (selKey != "") {
				event.getSource().setValueState("None");
				this.byId("itbWorkdayRole").setSelectedKey("addRole");
			}
			var sId = event.getSource().sId;
			if (sId.includes("cbInstance")) {
				sap.ui.getCore().getModel("createReqModel").setProperty("/INSTANCE_ID", selKey);
				sap.ui.getCore().getModel("createReqModel").setProperty("/INSTANCE", selKeyValue);
				// filtering the permission set Names
				var selectedPermisionName = this.getView().getModel("JobDetailsWorkdayModel").getData().Nav_Header_To_Permission.results.filter(
					function (
						oItem) {
						return oItem.INSTANCE === selKeyCode[0].INSTANCE_CODE
					});

				this.getView().getModel("CapexModel").setProperty("/InstanceType", selKeyCode[0].INSTANCE_CODE);
				//Visibility of GWA and permission set display
				if (selKeyCode[0].INSTANCE_CODE === "WFP") {
					this.getView().getModel("JobDetailsWorkdayModel").setProperty("/Nav_To_Permission", selectedPermisionName);
					this.getView().getModel("JobDetailsWorkdayModel").setProperty("/sSelectedInstance", true);

				} else if (selKeyCode[0].INSTANCE_CODE === "CAP") {
					this.getView().getModel("JobDetailsWorkdayModel").setProperty("/Nav_To_Permission", selectedPermisionName);
					this.getView().getModel("JobDetailsWorkdayModel").setProperty("/sSelectedInstance", false);

				} else if (selKeyCode[0].INSTANCE_CODE === "R&D") {
					this.getView().getModel("JobDetailsWorkdayModel").setProperty("/Nav_To_Permission", selectedPermisionName);
					this.getView().getModel("JobDetailsWorkdayModel").setProperty("/sSelectedInstance", false);

				}

				this.getView().byId("cbPermission").setEnabled(true);
				this.getView().byId("cbPermission").setSelectedKey("");
				this.getView().byId("cbSegregation").setEnabled(true);
				this.getView().byId("cbSegregation").setSelectedKey("");
				this.getView().byId("cbCountry").setSelectedKey("");
				this.byId("cbCountry").setVisible(false);
				this.byId("itbWorkdayRole").setSelectedKey("addRole");

			}
			if (sId.includes("cbPermission")) {
				sap.ui.getCore().getModel("createReqModel").setProperty("/Permission_ID", selKey);
				sap.ui.getCore().getModel("createReqModel").setProperty("/Permission_Name", selKeyValue);
				var InstId = this.getView().byId("cbInstance").getSelectedKey();
				var selectedInstance = this.getView().getModel("JobDetailsWorkdayModel").getData().Nav_Header_To_Instance.results.filter(function (
					oItem) {
					return oItem.INSTANCE_ID === InstId
				});
				var selectedPermName = this.getView().getModel("JobDetailsWorkdayModel").getData().Nav_Header_To_Permission.results.filter(
					function (
						oItem) {
						return oItem.Permission_ID === selKey
					});
				// setting default value while selecting Instance
				if ((selectedInstance[0].INSTANCE_CODE === "WFP") && (selectedPermName[0].Permission_Name.includes("ADMIN"))) {
					this.getView().byId("cbSegregation").setValue("GLOBAL");
					this.getView().byId("cbSegregation").setSelectedKey("GLOBAL");
				} else if (selectedInstance[0].INSTANCE_CODE === "CAP") {
					this.getView().byId("cbSegregation").setValue("MTO");
					this.getView().byId("cbSegregation").setSelectedKey("MTO");
				} else if (selectedInstance[0].INSTANCE_CODE === "R&D") {
					this.getView().byId("cbSegregation").setValue("RD");
					this.getView().byId("cbSegregation").setSelectedKey("RD");
				} else {
					this.byId("cbSegregation").setValue("");
				}
				this.byId("cbCountry").setVisible(false);
				this.byId("itbWorkdayRole").setSelectedKey("addRole");
			}
			if (sId.includes("cbSegregation")) {
				sap.ui.getCore().getModel("createReqModel").setProperty("/Seglevel", selKey);
				sap.ui.getCore().getModel("createReqModel").setProperty("/SeglevelValue", selKeyValue);
				if (selKey === "COUNTRY/REGION") {
					this.getView().byId("cbCountry").setVisible(true);

				} else {
					this.byId("cbCountry").setVisible(false);
				}

				this.byId("itbWorkdayRole").setSelectedKey("addRole");

			}
			if (sId.includes("cbCountry")) {
				sap.ui.getCore().getModel("createReqModel").setProperty("/CONTRY", selKey);
				sap.ui.getCore().getModel("createReqModel").setProperty("/CONTRY_NAME", selKeyValue);

				this.byId("itbWorkdayRole").setSelectedKey("addRole");
			}
		},

		onNextStep: function (oEvent) {
			var that = this;
			var busApplName = "WORKDAY";
			var oView = this.getView();

			if (oEvent.getParameters()["index"] === 2) {

				var sysId = oView.byId("cbSystem").getSelectedKey();
				var appId = this.getOwnerComponent().applId;

				if ((sysId !== "" && appId != "")) {
					this.getWorkdayInstance(sysId);
				} else {
					oView.byId("cbSystem").setValueState("Error");
					oView.byId('UserRoleAccessWizard1').previousStep();

				}

			} else if (oEvent.getParameters()["index"] === 3) {
				this.byId("taReason").setValue("");
				this.byId("itbWorkdayRole").setSelectedKey("addRole");
				var sysId = oView.byId("cbSystem").getSelectedKey();
				var appId = this.getOwnerComponent().applId;
				var InstId = oView.byId("cbInstance").getSelectedKey();
				var permId = oView.byId("cbPermission").getSelectedKey();
				var segId = oView.byId("cbSegregation").getSelectedKey();
				var countryId = oView.byId("cbCountry").getSelectedKey();

				var requestedUser = (this.byId("cbRTForSelf").getSelected()) ? this.getOwnerComponent().getModel("LogInUserModel").getData().User_ID :
					this.byId("in521Id").getValue();
				//	&& countryFlag
				if ((sysId != "" && appId != "") && (InstId != "" && permId != "" && segId !== "")) {
					sap.ui.getCore().getModel("createReqModel").setProperty("/INSTANCE_ID", InstId);

					this.clearApplicationModelData();
					this.getSubapplWorkdayInstance(sysId, InstId, permId);
					this.getSubappliRemoveInstance(sysId, InstId, requestedUser);

				} else {
					if (sysId == "") {
						oView.byId("cbSystem").setValueState("Error");
					}

					if (InstId == "") {
						oView.byId("cbInstance").setValueState("Error");
					}
					if (permId == "") {
						oView.byId("cbPermission").setValueState("Error");
					}
					if (segId == "") {
						oView.byId("cbSegregation").setValueState("Error");
					}
					if (segId === "COUNTRY/REGION" && countryId == "") {
						oView.byId("cbCountry").setValueState("Error");
					}

					oView.byId('UserRoleAccessWizard1').previousStep();
				}
			}
		},

		onListApplChange: function (oEvent) {
			//flag to know which section is selected
			addSel = true;
			removeSel = false;
			this.onApplicationChange1(oEvent.getParameter("listItem").getAggregation("cells")[0].getText(), oEvent.getParameter("selected"));

		},

		onListApplChangeRemove: function (oEvent) {
			//flag to know which section is selected
			addSel = false;
			removeSel = true;
			this.onApplicationChangeRemove1(oEvent.getParameter("listItem").getAggregation("cells")[0].getText(), oEvent.getParameter(
				"selected"));
		},

		onForSelfSelect: function (oEvent) {
			if (oEvent !== "" && oEvent.getParameters()["selected"]) {
				this.byId("cbRTForOther").setSelected(false);
				this.byId("lbl521MgrId").setVisible(false);
				this.byId("in521MgrNameId").setVisible(false);
				this.byId("lbl521Id").setVisible(false);
				this.byId("in521Id").setVisible(false);
				this.byId("in521Id").setValue("");
				sap.ui.getCore().getModel("createReqModel").setProperty("/selfFlag", "true");
				this.byId("idOtherDet").setVisible(false);

			} else {
				this.byId("cbRTForOther").setSelected(false);
				this.byId("cbRTForSelf").setSelected(true);
				this.byId("lbl521Id").setVisible(false);
				this.byId("in521Id").setVisible(false);
				this.byId("in521Id").setValue("");
				this.byId("idOtherDet").setVisible(false);

			}
			this.onChangeSystem();

		},
		onForOtherSelect: function (oEvent) {
			if (oEvent.getParameters()["selected"]) {
				this.byId("cbRTForSelf").setSelected(false);
				this.byId("lbl521Id").setVisible(true);
				this.byId("in521Id").setVisible(true);
				this.byId("in521Id").setValue("");
				sap.ui.getCore().getModel("createReqModel").setProperty("/selfFlag", "false");
			} else {
				this.byId("cbRTForOther").setSelected(true);
			}
			this.onChangeSystem();

		},
		onChangeSystem: function () {
			var getDetailsrv = this.getOwnerComponent().getModel("ZAL_CREATE_REQUEST_SRV_01");
			var currentStep = this.getView().byId("UserRoleAccessWizard1").mAssociations.currentStep;
			if (currentStep.includes("departmentSelection")) {
				this.getView().byId('UserRoleAccessWizard1').previousStep();
			}
			if (currentStep.includes("roleSelection")) {
				this.getView().byId('UserRoleAccessWizard1').previousStep();
				this.getView().byId('UserRoleAccessWizard1').previousStep();
			}

			this.byId("cbInstance").setSelectedKey("");
			this.byId("cbPermission").setSelectedKey("");
			this.byId("cbSegregation").setSelectedKey("");
			this.byId("cbCountry").setSelectedKey("");
			this.byId("cbCountry").setVisible(false);
		},
		onChange521Id: function (User_ID) {
			var getDetailsrv = this.getOwnerComponent().getModel("ZAL_CREATE_REQUEST_SRV_01");
			var that = this;
			var selUser = User_ID;

			sap.ui.getCore().getModel("createReqModel").setProperty("/user_id", selUser);
			var oFilter = new Array();
			var usrFilter = new Filter("User_ID", FilterOperator.EQ, selUser);
			oFilter.push(usrFilter);

			var omod = this.getView().getModel("List521Model");
			this.getView().setModel(omod, "List521Model");

			getDetailsrv.read("/User_DetailsSet(User_ID='" + selUser + "')", {

				success: function (oData) {
					that.getOwnerComponent().getModel("OtherUserModel1").setData(oData);

				},
				error: function (oError) {
					var errorMsg = that.errorMsgParse(oError);
					MessageBox.error(errorMsg);
					busyDialog.close();
				}
			});
			var usr_name = this.getOwnerComponent().getModel("OtherUserModel1").getProperty("/Name");

			this.byId("idOtherDet").setVisible(true);
		},
		userListDialog: function (oEvent) {
			var id = oEvent.mParameters.id;
			var check = id.includes("521");
			this.exemptUser = "";

			if (!this._oValueHelpDialog) {
				this._oValueHelpDialog = sap.ui.xmlfragment("id1", "com.alcon.UAM.view.fragments.ValueHelpUser", this);
			}
			this.getView().addDependent(this._oValueHelpDialog);

			if (check) {
				sap.ui.getCore().getModel("flagModel").setProperty("/flag", "true");
				this._oValueHelpDialog.setTitle("Search User");
				this.exemptUser = this.getOwnerComponent().getModel("LogInUserModel").getData().User_ID;
			} else {
				sap.ui.getCore().getModel("flagModel").setProperty("/flag", "false");
				this._oValueHelpDialog.setTitle("Search Line Manager");
				this.exemptUser = this.byId("in521Id").getValue();
			}
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._oValueHelpDialog);
			this._oValueHelpDialog.open();
		},
		onUserSearch: function () {
			var getDetailsrv = this.getOwnerComponent().getModel("ZAL_CREATE_REQUEST_SRV_01");
			var that = this;

			var oFilter = [];
			if (sap.ui.getCore().byId("id1--in521").getValue() !== "" || sap.ui.getCore().byId("id1--inFirstName").getValue() !== "" || sap.ui
				.getCore()
				.byId(
					"id1--inLastName").getValue() !== "") {
				busyDialog.open();
				busyDialog.setText("Fetching");
				oFilter.push(new Filter("ID_521", FilterOperator.EQ, sap.ui.getCore().byId("id1--in521").getValue()));
				oFilter.push(new Filter("Firstname", FilterOperator.EQ, sap.ui.getCore().byId("id1--inFirstName").getValue()));
				oFilter.push(new Filter("Lastname", FilterOperator.EQ, sap.ui.getCore().byId("id1--inLastName").getValue()));
			} else {
				MessageToast.show("Please enter a value in any of the fields to search user");
				return;
			}
			var list521Id = new JSONModel();
			getDetailsrv.read("/User_ListSet", {
				filters: oFilter,
				success: function (oData) {
					//this loop is to exempt some user details that the user is not supposed to select
					for (let m in oData.results) {
						if (oData.results[m].ID_521 === that.exemptUser) {
							oData.results.splice(m, 1);
						}
					}

					list521Id.setData(oData);
					that.getView().setModel(list521Id, "List521Model");
					sap.ui.getCore().byId("id1--tblUserList").setVisible(true);
					busyDialog.close();
				},
				error: function (oError) {
					var errorMsg = that.errorMsgParse(oError);
					MessageBox.error(errorMsg);
					busyDialog.close();
				}
			});
		},
		setBtnVisible() {
			sap.ui.getCore().byId("id1--btOK").setVisible(true);
		},
		onValueHelpOkPress: function (oEvent) {
			if (sap.ui.getCore().byId("id1--tblUserList").getSelectedItem() == null) {
				MessageBox.error("Please select One User");
			} else {
				var id521 = sap.ui.getCore().byId("id1--tblUserList").getSelectedItem().mAggregations.cells[0].getText();
				var first = sap.ui.getCore().byId("id1--tblUserList").getSelectedItem().mAggregations.cells[1].getText()
				var last = sap.ui.getCore().byId("id1--tblUserList").getSelectedItem().mAggregations.cells[2].getText()
				var full = first + ' ' + last;
				var check = sap.ui.getCore().getModel("flagModel").getProperty("/flag");
				if (check == "true") {
					if (this.byId("in521Id").getVisible()) {
						this.byId("in521Id").setValue(id521);
						this.onChange521Id(id521);
					} else if (this.byId("in521MgrNameId").getVisible()) {
						this.byId("in521MgrNameId").setValue(full);
						this.byId("in521MgrId").setValue(id521);
						sap.ui.getCore().getModel("createReqModel").setProperty("/line_manager_name", full);
						sap.ui.getCore().getModel("createReqModel").setProperty("/line_manager_id", id521);
					}

				} else {
					this.byId("managerfieldval").setValue(full);
					sap.ui.getCore().getModel("createReqModel").setProperty("/line_manager_name", full);
					sap.ui.getCore().getModel("createReqModel").setProperty("/line_manager_id", id521);

				}
				if (check == "true") {
					console.log(this.byId("otherDept").getText());
				}
				this._oValueHelpDialog.close();
				this._oValueHelpDialog.destroy(true);
				this._oValueHelpDialog = null;

			}
		},

		onValueHelpCancelPress: function () {
			this._oValueHelpDialog.close();
			this._oValueHelpDialog.destroy(true);
			this._oValueHelpDialog = null;
		},
		onSelectRoleSection: function (oEvent) {
			var key = oEvent.getParameter("key");
			if ((key === "removeRole" && this.byId("liApplication").getSelectedItems().length !== 0) ||
				(key === "addRole" && this.byId("liBusRoleRemove").getSelectedItems().length !== 0)) {
				removeSel = true;
				if (key === "addRole" && removeSel) {
					this.byId("itbWorkdayRole").setSelectedKey("removeRole");
					MessageBox.warning("Your changes in Remove Role section will be removed, if you click on Yes", {
						actions: [MessageBox.Action.YES, MessageBox.Action.NO],
						onClose: function (oAction) {

							if (oAction === MessageBox.Action.YES) {
								this.byId("itbWorkdayRole").setSelectedKey("addRole");

								this.getOwnerComponent().getModel("SubApplicationRemoveModel").setData({});
								this.getOwnerComponent().getModel("UamRoleRemoveModel").setData({});
								this.getOwnerComponent().getModel("HiearchyRemoveModel").setData({});
							} else if (oAction === MessageBox.Action.NO) {
								return;
							}
						}.bind(this)
					});
				} else if (key === "removeRole") {
					this.byId("itbWorkdayRole").setSelectedKey("addRole");
					if (this.getOwnerComponent().getModel("ApplicationModel2").getData().length === 0) {
						MessageToast.show("No role is assigned to the selected user");
						return;
					} else if (addSel) {
						MessageBox.warning("Your changes in Add Role will be removed, if you click on Yes", {
							actions: [MessageBox.Action.YES, MessageBox.Action.NO],
							onClose: function (oAction) {

								if (oAction === MessageBox.Action.YES) {
									this.byId("itbWorkdayRole").setSelectedKey("removeRole");
									this.byId("liApplication").removeSelections();
									this.getOwnerComponent().getModel("SubApplicationModel").setData({});
									this.getOwnerComponent().getModel("UamRoleModel").setData({});

								} else if (oAction === MessageBox.Action.NO) {
									return;
								}
							}.bind(this)
						});
					} else {
						this.byId("itbWorkdayRole").setSelectedKey("removeRole");
					}
				}
			}
		},
		/**
		 * Jsons structure used for displaying Access roles
		 * @public
		 * @override
		 * @param{string} selected attribuite roles
		 * @return{entitlement} 
		 */
		onSubApplChange: function (oEvent) {
			var selPath = oEvent.getSource().getBindingInfo("selected")["binding"].getContext().getPath();
			var subApplName = this.getOwnerComponent().getModel("SubApplicationModel").getProperty(selPath).Value
			this.onSubApplicationChange1(subApplName, oEvent.getParameter("selected"), "WORKDAY");

		},

		toAddrowTable: function (oEvent) {
			var oGWADataModel = this.getOwnerComponent().getModel("UamRoleModel");
			let aGWAData = oGWADataModel.getData();
			let sPath = oEvent.getSource().getParent().getParent().oBindingContexts.UamRoleModel.getPath();
			let oGWAData = Object.assign({}, oGWADataModel.getProperty(sPath));

			oGWAData.aCostCenter = [];
			oGWAData.aMarket = [];
			oGWAData.functionalArea = undefined;
			oGWAData.franchiseValue = undefined;
			oGWAData.countryName = undefined;
			oGWAData.locationName = undefined;
			oGWAData.BussnuisSiteArea = undefined;
			oGWAData.hideDelBtn = false;
			oGWAData.index = Math.floor(Math.random() * (10000 - 1 + 1)) + 1;
			oGWAData.ButtonType = "";

			aGWAData.push(oGWAData);
			this.getOwnerComponent().getModel("UamRoleModel").setData(aGWAData);
		},
		toDeleteTable: function (oEvent) {
			var index = parseInt(oEvent.getSource().getParent().getAggregation("items")[0].getParent().getParent().getAggregation("cells")[8].getText());
			var oGWADataModel = this.getOwnerComponent().getModel("UamRoleModel");
			let aGWAData = oGWADataModel.getData();
			let sPath = oEvent.getSource().getParent().getParent().oBindingContexts.UamRoleModel.getPath();
			let oGWAData = Object.assign({}, oGWADataModel.getProperty(sPath));
			//aGWAData.push(oGWAData);
			for (var i = 0; i < aGWAData.length; i++) {

				if (aGWAData[i].index !== undefined && aGWAData[i].index === index) {
					aGWAData.splice(i, 1); //removing 1 record from i th index.
				}
			}

			this.getOwnerComponent().getModel("UamRoleModel").setData(aGWAData);
			MessageToast.show("Successfully Deleted");

		},

		completedHandler: function () {
			//Validation for same entry in Edit and FullView 
			var Array1 = this.getOwnerComponent().getModel("UamRoleModel").getData();
			for (var i = 0; i < Array1.length; i++) {
				var currApplSubAppl = Array1[i].ApplSubAppl,
					currAccess = currApplSubAppl.split("/");
				for (var j = i + 1; j < Array1.length; j++) {
					var selApplSubAppl = Array1[j].ApplSubAppl,
						selAccess = selApplSubAppl.split("/");
					if (selAccess[0].trim() != currAccess[0].trim() &&
						selAccess[1].trim() === currAccess[1].trim()) {
						// Start of new code 
						if (Array1[i].functionalArea === "") {
							Array1[i].functionalArea = undefined;
						}

						if (Array1[i].franchiseValue === "") {
							Array1[i].franchiseValue = undefined;
						}
						if (Array1[i].countryName === "") {
							Array1[i].countryName = undefined;
						}
						if (Array1[i].locationName === "") {
							Array1[i].locationName = undefined;
						}
						if (Array1[j].functionalArea === "") {
							Array1[j].functionalArea = undefined;
						}
						if (Array1[j].franchiseValue === "") {
							Array1[j].franchiseValue = undefined;
						}
						if (Array1[j].countryName === "") {
							Array1[j].countryName = undefined;
						}
						if (Array1[j].locationName === "") {
							Array1[j].locationName = undefined;
						}

						//Market	
						if (Array1[i].aMarket.length > 0 && Array1[j].aMarket.length > 0) {
							if (Array1[i].aMarket[0].ID === Array1[j].aMarket[0].ID) {
								this.bValidationError = true;
							} else {
								this.bValidationError = false;
							}
						} else if (Array1[i].aMarket.length > 0 || Array1[j].aMarket.length > 0) {
							//Ignore this entry is diff
							this.bValidationError = false;
							continue;
						}
						//Costcenter	
						if (Array1[i].aCostCenter.length > 0 && Array1[j].aCostCenter.length > 0) {
							if (Array1[i].aCostCenter[0].ID === Array1[j].aCostCenter[0].ID) {
								this.bValidationError = true;
							} else {
								this.bValidationError = false;
							}
						} else if (Array1[i].aCostCenter.length > 0 || Array1[j].aCostCenter.length > 0) {
							//Ignore this entry is diff
							this.bValidationError = false;
							continue;
						}
						//Functional area	
						if (Array1[i].functionalArea !== undefined && Array1[j].functionalArea !== undefined) {
							if (Array1[i].functionalArea === Array1[j].functionalArea) {
								this.bValidationError = true;
							} else {
								this.bValidationError = false;
							}
						} else if (Array1[i].functionalArea !== undefined || Array1[j].functionalArea !== undefined) {
							//Ignore this entry is diff
							this.bValidationError = false;
							continue;
						}

						//Functional area	
						if (Array1[i].franchiseValue !== undefined && Array1[j].franchiseValue !== undefined) {
							if (Array1[i].franchiseValue === Array1[j].franchiseValue) {
								this.bValidationError = true;
							} else {
								this.bValidationError = false;
							}
						} else if (Array1[i].franchiseValue !== undefined || Array1[j].franchiseValue !== undefined) {
							//Ignore this entry is diff
							this.bValidationError = false;
							continue;
						}

						//Country Name	
						if (Array1[i].countryName !== undefined && Array1[j].countryName !== undefined) {
							if (Array1[i].countryName === Array1[j].countryName) {
								this.bValidationError = true;
							} else {
								this.bValidationError = false;
							}
						} else if (Array1[i].countryName !== undefined || Array1[j].countryName !== undefined) {
							//Ignore this entry is diff
							this.bValidationError = false;
							continue;
						}

						//Location
						if (Array1[i].locationName !== undefined || Array1[i].locationName !== undefined) {
							if (Array1[i].locationName === Array1[j].locationName) {
								this.bValidationError = true;
							} else {
								this.bValidationError = false;
							}
						} else if (Array1[i].locationName !== undefined || Array1[j].locationName !== undefined) {
							//Ignore this entry is diff
							this.bValidationError = false;
							continue;
						}

					}
					if (this.bValidationError) {
						break;
					}
				};
				if (this.bValidationError) {
					break;
				}
			};

			if (this.bValidationError) {
				var errorMsg = "Same attribute values in Edit and Fullview not allowed";
				MessageBox.error(errorMsg);
			}

			if (!this.bValidationError) {
				var checkSubAppl = false,
					checkUamrole = false;
				var key = this.byId("itbWorkdayRole").getSelectedKey();
				var apps, subApplModel, uamModel;
				var InstId = this.getView().byId("cbInstance").getSelectedKey();
				var permId = this.getView().byId("cbPermission").getSelectedKey();
				var selectedPermName = this.getView().getModel("JobDetailsWorkdayModel").getData().Nav_Header_To_Permission.results.filter(
					function (
						oItem) {
						return oItem.Permission_ID === permId
					});
				var selectedInstance = this.getView().getModel("JobDetailsWorkdayModel").getData().Nav_Header_To_Instance.results.filter(function (
					oItem) {
					return oItem.INSTANCE_ID === InstId
				});

				if (key === "addRole") {
					apps = this.byId("liApplication").getSelectedItems();
					subApplModel = this.getOwnerComponent().getModel("SubApplicationModel");
					uamModel = this.getOwnerComponent().getModel("UamRoleModel");
					//check any sub application is selected
					if (selectedInstance[0].INSTANCE_CODE === "WFP") {
						for (let m in subApplModel.getData()) {
							if (subApplModel.getData()[m].selected === true) {
								checkSubAppl = true;
							}
						}
						if (apps.length == 0) {
							MessageToast.show("Please select any one Access Type atleast");
							return;
						}
						if (!checkSubAppl) {
							MessageToast.show("Please select any one GWA atleast");
							return;
						}
						//validation for R&D 
					} else if ((selectedInstance[0].INSTANCE_CODE === "R&D") && !(selectedPermName[0].Permission_Name.includes("ADMINISTRATOR"))) {
						var uamModel = this.getView().getModel("UamRoleModel");
						for (var i in uamModel.getData()) {

							if (uamModel.getData()[i].aMarket.length === 0 && uamModel.getData()[i].aCostCenter.length === 0) {
								uamModel.getData()[i].ButtonType = "X";
							} else {
								uamModel.getData()[i].ButtonType = "";

							}
						}
						this.getView().getModel("UamRoleModel").refresh();
						var ButtonMarketType = this.getView().getModel("UamRoleModel").getData().filter(function (oItem) {
							return oItem.ButtonType === "X"
						});
						if (ButtonMarketType.length > 0) {
							MessageToast.show("Please select either Market or Cost Center");
							return;
						}
					}
				} else if (key === "removeRole") {
					uamModel = this.getOwnerComponent().getModel("UamRoleRemoveModel");
					apps = this.byId("liBusRoleRemove").getSelectedItems();
					if (apps.length == 0) {
						MessageToast.show("Please select any one entitlement value At least");
						return;
					}
					var aEntitleValue = [];
					for (var i in apps) {
						var data = uamModel.getProperty(apps[i].getBindingContextPath())
						var data = {
							"entitlementtype": "AccessRules",
							"entitlementvalue": uamModel.getProperty(apps[i].getBindingContextPath()).Id,
							"displayname": uamModel.getProperty(apps[i].getBindingContextPath()).Id
						}
						aEntitleValue.push(data);
					}

					this.getView().getModel("EntitlementModel").setData(aEntitleValue);

				}
				//front end validation

				if (this.byId("taReason").getValue() === "") {
					this.byId("taReason").setValueState("Error");
					return;
				}

				var data = {};

				var hierSelArrVal = [];

				sap.ui.getCore().getModel("createReqModel").setProperty("/selType", (key === "addRole") ? "Add Access" : "Remove Access");
				sap.ui.getCore().getModel("createReqModel").setProperty("/application", uamModel.getData());

				sap.ui.getCore().getModel("createReqModel").setProperty("/hier", hierSelArrVal);
				sap.ui.getCore().getModel("createReqModel").setProperty("/reason", this.byId("taReason").getValue());

				sap.ui.getCore().getModel("createReqModel").setProperty("/system_id", this.byId("cbSystem").getSelectedKey());
				sap.ui.getCore().getModel("createReqModel").setProperty("/INSTANCE", this.byId("cbInstance").getValue());
				sap.ui.getCore().getModel("createReqModel").setProperty("/SeglevelValue", this.byId("cbSegregation").getSelectedKey());

				var check = sap.ui.getCore().getModel("createReqModel").getProperty("/selfFlag");
				sap.ui.getCore().getModel("createReqModel").setProperty("/requestor_id", this.byId("selfUserID").getText());
				if (check == "false") {
					sap.ui.getCore().getModel("createReqModel").setProperty("/full_name", this.byId("otherName").getText());

					sap.ui.getCore().getModel("createReqModel").setProperty("/user_dept", this.byId("otherDept").getText());
					sap.ui.getCore().getModel("createReqModel").setProperty("/user_country", this.byId("otherCountry").getText());
					sap.ui.getCore().getModel("createReqModel").setProperty("/user_jobtitle", this.byId("otherJobTitle").getText());

				} else {
					sap.ui.getCore().getModel("createReqModel").setProperty("/full_name", this.byId("selfName").getTitle());

					sap.ui.getCore().getModel("createReqModel").setProperty("/user_dept", this.byId("selfDept").getText());
					sap.ui.getCore().getModel("createReqModel").setProperty("/user_country", this.byId("selfCountry").getText());
					sap.ui.getCore().getModel("createReqModel").setProperty("/user_jobtitle", this.byId("selfJobTitle").getText());
				}
				var sysId = this.getView().byId("cbSystem").getSelectedKey();

				var requestedUser = (this.byId("cbRTForSelf").getSelected()) ? this.getOwnerComponent().getModel("LogInUserModel").getData().User_ID :
					this
					.byId("in521Id").getValue();

				this.getAuthorzationDetails(sysId, InstId, requestedUser, selectedInstance[0].INSTANCE_CODE, key);

			}
		},
		_onSuccessApi: function (data) {
			var success = data;
		},
		_onErrorApi: function (error) {
			var error = error;
		},
		getAuthorzationDetails: function (sysId, InstId, requestedUser, selInstanceCode, key) {
			var that = this;
			var oFilter = [];
			var getDetailsrv = this.getOwnerComponent().getModel("Z8CZ_WORKDAY_ADAPTIVE_SRV");
			oFilter.push(new Filter("System_ID", FilterOperator.EQ, sysId));
			oFilter.push(new Filter("INSTANCE", FilterOperator.EQ, InstId));
			oFilter.push(new Filter("ID_521", FilterOperator.EQ, requestedUser));

			busyDialog.open();
			busyDialog.setText("Loading");
			getDetailsrv.read("/ReviewButtonSet", {
				filters: oFilter,
				success: function (oData) {
					that.createAPIValue = oData.results.filter(function (oItem) {
						return oItem.API_Name === "CRE_ENT"
					});
					var updateApi = oData.results.filter(function (oItem) {
						return oItem.API_Name === "UPD_ENT"
					});
					if (key === "addRole") {

						var uamModel = that.getOwnerComponent().getModel("UamRoleModel");
						that.entitleValue = [];
						for (var i in uamModel.getData()) {
							var val = "";
							val = (uamModel.getData()[i].aMarket && uamModel.getData()[i].aMarket[0] !== undefined) ? val + "MKT:" + uamModel.getData()[
								i].aMarket[0].ID + "|" : val;
							val = (uamModel.getData()[i].aCostCenter && uamModel.getData()[i].aCostCenter[0] !== undefined) ? val +
								"CC:" + uamModel.getData()[i].aCostCenter[0].ID.substring(uamModel.getData()[i].aCostCenter[0].ID.indexOf("7100") + 4,
									uamModel.getData()[i].aCostCenter[0].ID.length) + "|" : val;
							val = (uamModel.getData()[i].functionalArea && uamModel.getData()[i].functionalArea !== undefined) ? val + "FA:" + uamModel.getData()[
								i].functionalArea + "|" : val;
							val = (uamModel.getData()[i].franchiseValue && uamModel.getData()[i].franchiseValue !== undefined) ? val + "FRA:" + uamModel
								.getData()[
									i].franchiseValue + "|" : val;
							val = (uamModel.getData()[i].countryName && uamModel.getData()[i].countryName !== undefined) ? val + "CN:" + uamModel.getData()[
								i].countryName + "|" : val;
							val = (uamModel.getData()[i].locationName && uamModel.getData()[i].locationName !== undefined) ? val + "LOC:" + uamModel.getData()[
								i].locationName : val;
							val = (uamModel.getData()[i].BussnuisSiteArea && uamModel.getData()[i].BussnuisSiteArea !== undefined) ? val + "BS:" +
								uamModel.getData()[
									i].BussnuisSiteArea + "|" : val;
							val = (uamModel.getData()[i].tech && uamModel.getData()[i].tech !== undefined) ? val + "TECH:" + uamModel.getData()[
								i].tech : val;
							if (selInstanceCode === "WFP") {
								var data = {
									"entitlementtype": "AccessRules",
									"entitlementvalue": "AT:" + uamModel.getData()[i].Id.split("~")[0] + "|GWA:" + uamModel.getData()[i].Id.split("~")[1] +
										"|" +
										val,
									"displayname": "AT:" + uamModel.getData()[i].Id.split("~")[0] + "|GWA:" + uamModel.getData()[i].Id.split("~")[1] + "|" +
										val
								}
								that.entitleValue.push(data);
							} else if (selInstanceCode === "CAP") {
								var data1 = {
									"entitlementtype": "AccessRules",
									"entitlementvalue": "AT:" + uamModel.getData()[i].value + "|" + val,
									"displayname": "AT:" + uamModel.getData()[i].value + "|" + val
								}
								that.entitleValue.push(data1);
							} else {
								var data2 = {
									"entitlementtype": "AccessRules",
									"entitlementvalue": "AT:" + uamModel.getData()[i].value + "|" + val,
									"displayname": "AT:" + uamModel.getData()[i].value + "|" + val
								}
								that.entitleValue.push(data2);
							}

						}
						that.getView().getModel("EntitlementModel").setData(that.entitleValue);
						that.updateCreateEntitlement(updateApi, that.entitleValue, InstId);

					} else if (key === "removeRole") {
						sap.ui.getCore().getModel("createReqModel").setProperty("/NDABtnVisible", false);
						sap.ui.getCore().getModel("createReqModel").setProperty("/NDABtnPressed", false);
						sap.ui.getCore().getModel("createReqModel").setProperty("/SubmitBtnEnabled", true);
						sap.ui.getCore().getModel("createReqModel").setProperty("/NDABtnText", "NDA Declaration");
						that.loadReviewPage();
					}

					busyDialog.close();
				},
				error: function (Error) {
					var errorMsg = that.errorMsgParse(Error);
					MessageBox.error(errorMsg);
					busyDialog.close();
				}
			});
		},

		updateCreateEntitlement: function (updateApi, entitleValue, InstId) {
			var that = this;
			if (entitleValue) {
				// passing InstID in endpoint
				var payload = {
					"endpoint": InstId,
					"entitlement": entitleValue,
					"status": 1
				};

				$.ajax({
					type: 'POST',
					contentType: "application/json",
					dataType: 'json',
					headers: {
						"Access-Control-Allow-Origin": "*",
						"Access-Control-Allow-Headers": "*",
						"Access-Control-Allow-Credentials": "true",
						"Access-Control-Allow-Methods": "*",

						"Accept": "application/json, text/html"
					},
					url: updateApi[0].URL,
					data: JSON.stringify(payload),
					async: true,
					cache: false,
					success: function (data) {
						if (data[0].errorCode === "0") {

							//condition to show the nda button
							sap.ui.getCore().getModel("createReqModel").setProperty("/NDABtnVisible", false);
							sap.ui.getCore().getModel("createReqModel").setProperty("/NDABtnPressed", false);
							sap.ui.getCore().getModel("createReqModel").setProperty("/SubmitBtnEnabled", false);
							sap.ui.getCore().getModel("createReqModel").setProperty("/NDABtnText", "NDA Declaration");

							//NDA button can be visible with the following conditions
							//NDA should be X
							//Request is raised for Self
							//Request is raised for Salary
							//By default Submit Button should be enabled except the below conditions
							sap.ui.getCore().getModel("createReqModel").setProperty("/SubmitBtnEnabled", true);
							if (updateApi[0].NDA_SIGN === "X" && that.byId("cbRTForSelf").getSelected() &&
								JSON.stringify(that.getView().getModel("EntitlementModel").getData()).includes(":SALARY DETAIL")) {

								sap.ui.getCore().getModel("createReqModel").setProperty("/NDABtnVisible", true);
								sap.ui.getCore().getModel("createReqModel").setProperty("/SubmitBtnEnabled", false);
							} else if (updateApi[0].NDA_SIGN === "X" && that.byId("cbRTForSelf").getSelected() &&
								!JSON.stringify(that.getView().getModel("EntitlementModel").getData()).includes(":SALARY DETAIL")) {

								sap.ui.getCore().getModel("createReqModel").setProperty("/NDABtnVisible", false);
								sap.ui.getCore().getModel("createReqModel").setProperty("/SubmitBtnEnabled", true);
							} else if (updateApi[0].NDA_SIGN === "" && that.byId("cbRTForSelf").getSelected() &&
								JSON.stringify(that.getView().getModel("EntitlementModel").getData()).includes(":SALARY DETAIL")) {

								sap.ui.getCore().getModel("createReqModel").setProperty("/NDABtnVisible", false);
								sap.ui.getCore().getModel("createReqModel").setProperty("/SubmitBtnEnabled", true);
							} else if (that.byId("cbRTForSelf").getSelected() &&
								JSON.stringify(!that.getView().getModel("EntitlementModel").getData()).includes(":SALARY DETAIL")) {

								sap.ui.getCore().getModel("createReqModel").setProperty("/NDABtnVisible", false);
								sap.ui.getCore().getModel("createReqModel").setProperty("/SubmitBtnEnabled", true);
							} else if (that.byId("cbRTForOther").getSelected() &&
								JSON.stringify(that.getView().getModel("EntitlementModel").getData()).includes(":SALARY DETAIL") &&
								updateApi[0].NDA_SIGN === "X") {
								sap.ui.getCore().getModel("createReqModel").setProperty("/NDABtnVisible", false);
								sap.ui.getCore().getModel("createReqModel").setProperty("/SubmitBtnEnabled", true);
							}

							that.loadReviewPage();
						}
					},
					error: function (oError) {
						console.log(oError)
						MessageBox.error("Entiltlement updation failed");
					},
					beforeSend: function (req) {
						req.setRequestHeader("Authorization", "Basic " + btoa(updateApi[0].RFC_ID + ":" + updateApi[0].Password)); // <<<<----- USED HERE
					}
				});
			}
		},
		/**
		 * Jsons structure is posted for ajax call, to create Saviynt request
		 * @public
		 * @override
		 * @param{Json} Saviynt Create API structure
		 * @return{object} Json moddel with saviynt request number
		 */
		toSubmit: function () {
			//submit action happens with following scenarios.
			var that = this;
			var InstId = this.getView().byId("cbInstance").getSelectedKey();
			var req_type;
			if (addSel === true) {
				req_type = "ADD"
			} else if (removeSel === true) {
				req_type = "REMOVE"
			}

			if ((this.byId("cbRTForSelf").getSelected() &&
					JSON.stringify(that.getView().getModel("EntitlementModel").getData()).includes(":SALARY DETAIL") &&
					(sap.ui.getCore().getModel("createReqModel").getProperty("/NDABtnPressed") ||
						!sap.ui.getCore().getModel("createReqModel").getProperty("/NDABtnVisible"))
				) ||
				(this.byId("cbRTForOther").getSelected() &&
					!JSON.stringify(that.getView().getModel("EntitlementModel").getData()).includes(":SALARY DETAIL")) ||

				(this.byId("cbRTForOther").getSelected() && (removeSel === true)) ||

				(this.byId("cbRTForSelf").getSelected() &&
					!JSON.stringify(that.getView().getModel("EntitlementModel").getData()).includes(":SALARY DETAIL"))) {
				//
				var payload = {
					"requesttype": req_type,
					"username": that.createAPIValue[0].EMP_ID,
					"endpoint": InstId, //passing instID as endpoint
					"accountname": (this.byId("cbRTForSelf").getSelected()) ? this.getOwnerComponent().getModel("LogInUserModel").getProperty(
						"/Email") : this.getOwnerComponent().getModel("OtherUserModel1").getProperty("/Email"),
					"comments": sap.ui.getCore().getModel("createReqModel").getProperty("/reason"),
					"requestor": that.createAPIValue[0].BATCH_ID,
					"createaccountifnotexists": "false",
					"dynamicattr": {
						"Permissionset": sap.ui.getCore().getModel("createReqModel").getProperty("/Permission_ID"),
						"Permissionset_Name": sap.ui.getCore().getModel("createReqModel").getProperty("/Permission_Name"),
						"seglevel": sap.ui.getCore().getModel("createReqModel").getProperty("/SeglevelValue"),
						"seglvlcr": (sap.ui.getCore().getModel("createReqModel").getProperty("/SeglevelValue") === "COUNTRY/REGION") ? sap.ui.getCore()
							.getModel("createReqModel").getProperty("/CONTRY") : ""
					},
					"entitlement": that.getView().getModel("EntitlementModel").getData(),
					"checksod": "false"
				}
				busyDialog.open();
				busyDialog.setText("Loading");
				$.ajax({
					type: 'POST',
					contentType: "application/json",
					dataType: 'json',
					headers: {
						"Access-Control-Allow-Origin": "*",
						"Access-Control-Allow-Headers": "*",
						"Access-Control-Allow-Credentials": "true",
						"Access-Control-Allow-Methods": "*",
						"Accept": "application/json, text/html"
					},
					url: that.createAPIValue[0].URL,
					data: JSON.stringify(payload),
					async: true,
					cache: false,
					success: function (data) {
						busyDialog.close();
						if (data.errorCode === "0") {
							that.onSaveSaviyantDetails(data);
						} else {
							MessageBox.error(data.message);
						}

					},
					error: function (oError) {

						MessageBox.error("Create request failed");
					},
					beforeSend: function (req) {
						req.setRequestHeader("Authorization", "Basic " + btoa(that.createAPIValue[0].RFC_ID + ":" + that.createAPIValue[0].Password)); // <<<<----- USED HERE
					}
				});

			} else if (this.byId("cbRTForOther").getSelected() &&
				JSON.stringify(that.getView().getModel("EntitlementModel").getData()).includes(":SALARY DETAIL") &&
				that.createAPIValue[0].NDA_SIGN === "X"
			) {
				var payload1 = {
					"System_ID": this.byId("cbSystem").getSelectedKey(),
					"EMP_ID": that.createAPIValue[0].EMP_ID,
					"User_ID": this.getOwnerComponent().getModel("LogInUserModel").getProperty("/User_ID"),

					"REQ_FOR": (this.byId("cbRTForSelf").getSelected()) ? this.getOwnerComponent().getModel("LogInUserModel").getProperty("/User_ID") : sap
						.ui.getCore().getModel("createReqModel").getProperty("/user_id"),
					"Name": "",
					"Country": sap.ui.getCore().getModel("createReqModel").getProperty("/user_country"),
					"Department": sap.ui.getCore().getModel("createReqModel").getProperty("/user_dept"),
					"Job_Title": sap.ui.getCore().getModel("createReqModel").getProperty("/user_jobtitle"),
					"Email": (this.byId("cbRTForSelf").getSelected()) ? this.getOwnerComponent().getModel("LogInUserModel").getProperty(
						"/Email") : this.getOwnerComponent().getModel("OtherUserModel1").getProperty("/Email"),
					"Reason": sap.ui.getCore().getModel("createReqModel").getProperty("/reason"),
					"INSTANCE_ID": sap.ui.getCore().getModel("createReqModel").getProperty("/INSTANCE_ID"),
					"INSTANCE": sap.ui.getCore().getModel("createReqModel").getProperty("/INSTANCE"),
					"Permission_ID": sap.ui.getCore().getModel("createReqModel").getProperty("/Permission_ID"),
					"Permission_Name": sap.ui.getCore().getModel("createReqModel").getProperty("/Permission_Name"),
					"Requestor_Mail": this.getOwnerComponent().getModel("LogInUserModel").getProperty("/Email"),
					"Seglevel": sap.ui.getCore().getModel("createReqModel").getProperty("/SeglevelValue"),
					"CONTRY": (sap.ui.getCore().getModel("createReqModel").getProperty("/SeglevelValue") === "COUNTRY/REGION") ? sap.ui.getCore().getModel(
						"createReqModel").getProperty("/CONTRY") : "",

					"UAM_REQ": "",
					"SAV_REQ": "",
					"REQ_TYPE": "UAM",
					"APP_FLAG": "",
					"add_remove": "add",
					"comments": "",
					"SAV_REQ_ID": "",
					"Nav_Submit_To_Item": this.entitleValue,
					"Nav_Submit_To_Ret": []

				};
				var saveDetailsSrv = this.getOwnerComponent().getModel("Z8CZ_WORKDAY_ADAPTIVE_SRV");
				busyDialog.open();

				saveDetailsSrv.create("/SubmitButtonSet", payload1, {
					success: function (oData) {
						busyDialog.close();
						that.showMessage(oData.Nav_Submit_To_Ret.results[0]);
					},
					error: function (Error) {
						var errorMsg = that.errorMsgParse(Error);
						MessageBox.error(errorMsg);
						busyDialog.close();
					}
				});
			}
		},
		onSaveSaviyantDetails: function (data) {

			var ndaaccept = "";
			var that = this;
			if (sap.ui.getCore().getModel("createReqModel").getProperty("/NDABtnPressed")) {
				ndaaccept = "X";
			} else {
				ndaaccept = "";
			}
			var oDataPayload = {
				"User_ID": this.getOwnerComponent().getModel("LogInUserModel").getProperty("/User_ID"),
				"SAV_REQ": data.requestkey,
				"SAV_REQ_ID": data.RequestId,
				"NDA": ndaaccept,

				"REQ_FOR": (this.byId("cbRTForSelf").getSelected()) ? this.getOwnerComponent().getModel("LogInUserModel").getProperty(
					"/User_ID") : sap.ui.getCore().getModel("createReqModel").getProperty("/user_id"),
				"Nav_Submit_To_Item": [{
					"System_ID": "PROD"
				}]
			};

			var saveDetailsSrv = this.getOwnerComponent().getModel("Z8CZ_WORKDAY_ADAPTIVE_SRV");
			busyDialog.open();

			saveDetailsSrv.create("/SubmitButtonSet", oDataPayload, {
				success: function (oData) {
					busyDialog.close();
					var dataMsg = {
						"MsgType": "S",
						"MsgText": "Saviynt Request " + oDataPayload.SAV_REQ + " created successfully."
					};
					that.showMessage(dataMsg);
				},
				error: function (Error) {
					var errorMsg = that.errorMsgParse(Error);
					MessageBox.error(errorMsg);
					busyDialog.close();
				}
			});

		},
		showMessage: function (oResult) {

			MessageBox[(oResult.MsgType === "S") ? "success" : "error"](oResult.MsgText, {
				actions: [MessageBox.Action.CLOSE],
				onClose: function (oAction) {
					this.closeAction();
				}.bind(this)
			});
		},
		onClose: function () {},
		closeAction: function () {
			this.clearModelData();
			this._oWizardReviewPage.destroy();
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("RouteMain");
		},

		loadReviewPage: function () {
			Fragment.load({
				name: "com.alcon.UAM.view.fragments.WorkdayReviewPage",
				controller: this
			}).then(function (oWizardReviewPage) {
				this._oWizardReviewPage = oWizardReviewPage;
				this._oNavContainer.addPage(this._oWizardReviewPage);

				sap.ui.getCore().byId("wizardBranchingReviewPage").setModel(sap.ui.getCore().getModel("createReqModel"), "createReqModel");
				var details = sap.ui.getCore().getModel('createReqModel').oData.selType;
				sap.ui.getCore().byId('tblHierWorkdayTable').setHeaderText(details);

				this._oNavContainer.to(this._oWizardReviewPage); ////to bechecked
			}.bind(this));
		},

		onReasonChange: function () {
			if (this.byId("taReason").getValue() != "") {
				this.byId("taReason").setValueState("None");
			}
		},
		getHierarchy: function (sysId, EMflag, src, sPath, uamSelPath) {
			var that = this;
			var uamModel = this.getOwnerComponent().getModel("UamRoleModel");
			var costcenterArray = [],
				marketArray = [];
			hierSelCostCenterArray = [];
			hierSelMarketArray = [];
			var oModel = this.getOwnerComponent().getModel("Z8CZ_WORKDAY_ADAPTIVE_SRV");
			busyDialog.open();
			busyDialog.setText("Loading");
			var oFilter = [];
			this.getOwnerComponent().getModel("HierWorkdayMarketModel").setData({});
			this.getOwnerComponent().getModel("HierWorkdayCostModel").setData({});
			oFilter.push(new Filter("System_ID", FilterOperator.EQ, sysId));
			oFilter.push(new Filter("EMflag", FilterOperator.EQ, src));

			oModel.read("/Hier_MarketSet", {
				filters: [oFilter],
				success: function (oData) {
					var dataMarket = [],
						dataCostCenter = [];
					var val = {
						"NODEID": oData.results[0].PARENTID,
						"PARENTID": null
					};
					if (src === "MARKET") {
						var marketArrayTemp = [];
						for (let item of oData.results) {
							item.selected = false;
							item.editable = true;

							if (item.Default_Node) {
								item.selected = true;
								item.editable = false;
								item.selectedPath = "";
								marketArrayTemp.push(item);
							}
						}
						dataMarket = oData.results;
						dataMarket.unshift(val);
						var dataMarketMod1 = JSON.parse(JSON.stringify(dataMarket));
						that.getOwnerComponent().getModel("HierWorkdayMarketModel").setData(that.createTreeStructMarket(dataMarketMod1));
						if (uamModel.getProperty(uamSelPath)["aMarket"].length > 0) {
							for (let item of uamModel.getProperty(uamSelPath)["aMarket"]) {
								if (item.selectedPath !== "" && item.selectedPath !== undefined) {
									that.getOwnerComponent().getModel("HierWorkdayMarketModel").getProperty(item.selectedPath)
										.selected = true
									marketArray.push(item);
								}

							}
						}
					} else if (src === "COSTCENTER") {
						var costcenterArrayTemp = [];
						for (let item of oData.results) {
							item.selected = false;
							item.editable = true;

							if (item.Default_Node) {
								item.selected = true;
								item.editable = false;
								item.selectedPath = "";
								costcenterArrayTemp.push(item);
							}
						}
						dataCostCenter = oData.results;
						dataCostCenter.unshift(val);
						var dataCostcenterMod1 = JSON.parse(JSON.stringify(dataCostCenter));
						that.getOwnerComponent().getModel("HierWorkdayCostModel").setData(that.createTreeStructEntity(dataCostcenterMod1));
						if (uamModel.getProperty(uamSelPath)["aCostCenter"].length > 0) {
							for (let item of uamModel.getProperty(uamSelPath)["aCostCenter"]) {
								if (item.selectedPath !== "" && item.selectedPath !== undefined) {
									that.getOwnerComponent().getModel("HierWorkdayCostModel").getProperty(item.selectedPath)
										.selected = true

									costcenterArray.push(item);
								}

							}
						}
					}
					var oView = that.getView();
					if (!that._oDialog) {
						Fragment.load({
							name: "com.alcon.UAM.view.fragments.WorkdayHierarchy",
							controller: that
						}).then(function (oDialog) {
							that._oDialog = oDialog;
							that._oDialog.addStyleClass(this.getContentDensityClass())
							that.getView().addDependent(that._oDialog);
							that._oDialog.setModel({});
							sap.ui.getCore().byId("hierVerticallay1").setVisible(false);
							sap.ui.getCore().byId("hierVerticallay2").setVisible(false);
							sap.ui.getCore().byId("sfMarketSearch").setValue("");
							sap.ui.getCore().byId("sfEntitySearch").setValue("");
							sap.ui.getCore().byId("sfWDMarketSearchType").setSelectedKey("ws");
							sap.ui.getCore().byId("sfWDEntitySearchType").setSelectedKey("ws");
							if (dataMarket.length > 1) {
								that._oDialog.setModel(that.getOwnerComponent().getModel("HierWorkdayMarketModel"));
								sap.ui.getCore().byId("hierVerticallay1").setVisible(true);
								selMarketWorkDayModel.setData(marketArrayTemp.concat(marketArray));
								uamModel.getProperty(uamSelPath)["aMarket"] = marketArrayTemp.concat(marketArray);
								sap.ui.getCore().byId("tblSelValueMarket").setModel(selMarketWorkDayModel, "selMarketWorkDayModel");
								sap.ui.getCore().byId("tblSelValueMarket").getModel("selMarketWorkDayModel").refresh(true);
								if (uamModel.getProperty(uamSelPath)["aMarket"].length === 0) {
									sap.ui.getCore().byId("treeHierMarket").expandToLevel(0);
								}
							}
							if (dataCostCenter.length > 1) {
								that._oDialog.setModel(that.getOwnerComponent().getModel("HierWorkdayCostModel"));
								sap.ui.getCore().byId("hierVerticallay2").setVisible(true);
								selCostCenterWorkDayModel.setData(costcenterArrayTemp.concat(costcenterArray));
								uamModel.getProperty(uamSelPath)["aCostCenter"] = costcenterArrayTemp.concat(costcenterArray);
								sap.ui.getCore().byId("tblSelValueEntity").setModel(selCostCenterWorkDayModel, "selCostCenterWorkDayModel");
								sap.ui.getCore().byId("tblSelValueEntity").getModel("selCostCenterWorkDayModel").refresh(true);
								if (uamModel.getProperty(uamSelPath)["aCostCenter"].length === 0) {
									sap.ui.getCore().byId("treeHierEntity").expandToLevel(0);
								}
							}
							that._oDialog.open();
						}.bind(that));
					} else {
						that._oDialog.setModel({});
						that._oDialog.setModel(that.getOwnerComponent().getModel("HierWorkdayMarketModel"));
						that._oDialog.setModel(that.getOwnerComponent().getModel("HierWorkdayCostModel"));
						that.getView().addDependent(that._oDialog);
						sap.ui.getCore().byId("hierVerticallay1").setVisible(false);
						sap.ui.getCore().byId("hierVerticallay2").setVisible(false);
						sap.ui.getCore().byId("sfMarketSearch").setValue("");
						sap.ui.getCore().byId("sfEntitySearch").setValue("");
						sap.ui.getCore().byId("sfWDMarketSearchType").setSelectedKey("ws");
						sap.ui.getCore().byId("sfWDEntitySearchType").setSelectedKey("ws");
						if (dataMarket.length > 1) {
							sap.ui.getCore().byId("hierVerticallay1").setVisible(true);
							sap.ui.getCore().byId("treeHierMarket").setVisible(true);
							selMarketWorkDayModel.setData(marketArrayTemp.concat(marketArray));
							uamModel.getProperty(uamSelPath)["aMarket"] = marketArrayTemp.concat(marketArray);
							sap.ui.getCore().byId("tblSelValueMarket").setModel(selMarketWorkDayModel, "selMarketWorkDayModel");
							sap.ui.getCore().byId("tblSelValueMarket").getModel("selMarketWorkDayModel").refresh(true);
							if (uamModel.getProperty(uamSelPath)["aMarket"].length === 0) {
								sap.ui.getCore().byId("treeHierMarket").expandToLevel(0);
							}
						}
						if (dataCostCenter.length > 1) {
							sap.ui.getCore().byId("hierVerticallay2").setVisible(true);
							sap.ui.getCore().byId("treeHierEntity").setVisible(true);
							selCostCenterWorkDayModel.setData(costcenterArrayTemp.concat(costcenterArray));
							uamModel.getProperty(uamSelPath)["aCostCenter"] = costcenterArrayTemp.concat(costcenterArray);
							sap.ui.getCore().byId("tblSelValueEntity").setModel(selCostCenterWorkDayModel, "selCostCenterWorkDayModel");
							sap.ui.getCore().byId("tblSelValueEntity").getModel("selCostCenterWorkDayModel").refresh(true);
							if (uamModel.getProperty(uamSelPath)["aCostCenter"].length === 0) {
								sap.ui.getCore().byId("treeHierEntity").expandToLevel(0);
							}
						}
						that._oDialog.open();
					}
					busyDialog.close();
				},

				error: function (oError) {
					var errorMsg = that.errorMsgParse(oError);
					MessageBox.error(errorMsg);
					busyDialog.close();
				}
			});
		},
		toOpenHierarchy: function (oEvent) {
			uamSelPath = oEvent.getSource().getParent()["oPropagatedProperties"]["oModels"]["UamRoleModel"]["mContexts"]['/0'].getPath();
			let sPath = "";
			var rowValue = this.getOwnerComponent().getModel("UamRoleModel").getProperty(uamSelPath);
			var oMarketDataModel = this.getOwnerComponent().getModel("UamRoleModel");
			let aMarketData = oMarketDataModel.getData();
			uamSelPath = oEvent.getSource().getParent().oBindingContexts.UamRoleModel.getPath();
			let oMarketData = oMarketDataModel.getProperty(uamSelPath);
			var sysId = this.getView().byId("cbSystem").getSelectedKey();
			var InstId = this.getView().byId("cbInstance").getSelectedKey();
			var EMflag = oEvent.getSource().getText();

			this.systemValue = {
				"sysId": sysId,
				"InstId": InstId,
				"emFlag": EMflag
			};

			var src = (oEvent.getSource().getProperty("text") === "Cost Center") ? "COSTCENTER" : "MARKET";
			this.getHierarchy(sysId, EMflag, src, sPath, uamSelPath);

		},
		createTreeStructMarket: function (data) {
			const idMapping1 = data.reduce((acc, el, i) => {
				acc[el.NODEID] = i;
				return acc;
			}, {});
			let modData1;
			data.forEach(el => {
				// Handle the root element
				if (el.PARENTID === null) {
					modData1 = el;
					return;
				}
				// Use our mapping to locate the parent element in our data array
				const parentEl1 = data[idMapping1[el.PARENTID]];
				// Add our current el to its parent's `children` array
				parentEl1.children = [...(parentEl1.children || []), el];
			});
			return modData1;
		},
		createTreeStructEntity: function (data) {
			const idMapping = data.reduce((acc, el, i) => {
				acc[el.NODEID] = i;
				return acc;
			}, {});
			let modData;
			data.forEach(el => {
				// Handle the root element
				if (el.PARENTID === null) {
					modData = el;
					return;
				}
				// Use our mapping to locate the parent element in our data array
				const parentEl = data[idMapping[el.PARENTID]];
				// Add our current el to its parent's `children` array
				parentEl.children = [...(parentEl.children || []), el];
			});
			return modData;
		},
		onChangeMarketType: function (oEvent) {
			let key = oEvent.getSource().mProperties.selectedKey;
			if (key !== "ws" && key !== "cs") {
				this.byId("sfWDMarketSearchType").setSelectedKey("ws");
			}
		},
		onChangeEntityType: function (oEvent) {
			let key = oEvent.getSource().mProperties.selectedKey;
			if (key !== "ws" && key !== "cs") {
				this.byId("sfWDEntitySearchType").setSelectedKey("ws");
			}
		},
		onSearchMarket: function (oEvent) {
			let val;
			if (oEvent) {
				val = oEvent.getParameter("query").trim();
			} else {
				val = "";
			}

			var filter;
			let type = sap.ui.getCore().byId("sfWDMarketSearchType").getSelectedKey();

			if (type === "ws") {
				filter = new Filter({
					filters: [
						new Filter("ID", FilterOperator.Contains, val),
						new Filter("TXT", FilterOperator.Contains, val),
					],
					and: false,
				});
			} else if (type === "cs") {
				filter = new Filter({
					filters: [
						new Filter("ID", FilterOperator.EQ, val),
						new Filter("TXT", FilterOperator.EQ, val),
					],
					and: false,
				});
			}

			sap.ui.getCore().byId("treeHierMarket").getBinding("rows").filter(val ? filter : null);
			sap.ui.getCore().byId("treeHierMarket").expandToLevel(val ? 13 : 1);
		},
		onSearchEntity: function (oEvent) {
			let val;
			if (oEvent) {
				val = oEvent.getParameter("query").trim();
			} else {
				val = "";
			}

			var filter;
			let type = sap.ui.getCore().byId("sfWDEntitySearchType").getSelectedKey();

			if (type === "ws") {
				filter = new Filter({
					filters: [
						new Filter("ID", FilterOperator.Contains, val),
						new Filter("TXT", FilterOperator.Contains, val),
					],
					and: false,
				});
			} else if (type === "cs") {
				filter = new Filter({
					filters: [
						new Filter("ID", FilterOperator.EQ, val),
						new Filter("TXT", FilterOperator.EQ, val),
					],
					and: false,
				});
			}

			sap.ui.getCore().byId("treeHierEntity").getBinding("rows").filter(val ? filter : null);
			sap.ui.getCore().byId("treeHierEntity").expandToLevel(val ? 13 : 0);
		},
		onHierClose: function (oEvent) {
			var that = this;
			var oCore = sap.ui.getCore();
			var getValidatesrv = this.getOwnerComponent().getModel("Z8CZ_WORKDAY_ADAPTIVE_SRV");
			let id = "";
			let emflag = "";

			if (oCore.byId("hierVerticallay1").getVisible()) {
				if (oCore.byId("tblSelValueMarket").getModel("selMarketWorkDayModel").getData().length > 0) {
					id = oCore.byId("tblSelValueMarket").getModel("selMarketWorkDayModel").getData()[0].ID;
					emflag = "M";
				}

			} else if (oCore.byId("hierVerticallay2").getVisible()) {
				if (oCore.byId("tblSelValueEntity").getModel("selCostCenterWorkDayModel").getData().length > 0) {
					id = oCore.byId("tblSelValueEntity").getModel("selCostCenterWorkDayModel").getData()[0].ID;
					emflag = "C";
				}
			}
			if (id == "") {
				MessageToast.show("At least one value to be selected or press Escape to exit");
				return;
			}
			busyDialog.open();

			var url = "/ValidateNodeSet(System_ID='" + this.systemValue.sysId + "',EMFlag='" + emflag + "',ID='" +
				id + "',Instance_ID='" + this.systemValue.InstId + "')";
			getValidatesrv.read("/ValidateNodeSet(System_ID='" + this.systemValue.sysId + "',EMFlag='" + emflag + "',ID='" +
				id + "',Instance_ID='" + this.systemValue.InstId + "')", {

					success: function (oData) {
						if (oData.ret_code === "S") {
							MessageToast.show("Verified");
							that._oDialog.close();
							that.onSearchMarket();
							that.onSearchEntity();
						} else {
							that.getOwnerComponent().getModel("UamRoleModel").getData()[0].aMarket.shift();
							that.getOwnerComponent().getModel("UamRoleModel").getData()[0].aCostCenter.shift();
							MessageToast.show("Unrecognized");
						}
						busyDialog.close();
					},
					error: function (oError) {
						var errorMsg = that.errorMsgParse(oError);
						MessageBox.error(errorMsg);
						busyDialog.close();
					}
				});

		},

		onPressNdaButton: function () {
			var that = this;
			var sSource;
			var sServiceURL;
			var oController = this.getView();

			var opdfViewer = new PDFViewer();
			this.getView().addDependent(opdfViewer);

			sServiceURL = '/sap/opu/odata/sap/Z8CZ_WORKDAY_ADAPTIVE_SRV/';

			sSource = sServiceURL + "NDASet(DOC_NAME='NDA')/$value";
			opdfViewer.setSource(sSource);
			opdfViewer.setTitle("Non Disclosure Agreement");
			opdfViewer.setDisplayType("Embedded");
			opdfViewer.addPopupButton(new sap.m.Button({
				text: "Accept",
				type: "Accept",
				press: function (oEvent) {
					that.onAcceptNDA(oEvent, opdfViewer);
				}

			}));
			opdfViewer.addPopupButton(new sap.m.Button({
				text: "Reject",
				type: "Reject",
				press: function (oEvent) {
					that.onRejectNDA(oEvent, opdfViewer);
				}

			}));
			opdfViewer.addPopupButton(new sap.m.Button({
				text: "Close",
				type: "Emphasized",
				press: function (oEvent) {
					that.onCloseNDA(oEvent, opdfViewer);
				}

			}));
			opdfViewer._objectsRegister.getPopupCloseButton().setVisible(false);
			oController.addDependent(opdfViewer);
			opdfViewer.open();

		},
		onAcceptNDA: function (oEvent, opdfViewer) {
			var p = opdfViewer._objectsRegister.getPopup();
			p.removeAllContent();
			p.oPopup.close();

			sap.ui.getCore().getModel("createReqModel").setProperty("/SubmitBtnEnabled", true);
			sap.ui.getCore().getModel("createReqModel").setProperty("/NDABtnPressed", true);
			sap.ui.getCore().getModel("createReqModel").setProperty("/NDABtnText", "NDA Declaration Accepted");
		},
		onRejectNDA: function (oEvent, opdfViewer) {
			var p = opdfViewer._objectsRegister.getPopup();
			p.removeAllContent();
			p.oPopup.close();

			sap.ui.getCore().getModel("createReqModel").setProperty("/NDABtnPressed", true);
			sap.ui.getCore().getModel("createReqModel").setProperty("/NDABtnText", "NDA Declaration Rejected");
		},
		onCloseNDA: function (oEvent, opdfViewer) {
			var closeNDA = opdfViewer._objectsRegister.getPopup();
			closeNDA.removeAllContent();
			closeNDA.oPopup.close();

			sap.ui.getCore().getModel("createReqModel").setProperty("/NDABtnVisible", true);
			sap.ui.getCore().getModel("createReqModel").setProperty("/NDABtnPressed", false);
		},

		clearApplicationModelData: function () {
			this.byId("liApplication").removeSelections();
			this.byId("liSubApplication").removeSelections();
			this.byId("liBusRole").removeSelections();
			this.byId("liBusRoleRemove").removeSelections();
			this.getOwnerComponent().getModel("ApplicationModel1").setData({});
			this.getOwnerComponent().getModel("SubApplicationModel").setData({});
			this.getOwnerComponent().getModel("UamRoleModel").setData({});
			this.getOwnerComponent().getModel("HierWorkdayCostModel").setData({});
			this.getOwnerComponent().getModel("HierWorkdayMarketModel").setData({});
			this.getOwnerComponent().getModel("HierButtonModel").setData({});
			this.getOwnerComponent().getModel("ApplicationModel1").refresh(true);
			this.getOwnerComponent().getModel("SubApplicationModel").refresh(true);
			this.getOwnerComponent().getModel("UamRoleModel").refresh(true);
			this.getOwnerComponent().getModel("HierWorkdayCostModel").refresh(true);
			this.getOwnerComponent().getModel("HierWorkdayMarketModel").refresh(true);
			this.getOwnerComponent().getModel("HierButtonModel").refresh(true);
			//	this.getOwnerComponent().getModel("ApplicationModel2").setData({});
			this.getOwnerComponent().getModel("SubApplicationRemoveModel").setData({});
			this.getOwnerComponent().getModel("UamRoleRemoveModel").setData({});
			this.getOwnerComponent().getModel("SubApplicationRemoveModel").refresh(true);
			this.getOwnerComponent().getModel("UamRoleRemoveModel").refresh(true);

		},

		onItemSelectionMarket1: function (oEvent) {

			var oModel = this.getOwnerComponent().getModel("HierWorkdayMarketModel");
			var selPath = oEvent.getSource().getBindingInfo("selected")["binding"].getContext().getPath();
			var data = {};
			var tempArray = [];
			hierSelMarketArray = this.getOwnerComponent().getModel("UamRoleModel").getProperty(uamSelPath)["aMarket"];
			if (hierSelMarketArray.length > 0) {
				this.getOwnerComponent().getModel("UamRoleModel").getProperty(uamSelPath)["aMarket"].shift();
			}
			//if condition to add the selected items to an array
			if (oEvent.getParameter("selected")) {
				for (var i in hierField) {
					data[hierField[i]] = oModel.getProperty(selPath)[hierField[i]];
				}
				data["selectedPath"] = selPath;
				hierSelMarketArray.push(data);
			}
			//else condition to remove the unselected items from an array
			else {
				for (let m in hierSelMarketArray) {
					if (hierSelMarketArray[m].selectedPath === selPath) {
						hierSelMarketArray.splice(m, 1);
					}
				}
			}
			for (let n in hierSelMarketArray) {
				tempArray.push({
					"ID": hierSelMarketArray[n]["ID"],
					"TXT": hierSelMarketArray[n]["TXT"]
				});
			}

			selMarketWorkDayModel.setData(tempArray);
			sap.ui.getCore().byId("tblSelValueMarket").setModel(selMarketWorkDayModel, "selMarketWorkDayModel");
			sap.ui.getCore().byId("tblSelValueMarket").getModel("selMarketWorkDayModel").refresh(true);
			this.getOwnerComponent().getModel("UamRoleModel").getProperty(uamSelPath)["aMarket"] = hierSelMarketArray;
		},

		onItemSelectionCost1: function (oEvent) {

			var oModel = this.getOwnerComponent().getModel("HierWorkdayCostModel");
			var selPath = oEvent.getSource().getBindingInfo("selected")["binding"].getContext().getPath();
			var data = {};
			var tempArray = [];
			hierSelCostCenterArray = this.getOwnerComponent().getModel("UamRoleModel").getProperty(uamSelPath)["aCostCenter"];
			if (hierSelCostCenterArray.length > 0) {
				this.getOwnerComponent().getModel("UamRoleModel").getProperty(uamSelPath)["aCostCenter"].shift();
			}
			//if condition to add the selected items to an array
			if (oEvent.getParameter("selected")) {
				for (var i in hierField) {
					data[hierField[i]] = oModel.getProperty(selPath)[hierField[i]];
				}
				data["selectedPath"] = selPath;
				hierSelCostCenterArray.push(data);
			}
			//else condition to remove the unselected items from an array
			else {
				for (let m in hierSelCostCenterArray) {
					if (hierSelCostCenterArray[m].selectedPath === selPath) {
						hierSelCostCenterArray.splice(m, 1);
					}
				}
			}
			for (let n in hierSelCostCenterArray) {
				tempArray.push({
					"ID": hierSelCostCenterArray[n]["ID"],
					"TXT": hierSelCostCenterArray[n]["TXT"]
				});
			}
			selCostCenterWorkDayModel.setData(tempArray);
			sap.ui.getCore().byId("tblSelValueEntity").setModel(selCostCenterWorkDayModel, "selCostCenterWorkDayModel");
			sap.ui.getCore().byId("tblSelValueEntity").getModel("selCostCenterWorkDayModel").refresh(true);
			this.getOwnerComponent().getModel("UamRoleModel").getProperty(uamSelPath)["aCostCenter"] = hierSelCostCenterArray;
		}
	});

});