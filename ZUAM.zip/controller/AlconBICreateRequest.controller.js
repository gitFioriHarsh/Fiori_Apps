sap.ui.define([
	"com/alcon/UAM/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageBox",
	"sap/m/MessageToast",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/core/Fragment",
	"sap/ui/model/odata/v2/ODataModel",
	"sap/ui/core/routing/History",
	"com/alcon/UAM/util/formatter",
	"sap/m/GroupHeaderListItem"
], function (BaseController, JSONModel, MessageBox, MessageToast, Filter, FilterOperator, Fragment, ODataModel, History, formatter,
	GroupHeaderListItem) {
	"use strict";
	var busyDialog = new sap.m.BusyDialog();
	var selCostModel = new JSONModel();
	var selProfitModel = new JSONModel();
	var selCompanyModel = new JSONModel();
	var uamSelPath = "";
	var treeSelValCost = "",
		treeSelValProfit = "",
		treeSelValCompanyt = "";
	var addSel = false,
		removeSel = false;
	var hierSelProfitArray = [];
	var hierSelCostArray = [];
	var hierSelCompanyArray = [];
	var hierField = ["Application", "CHILDID", "Consolidated_View", "Department_Role", "DrillState", "EMflag", "HEIR_NAME", "HIEID", "ID",
		"NAME", "NODEID", "OBJ", "PARENTID", "PID", "Segregation", "Subapplication", "System_ID", "TLEVEL", "TXT", "UAM_Role", "User_ID",
		"selected"
	];

	return BaseController.extend("com.alcon.UAM.controller.AlconBICreateRequest", {
		formatter: formatter,
		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.alcon.UAM.view.createRequest
		 */
		onInit: function () {
			jQuery.sap.includeStyleSheet("/sap/bc/ui5_ui5/sap/zuam/css/style.css");
			var sRootPath = jQuery.sap.getModulePath("zuam");
			var location = $(location).attr('href');

			this.getOwnerComponent().getRouter().getRoute("AlconBICreateRequest").attachMatched(this._onRouteMatched, this);
			this.getView().addStyleClass(this.getContentDensityClass());
			this._wizard = this.byId("UserRoleAccessWizard");
			this._oNavContainer = this.byId("navContainer");
			this._oDynamicPage = this.getView();

			var oModel = this.getOwnerComponent().getModel("ZAL_CREATE_REQUEST_SRV_01");
			oModel.setSizeLimit(100000);
			this.getView().setModel(oModel);
			var flagModel = new JSONModel({
				flag: "false"
			});
			sap.ui.getCore().setModel(flagModel, "flagModel");

		},

		_onRouteMatched: function (oEvent) {
			var error = ["", null, undefined];
			if (error.includes(this.getOwnerComponent().applId)) {
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("RouteMain");
			} else {
				this.byId("cbSystem").setSelectedKey("PN4");
				this.byId("cbDepartment").setSelectedKey("");
				this.byId("cbSegregation").setSelectedKey("");
				this.byId("cbSegregation").setEnabled(false);
				this.byId("taReason").setValue("");
				this.byId("txtApp").setText(this.getOwnerComponent().applName)
				this.getOwnerComponent().getModel("OtherUserModel1").setData({});
				this.clearModelData(); //this is to clear all the model data
				var currentStep = this.getView().byId("UserRoleAccessWizard").getAssociation("currentStep");
				if (currentStep.includes("roleSelection")) {
					this.getView().byId('UserRoleAccessWizard').previousStep();
					this.getView().byId('UserRoleAccessWizard').previousStep();
				} else if (currentStep.includes("departmentSelection")) {
					this.getView().byId('UserRoleAccessWizard').previousStep();
				}
			}
		},
		onNavBack: function () {

			MessageBox.warning("Your data may be lost. Are you sure to continue?", {
				actions: [MessageBox.Action.YES, MessageBox.Action.NO],
				onClose: function (oAction) {

					if (oAction === MessageBox.Action.YES) {
						this.clearModelData();
						var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
						oRouter.navTo("RouteMain");
					} else if (oAction === MessageBox.Action.NO) {
						return;
					}
				}.bind(this)
			});

		},

		resetCreateReqModel: function () {
			var oMod = sap.ui.getCore().getModel("createReqModel");
			oMod.setProperty("/selfFlag", "true");
			oMod.setProperty("/user_id", "");
			oMod.setProperty("/line_manager", "");
			oMod.setProperty("/application_id", "");
			oMod.setProperty("/aaplication_desc", "");
			oMod.setProperty("/system_id", "PN4");
			oMod.setProperty("/start_date", "");
			oMod.setProperty("/end_date", "");
			oMod.setProperty("/job_title", "");
			oMod.setProperty("/segr_level", "");
			oMod.setProperty("/reason", "");
			oMod.setProperty("/consolidation_flag", "");

		},
		liveChangeFunction: function (event) {
			var str = event.getSource().getValue().toUpperCase();
			event.getSource().setValue(str);

		},

		onAfterRendering: function () {
			var that = this;
			var getDetailsrv = this.getOwnerComponent().getModel("ZAL_CREATE_REQUEST_SRV_01");
			sap.ui.getCore().getModel("createReqModel");
			this.byId("txtApp").setText(this.getOwnerComponent().applName);
			this.byId("cbSystem").setSelectedKey("PN4");
		},

		onForSelfSelect: function (oEvent) {
			if (oEvent !== "" && oEvent.getParameters()["selected"]) {
				this.byId("cbRTForOther").setSelected(false);
				this.byId("lbl521MgrId").setVisible(true);
				this.byId("in521MgrNameId").setVisible(true);
				this.byId("lbl521Id").setVisible(false);
				this.byId("in521Id").setVisible(false);
				this.byId("in521Id").setValue("");
				sap.ui.getCore().getModel("createReqModel").setProperty("/selfFlag", "true");
				this.byId("idOtherDet").setVisible(false);

			} else {
				this.byId("cbRTForOther").setSelected(false);
				this.byId("cbRTForSelf").setSelected(true);
				this.byId("lbl521Id").setVisible(false);
				this.byId("in521Id").setVisible(false);
				this.byId("in521Id").setValue("");
				this.byId("idOtherDet").setVisible(false);

			}
			this.onChangeSystem();

		},
		onForOtherSelect: function (oEvent) {
			if (oEvent.getParameters()["selected"]) {
				this.byId("cbRTForSelf").setSelected(false);
				this.byId("lbl521MgrId").setVisible(false);
				this.byId("in521MgrNameId").setVisible(false);
				this.byId("lbl521Id").setVisible(true);
				this.byId("in521Id").setVisible(true);
				this.byId("in521Id").setValue("");
				sap.ui.getCore().getModel("createReqModel").setProperty("/selfFlag", "false");
			} else {
				this.byId("cbRTForOther").setSelected(true);
			}
			this.onChangeSystem();

		},
		getList: function (data) {
			var list = [];

			for (var i in data) {
				list.push({
					"value": data[i].getAggregation("cells")[0].getText()
				});
			}
			return list;
		},
		onReasonChange: function () {
			if (this.byId("taReason").getValue() != "") {
				this.byId("taReason").setValueState("None");
			}
		},
		completedHandler: function () {
			var checkSubAppl = false,
				checkUamrole = false;
			var key = this.byId("itbAlconRole").getSelectedKey();
			var apps, uamModel, subApplModel;

			if (key === "addRole") {
				apps = this.byId("liApplication").getSelectedItems();
				uamModel = this.getOwnerComponent().getModel("UamRoleModel");
				subApplModel = this.getOwnerComponent().getModel("SubApplicationModel");
			} else if (key === "removeRole") {
				apps = this.byId("liApplicationRemove").getSelectedItems();
				uamModel = this.getOwnerComponent().getModel("UamRoleRemoveModel");
				subApplModel = this.getOwnerComponent().getModel("SubApplicationRemoveModel");
			}
			//front end validation
			//check any sub application is selected
			for (let m in subApplModel.getData()) {
				if (subApplModel.getData()[m].selected = true) {
					checkSubAppl = true;
				}
			}
			for (let m in uamModel.getData()) {
				if (uamModel.getData()[m].selected = true) {
					checkUamrole = true;
				}
			}

			if (this.byId("taReason").getValue() === "") {
				this.byId("taReason").setValueState("Error");
				return;
			}
			if (apps.length == 0) {
				MessageToast.show("Please select any one application atleast");
				return;
			}
			if (!checkSubAppl) {
				MessageToast.show("Please select any one subapplication atleast");
				return;
			}
			if (!checkUamrole) {
				MessageToast.show("Please select any one role atleast");
				return;
			}
			var data = {};

			var hierSelArrVal = [];

			if (key === "addRole") {

				//getting the selected Hierachy value for both cost and profit
				for (let k in uamModel.getData()) {
					for (let m in uamModel.getData()[k]["profit"]) {
						if (uamModel.getData()[k].selected) {
							data = {};
							for (let i in hierField) {
								if (hierField[i] !== "selected" && hierField[i] !== "selectedPath") {
									data[hierField[i]] = uamModel.getData()[k]["profit"][m][hierField[i]];
								}
							}
							hierSelArrVal.push(data);
						}
					}

				}
				for (let j in uamModel.getData()) {
					for (let m in uamModel.getData()[j]["cost"]) {
						if (uamModel.getData()[j].selected) {
							data = {};
							for (let i in hierField) {
								if (hierField[i] !== "selected" && hierField[i] !== "selectedPath") {
									data[hierField[i]] = uamModel.getData()[j]["cost"][m][hierField[i]];
								}
							}
							hierSelArrVal.push(data);
						}
					}
				}
				for (let j in uamModel.getData()) {
					for (let m in uamModel.getData()[j]["company"]) {
						if (uamModel.getData()[j].selected) {
							data = {};
							for (let i in hierField) {
								if (hierField[i] !== "selected" && hierField[i] !== "selectedPath") {
									data[hierField[i]] = uamModel.getData()[j]["company"][m][hierField[i]];
								}
							}
							hierSelArrVal.push(data);
						}
					}
				}
			} else if (key == "removeRole") {
				let oUamModel = this.getOwnerComponent().getModel("HiearchyRemoveModel").getData();
				let sysId = this.getView().byId("cbSystem").getSelectedKey();

				let deptId = this.getView().byId("cbDepartment").getSelectedKey();
				let segId = this.getView().byId("cbSegregation").getSelectedKey();
				let requestedUser = (this.byId("cbRTForSelf").getSelected()) ? this.getOwnerComponent().getModel("LogInUserModel").getData().User_ID :
					this
					.byId("in521Id").getValue();
				for (let item of oUamModel) {
					if (item.selected) {
						let dat = {
							"Application": item.hier.split(" / ")[0],
							"Subapplication": item.hier.split(" / ")[1],
							"UAM_Role": item.hier.split(" / ")[2],
							"HEIR_NAME": item.hier.split(" / ")[3],
							"Consolidated_View": "",
							"Department_Role": deptId,
							"ID": item.node,
							"OBJ": item.obj,
							"Segregation": segId,
							"System_ID": sysId,
							"User_ID": requestedUser
						}
						hierSelArrVal.push(dat);
					}
				}
			}

			sap.ui.getCore().getModel("createReqModel").setProperty("/selType", (key === "addRole") ? "Add Role" : "Remove Role");
			sap.ui.getCore().getModel("createReqModel").setProperty("/application", uamModel.getData());

			sap.ui.getCore().getModel("createReqModel").setProperty("/hier", hierSelArrVal);
			sap.ui.getCore().getModel("createReqModel").setProperty("/reason", this.byId("taReason").getValue());

			sap.ui.getCore().getModel("createReqModel").setProperty("/system_id", this.byId("cbSystem").getSelectedKey());
			sap.ui.getCore().getModel("createReqModel").setProperty("/start_date", this.byId("DP1").getValue());
			sap.ui.getCore().getModel("createReqModel").setProperty("/end_date", this.byId("DP2").getValue());

			var check = sap.ui.getCore().getModel("createReqModel").getProperty("/selfFlag");
			sap.ui.getCore().getModel("createReqModel").setProperty("/requestor_id", this.byId("selfUserID").getText());
			if (check == "false") {
				sap.ui.getCore().getModel("createReqModel").setProperty("/full_name", this.byId("otherName").getText());
				sap.ui.getCore().getModel("createReqModel").setProperty("/line_manager_name", this.byId("managerfieldval").getValue());
				sap.ui.getCore().getModel("createReqModel").setProperty("/user_dept", this.byId("otherDept").getText());
				sap.ui.getCore().getModel("createReqModel").setProperty("/user_country", this.byId("otherCountry").getText());
				sap.ui.getCore().getModel("createReqModel").setProperty("/user_jobtitle", this.byId("otherJobTitle").getText());

			} else {
				sap.ui.getCore().getModel("createReqModel").setProperty("/full_name", this.byId("selfName").getTitle());
				sap.ui.getCore().getModel("createReqModel").setProperty("/line_manager_name", this.byId("selfLineManager").getText());
				sap.ui.getCore().getModel("createReqModel").setProperty("/user_dept", this.byId("selfDept").getText());
				sap.ui.getCore().getModel("createReqModel").setProperty("/user_country", this.byId("selfCountry").getText());
				sap.ui.getCore().getModel("createReqModel").setProperty("/user_jobtitle", this.byId("selfJobTitle").getText());
			}

			Fragment.load({
				name: "com.alcon.UAM.view.fragments.AlconBIReviewPage",
				controller: this
			}).then(function (oWizardReviewPage) {
				this._oWizardReviewPage = oWizardReviewPage;
				this._oNavContainer.addPage(this._oWizardReviewPage);

				sap.ui.getCore().byId("wizardBranchingReviewPage").setModel(sap.ui.getCore().getModel("createReqModel"), "createReqModel");
				var details = sap.ui.getCore().getModel('createReqModel').oData.selType;
				sap.ui.getCore().byId('tblHierTable').setHeaderText(details);

				this._oNavContainer.to(this._oWizardReviewPage); ////to bechecked
			}.bind(this));

		},
		_handleMessageBoxOpen: function (sMessage, sMessageBoxType) {
			MessageBox[sMessageBoxType](sMessage, {
				actions: [MessageBox.Action.YES, MessageBox.Action.NO],
				onClose: function (oAction) {

					if (oAction === MessageBox.Action.YES) {
						this._wizard.discardProgress(this._wizard.getSteps()[0]);
						this.handleNavBackToList();
					}
				}.bind(this)
			});
		},
		toCancel: function () {
			this.closeAction();

		},
		handleNavBackToList: function () {
			this._navBackToStep(this.byId("userSelection"));
			this.resetCreateReqModel();
		},

		_navBackToStep: function (step) {
			var fnAfterNavigate = function () {
				this._wizard.goToStep(step);
				this._oNavContainer.detachAfterNavigate(fnAfterNavigate);
			}.bind(this);

			this._oNavContainer.attachAfterNavigate(fnAfterNavigate);
			this._oNavContainer.to(this._oDynamicPage);
		},

		onChangeRequestType: function () {

			if (this.byId("cbRequestType").getValue() === "Other User") {
				this.byId("lbl521Id").setVisible(true);
				this.byId("in521Id").setVisible(true);
			}
		},
		changeDateValueState: function (event) {
			var selKey = event.getSource().getValue();
			sap.ui.getCore().getModel("createReqModel").setProperty("/start_date", selKey);
			if (selKey != "") {
				event.getSource().setValueState("None");
			}
		},
		handleChange: function (event) {
			var selKey = event.getSource().getValue();
			sap.ui.getCore().getModel("createReqModel").setProperty("/end_date", selKey);
			if (selKey != "") {
				event.getSource().setValueState("None");
			}
		},

		changeValueState: function (event) {
			var selKey = event.getSource().getSelectedKey();
			var currentStep = this.getView().byId("UserRoleAccessWizard").getAssociation("currentStep");
			if (currentStep.includes("roleSelection")) {
				this.byId("itbAlconRole").setSelectedKey("addRole");
				this.getView().byId('UserRoleAccessWizard').previousStep();
			}
			if (selKey != "") {
				event.getSource().setValueState("None");
			}
			var sId = event.getSource().sId;
			if (sId.includes("cbDepartment")) {
				sap.ui.getCore().getModel("createReqModel").setProperty("/job_title", selKey);

				this.filterSegregation(selKey);
				this.byId("cbSegregation").setEnabled(true);
			}
			if (sId.includes("cbSegregation")) {
				sap.ui.getCore().getModel("createReqModel").setProperty("/segr_level", selKey);
			}
		},
		setBtnVisible() {
			sap.ui.getCore().byId("id3--btOK").setVisible(true);
		},

		onListApplChange: function (oEvent) {
			addSel = true;
			removeSel = false;
			this.onApplicationChange(oEvent.getParameter("listItem").getAggregation("cells")[0].getText(), oEvent.getParameter("selected"));
		},
		onListApplChangeRemove: function (oEvent) {
			addSel = true;
			removeSel = false;
			this.onApplicationChangeRemove(oEvent.getParameter("listItem").getAggregation("cells")[0].getText(), oEvent.getParameter("selected"));
		},

		onSubApplChange: function (oEvent) {
			var selPath = oEvent.getSource().getBindingInfo("selected")["binding"].getContext().getPath();
			var subApplName = this.getOwnerComponent().getModel("SubApplicationModel").getProperty(selPath).SubApplication
			this.onSubApplicationChange(subApplName, oEvent.getParameter("selected"), "ALCONBI");
		},
		onSubApplChangeRemove: function (oEvent) {
			var selPath = oEvent.getSource().getBindingInfo("selected")["binding"].getContext().getPath();
			var subApplName = this.getOwnerComponent().getModel("SubApplicationRemoveModel").getProperty(selPath).SubApplication
			this.onSubApplicationChangeRemove(subApplName, oEvent.getParameter("selected"), "ALCONBI");
		},

		onUamRoleChange: function (oEvent) {
			var selPath = oEvent.getSource().getBindingInfo("selected")["binding"].getContext().getPath();
			var uamRoleName = this.getOwnerComponent().getModel("UamRoleModel").getProperty(selPath).UamRole;
			this.onBusRoleChange(selPath, oEvent.getParameter("selected"), "ALCONBI");
		},
		onUamRoleChangeRemove: function (oEvent) {
			var selPath = oEvent.getSource().getBindingInfo("selected")["binding"].getContext().getPath();
			var uamRoleName = this.getOwnerComponent().getModel("UamRoleRemoveModel").getProperty(selPath).UamRole;
			this.onBusRoleChangeRemove(selPath, oEvent.getParameter("selected"), "ALCONBI");
		},

		onUamRoleChangeForRetraction: function (oEvent) {
			var selPath = oEvent.getSource().getBindingInfo("selected")["binding"].getContext().getPath();
			var uamRoleName = this.getOwnerComponent().getModel("UamRoleModel").getProperty(selPath).UamRole;
			this.onBusRoleChange(selPath, oEvent.getParameter("selected"), "ALCONBI", "Retraction");
		},
		onUamRoleChangeRemoveForRetraction: function (oEvent) {
			var selPath = oEvent.getSource().getBindingInfo("selected")["binding"].getContext().getPath();
			var uamRoleName = this.getOwnerComponent().getModel("UamRoleRemoveModel").getProperty(selPath).UamRole;
			this.onBusRoleChangeRemove(selPath, oEvent.getParameter("selected"), "ALCONBI", "Retraction");
		},

		onUamRoleChangeForCCP: function (oEvent) {
			var selPath = oEvent.getSource().getBindingInfo("selected")["binding"].getContext().getPath();
			var uamRoleName = this.getOwnerComponent().getModel("UamRoleModel").getProperty(selPath).UamRole;
			this.onBusRoleChange(selPath, oEvent.getParameter("selected"), "ALCONBI", "CCP");
		},
		onUamRoleChangeRemoveForCCP: function (oEvent) {
			var selPath = oEvent.getSource().getBindingInfo("selected")["binding"].getContext().getPath();
			var uamRoleName = this.getOwnerComponent().getModel("UamRoleRemoveModel").getProperty(selPath).UamRole;
			this.onBusRoleChangeRemove(selPath, oEvent.getParameter("selected"), "ALCONBI", "CCP");
		},

		onChange521Id: function (User_ID) {
			var getDetailsrv = this.getOwnerComponent().getModel("ZAL_CREATE_REQUEST_SRV_01");
			var that = this;
			var selUser = User_ID;

			sap.ui.getCore().getModel("createReqModel").setProperty("/user_id", selUser);
			var oFilter = new Array();
			var usrFilter = new Filter("User_ID", FilterOperator.EQ, selUser);
			oFilter.push(usrFilter);

			var omod = this.getView().getModel("List521Model");
			this.getView().setModel(omod, "List521Model");

			getDetailsrv.read("/User_DetailsSet(User_ID='" + selUser + "')", {

				success: function (oData) {
					that.getOwnerComponent().getModel("OtherUserModel1").setData(oData);
					sap.ui.getCore().getModel("createReqModel").setProperty("/line_manager_name", oData.Line_Manager);
					sap.ui.getCore().getModel("createReqModel").setProperty("/line_manager_id", oData.Line_Manager_ID);
				},
				error: function (oError) {
					var errorMsg = that.errorMsgParse(oError);
					MessageBox.error(errorMsg);
					busyDialog.close();
				}
			});

			var usr_name = this.getOwnerComponent().getModel("OtherUserModel1").getProperty("/Name");
			this.byId("managerfield").setVisible(true);
			this.byId("managerfieldval").setVisible(true);
			this.byId("idOtherDet").setVisible(true);
		},

		toOpenHierarchy: function (oEvent) {
			uamSelPath = oEvent.getSource().getParent()["oPropagatedProperties"]["oBindingContexts"]["UamRoleModel"].getPath();
			var rowValue = this.getOwnerComponent().getModel("UamRoleModel").getProperty(uamSelPath);
			var sysId = this.getView().byId("cbSystem").getSelectedKey();
			var appId = this.getOwnerComponent().applId;
			var deptId = this.getView().byId("cbDepartment").getSelectedKey();
			var segId = this.getView().byId("cbSegregation").getSelectedKey();
			var appl = rowValue.Id.split("~")[0];;
			var subAppl = rowValue.Id.split("~")[1];
			var role = rowValue.Id.split("~")[2];
			var flag = oEvent.getSource().getProperty("text"); //the value can be Cost Center or Profit Center
			if (flag === "Company Code") {
				var src = (oEvent.getSource().getProperty("text") === "Company Code") ? "COMPANYCODE" : "PROFITCENTER";
			} else {
				var src = (oEvent.getSource().getProperty("text") === "Cost Center") ? "COSTCENTER" : "PROFITCENTER";
			}
			this.getHierarchy(sysId, appId, deptId, segId, appl, subAppl, role, flag, uamSelPath, src);
		},
		toOpenHierarchyRemove: function (oEvent) {
			uamSelPath = oEvent.getSource().getParent()["oPropagatedProperties"]["oBindingContexts"]["UamRoleRemoveModel"].getPath();
			var rowValue = this.getOwnerComponent().getModel("UamRoleRemoveModel").getProperty(uamSelPath);
			var sysId = this.getView().byId("cbSystem").getSelectedKey();
			var appId = this.getOwnerComponent().applId;
			var deptId = this.getView().byId("cbDepartment").getSelectedKey();
			var segId = this.getView().byId("cbSegregation").getSelectedKey();
			var appl = rowValue.Id.split("~")[0];;
			var subAppl = rowValue.Id.split("~")[1];
			var role = rowValue.Id.split("~")[2];
			var flag = oEvent.getSource().getProperty("text"); //the value can be Cost Center or Profit Center
			if (flag === "Company Code") {
				var src = (oEvent.getSource().getProperty("text") === "Company Code") ? "COMPANYCODE" : "PROFITCENTER";
			} else {
				var src = (oEvent.getSource().getProperty("text") === "Cost Center") ? "COSTCENTER" : "PROFITCENTER";
			}
			this.getHierarchy(sysId, appId, deptId, segId, appl, subAppl, role, flag, uamSelPath, src);
		},

		onChangeCostType: function (oEvent) {
			let key = oEvent.getSource().mProperties.selectedKey;
			if (key !== "ws" && key !== "cs") {
				this.byId("sfCostSearchType").setSelectedKey("ws");
			}
		},
		onChangeProfitType: function (oEvent) {
			let key = oEvent.getSource().mProperties.selectedKey;
			if (key !== "ws" && key !== "cs") {
				this.byId("sfProfitSearchType").setSelectedKey("ws");
			}
		},
		onChangeCompanyType: function (oEvent) {
			let key = oEvent.getSource().mProperties.selectedKey;
			if (key !== "ws" && key !== "cs") {
				this.byId("sfCompanySearchType").setSelectedKey("ws");
			}
		},
		onSearchCost: function (oEvent) {
			const val = oEvent.getParameter("query").trim();
			var filter;
			let type = sap.ui.getCore().byId("sfCostSearchType").getSelectedKey();

			if (type === "ws") {
				filter = new Filter({
					filters: [
						new Filter("ID", FilterOperator.Contains, val),
						new Filter("TXT", FilterOperator.Contains, val),
					],
					and: false,
				});
			} else if (type === "cs") {
				filter = new Filter({
					filters: [
						new Filter("ID", FilterOperator.EQ, val),
						new Filter("TXT", FilterOperator.EQ, val),
					],
					and: false,
				});
			}

			sap.ui.getCore().byId("treeHierCostCenter").getBinding("rows").filter(val ? filter : null);

			sap.ui.getCore().byId("treeHierCostCenter").expandToLevel(val ? 13 : 1);
		},
		onSearchCompany: function (oEvent) {
			const val = oEvent.getParameter("query").trim();
			var filter;
			let type = sap.ui.getCore().byId("sfCompanySearchType").getSelectedKey();

			if (type === "ws") {
				filter = new Filter({
					filters: [
						new Filter("ID", FilterOperator.Contains, val),
						new Filter("TXT", FilterOperator.Contains, val),
					],
					and: false,
				});
			} else if (type === "cs") {
				filter = new Filter({
					filters: [
						new Filter("ID", FilterOperator.EQ, val),
						new Filter("TXT", FilterOperator.EQ, val),
					],
					and: false,
				});
			}

			sap.ui.getCore().byId("treeHierCompanyCode").getBinding("rows").filter(val ? filter : null);
			sap.ui.getCore().byId("treeHierCompanyCode").expandToLevel(val ? 13 : 0);
		},
		onSearchProfit: function (oEvent) {
			const val = oEvent.getParameter("query").trim();
			var filter;
			let type = sap.ui.getCore().byId("sfProfitSearchType").getSelectedKey();

			if (type === "ws") {
				filter = new Filter({
					filters: [
						new Filter("ID", FilterOperator.Contains, val),
						new Filter("TXT", FilterOperator.Contains, val),
					],
					and: false,
				});
			} else if (type === "cs") {
				filter = new Filter({
					filters: [
						new Filter("ID", FilterOperator.EQ, val),
						new Filter("TXT", FilterOperator.EQ, val),
					],
					and: false,
				});
			}

			sap.ui.getCore().byId("treeHierProfitCenter").getBinding("rows").filter(val ? filter : null);
			sap.ui.getCore().byId("treeHierProfitCenter").expandToLevel(val ? 13 : 0);
		},

		onNextStep: function (oEvent) {
			var that = this;
			var busApplName = "ALCONBI";

			if (oEvent.getParameters()["index"] === 2) {

				var sysId = this.getView().byId("cbSystem").getSelectedKey();
				var appId = this.getOwnerComponent().applId;
				var sDate = this.getView().byId("DP1").getValue();
				var eDate = this.getView().byId("DP2").getValue();
				var startDate = new Date(sDate.split("-")[2], sDate.split("-")[1], sDate.split("-")[0]);
				var endDate = new Date(eDate.split("-")[2], eDate.split("-")[1], eDate.split("-")[0]);
				if (this.byId("cbRTForOther").getSelected() && this.byId("in521Id").getValue() === "") {
					this.getView().byId("in521Id").setValueState("Error");
					return;
				}
				if ((sysId !== "" && appId != "") && (sDate !== "" && eDate !== "") && (this.isValidDate(startDate) && this.isValidDate(endDate)) &&
					(startDate <= endDate)) {
					this.getDepartSeg(sysId, appId, busApplName);
				} else {
					if (sysId == "") {
						this.getView().byId("cbSystem").setValueState("Error");
					}

					if (sDate == "" || !(this.isValidDate(startDate))) {
						this.getView().byId("DP1").setValueState("Error");
					}
					if (eDate == "" || !(this.isValidDate(endDate))) {
						this.getView().byId("DP2").setValueState("Error");
					}
					if (startDate > endDate) {
						this.getView().byId("DP2").setValueState("Error");
					}
					this.getView().byId('UserRoleAccessWizard').previousStep();
				}
			} else if (oEvent.getParameters()["index"] === 3) {
				this.byId("taReason").setValue("");
				var sysId = this.getView().byId("cbSystem").getSelectedKey();
				var appId = this.getOwnerComponent().applId;
				var deptId = this.getView().byId("cbDepartment").getSelectedKey();
				var segId = this.getView().byId("cbSegregation").getSelectedKey();
				var requestedUser = (this.byId("cbRTForSelf").getSelected()) ? this.getOwnerComponent().getModel("LogInUserModel").getData().User_ID :
					this
					.byId("in521Id").getValue();
				if (((sysId != "" && appId != "") && (deptId != "" && segId != ""))) {
					sap.ui.getCore().getModel("createReqModel").setProperty("/job_title", deptId);
					sap.ui.getCore().getModel("createReqModel").setProperty("/segr_level", segId);
					this.clearApplicationModelData();
					if (this.getApplSubApplList(sysId, appId, deptId, segId, "", busApplName, requestedUser) === "error") {
						this.getView().byId('UserRoleAccessWizard').previousStep();
					}

				} else {
					if (sysId == "") {
						this.getView().byId("cbSystem").setValueState("Error");
					}

					if (deptId == "") {
						this.getView().byId("cbDepartment").setValueState("Error");
					}
					if (segId == "") {
						this.getView().byId("cbSegregation").setValueState("Error");
					}
					this.getView().byId('UserRoleAccessWizard').previousStep();
				}
			}
		},
		userListDialog: function (oEvent) {
			var id = oEvent.mParameters.id;
			var check = id.includes("521");
			this.exemptUser = "";

			this._oValueHelpDialog = sap.ui.xmlfragment("id3", "com.alcon.UAM.view.fragments.ValueHelpUser", this);
			this.getView().addDependent(this._oValueHelpDialog);
			if (check) {
				sap.ui.getCore().getModel("flagModel").setProperty("/flag", "true");
				this._oValueHelpDialog.setTitle("Search User");
				this.exemptUser = this.getOwnerComponent().getModel("LogInUserModel").getData().User_ID;
			} else {
				sap.ui.getCore().getModel("flagModel").setProperty("/flag", "false");
				this._oValueHelpDialog.setTitle("Search Line Manager");
				this.exemptUser = this.byId("in521Id").getValue();
			}

			this._oValueHelpDialog.open();
		},

		onValueHelpOkPress: function (oEvent) {
			if (sap.ui.getCore().byId("id3--tblUserList").getSelectedItem() == null) {
				MessageBox.error("Please select One User");
			} else {
				var id521 = sap.ui.getCore().byId("id3--tblUserList").getSelectedItem().mAggregations.cells[0].getText();
				var first = sap.ui.getCore().byId("id3--tblUserList").getSelectedItem().mAggregations.cells[1].getText()
				var last = sap.ui.getCore().byId("id3--tblUserList").getSelectedItem().mAggregations.cells[2].getText()
				var full = first + ' ' + last;
				var check = sap.ui.getCore().getModel("flagModel").getProperty("/flag");
				if (check == "true") {
					if (this.byId("in521Id").getVisible()) {
						this.byId("in521Id").setValue(id521);
						this.onChange521Id(id521);
					} else if (this.byId("in521MgrNameId").getVisible()) {
						this.byId("in521MgrNameId").setValue(full);
						this.byId("in521MgrId").setValue(id521);
						sap.ui.getCore().getModel("createReqModel").setProperty("/line_manager_name", full);
						sap.ui.getCore().getModel("createReqModel").setProperty("/line_manager_id", id521);
					}
				} else {
					this.byId("managerfieldval").setValue(full);
					sap.ui.getCore().getModel("createReqModel").setProperty("/line_manager_name", full);
					sap.ui.getCore().getModel("createReqModel").setProperty("/line_manager_id", id521);

				}
				if (check == "true") {
					console.log(this.byId("otherDept").getText());
				}
				this._oValueHelpDialog.close();
				this._oValueHelpDialog.destroy();

			}
		},

		onValueHelpCancelPress: function () {
			this._oValueHelpDialog.close();
			this._oValueHelpDialog.destroy();
		},

		onUserSearch: function () {
			var getDetailsrv = this.getOwnerComponent().getModel("ZAL_CREATE_REQUEST_SRV_01");
			var that = this;

			var oFilter = [];
			if (sap.ui.getCore().byId("id3--in521").getValue() !== "" || sap.ui.getCore().byId("id3--inFirstName").getValue() !== "" || sap.ui.getCore()
				.byId(
					"id3--inLastName").getValue() !== "") {
				busyDialog.open();
				busyDialog.setText("Fetching");
				oFilter.push(new Filter("ID_521", FilterOperator.EQ, sap.ui.getCore().byId("id3--in521").getValue()));
				oFilter.push(new Filter("Firstname", FilterOperator.EQ, sap.ui.getCore().byId("id3--inFirstName").getValue()));
				oFilter.push(new Filter("Lastname", FilterOperator.EQ, sap.ui.getCore().byId("id3--inLastName").getValue()));
			} else {
				MessageToast.show("Please enter a value in any of the fields to search user");
				return;
			}
			var list521Id = new JSONModel();
			getDetailsrv.read("/User_ListSet", {
				filters: oFilter,
				success: function (oData) {
					//this loop is to exempt some user details that the user is not supposed to select
					for (let m in oData.results) {
						if (oData.results[m].ID_521 === that.exemptUser) {
							oData.results.splice(m, 1);
						}
					}

					list521Id.setData(oData);
					that.getView().setModel(list521Id, "List521Model");
					sap.ui.getCore().byId("id3--tblUserList").setVisible(true);
					busyDialog.close();
				},
				error: function (oError) {
					var errorMsg = that.errorMsgParse(oError);
					MessageBox.error(errorMsg);
					busyDialog.close();
				}
			});
		},

		onItemSelectionProfit1: function (oEvent) {
			var oModel = this.getOwnerComponent().getModel("HierProfitModel");
			var selPath = oEvent.getSource().getBindingInfo("selected")["binding"].getContext().getPath();
			var data = {};
			var tempArray = [];
			hierSelProfitArray = this.getOwnerComponent().getModel("UamRoleModel").getProperty(uamSelPath)["profit"];

			//if condition to add the selected items to an array
			if (oEvent.getParameter("selected")) {
				for (var i in hierField) {
					data[hierField[i]] = oModel.getProperty(selPath)[hierField[i]];
				}
				data["selectedPath"] = selPath;
				hierSelProfitArray.push(data);
			}
			//else condition to remove the unselected items from an array
			else {
				for (let m in hierSelProfitArray) {
					if (hierSelProfitArray[m].selectedPath === selPath) {
						hierSelProfitArray.splice(m, 1);
					}
				}
			}
			for (let n in hierSelProfitArray) {
				tempArray.push({
					"ID": hierSelProfitArray[n]["ID"],
					"TXT": hierSelProfitArray[n]["TXT"]
				});
			}
			selProfitModel.setData(tempArray);
			sap.ui.getCore().byId("tblSelValueProfit").setModel(selProfitModel, "selProfitModel");
			sap.ui.getCore().byId("tblSelValueProfit").getModel("selProfitModel").refresh(true);
			this.getOwnerComponent().getModel("UamRoleModel").getProperty(uamSelPath)["profit"] = hierSelProfitArray;
		},
		/*********************   For Company Code                   */
		onItemSelectionCompany: function (oEvent) {
			var oModel = this.getOwnerComponent().getModel("HierCompanyModel");
			var selPath = oEvent.getSource().getBindingInfo("selected")["binding"].getContext().getPath();
			var data = {};
			var tempArray = [];

			hierSelCompanyArray = this.getOwnerComponent().getModel("UamRoleModel").getProperty(uamSelPath)["company"];

			//if condition to add the selected items to an array
			if (oEvent.getParameter("selected")) {
				for (var i in hierField) {
					data[hierField[i]] = oModel.getProperty(selPath)[hierField[i]];
				}
				data["selectedPath"] = selPath;
				hierSelCompanyArray.push(data);
			}
			//else condition to remove the unselected items from an array
			else {
				for (let m in hierSelCompanyArray) {
					if (hierSelCompanyArray[m].selectedPath === selPath) {
						hierSelCompanyArray.splice(m, 1);
					}
				}
			}
			for (let n in hierSelCompanyArray) {
				tempArray.push({
					"ID": hierSelCompanyArray[n]["ID"],
					"TXT": hierSelCompanyArray[n]["TXT"]
				});
			}
			selCompanyModel.setData(tempArray);
			sap.ui.getCore().byId("tblSelValueCompany").setModel(selCompanyModel, "selCompanyModel");
			sap.ui.getCore().byId("tblSelValueCompany").getModel("selCompanyModel").refresh(true);
			this.getOwnerComponent().getModel("UamRoleModel").getProperty(uamSelPath)["company"] = hierSelCompanyArray;
		},

		/**  End of Company Code     **/
		onItemSelectionCost1: function (oEvent) {
			var oModel = this.getOwnerComponent().getModel("HierCostModel");
			var selPath = oEvent.getSource().getBindingInfo("selected")["binding"].getContext().getPath();
			var data = {};
			//	var text = "";
			var tempArray = [];
			hierSelCostArray = this.getOwnerComponent().getModel("UamRoleModel").getProperty(uamSelPath)["cost"];

			//if condition to add the selected items to an array
			if (oEvent.getParameter("selected")) {
				for (var i in hierField) {
					data[hierField[i]] = oModel.getProperty(selPath)[hierField[i]];
				}
				data["selectedPath"] = selPath;
				hierSelCostArray.push(data);
			}
			//else condition to remove the unselected items from an array
			else {
				for (let m in hierSelCostArray) {
					if (hierSelCostArray[m].selectedPath === selPath) {
						hierSelCostArray.splice(m, 1);
					}
				}
			}
			for (let n in hierSelCostArray) {
				tempArray.push({
					"ID": hierSelCostArray[n]["ID"],
					"TXT": hierSelCostArray[n]["TXT"]
				});
			}
			selCostModel.setData(tempArray);
			sap.ui.getCore().byId("tblSelValueCost").setModel(selCostModel, "selCostModel");
			sap.ui.getCore().byId("tblSelValueCost").getModel("selCostModel").refresh(true);
			this.getOwnerComponent().getModel("UamRoleModel").getProperty(uamSelPath)["cost"] = hierSelCostArray;
		},

		onHierClose: function () {

			this._oDialog.close();
		},

		onChangeSystem: function () {
			var getDetailsrv = this.getOwnerComponent().getModel("ZAL_CREATE_REQUEST_SRV_01");
			var currentStep = this.getView().byId("UserRoleAccessWizard").mAssociations.currentStep;
			if (currentStep.includes("departmentSelection")) {
				this.getView().byId('UserRoleAccessWizard').previousStep();
			}
			if (currentStep.includes("roleSelection")) {
				this.getView().byId('UserRoleAccessWizard').previousStep();
				this.getView().byId('UserRoleAccessWizard').previousStep();
			}

			this.byId("cbDepartment").setSelectedKey("");

			this.byId("cbSegregation").setSelectedKey("");
			this.byId("cbDepartment").setValue("");

			this.byId("cbSegregation").setValue("");
			this.byId("cbSegregation").setEnabled(false);

		},
		onHierCancelPress: function () {
			this._oDialog.close();
		},

		getHierarchy: function (sysId, appId, deptId, segId, appl, subAppl, role, flag, uamSelPath, src) {
			var that = this;
			var uamModel;
			var key = this.byId("itbAlconRole").getSelectedKey();
			if (key === "addRole") {
				uamModel = this.getOwnerComponent().getModel("UamRoleModel");
			} else if (key === "removeRole") {
				uamModel = this.getOwnerComponent().getModel("UamRoleRemoveModel");
			}
			var profitArray = [],
				costArray = [],
				companyArray = [];
			hierSelProfitArray = []; //make this global array empty
			hierSelCostArray = []; //make this global array empty
			hierSelCompanyArray = []; //make this global array empty
			var getDetailsrv = this.getOwnerComponent().getModel("Z8C_UAM_ALCON_BI_SRV");
			busyDialog.open();
			busyDialog.setText("Loading");
			var oFilter = [];
			this.getOwnerComponent().getModel("HierCostModel").setData({});
			this.getOwnerComponent().getModel("HierProfitModel").setData({});
			this.getOwnerComponent().getModel("HierCompanyModel").setData({});
			oFilter.push(new Filter("System_ID", FilterOperator.EQ, sysId));
			oFilter.push(new Filter("Department_Role", FilterOperator.EQ, deptId));
			oFilter.push(new Filter("Segregation", FilterOperator.EQ, segId));
			oFilter.push(new Filter("Application", FilterOperator.EQ, appl));
			oFilter.push(new Filter("Subapplication", FilterOperator.EQ, subAppl));
			oFilter.push(new Filter("UAM_Role", FilterOperator.EQ, role));
			oFilter.push(new Filter("EMflag", FilterOperator.EQ, src));
			getDetailsrv.read("/HierarchySet", {
				filters: [oFilter],
				success: function (oData) {
					var dataCost = [],
						dataProfit = [],
						dataCompany = [];
					var val = {
						"NODEID": oData.results[0].PARENTID,
						"PARENTID": null
					};
					if (src === "COSTCENTER") {
						var costArrayTemp = [];
						for (let item of oData.results) {
							item.selected = false;
							item.editable = true;

							if (item.Default_Node) {
								item.selected = true;
								item.editable = false;
								item.selectedPath = "";
								costArrayTemp.push(item);
							}
						}

						dataCost = oData.results;
						dataCost.unshift(val);
						var dataCostMod1 = JSON.parse(JSON.stringify(dataCost));
						that.getOwnerComponent().getModel("HierCostModel").setData(that.createTreeStructCost(dataCostMod1));

						if (uamModel.getProperty(uamSelPath)["cost"].length > 0) {
							for (let item of uamModel.getProperty(uamSelPath)["cost"]) {
								if (item.selectedPath !== "") {
									that.getOwnerComponent().getModel("HierCostModel").getProperty(item.selectedPath)
										.selected = true
									costArray.push(item);
								}

							}
						}

					} else if (src === "PROFITCENTER") {
						var profitArrayTemp = [];
						for (let item of oData.results) {
							item.selected = false;
							item.editable = true;

							if (item.Default_Node) {
								item.selected = true;
								item.editable = false;
								item.selectedPath = "";
								profitArrayTemp.push(item);
							}
						}

						dataProfit = oData.results;
						dataProfit.unshift(val);
						var dataEntityMod1 = JSON.parse(JSON.stringify(dataProfit));
						that.getOwnerComponent().getModel("HierProfitModel").setData(that.createTreeStructProfit(dataEntityMod1));

						if (uamModel.getProperty(uamSelPath)["profit"].length > 0) {
							for (let item of uamModel.getProperty(uamSelPath)["profit"]) {
								if (item.selectedPath !== "") {
									that.getOwnerComponent().getModel("HierProfitModel").getProperty(item.selectedPath)
										.selected = true

									profitArray.push(item);
								}

							}
						}

					} else if (src === "COMPANYCODE") {
						var companyArrayTemp = [];
						for (let item of oData.results) {
							item.selected = false;
							item.editable = true;

							if (item.Default_Node) {
								item.selected = false;
								item.editable = true;
								item.selectedPath = "";
								companyArrayTemp.push(item);
							}
						}

						dataCompany = oData.results;
						var oModel = new sap.ui.model.json.JSONModel(dataCompany);
						that.getOwnerComponent().setModel(oModel, "HierCompanyModel");

						if (uamModel.getProperty(uamSelPath)["company"].length > 0) {
							for (let item of uamModel.getProperty(uamSelPath)["company"]) {
								if (item.selectedPath !== "") {
									that.getOwnerComponent().getModel("HierCompanyModel").getProperty(item.selectedPath)
										.selected = true

									companyArray.push(item);
								}

							}
						}

					}

					var oView = that.getView();

					if (!that._oDialog) {
						Fragment.load({
							name: "com.alcon.UAM.view.fragments.AlconBIHierarchy",
							controller: that
						}).then(function (oDialog) {
							that._oDialog = oDialog;
							that._oDialog.addStyleClass(this.getContentDensityClass())
							that.getView().addDependent(that._oDialog);
							that._oDialog.setModel({});
							sap.ui.getCore().byId("hierVerticallay3").setVisible(false);
							sap.ui.getCore().byId("hierVerticallay4").setVisible(false);
							sap.ui.getCore().byId("sfCostSearch").setValue("");
							sap.ui.getCore().byId("sfProfitSearch").setValue("");
							if (dataCost.length > 1) {

								that._oDialog.setModel(that.getOwnerComponent().getModel("HierCostModel"));
								sap.ui.getCore().byId("hierVerticallay3").setVisible(true);
								selCostModel.setData(costArrayTemp.concat(costArray));

								uamModel.getProperty(uamSelPath)["cost"] = costArrayTemp.concat(costArray);

								sap.ui.getCore().byId("tblSelValueCost").setModel(selCostModel, "selCostModel");
								sap.ui.getCore().byId("tblSelValueCost").getModel("selCostModel").refresh(true);
								if (uamModel.getProperty(uamSelPath)["cost"].length === 0) {
									sap.ui.getCore().byId("treeHierCostCenter").expandToLevel(0);
								}

							}
							if (dataProfit.length > 1) {

								that._oDialog.setModel(that.getOwnerComponent().getModel("HierProfitModel"));
								sap.ui.getCore().byId("hierVerticallay4").setVisible(true);
								selProfitModel.setData(profitArrayTemp.concat(profitArray));
								uamModel.getProperty(uamSelPath)["profit"] = profitArrayTemp.concat(profitArray);
								sap.ui.getCore().byId("tblSelValueProfit").setModel(selProfitModel, "selProfitModel");
								sap.ui.getCore().byId("tblSelValueProfit").getModel("selProfitModel").refresh(true);
								if (uamModel.getProperty(uamSelPath)["profit"].length === 0) {
									sap.ui.getCore().byId("treeHierProfitCenter").expandToLevel(0);
								}

							}
							if (dataCompany.length > 1) {

								that._oDialog.setModel(that.getOwnerComponent().getModel("HierCompanyModel"));
								sap.ui.getCore().byId("hierVerticallay5").setVisible(true);
								sap.ui.getCore().byId("tblSelValueCompany").setModel(selCompanyModel, "selCompanyModel");
								sap.ui.getCore().byId("tblSelValueCompany").getModel("selCompanyModel").refresh(true);
							}
							that._oDialog.open();
						}.bind(that));
					} else {
						that._oDialog.setModel({});
						that._oDialog.setModel(that.getOwnerComponent().getModel("HierCostModel"));
						that._oDialog.setModel(that.getOwnerComponent().getModel("HierProfitModel"));
						that._oDialog.setModel(that.getOwnerComponent().getModel("HierCompanyModel"));
						that.getView().addDependent(that._oDialog);
						sap.ui.getCore().byId("hierVerticallay3").setVisible(false);
						sap.ui.getCore().byId("hierVerticallay4").setVisible(false);
						sap.ui.getCore().byId("hierVerticallay5").setVisible(false);
						sap.ui.getCore().byId("sfCostSearch").setValue("");
						sap.ui.getCore().byId("sfProfitSearch").setValue("");
						sap.ui.getCore().byId("sfCompanySearch").setValue("");
						if (dataCost.length > 1) {
							sap.ui.getCore().byId("hierVerticallay3").setVisible(true);
							sap.ui.getCore().byId("treeHierCostCenter").setVisible(true);
							selCostModel.setData(costArrayTemp.concat(costArray));

							uamModel.getProperty(uamSelPath)["cost"] = costArrayTemp.concat(costArray);
							sap.ui.getCore().byId("tblSelValueCost").setModel(selCostModel, "selCostModel");
							sap.ui.getCore().byId("tblSelValueCost").getModel("selCostModel").refresh(true);
							if (uamModel.getProperty(uamSelPath)["cost"].length === 0) {
								sap.ui.getCore().byId("treeHierCostCenter").expandToLevel(0);
							}
						}
						if (dataProfit.length > 1) {
							sap.ui.getCore().byId("hierVerticallay4").setVisible(true);
							sap.ui.getCore().byId("treeHierProfitCenter").setVisible(true);
							selProfitModel.setData(profitArrayTemp.concat(profitArray));
							uamModel.getProperty(uamSelPath)["profit"] = profitArrayTemp.concat(profitArray);
							sap.ui.getCore().byId("tblSelValueProfit").setModel(selProfitModel, "selProfitModel");
							sap.ui.getCore().byId("tblSelValueProfit").getModel("selProfitModel").refresh(true);
							if (uamModel.getProperty(uamSelPath)["profit"].length === 0) {
								sap.ui.getCore().byId("treeHierProfitCenter").expandToLevel(0);
							}
						}
						if (dataCompany.length > 1) {
							sap.ui.getCore().byId("hierVerticallay5").setVisible(true);
							sap.ui.getCore().byId("treeHierCompanyCode").setVisible(true);
							sap.ui.getCore().byId("tblSelValueCompany").setModel(selCompanyModel, "selCompanyModel");
							sap.ui.getCore().byId("tblSelValueCompany").getModel("selCompanyModel").refresh(true);
						}
						that._oDialog.open();
					}
					busyDialog.close();
				},
				error: function (oError) {
					var errorMsg = that.errorMsgParse(oError);
					MessageBox.error(errorMsg);
					busyDialog.close();
				}
			});
		},
		createTreeStructProfit: function (data) {
			const idMapping = data.reduce((acc, el, i) => {
				acc[el.NODEID] = i;
				return acc;
			}, {});
			let modData;
			data.forEach(el => {
				// Handle the root element
				if (el.PARENTID === null) {
					modData = el;
					return;
				}
				// Use our mapping to locate the parent element in our data array
				const parentEl = data[idMapping[el.PARENTID]];
				// Add our current el to its parent's `children` array
				parentEl.children = [...(parentEl.children || []), el];
			});
			return modData;
		},
		createTreeStructCost: function (data) {
			const idMapping1 = data.reduce((acc, el, i) => {
				acc[el.NODEID] = i;
				return acc;
			}, {});
			let modData1;
			data.forEach(el => {
				// Handle the root element
				if (el.PARENTID === null) {
					modData1 = el;
					return;
				}
				// Use our mapping to locate the parent element in our data array
				const parentEl1 = data[idMapping1[el.PARENTID]];
				// Add our current el to its parent's `children` array
				parentEl1.children = [...(parentEl1.children || []), el];
			});
			return modData1;
		},

		toSubmit: function () {
			var key = this.byId("itbAlconRole").getSelectedKey();
			var applsubData = "";

			var requestedUser = (this.byId("cbRTForSelf").getSelected()) ? this.getOwnerComponent().getModel("LogInUserModel").getData().User_ID :
				this
				.byId("in521Id").getValue();

			var hierVal = sap.ui.getCore().getModel("createReqModel").getProperty("/hier");
			if (key === "addRole") {
				applsubData = this.getOwnerComponent().getModel("UamRoleModel").getData();
			} else if (key === "removeRole") {
				applsubData = this.getOwnerComponent().getModel("UamRoleRemoveModel").getData();
			}

			var headerAppl = [];
			for (var j in hierVal) {
				hierVal[j].User_ID = requestedUser;
			}

			for (var k in applsubData) {
				var data = {
					"User_ID": requestedUser,
					"System_ID": this.byId("cbSystem").getSelectedKey(),
					"Department_Role": this.byId("cbDepartment").getSelectedKey(),
					"Segregation": this.byId("cbSegregation").getSelectedKey(),
					"Application": applsubData[k].ApplSubAppl.split("~")[0],
					"Subapplication": applsubData[k].ApplSubAppl.split("~")[1],
					"UAM_Role": applsubData[k].UamRole
				}
				headerAppl.push(data);
			}
			var dateFrom = this.byId("DP1").getValue().split("-");
			var dateTo = this.byId("DP2").getValue().split("-");
			var type = (this.byId("itbAlconRole").getSelectedKey() === "addRole") ? "NEW" : "REMOVE";

			var payload = {
				"User_ID": requestedUser,
				"Line_Manager": (this.byId("cbRTForSelf").getSelected()) ? this.byId("in521MgrId").getValue() : sap
					.ui.getCore().getModel("createReqModel").getProperty("/line_manager_id"),
				"request_type": type,
				"Division": this.getOwnerComponent().getModel("LogInUserModel").getData().Division,
				"DATE_FROM": dateFrom[2] + dateFrom[1] + dateFrom[0],
				"DATE_TO": dateTo[2] + dateTo[1] + dateTo[0],
				"Appl_ID": "004",
				"System_ID": this.byId("cbSystem").getSelectedKey(),
				"Creator_ID": this.getOwnerComponent().getModel("LogInUserModel").getData().User_ID,
				"Reason": this.byId("taReason").getValue(),
				"Nav_Header_To_Appl": headerAppl,
				"Nav_Header_To_Hier": hierVal,
				"Nav_Header_To_Ret": [{}]
			};

			var that = this;

			var getDetailsrv = this.getOwnerComponent().getModel("Z8C_UAM_ALCON_BI_SRV");
			busyDialog.open();
			busyDialog.setText("Loading");
			getDetailsrv.create("/User_DetailsSet", payload, {
				success: function (oData) {
					busyDialog.close();
					that.showMessage(oData);
				},
				error: function (Error) {
					var errorMsg = that.errorMsgParse(Error);
					MessageBox.error(errorMsg);
					busyDialog.close();
				}
			});
		},
		showMessage: function (oData) {
			var data = oData.Nav_Header_To_Ret.results[0];
			MessageBox[(data.MsgType === "S") ? "success" : "error"](data.MsgText, {
				actions: [MessageBox.Action.CLOSE],
				onClose: function (oAction) {
					this.closeAction();
				}.bind(this)
			});
		},
		closeAction: function () {
			this.clearModelData();
			this._oWizardReviewPage.destroy();
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("RouteMain");
		},
		backToWizardContent: function () {
			this._oWizardReviewPage.destroy();

		},
		clearModelData: function () {
			this.resetCreateReqModel();
			this.onForSelfSelect("");
			this.dateSetter();

			this.getOwnerComponent().getModel("OtherUserModel1").setData({});
			this.getOwnerComponent().getModel("DepartmentModel").setData({});
			this.getOwnerComponent().getModel("SegregationModel").setData({});
			this.clearApplicationModelData();
		},

		clearApplicationModelData: function () {
			this.byId("liApplication").removeSelections();
			this.byId("liSubApplication").removeSelections();
			this.byId("liBusRole").removeSelections();
			this.byId("liHierRemove").removeSelections();
			this.byId("liApplicationRemove").removeSelections();
			this.byId("liSubApplicationRemove").removeSelections();
			this.byId("liBusRoleRemove").removeSelections();
			this.getOwnerComponent().getModel("ApplicationModel1").setData({});
			this.getOwnerComponent().getModel("SubApplicationModel").setData({});
			this.getOwnerComponent().getModel("UamRoleModel").setData({});
			this.getOwnerComponent().getModel("HierCostModel").setData({});
			this.getOwnerComponent().getModel("HierProfitModel").setData({});
			this.getOwnerComponent().getModel("HierButtonModel").setData({});
			this.getOwnerComponent().getModel("ApplicationModel1").refresh(true);
			this.getOwnerComponent().getModel("SubApplicationModel").refresh(true);
			this.getOwnerComponent().getModel("UamRoleModel").refresh(true);
			this.getOwnerComponent().getModel("HierCostModel").refresh(true);
			this.getOwnerComponent().getModel("HierProfitModel").refresh(true);
			this.getOwnerComponent().getModel("HierButtonModel").refresh(true);
			this.getOwnerComponent().getModel("HiearchyRemoveModel").setData({});

			this.getOwnerComponent().getModel("ApplicationModel2").setData({});
			this.getOwnerComponent().getModel("SubApplicationRemoveModel").setData({});
			this.getOwnerComponent().getModel("UamRoleRemoveModel").setData({});
			this.getOwnerComponent().getModel("ApplicationModel2").refresh(true);
			this.getOwnerComponent().getModel("SubApplicationRemoveModel").refresh(true);
			this.getOwnerComponent().getModel("UamRoleRemoveModel").refresh(true);
			this.getOwnerComponent().getModel("HiearchyRemoveModel").refresh(true);

		},
		onExit: function () {
			if (this._oWizardReviewPage) {
				this._oWizardReviewPage.destroy();
			}
		},

		onSelectRoleSection: function (oEvent) {
			var key = oEvent.getParameter("key");
			if ((key === "removeRole" && this.byId("liApplication").getSelectedItems().length !== 0) ||
				(key === "addRole" && this.byId("liApplicationRemove").getSelectedItems().length !== 0)) {
				removeSel = true;
				if (key === "addRole" && removeSel) {
					this.byId("itbAlconRole").setSelectedKey("removeRole");
					MessageBox.warning("Your changes in Remove Role section will be removed, if you click on Yes", {
						actions: [MessageBox.Action.YES, MessageBox.Action.NO],
						onClose: function (oAction) {
							if (oAction === MessageBox.Action.YES) {
								this.byId("itbAlconRole").setSelectedKey("addRole");
								this.byId("liApplicationRemove").removeSelections();
								this.getOwnerComponent().getModel("SubApplicationRemoveModel").setData({});
								this.getOwnerComponent().getModel("UamRoleRemoveModel").setData({});
								this.getOwnerComponent().getModel("HiearchyRemoveModel").setData({});
							} else if (oAction === MessageBox.Action.NO) {
								return;
							}
						}.bind(this)
					});
				} else if (key === "removeRole") {
					this.byId("itbAlconRole").setSelectedKey("addRole");
					if (this.getOwnerComponent().getModel("ApplicationModel2").getData().length === 0) {
						MessageToast.show("No role is assigned to the selected user");
						return;
					} else if (addSel) {
						MessageBox.warning("Your changes in Add Role will be removed, if you click on Yes", {
							actions: [MessageBox.Action.YES, MessageBox.Action.NO],
							onClose: function (oAction) {

								if (oAction === MessageBox.Action.YES) {
									this.byId("itbAlconRole").setSelectedKey("removeRole");
									this.byId("liApplication").removeSelections();
									this.getOwnerComponent().getModel("SubApplicationModel").setData({});
									this.getOwnerComponent().getModel("UamRoleModel").setData({});

								} else if (oAction === MessageBox.Action.NO) {
									return;
								}
							}.bind(this)
						});
					} else {
						this.byId("itbAlconRole").setSelectedKey("removeRole");
					}
				}
			}
		}

	});

});