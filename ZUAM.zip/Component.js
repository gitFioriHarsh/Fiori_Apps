sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"sap/ui/model/json/JSONModel",
	"com/alcon/UAM/model/models"
], function (UIComponent, Device, JSONModel, models) {
	"use strict";

	return UIComponent.extend("com.alcon.UAM.Component", {

		metadata: {
			manifest: "json"
		},

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
		init: function () {
			// call the base component's init function
			UIComponent.prototype.init.apply(this, arguments);

			// enable routing
			this.getRouter().initialize();
		
			//jQuery.sap.includeStyleSheet("css/style.css"); 
			
			jQuery.sap.includeStyleSheet("/sap/bc/ui5_ui5/sap/zuam/css/style.css");
			var sRootPath = jQuery.sap.getModulePath("zuam");
			var location= $(location).attr('href'); 

			// set the device model
			this.setModel(models.createDeviceModel(), "device");
			this.setModel(new JSONModel(),"LogInUserModel");
			this.setModel(new JSONModel(), "ApplicationModel");
			this.setModel(new JSONModel(), "SystemModel");
			this.setModel(new JSONModel(), "DepartmentModel");
			this.setModel(new JSONModel(), "SegregationModel");
			this.setModel(new JSONModel(), "ConsolidationModel");
			this.setModel(new JSONModel(), "ApplicationModel1");  ///this is to show the values in Add role section
			this.setModel(new JSONModel(), "SubApplicationModel");
			this.setModel(new JSONModel(), "UamRoleModel");
			this.setModel(new JSONModel(), "ApplicationModel2");   // this is to show the values in Remove role section
			this.setModel(new JSONModel(), "SubApplicationRemoveModel");
			this.setModel(new JSONModel(), "UamRoleRemoveModel");
			this.setModel(new JSONModel(), "HierEntityModel");
			this.setModel(new JSONModel(), "HierMarketModel");
			this.setModel(new JSONModel(), "HierCostModel");
			this.setModel(new JSONModel(), "HierProfitModel");
			this.setModel(new JSONModel(), "HierButtonModel");
			this.setModel(new JSONModel(), "HierCompanyModel");
			this.setModel(new JSONModel(), "HierWorkdayMarketModel");  //Workday Adaptive Market Model
		    this.setModel(new JSONModel(), "HierWorkdayCostModel");  //Workday Adaptive cost Center Model
			this.setModel(new JSONModel(), "DateModel");
			this.setModel(new JSONModel(), "OtherUserModel1");
				this.setModel(new JSONModel(), "SearchTypeModel");  
					this.setModel(new JSONModel(), "HiearchyRemoveModel");
		}
	});
});