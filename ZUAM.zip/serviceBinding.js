function initModel() {
	var sUrl = "/sap/opu/odata/sap/Z8CZ_WORKDAY_ADAPTIVE_SRV/";
	var oModel = new sap.ui.model.odata.ODataModel(sUrl, true);
	sap.ui.getCore().setModel(oModel);
}