sap.ui.define([
	"com/alcon/UAM/test/unit/controller/Main.controller"
], function () {
	"use strict";
});