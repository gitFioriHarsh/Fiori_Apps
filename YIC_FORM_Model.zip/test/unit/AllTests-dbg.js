sap.ui.define([
	"com/spe/YIC_FORM/test/unit/controller/HomeToolPage.controller"
], function () {
	"use strict";
});