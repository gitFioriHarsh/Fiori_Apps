sap.ui.define([], function () {
	"use strict";
	return {
		createDate: function (datechange) {
			var year = datechange.slice(0, 4);
				var mm = datechange.slice(4, 6);
				var dd = datechange.slice(6, 8);
				var append = year + "/" + mm + "/" + dd;
				var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
					pattern: "MM/dd/yyyy"
				});
				var datab = dateFormat.format(new Date(append));
				return datab;
		}
	};
});