sap.ui.define([
	"./BaseController"
], function (BaseController) {
	"use strict";

	return BaseController.extend("com.spe.YIC_FORM.controller.HomeToolPage", {
		onInit: function () {
			this.Router = sap.ui.core.UIComponent.getRouterFor(this);
		},
		onItemSelect: function (oEvent) {
			var oItem = oEvent.getParameter("item");
			this.byId("pageContainer").to(this.getView().createId(oItem.getKey()));

		},
		onPressNavListItem: function (oEvent) {

			var sAction = oEvent.getSource().getProperty("text");
			switch (sAction) {
			case "Create / Extend IC Relationship":
				this.Router.navTo("CreateIC");
				break;
			case "Home":
				this.Router.navTo("HomeToolPage");
				break;
			case "Change IC Relationship":
				this.Router.navTo("ChangeIC");
				break;
			case "Search IC Relationship Form":
				this.Router.navTo("SearchIC");
				break;
			case "FAQs":
				this.Router.navTo("FAQ");
				break;
			}

		}
	});
});