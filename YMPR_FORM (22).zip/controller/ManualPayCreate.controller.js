sap.ui.define([
	"./BaseController",
	'jquery.sap.global',
	"sap/ui/model/json/JSONModel",
	'sap/ui/core/Fragment',
	"sap/m/MessageToast",
	"sap/m/MessageBox",
	"sap/ui/core/routing/History",
	"sap/ui/model/Sorter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/FilterType",
	"sap/ui/core/format/DateFormat",
	"../model/formatter"
], function (BaseController, jQuery, JSONModel, Fragment, MessageToast, MessageBox, History, Sorter, Filter,
	FilterOperator, FilterType, DateFormat, formatter) {
	"use strict";
	var index_counter = 0;
	var e_form_num = "";
	var copy_case;
	var Title;
	var img_type;
	var dataset = [];
	var flagCurrency;
	var num;
	var clicks = 1;
	return BaseController.extend("com.spe.ManualPayReq.YMPR_FORM.controller.ManualPayCreate", {
		formatter: formatter,
		onInit: function (oEvent) {
			var me = this;
			var that = this;
			this.form_number = "";
			var style = "sapUiSizeCompact";
			me.getView().addStyleClass(style);
			this.oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this.oRouter.attachRouteMatched(this._onObjectMatched, this);
			me.getModel().setData({
				InitialuserinfoSet: {
					items: []
				},
				CompanyCodeSet: {
					items: []
				},
				Title: {
					items: []
				},
				VendorID: {
					items: []
				},
				Currency: {
					items: []
				},
				Reason: {
					items: []
				},
				DisplayEmployee: {
					items: []
				},
				summaryTable: {
					items: []
				},
				ApproverTable: {
					items: []
				},
				Determine: {
					items: []
				}
			});
			var oModel = new JSONModel({
				busy: false,
				lineItemData: [],
				BarAndTable: false,
				SearchButtonVisible: true,
				FooterButton: false
			});
			this.getView().setModel(oModel, "settingsModel");

			var commentModel = new JSONModel();
			this.getView().setModel(commentModel, "commentModel");
			var EnableModel = new JSONModel();
			this.getView().setModel(EnableModel, "EnableModel");

			this.getView().getModel("EnableModel").setProperty("/enabledVendorID", false);
			var cal = this.getView().byId("idReqdate");
			cal.addDelegate({
				onAfterRendering: function () {
					cal.$().find('INPUT').attr('disabled', true).css('color', 'Black');
				}
			}, cal);

			window.addEventListener("paste", function (e) {
				return new Promise(function (resolve, reject) {
					if (e.clipboardData && e.clipboardData.items) {
						var aItems = [];
						aItems = e.clipboardData.items;
						var bImageFound = false;
						for (var i = 0; i < aItems.length; i++) {
							// Skip content if not image
							if (aItems[i].type.indexOf("image") == -1) {
								continue;
							}
							bImageFound = true;
							// Retrieve image on clipboard as blob
							var oBlob = aItems[i].getAsFile();
							img_type = aItems[i].getAsFile().type;
							var name = oBlob.name;
							var oReader = new FileReader();
							oReader.readAsDataURL(oBlob);
							oReader.onloadend = function () {
								var sBase64data = oReader.result;
								resolve(sBase64data);
							};
						}
						if (!bImageFound) {
							reject("noImageInClipboard");
						}
					} else {
						reject("noItemFound");
					}
				}).then(function (sBase64data) {
					if (e.target['id'].split('-').reverse()[1] === "idDocPay") {
						that.getView().byId("b_upload").setVisible(true);
						that.getView().byId("Label1").setVisible(false);
						that.getView().byId("Label2").setVisible(true);
						that.getView().byId("ss1").setVisible(true);
						that.getView().byId("idDocPay").setVisible(false);
						that.getView().byId("ss").setVisible(true);
						that.getView().byId("ss").setSrc(sBase64data);
						that.getView().byId("ss1").setSrc(sBase64data);
						that.getView().byId("i_fileUploader").setVisible(false);
						that.getView().getModel("EnableModel").setProperty("/enabledResetButton", true);
						var image = that.getView().byId('ss').getSrc().replace("data:" + img_type + ";base64,", "");
						var image_type = img_type;
						dataset.push({
							EFORM_NUM: that.form_number,
							IMAGE_ID: "1",
							IMAGE_TYPE: image_type,
							IMG_CONTENT: image
						});
					}
					if (e.target['id'].split('-').reverse()[1] === "idBenInfo") {
						that.getView().byId("b_upload1").setVisible(true);
						that.getView().byId("label3").setVisible(false);
						that.getView().byId("label4").setVisible(true);
						that.getView().byId("idimage1Summary").setVisible(true);
						that.getView().byId("idBenInfo").setVisible(false);
						that.getView().byId("idimage1").setVisible(true);
						that.getView().byId("idimage1").setSrc(sBase64data);
						that.getView().byId("idimage1Summary").setSrc(sBase64data);
						that.getView().byId("idBInuploader").setVisible(false);
						that.getView().getModel("EnableModel").setProperty("/enabledResetButton", true);
						var image = that.getView().byId('idimage1').getSrc().replace("data:" + img_type + ";base64,", "");
						var image_type = img_type;
						dataset.push({
							EFORM_NUM: that.form_number,
							IMAGE_ID: "2",
							IMAGE_TYPE: image_type,
							IMG_CONTENT: image
						});
					}
					if (e.target['id'].split('-').reverse()[1] === "idBankingInfo") {
						that.getView().byId("b_upload2").setVisible(true);
						that.getView().byId("label5").setVisible(false);
						that.getView().byId("label6").setVisible(true);
						that.getView().byId("idimage2summary").setVisible(true);
						that.getView().byId("idBankingInfo").setVisible(false);
						that.getView().byId("idimage2").setVisible(true);
						that.getView().byId("idimage2").setSrc(sBase64data);
						that.getView().byId("idimage2summary").setSrc(sBase64data);
						that.getView().byId("idBankInfoUploader").setVisible(false);
						that.getView().getModel("EnableModel").setProperty("/enabledResetButton", true);
						var image = that.getView().byId('idimage2').getSrc().replace("data:" + img_type + ";base64,", "");
						var image_type = img_type;
						dataset.push({
							EFORM_NUM: that.form_number,
							IMAGE_ID: "3",
							IMAGE_TYPE: image_type,
							IMG_CONTENT: image
						});
					}
					if (e.target['id'].split('-').reverse()[1] === "idInvoiceInfo") {
						that.getView().byId("b_upload3").setVisible(true);
						that.getView().byId("label7").setVisible(false);
						that.getView().byId("label8").setVisible(true);
						that.getView().byId("idimage2summary").setVisible(true);
						that.getView().byId("idInvoiceInfo").setVisible(false);
						that.getView().byId("idimage3").setVisible(true);
						that.getView().byId("idimage3").setSrc(sBase64data);
						that.getView().byId("idimage3summary").setSrc(sBase64data);
						that.getView().byId("idInInformUploader").setVisible(false);
						that.getView().getModel("EnableModel").setProperty("/enabledResetButton", true);
						var image = that.getView().byId('idimage3').getSrc().replace("data:" + img_type + ";base64,", "");
						var image_type = img_type;
						dataset.push({
							EFORM_NUM: that.form_number,
							IMAGE_ID: "4",
							IMAGE_TYPE: image_type,
							IMG_CONTENT: image
						});
					}
					if (e.target['id'].split('-').reverse()[1] === "idInvoicePO") {
						that.getView().byId("b_upload4").setVisible(true);
						that.getView().byId("label9").setVisible(false);
						that.getView().byId("label10").setVisible(true);
						that.getView().byId("idInvoicePO").setVisible(false);
						that.getView().byId("idimage4").setVisible(true);
						that.getView().byId("idimage4").setSrc(sBase64data);
						that.getView().byId("idimage4summary").setSrc(sBase64data);
						that.getView().byId("idInvoicePOUploader").setVisible(false);
						that.getView().getModel("EnableModel").setProperty("/enabledResetButton", true);
						var image = that.getView().byId('idimage4').getSrc().replace("data:" + img_type + ";base64,", "");
						var image_type = img_type;
						dataset.push({
							EFORM_NUM: that.form_number,
							IMAGE_ID: "5",
							IMAGE_TYPE: image_type,
							IMG_CONTENT: image
						});
					}
					if (e.target['id'].split('-').reverse()[1] === "idComInfo") {
						that.getView().byId("b_upload5").setVisible(true);
						that.getView().byId("label11").setVisible(false);
						that.getView().byId("label12").setVisible(true);
						that.getView().byId("idComInfo").setVisible(false);
						that.getView().byId("idimage5").setVisible(true);
						that.getView().byId("idimage5").setSrc(sBase64data);
						that.getView().byId("idimage5summary").setSrc(sBase64data);
						that.getView().byId("idCommuformUploader").setVisible(false);
						that.getView().getModel("EnableModel").setProperty("/enabledResetButton", true);
						var image = that.getView().byId('idimage5').getSrc().replace("data:" + img_type + ";base64,", "");
						var image_type = img_type;
						dataset.push({
							EFORM_NUM: that.form_number,
							IMAGE_ID: "6",
							IMAGE_TYPE: image_type,
							IMG_CONTENT: image
						});
					}
				}, false);
			});
		},
		getInitialuserinfoSet: function (selectedUser) {
			var me = this;
			if (selectedUser === undefined || selectedUser === "null" || selectedUser === "") {
				var UserID = sap.ushell.Container.getService("UserInfo").getUser().getId();
			} else {
				UserID = selectedUser;
			}
			var oModel = me.getModel("Mprsrvmodel");
			oModel.read("/InitialuserinfoSet('" + UserID + "')", {
				method: "GET",
				success: function (oData, response) {
					me.getModel().setProperty("/InitialuserinfoSet/items", oData);
					Title = "Manual Payment Request";
					me.getModel().setProperty("/Title/items", Title);
					me.getView().byId("idTextPreparer").setText(oData.FULLNAME);
					me.getView().byId("idTextPreparer1").setText(oData.FULLNAME);
					me.getView().byId("idinputTitle").setValue(Title);
				}.bind(this),
				error: function (response) {
					MessageBox.error(response.responseText);
				}.bind(this)
			});
		},
		_onObjectMatched: function (oEvent) {
			var me = this;
			var that = this;
			e_form_num = "";
			this.form_number = "";
			copy_case = "";
			var userModel = me.getModel("Mprsrvmodel");
			userModel.refreshSecurityToken();
			var csrf = userModel.getSecurityToken();
			me.getView().getModel("settingsModel").setProperty("/csrf", csrf);
			var contextName = oEvent.getParameters().arguments.context;
			var eform_dsp = oEvent.getParameters().arguments.context;
			var back = oEvent.getParameter("name");
			if (back !== "default") {
				me.getModel().setData({
					InitialuserinfoSet: {
						items: []
					},
					CompanyCodeSet: {
						items: []
					},
					Title: {
						items: []
					},
					VendorID: {
						items: []
					},
					Currency: {
						items: []
					},
					Reason: {
						items: []
					},
					DisplayEmployee: {
						items: []
					},
					summaryTable: {
						items: []
					},
					ApproverTable: {
						items: []
					},
					Determine: {
						items: []
					}
				});
				var oModel = new JSONModel({
					busy: false,
					lineItemData: [],
					BarAndTable: false,
					SearchButtonVisible: true,
					FooterButton: false
				});
				this.getView().setModel(oModel, "settingsModel");
				var commentModel = new JSONModel();
				this.getView().setModel(commentModel, "commentModel");
				var EnableModel = new JSONModel();
				this.getView().setModel(EnableModel, "EnableModel");
				this.getView().getModel("EnableModel").setProperty("/enabledVendorID", false);
			}
			var cal = this.getView().byId("idReqdate");
			cal.addDelegate({
				onAfterRendering: function () {
					cal.$().find('INPUT').attr('disabled', true).css('color', 'Black');
				}
			}, cal);
			$.sap.eform_dsp = eform_dsp;
			if (eform_dsp !== undefined && back !== "default") {
				if (eform_dsp.toLowerCase().indexOf("copy") > -1) {
					// Copy scenario
					var array = eform_dsp.split('#');
					eform_dsp = array[0];
					e_form_num = eform_dsp;
					copy_case = "X";
				} else {
					// Display scenario
					copy_case = "";
					e_form_num = eform_dsp;
				}
			}
			if (back === "default") {
				dataset = [];
				e_form_num = "";
				this.form_number = "";
				copy_case = "";
				contextName = "";
				this.form_number = "";
				img_type = "";
				that.getModel().setProperty("/InitialuserinfoSet/items", []);
				that.getModel().setProperty("/CompanyCodeSet/items", []);
				that.getModel().setProperty("/Title/items", []);
				that.getModel().setProperty("/VendorID/items", []);
				that.getModel().setProperty("/Currency/items", []);
				that.getModel().setProperty("/Reason/items", []);
				that.getModel().setProperty("/DisplayEmployee/items", []);
				that.getModel().setProperty("/summaryTable/items", []);
				that.getModel().setProperty("/ApproverTable/items", []);
				that.getModel().setProperty("/Determine/items", []);
			}
			if (copy_case === "X" && back !== "default") {
				this.form_number = "";
				dataset = [];
				that.getView().byId("pagetitle").setText('Manual Payment Request Form');
				that.getView().getModel("EnableModel").setProperty("/Getcontxt", false);
				that.getView().getModel("EnableModel").setProperty("/enabled", true);
				that.getView().getModel("EnableModel").setProperty("/enabledVendorID", false);
				that.getView().getModel("EnableModel").setProperty("/enabledTextAreaImage", true);
				that.getView().getModel("EnableModel").setProperty("/enabledResetButton", false);
				that.getView().getModel("EnableModel").setProperty("/enabledupload", true);
				that.getView().getModel("EnableModel").setProperty("/enabledAttachment", true);
				that.getView().getModel("EnableModel").setProperty("/enabledComment", true);
				that.getView().byId("ss").setSrc("");
				that.getView().byId("ss1").setSrc("");
				that.getView().byId("idimage1").setSrc("");
				that.getView().byId("idimage1Summary").setSrc("");
				that.getView().byId("idimage2").setSrc("");
				that.getView().byId("idimage2summary").setSrc("");
				that.getView().byId("idimage3").setSrc("");
				that.getView().byId("idimage3summary").setSrc("");
				that.getView().byId("idimage4").setSrc("");
				that.getView().byId("idimage4summary").setSrc("");
				that.getView().byId("idimage5").setSrc("");
				that.getView().byId("idimage5summary").setSrc("");
				that.getView().byId("submit_button").setVisible(false);
				that.getView().byId("b_approve").setVisible(false);
				that.getView().byId("b_reject").setVisible(false);

				that.getView().byId("Label2").setVisible(false);
				that.getView().byId("idDocPay").setVisible(true);
				that.getView().byId("i_fileUploader").setVisible(true);
				that.getView().byId("ss").setVisible(false);
				that.getView().byId("b_upload").setVisible(false);

				that.getView().byId("idBenInfo").setVisible(true);
				that.getView().byId("idBInuploader").setVisible(true);
				that.getView().byId("idimage1").setVisible(false);
				that.getView().byId("b_upload1").setVisible(false);

				that.getView().byId("idBankingInfo").setVisible(true);
				that.getView().byId("idBankInfoUploader").setVisible(true);
				that.getView().byId("idimage2").setVisible(false);
				that.getView().byId("b_upload2").setVisible(false);

				that.getView().byId("idInvoiceInfo").setVisible(true);
				that.getView().byId("idInInformUploader").setVisible(true);
				that.getView().byId("idimage3").setVisible(false);
				that.getView().byId("b_upload3").setVisible(false);

				that.getView().byId("idInvoicePO").setVisible(true);
				that.getView().byId("idInvoicePOUploader").setVisible(true);
				that.getView().byId("idimage4").setVisible(false);
				that.getView().byId("b_upload4").setVisible(false);

				that.getView().byId("idComInfo").setVisible(true);
				that.getView().byId("idCommuformUploader").setVisible(true);
				that.getView().byId("idimage5").setVisible(false);
				that.getView().byId("b_upload5").setVisible(false);

				that.getView().byId("t_attachment1").destroyItems();
				that.getView().byId("t_attachment11").destroyItems();
				that.getView().byId("idinputTotalAmount").setEditable(true);
				this.setCopyData(e_form_num);
			}
			if (contextName === undefined && back !== "default" && copy_case !== "X") {
				that.getView().byId("pagetitle").setText('Manual Payment Request Form');
				this.form_number = "";
				dataset = [];
				that.getView().getModel("EnableModel").setProperty("/Getcontxt", false);
				that.getView().getModel("EnableModel").setProperty("/enabled", true);
				that.getView().getModel("EnableModel").setProperty("/enabledVendorID", false);
				that.getView().getModel("EnableModel").setProperty("/enabledTextAreaImage", true);
				that.getView().getModel("EnableModel").setProperty("/enabledResetButton", true);
				that.getView().getModel("EnableModel").setProperty("/enabledupload", true);
				that.getView().getModel("EnableModel").setProperty("/enabledAttachment", true);
				that.getView().getModel("EnableModel").setProperty("/enabledComment", true);
				that.getView().byId("idinputTotalAmount").setEditable(false);
				that.getView().byId("submit_button").setVisible(false);
				that.getView().byId("b_approve").setVisible(false);
				that.getView().byId("b_reject").setVisible(false);
				that.getView().byId("b_delete").setVisible(true);
				that.getView().byId("b_edit").setVisible(true);

				that.getView().byId("Label2").setVisible(false);
				that.getView().byId("idDocPay").setVisible(true);
				that.getView().byId("i_fileUploader").setVisible(true);
				that.getView().byId("ss").setVisible(false);

				that.getView().byId("idBenInfo").setVisible(true);
				that.getView().byId("idBInuploader").setVisible(true);
				that.getView().byId("idimage1").setVisible(false);

				that.getView().byId("idBankingInfo").setVisible(true);
				that.getView().byId("idBankInfoUploader").setVisible(true);
				that.getView().byId("idimage2").setVisible(false);

				that.getView().byId("idInvoiceInfo").setVisible(true);
				that.getView().byId("idInInformUploader").setVisible(true);
				that.getView().byId("idimage3").setVisible(false);

				that.getView().byId("idInvoicePO").setVisible(true);
				that.getView().byId("idInvoicePOUploader").setVisible(true);
				that.getView().byId("idimage4").setVisible(false);

				that.getView().byId("idComInfo").setVisible(true);
				that.getView().byId("idCommuformUploader").setVisible(true);
				that.getView().byId("idimage5").setVisible(false);

				that.getView().byId("t_attachment1").destroyItems();
				that.getView().byId("t_attachment11").destroyItems();
				that.getInitialuserinfoSet();
			}
			if (contextName !== undefined && back !== "default" && copy_case !== "X") {
				this.form_number = contextName;
				dataset = [];
				that.getView().getModel("EnableModel").setProperty("/Getcontxt", true);
				that.getView().getModel("EnableModel").setProperty("/enabled", false);
				that.getView().getModel("EnableModel").setProperty("/enabledVendorID", false);
				that.getView().getModel("EnableModel").setProperty("/enabledTextAreaImage", false);
				that.getView().getModel("EnableModel").setProperty("/enabledResetButton", false);
				that.getComments(contextName);
				that.getattachments(contextName);
				that.getContextBackendData(contextName);
				that.GetDetermineapprlogin(contextName);
			}
		},
		getContextBackendData: function (contextName) {
			var me = this;
			sap.ui.core.BusyIndicator.show();
			var oModel = me.getModel("Mprsrvmodel");
			oModel.read("/HeaderdataSet('" + contextName + "')", {
				method: "GET",
				urlParameters: {
					"$expand": "ImageSet,ApproverSet"
				},
				success: function (oData, response) {
					sap.ui.core.BusyIndicator.hide();
					me.getView().getModel("settingsModel").setProperty("/lineItemData", oData);
					this.getView().byId("pagetitle").setText('Manual Payment Request Form' + '-' + oData.EFORM_NUM);
					me.setContextData(oData);
				}.bind(this),
				error: function (oData) {
					var strResponse = oData.responseText;
					var strErrorDetail = strResponse.substring(strResponse.indexOf("error"));
					var strStatusMsg = strErrorDetail.split(",")[2];
					var strFullStatus = strStatusMsg;
					var strStatus = strFullStatus.substring(strFullStatus.indexOf("message") + 10) + "";
					var strStatus1 = strStatus.slice(0, -2) + "";
					MessageBox.error(strStatus1);
				}.bind(this)
			});
		},

		setContextData: function (oData) {
			// Setting data for Title Detail Tabs
			var that = this;
			var ApprByDate = oData.REQUEST_DATE;
			var year = ApprByDate.slice(0, 4);
			var mm = ApprByDate.slice(4, 6);
			var dd = ApprByDate.slice(6, 8);
			var append = year + "/" + mm + "/" + dd;
			var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: "MM/dd/yyyy"
			});
			var ApproveByDate = dateFormat.format(new Date(append));
			that.getView().getModel("settingsModel").setProperty("/sStatus", oData.STATUS);
			that.getView().getModel("settingsModel").setProperty("/prepare", oData.PREPARER);
			that.getView().getModel("settingsModel").setProperty("/preparefn", oData.PREPARER_FN);
			that.getView().getModel("settingsModel").setProperty("/selectedCompCode", oData.DOC_CCODE);
			that.getView().getModel("settingsModel").setProperty("/CompDes", oData.DOC_CCODE_DES);
			that.getView().getModel("settingsModel").setProperty("/region", oData.REGION);
			that.getView().getModel("settingsModel").setProperty("/regionDes", oData.REGION_DES);
			that.getView().getModel("settingsModel").setProperty("/VendorLIFNR", oData.VENDOR);
			that.getView().getModel("settingsModel").setProperty("/VendorNAME1", oData.VENDOR_NAME);
			that.getView().getModel("settingsModel").setProperty("/Currency", oData.CURRENCY);
			that.getView().getModel("settingsModel").setProperty("/Amount", oData.AMOUNT);
			that.getView().getModel("settingsModel").setProperty("/selectedDate", oData.REQUEST_DATE);
			that.getView().getModel("settingsModel").setProperty("/selectedPayCompCode", oData.PAYER_CCODE);
			that.getView().getModel("settingsModel").setProperty("/PayerCompDes", oData.PAYER_CCODE_DES);
			that.getView().getModel("settingsModel").setProperty("/REASONID", oData.REASON);
			that.getView().getModel("settingsModel").setProperty("/DESCRIPTION", oData.REASON_DES);
			that.getView().getModel("settingsModel").setProperty("/saveStatuss", oData.STATUS);
			that.getView().byId("idinputTitle").setValue(oData.TITLE);
			that.getView().byId("idTextPreparer").setText(oData.PREPARER_FN);
			that.getView().byId("idinputPayerCompny").setValue(oData.PAYER_CCODE + '-' + oData.PAYER_CCODE_DES);
			that.getView().byId("idinputRegion").setValue(oData.REGION);
			that.getView().byId("idInputVendorID").setValue(oData.VENDOR);
			that.getView().byId("idinputVendorName").setValue(oData.VENDOR_NAME);
			that.getView().byId("idinputTotalAmount").setValue(oData.AMOUNT);
			that.getView().byId("idinputTotalAmount").setEditable(false);
			that.getView().byId("idCurrency").setValue(oData.CURRENCY);
			that.getView().byId("idReqdate").setValue(ApproveByDate);
			that.getView().byId("idinputDocCompny").setValue(oData.DOC_CCODE + '-' + oData.DOC_CCODE_DES);
			that.getView().byId("idReason").setValue(oData.REASON + '-' + oData.REASON_DES);
			that.getView().byId("text_Document").setValue(oData.DOCLINK);

			that.getView().byId("Label2").setVisible(true);
			that.getView().byId("idDocPay").setVisible(false);
			that.getView().byId("i_fileUploader").setVisible(false);
			that.getView().byId("ss").setVisible(true);

			that.getView().byId("idBenInfo").setVisible(false);
			that.getView().byId("idBInuploader").setVisible(false);
			that.getView().byId("idimage1").setVisible(true);

			that.getView().byId("idBankingInfo").setVisible(false);
			that.getView().byId("idBankInfoUploader").setVisible(false);
			that.getView().byId("idimage2").setVisible(true);

			that.getView().byId("idInvoiceInfo").setVisible(false);
			that.getView().byId("idInInformUploader").setVisible(false);
			that.getView().byId("idimage3").setVisible(true);

			that.getView().byId("idInvoicePO").setVisible(false);
			that.getView().byId("idInvoicePOUploader").setVisible(false);
			that.getView().byId("idimage4").setVisible(true);

			that.getView().byId("idComInfo").setVisible(false);
			that.getView().byId("idCommuformUploader").setVisible(false);
			that.getView().byId("idimage5").setVisible(true);
			dataset = oData.ImageSet.results;
			for (var i = 0; i < oData.ImageSet.results.length; i++) {
				var image_type = oData.ImageSet.results[i].IMAGE_TYPE;
				var image_sequence = oData.ImageSet.results[i].IMAGE_ID;
				if (image_type == "") {
					var b64 = "";
				} else {
					var b64 = "data:" + image_type + ";base64,";
					b64 = b64.concat(oData.ImageSet.results[i].IMG_CONTENT);
					if (image_sequence === "1") {
						that.getView().byId("ss").setSrc(b64);
						that.getView().byId("ss1").setSrc(b64);
					}
					if (image_sequence === "2") {
						that.getView().byId("idimage1").setSrc(b64);
						that.getView().byId("idimage1Summary").setSrc(b64);
					}
					if (image_sequence === "3") {
						that.getView().byId("idimage2").setSrc(b64);
						that.getView().byId("idimage2summary").setSrc(b64);
					}
					if (image_sequence === "4") {
						that.getView().byId("idimage3").setSrc(b64);
						that.getView().byId("idimage3summary").setSrc(b64);
					}
					if (image_sequence === "5") {
						that.getView().byId("idimage4").setSrc(b64);
						that.getView().byId("idimage4summary").setSrc(b64);
					}
					if (image_sequence === "6") {
						that.getView().byId("idimage5").setSrc(b64);
						that.getView().byId("idimage5summary").setSrc(b64);
					}
				}
			}

			// Setting data for Summary Tab
			that.getView().byId("idTextTitle").setText(oData.TITLE);
			that.getView().byId("idTextPreparer1").setText(oData.PREPARER_FN);
			that.getView().byId("idTextPaycomCode").setText(oData.PAYER_CCODE + '-' + oData.PAYER_CCODE_DES);
			that.getView().byId("idTextRegion").setText(oData.REGION);
			that.getView().byId("idTextVendorID").setText(oData.VENDOR);
			that.getView().byId("idTextVendorName").setText(oData.VENDOR_NAME);
			that.getView().byId("idTextAmount").setText(oData.AMOUNT);
			that.getView().byId("idTextCurrency").setText(oData.CURRENCY);
			that.getView().byId("idTextReqDate").setText(ApproveByDate);
			that.getView().byId("idTextDocComp").setText(oData.DOC_CCODE + '-' + oData.DOC_CCODE_DES);
			that.getView().byId("idTextReason").setText(oData.REASON + '-' + oData.REASON_DES);
			that.getView().byId("idTextDocLink").setText(oData.DOCLINK);

			//setting Approval list
			var approverlist = oData.ApproverSet.results;
			for (var j = 0; j < approverlist.length; j++) {
				var datechange = approverlist[j].CREATION_DT;
				var Apprdatechange = approverlist[j].APPROVED_DT;
				var ApprdTimechange = approverlist[j].APPROVED_TM;
				var year = datechange.slice(0, 4);
				var mm = datechange.slice(4, 6);
				var dd = datechange.slice(6, 8);
				var append = year + "/" + mm + "/" + dd;
				var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
					pattern: "MM/dd/yyyy"
				});
				var datab = dateFormat.format(new Date(append));
				var year1 = Apprdatechange.slice(0, 4);
				var mm1 = Apprdatechange.slice(4, 6);
				var dd1 = Apprdatechange.slice(6, 8);
				var append1 = year1 + "/" + mm1 + "/" + dd1;
				var dataAppr = dateFormat.format(new Date(append1));
				if (ApprdTimechange !== "") {
					var hrs = ApprdTimechange.slice(0, 2);
					var min = ApprdTimechange.slice(2, 4);
					var sec = ApprdTimechange.slice(4, 6);
					var hrsmin = hrs.concat(":" + min);
					var fulltime = hrsmin.concat(":" + sec);
					approverlist[j].APPROVED_TM = fulltime;
				}
				approverlist[j].CREATION_DT = datab;
				approverlist[j].APPROVED_DT = dataAppr;
				that.getModel().setProperty("/ApproverTable/items", []);
				that.getModel().setProperty("/ApproverTable/items", approverlist);
			}

			//Visibility for buttons
			if (oData.STATUS === "S") {
				that.getView().byId("b_delete").setVisible(true);
				that.getView().byId("b_edit").setVisible(true);
				that.getView().byId("submit_button").setVisible(true);
			}
			if (oData.STATUS === "I") {
				that.getView().byId("b_delete").setVisible(true);
				that.getView().byId("b_edit").setVisible(false);
				that.getView().byId("submit_button").setVisible(false);
			}
			if (oData.STATUS === "A" || oData.STATUS === "R") {
				that.getView().byId("b_delete").setVisible(false);
				that.getView().byId("b_edit").setVisible(false);
				that.getView().byId("submit_button").setVisible(false);
				that.getView().byId("apprtoolbarid").setVisible(false);
			}
			if (sap.ushell.Container.getService("UserInfo").getUser().getId() !== oData.PREPARER) {
				that.getView().byId("b_delete").setVisible(false);
				that.getView().byId("b_edit").setVisible(false);
				that.getView().byId("submit_button").setVisible(false);
			}
		},
		setCopyData: function (copyformnumber) {
			var me = this;
			sap.ui.core.BusyIndicator.show();
			var oModel = me.getModel("Mprsrvmodel");
			var that = this;
			oModel.read("/HeaderdataSet('" + copyformnumber + "')", {
				method: "GET",
				urlParameters: {
					"$expand": "ImageSet,ApproverSet"
				},
				success: function (oData, response) {
					that.form_number = "";
					var LoggedUserName = sap.ushell.Container.getUser().getFullName();
					var sCurrentUser = sap.ushell.Container.getUser().getId();
					var title = oData.TITLE;
					oData.EFORM_NUM = "";
					oData.PREPARER = sCurrentUser;
					oData.APPROVE_BY_DATE = "";
					oData.REQUEST_DATE = "";
					oData.PREPARER_FN = LoggedUserName;
					oData.FULLNAME = LoggedUserName;
					oData.CREATE_DATE = "";
					oData.APPROVED_DATE = "";
					oData.ImageSet.results = [];
					oData.ApproverSet.results = [];
					oData.DOCLINK = "";
					oData.TITLE = title.slice(0, -11);
					oData.STATUS = "S";
					sap.ui.core.BusyIndicator.hide();
					that.getView().getModel("settingsModel").setProperty("/sStatus", oData.STATUS);
					that.getView().getModel("settingsModel").setProperty("/prepare", oData.PREPARER);
					that.getView().getModel("settingsModel").setProperty("/preparefn", oData.PREPARER_FN);
					that.getView().getModel("settingsModel").setProperty("/selectedCompCode", oData.DOC_CCODE);
					that.getView().getModel("settingsModel").setProperty("/CompDes", oData.DOC_CCODE_DES);
					that.getView().getModel("settingsModel").setProperty("/region", oData.REGION);
					that.getView().getModel("settingsModel").setProperty("/regionDes", oData.REGION_DES);
					that.getView().getModel("settingsModel").setProperty("/VendorLIFNR", oData.VENDOR);
					that.getView().getModel("settingsModel").setProperty("/VendorNAME1", oData.VENDOR_NAME);
					that.getView().getModel("settingsModel").setProperty("/Currency", oData.CURRENCY);
					that.getView().getModel("settingsModel").setProperty("/selectedDate", oData.REQUEST_DATE);
					that.getView().getModel("settingsModel").setProperty("/selectedPayCompCode", oData.PAYER_CCODE);
					that.getView().getModel("settingsModel").setProperty("/PayerCompDes", oData.PAYER_CCODE_DES);
					that.getView().getModel("settingsModel").setProperty("/REASONID", oData.REASON);
					that.getView().getModel("settingsModel").setProperty("/DESCRIPTION", oData.REASON_DES);
					that.getView().getModel("settingsModel").setProperty("/saveStatuss", oData.STATUS);

					that.getView().byId("idinputTitle").setValue(oData.TITLE);
					that.getView().byId("idTextPreparer").setText(LoggedUserName);
					that.getView().byId("idinputPayerCompny").setValue(oData.PAYER_CCODE + '-' + oData.PAYER_CCODE_DES);
					that.getView().byId("idinputRegion").setValue(oData.REGION);
					that.getView().byId("idInputVendorID").setValue(oData.VENDOR);
					that.getView().byId("idinputVendorName").setValue(oData.VENDOR_NAME);
					that.getView().byId("idinputTotalAmount").setValue(oData.AMOUNT);
					that.getView().byId("idCurrency").setValue(oData.CURRENCY);
					that.getView().byId("idinputDocCompny").setValue(oData.DOC_CCODE + '-' + oData.DOC_CCODE_DES);
					that.getView().byId("idReason").setValue(oData.REASON + '-' + oData.REASON_DES);
					that.getView().byId("text_Document").setValue(oData.DOCLINK);
					that.getView().byId("idReqdate").setValue(oData.REQUEST_DATE);

					// Setting data for Summary Tab
					that.getView().byId("idTextTitle").setText(oData.TITLE);
					that.getView().byId("idTextPreparer1").setText(oData.PREPARER_FN);
					that.getView().byId("idTextPaycomCode").setText(oData.PAYER_CCODE + '-' + oData.PAYER_CCODE_DES);
					that.getView().byId("idTextRegion").setText(oData.REGION);
					that.getView().byId("idTextVendorID").setText(oData.VENDOR);
					that.getView().byId("idTextVendorName").setText(oData.VENDOR_NAME);
					that.getView().byId("idTextAmount").setText(oData.AMOUNT);
					that.getView().byId("idTextCurrency").setText(oData.CURRENCY);
					that.getView().byId("idTextReqDate").setText(oData.REQUEST_DATE);
					that.getView().byId("idTextDocComp").setText(oData.DOC_CCODE + '-' + oData.DOC_CCODE_DES);
					that.getView().byId("idTextReason").setText(oData.REASON + '-' + oData.REASON_DES);
					that.getView().byId("idTextDocLink").setText(oData.DOCLINK);
					that.getView().byId("b_delete").setVisible(false);
					that.getView().byId("b_edit").setVisible(false);

				}.bind(this),
				error: function (oData) {
					sap.ui.core.BusyIndicator.hide();
					var strResponse = oData.responseText;
					var strErrorDetail = strResponse.substring(strResponse.indexOf("error"));
					var strStatusMsg = strErrorDetail.split(",")[2];
					var strFullStatus = strStatusMsg;
					var strStatus = strFullStatus.substring(strFullStatus.indexOf("message") + 10) + "";
					var strStatus1 = strStatus.slice(0, -2) + "";
					MessageBox.error(strStatus1);
				}.bind(this)
			});
		},
		_onPressEditForm: function () {
			var that = this;
			var prepare = that.getView().byId("idTextPreparer").getText();
			var username = sap.ushell.Container.getUser().getFullName();
			if (prepare === username) {
				that.getView().getModel("EnableModel").setProperty("/enabled", true);
				that.getView().getModel("EnableModel").setProperty("/enabledupload", true);
				that.getView().getModel("EnableModel").setProperty("/enabledAttachment", true);
				that.getView().getModel("EnableModel").setProperty("/enabledComment", true);
				that.getView().getModel("EnableModel").setProperty("/enabledVendorID", true);
				that.getView().getModel("EnableModel").setProperty("/enabledResetButton", true);
				that.getView().byId("idinputTotalAmount").setEditable(true);
				that.getView().byId("submit_button").setVisible(true);
				that.getView().byId("b_upload").setVisible(true);
				that.getView().byId("b_upload1").setVisible(true);
				that.getView().byId("b_upload2").setVisible(true);
				that.getView().byId("b_upload3").setVisible(true);
				that.getView().byId("b_upload4").setVisible(true);
				that.getView().byId("b_upload5").setVisible(true);
			} else {
				that.getView().getModel("EnableModel").setProperty("/enabled", false);
				that.getView().getModel("EnableModel").setProperty("/enabledupload", true);
				that.getView().getModel("EnableModel").setProperty("/enabledAttachment", true);
				that.getView().getModel("EnableModel").setProperty("/enabledComment", true);
				that.getView().getModel("EnableModel").setProperty("/enabledVendorID", false);
				that.getView().getModel("EnableModel").setProperty("/enabledTextAreaImage", false);
				that.getView().getModel("EnableModel").setProperty("/enabledResetButton", false);
				that.getView().byId("b_upload").setVisible(false);
				that.getView().byId("b_upload1").setVisible(false);
				that.getView().byId("b_upload2").setVisible(false);
				that.getView().byId("b_upload3").setVisible(false);
				that.getView().byId("b_upload4").setVisible(false);
				that.getView().byId("b_upload5").setVisible(false);
				that.getView().byId("b_delete").setVisible(false);
				that.getView().byId("b_edit").setVisible(false);
				that.getView().byId("submit_button").setVisible(false);
				that.getView().byId("idinputTotalAmount").setEditable(false);
				MessageBox.alert("You are not authorized to edit this form");
			}
		},
		_onPressDeleteForm: function () {
			var that = this;
			var msg_returned = "";
			var prepare = that.getView().byId("idTextPreparer").getText();
			var username = sap.ushell.Container.getUser().getFullName();
			var status = this.getView().getModel("settingsModel").getProperty("/sStatus");
			if (status === "" || status === undefined || status === null) {
				status = "S";
			}
			if (prepare === username) {
				var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
				MessageBox.confirm(
					"Do you want to delete this form?", {
						actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
						styleClass: bCompact ? "sapUiSizeCompact" : "",
						onClose: function (sAction) {
							if (sAction === "OK") {
								var oModel = that.getModel("Mprsrvmodel");
								oModel.remove("/HeaderdataSet(EFORM_NUM='" + that.form_number + "')", {
									method: "DELETE",
									success: function (oData, response) {
										msg_returned = "The form has been deleted successfully";
										MessageBox.success(
											msg_returned, {
												actions: [MessageBox.Action.OK],
												styleClass: bCompact ? "sapUiSizeCompact" : "",
												onClose: function (sAction) {
													if (sAction === "OK") {
														that.oRouter.navTo("default", {
															from: "ManualPayCreate1"
														}, false);
													} else {
														return false;
													}
												}
											}
										);
									}.bind(this),
									error: function (response) {
										MessageBox.error(response.responseText);
									}.bind(this)
								});
							} else {
								return false;
							}
						}
					}
				);
			} else {
				MessageBox.alert("You are not authorized to delete this form");
			}
		},
		onValueHelpCompCode: function (oEvent) {
			var compcodeid = oEvent.getParameters().id.split('-').pop();
			this.getView().getModel("settingsModel").setProperty("/compcodeid", compcodeid);
			if (!this.CDialog) {
				this.CDialog = this.loadFragment({
					name: "com.spe.ManualPayReq.YMPR_FORM.fragments.CompanyCode"
				});
			}
			this.CDialog.then(function (oDialog) {
				this._oCCD = oDialog;
				oDialog.open();
			}.bind(this));
			this.getCompanycodeSet();
		},
		onCloseDialogCompCode: function () {
			this.getView().byId("idsearchCompCode").setValue(null);
			this._oCCD.close();
			var oFilter = new sap.ui.model.Filter("BUTXT", sap.ui.model.FilterOperator.Contains, "");
			var oFilter1 = new sap.ui.model.Filter("BUKRS", sap.ui.model.FilterOperator.Contains, "");
			var comFil = new sap.ui.model.Filter([oFilter, oFilter1]);
			var oList = this.getView().byId("idlistcomp");
			oList.getBinding("items").filter(comFil, sap.ui.model.FilterType.Application);
		},
		getCompanycodeSet: function () {
			var me = this;
			sap.ui.core.BusyIndicator.show();
			var oModel = me.getModel("Mprsrvmodel");
			oModel.read("/CompanycodeSet", {
				method: "GET",
				success: function (oData, response) {
					sap.ui.core.BusyIndicator.hide();
					me.getModel().setProperty("/CompanyCodeSet/items", oData.results);
				}.bind(this),
				error: function (response) {
					sap.ui.core.BusyIndicator.hide();
					MessageBox.error(response.responseText);
				}.bind(this)
			});
		},
		_handleItemPress: function (oEvent) {
			var compcodeid = "";
			compcodeid = this.getView().getModel("settingsModel").getProperty("/compcodeid");
			var status = this.getView().getModel("settingsModel").getProperty("/saveStatuss");
			var vendorid = this.getView().getModel("settingsModel").getProperty("/VendorLIFNR");
			var vendorname = this.getView().getModel("settingsModel").getProperty("/VendorNAME1");
			var requestDate = this.getView().byId("idReqdate").getValue();
			var selectedCompCode = oEvent.getSource().getProperty("title");
			var selectedCompCodeDes = oEvent.getSource().getAggregation("attributes");
			var CompDes = selectedCompCodeDes[0].getProperty('text');
			var region = selectedCompCodeDes[1].getProperty('text');
			var regionDes = selectedCompCodeDes[2].getProperty('text');
			var oFilter = new sap.ui.model.Filter("BUTXT", sap.ui.model.FilterOperator.Contains, "");
			var oFilter1 = new sap.ui.model.Filter("BUKRS", sap.ui.model.FilterOperator.Contains, "");
			var comFil = new sap.ui.model.Filter([oFilter, oFilter1]);
			var oList = this.getView().byId("idlistcomp");
			if (compcodeid === "idinputDocCompny") {
				flagCurrency = false;
				if (status === "S" && copy_case !== "X") {
					this.getView().byId("idinputTitle").setValue(null);
					Title = "Manual Payment Request";
					this.getModel().setProperty("/Title/items", Title);
					this.getModel().setProperty("/Title/items", Title + '-' + selectedCompCode);
					this.getView().byId("idinputTitle").setValue(Title + '-' + selectedCompCode + '-' + vendorid + '-' + vendorname + '-' +
						requestDate);
				}
				if (copy_case === "X") {
					this.getView().byId("idinputTitle").setValue(null);
					Title = "Manual Payment Request";
					this.getModel().setProperty("/Title/items", Title);
					this.getModel().setProperty("/Title/items", Title + '-' + selectedCompCode);
				} else {
					this.getModel().setProperty("/Title/items", Title + '-' + selectedCompCode);
					this.getView().byId("idinputTitle").setValue(Title + '-' + selectedCompCode);
				}
				this.getView().getModel("EnableModel").setProperty("/enabledVendorID", true);
				this.getView().getModel("settingsModel").setProperty("/selectedCompCode", selectedCompCode);
				this.getView().getModel("settingsModel").setProperty("/CompDes", CompDes);
				this.getView().getModel("settingsModel").setProperty("/region", region);
				this.getView().getModel("settingsModel").setProperty("/regionDes", regionDes);
				this.getView().byId("idinputDocCompny").setValue(selectedCompCode + '-' + CompDes);
				this.getView().byId("idTextDocComp").setText(selectedCompCode + '-' + CompDes);
				this.getView().byId("idinputRegion").setValue(regionDes);
				this.getView().byId("idTextRegion").setText(regionDes);
				this.getView().byId("idsearchCompCode").setValue(null);
				this.getView().getModel("settingsModel").setProperty("/VendorLIFNR", null);
				this.getView().getModel("settingsModel").setProperty("/VendorNAME1", null);
				this.getView().byId("idInputVendorID").setValue(null);
				this.getView().byId("idTextVendorID").setText(null);
				this.getView().byId("idinputVendorName").setValue(null);
				this.getView().byId("idTextVendorName").setText(null);
				oList.getBinding("items").filter(comFil, sap.ui.model.FilterType.Application);
			}
			if (compcodeid === "idinputPayerCompny") {
				this.getView().byId("idinputPayerCompny").setValue(selectedCompCode + '-' + CompDes);
				this.getView().byId("idTextPaycomCode").setText(selectedCompCode + '-' + CompDes);
				this.getView().getModel("settingsModel").setProperty("/compcodeid", null);
				this.getView().getModel("settingsModel").setProperty("/selectedPayCompCode", selectedCompCode);
				this.getView().getModel("settingsModel").setProperty("/PayerCompDes", CompDes);
				this.getView().byId("idsearchCompCode").setValue(null);
				oList.getBinding("items").filter(comFil, sap.ui.model.FilterType.Application);
			}
			this._oCCD.close();
		},
		onSearchComanyCode: function (oEvent) {
			if (oEvent !== undefined) {
				var query = oEvent.getParameter("value");
				var oFilter = new sap.ui.model.Filter("BUTXT", sap.ui.model.FilterOperator.Contains, query);
				var oFilter1 = new sap.ui.model.Filter("BUKRS", sap.ui.model.FilterOperator.Contains, query);
				var comFil = new sap.ui.model.Filter([oFilter, oFilter1]);
				var oList = this.getView().byId("idlistcomp");
				oList.getBinding("items").filter(comFil, sap.ui.model.FilterType.Application);
			}
		},
		onValueHelpVendorID: function (oEvent) {
			if (!this.VDialog) {
				this.VDialog = this.loadFragment({
					name: "com.spe.ManualPayReq.YMPR_FORM.fragments.VendorSAPID"
				});
			}
			this.VDialog.then(function (oDialog) {
				this._oVID = oDialog;
				oDialog.open();
			}.bind(this));
			var me = this;
			var name1 = "";
			var CompCode = this.getView().getModel("settingsModel").getProperty("/selectedCompCode");
			var oFilter = new sap.ui.model.Filter(
				"BUKRS",
				sap.ui.model.FilterOperator.EQ, CompCode
			);
			var oFilter1 = new sap.ui.model.Filter(
				"NAME1",
				sap.ui.model.FilterOperator.EQ, name1
			);
			num = "";
			num = 20;
			var oModel = me.getModel("Mprsrvmodel");
			oModel.read("/VendorSet?$skip=0&$top=" + num + "", {
				filters: [oFilter, oFilter1],
				success: function (oData, response) {
					me.getModel().setProperty("/VendorID/items", []);
					me.getModel().setProperty("/VendorID/items", oData.results);
				}
			});
		},
		onNext: function () {
			if (clicks < 0) {
				clicks = 0;
				clicks += 1;
			} else {
				clicks += 1;
			};
			num = clicks * 20;
			this.getVendorIDSet();
		},
		onCloseDialogVendorID: function () {
			this.getView().byId("idsearchVendorID").setValue(null);
			this._oVID.close();
		},
		getVendorIDSet: function () {
			var me = this;
			var name1 = this.getView().byId("idsearchVendorID").getValue();
			var CompCode = this.getView().getModel("settingsModel").getProperty("/selectedCompCode");
			var gatewayUrl = "/sap/opu/odata/sap/YFPSFIFRDD0037_MPR_EFORM_SRV/";
			var oModel3 = new sap.ui.model.odata.ODataModel(gatewayUrl);
			var spath = "/VendorSet?$skip=0&$top=" + num + "&$filter=BUKRS eq" + "'" + CompCode + "'" + "and NAME1 eq" + "'" + name1 + "'";
			oModel3.read(spath, null, null, true, function (oData) {
				me.getModel().setProperty("/VendorID/items", []);
				me.getModel().setProperty("/VendorID/items", oData.results);
			});
		},
		_handleSelectVendorID: function (oEvent) {
			var selectedVendorDes = oEvent.getSource().getAggregation("attributes");
			var selectedCompCode = this.getView().getModel("settingsModel").getProperty("/selectedCompCode");
			var status = this.getView().getModel("settingsModel").getProperty("/saveStatuss");
			var requestDate = this.getView().byId("idReqdate").getValue();
			var VendorLIFNR = selectedVendorDes[0].getProperty('text');
			var VendorNAME1 = selectedVendorDes[1].getProperty('text');
			var oFilter = new sap.ui.model.Filter("LIFNR", sap.ui.model.FilterOperator.Contains, "");
			var oFilter1 = new sap.ui.model.Filter("NAME1", sap.ui.model.FilterOperator.Contains, "");
			var comFil = new sap.ui.model.Filter([oFilter, oFilter1]);
			var oList = this.getView().byId("idlistVendorID");
			if (status === "S" && copy_case !== "X") {
				this.getView().byId("idinputTitle").setValue(null);
				Title = "Manual Payment Request";
				this.getModel().setProperty("/Title/items", Title);
				this.getView().byId("idinputTitle").setValue(Title + '-' + selectedCompCode + '-' + VendorLIFNR + '-' + VendorNAME1 + '-' +
					requestDate);
			}
			if (copy_case === "X") {
				var TillCompCodecopy = this.getView().byId("idinputTitle").getValue();
				this.getView().byId("idinputTitle").setValue(TillCompCodecopy + "-" + VendorLIFNR + "-" + VendorNAME1);
				this.getView().getModel("settingsModel").setProperty("/selectedDate", null);
				this.getView().byId("idReqdate").setValue(null);
				this.getView().byId("idTextReqDate").setText(null);
			} else {
				this.getView().byId("idinputTitle").setValue(null);
				Title = "Manual Payment Request";
				this.getModel().setProperty("/Title/items", Title);
				this.getView().byId("idinputTitle").setValue(Title + '-' + selectedCompCode + '-' + VendorLIFNR + '-' + VendorNAME1 + '-' +
					requestDate);
			}
			this.getView().getModel("settingsModel").setProperty("/VendorLIFNR", VendorLIFNR);
			this.getView().getModel("settingsModel").setProperty("/VendorNAME1", VendorNAME1);
			this.getView().byId("idInputVendorID").setValue(VendorLIFNR);
			this.getView().byId("idTextVendorID").setText(VendorLIFNR);
			this.getView().byId("idinputVendorName").setValue(VendorNAME1);
			this.getView().byId("idTextVendorName").setText(VendorNAME1);
			this.getView().byId("idsearchVendorID").setValue(null);
			oList.getBinding("items").filter(comFil, sap.ui.model.FilterType.Application);
			this._oVID.close();
		},
		onSearchVendorID: function (oEvent) {
			var me = this;
			var name1 = this.getView().byId("idsearchVendorID").getValue();
			var CompCode = this.getView().getModel("settingsModel").getProperty("/selectedCompCode");
			var gatewayUrl = "/sap/opu/odata/sap/YFPSFIFRDD0037_MPR_EFORM_SRV/";
			var oModel3 = new sap.ui.model.odata.ODataModel(gatewayUrl);
			var spath = "/VendorSet?$skip=0&$top=" + num + "&$filter=BUKRS eq" + "'" + CompCode + "'" + "and NAME1 eq" + "'" + name1 + "'";
			oModel3.read(spath, null, null, true, function (oData) {
				me.getModel().setProperty("/VendorID/items", []);
				me.getModel().setProperty("/VendorID/items", oData.results);
			});
		},
		OnValueHelpCurrency: function (oEvent) {
			if (!this.CUDialog) {
				this.CUDialog = this.loadFragment({
					name: "com.spe.ManualPayReq.YMPR_FORM.fragments.Currency"
				});
			}
			this.CUDialog.then(function (oDialog) {
				this._oCURR = oDialog;
				oDialog.open();
			}.bind(this));
			this.getCurrency();
		},
		onCloseDialogCurrency: function () {
			this.getView().byId("idsearchCurrency").setValue(null);
			this._oCURR.close();
			var oFilter = new sap.ui.model.Filter("WAERS", sap.ui.model.FilterOperator.Contains, "");
			var oFilter1 = new sap.ui.model.Filter("LTEXT", sap.ui.model.FilterOperator.Contains, "");
			var comFil = new sap.ui.model.Filter([oFilter, oFilter1]);
			var oList = this.getView().byId("idlistVendorID");
			oList.getBinding("items").filter(comFil, sap.ui.model.FilterType.Application);
		},
		getCurrency: function () {
			var me = this;
			sap.ui.core.BusyIndicator.show();
			var oModel = me.getModel("Mprsrvmodel");
			oModel.read("/CurrencykeySet", {
				method: "GET",
				success: function (oData, response) {
					sap.ui.core.BusyIndicator.hide();
					me.getModel().setProperty("/Currency/items", oData.results);
				}.bind(this),
				error: function (response) {
					sap.ui.core.BusyIndicator.hide();
					MessageBox.error(response.responseText);
				}.bind(this)
			});
		},
		onSelectCurrency: function (oEvent) {
			flagCurrency = true;
			var WAERS = oEvent.getParameters().listItem.getTitle();
			var LTEXT = oEvent.getParameters().listItem.getDescription();
			var oFilter = new sap.ui.model.Filter("WAERS", sap.ui.model.FilterOperator.Contains, "");
			var oFilter1 = new sap.ui.model.Filter("LTEXT", sap.ui.model.FilterOperator.Contains, "");
			var comFil = new sap.ui.model.Filter([oFilter, oFilter1]);
			var oList = this.getView().byId("idlistcurrency");
			this.getView().byId("idinputTotalAmount").setEditable(true);
			this.getView().getModel("settingsModel").setProperty("/Currency", WAERS);
			this.getView().getModel("settingsModel").setProperty("/Amount", null);
			this.getView().byId("idinputTotalAmount").setValue("");
			this.getView().byId("idconvertedTextAmount").setValue("");
			this.getView().byId("idCurrency").setValue(WAERS);
			this.getView().byId("idTextCurrency").setText(WAERS);
			this.getView().byId("idsearchCurrency").setValue(null);
			oList.getBinding("items").filter(comFil, sap.ui.model.FilterType.Application);
			this._oCURR.close();
		},
		onSearchCurrency: function (oEvent) {
			if (oEvent !== undefined) {
				var query = oEvent.getParameter("value");
				var oFilter = new sap.ui.model.Filter("WAERS", sap.ui.model.FilterOperator.Contains, query);
				var oFilter1 = new sap.ui.model.Filter("LTEXT", sap.ui.model.FilterOperator.Contains, query);
				var comFil = new sap.ui.model.Filter([oFilter, oFilter1]);
				var oList = this.getView().byId("idlistcurrency");
				oList.getBinding("items").filter(comFil, sap.ui.model.FilterType.Application);
			}
		},

		OnValueHelpReason: function (oEvent) {
			if (!this.RDialog) {
				this.RDialog = this.loadFragment({
					name: "com.spe.ManualPayReq.YMPR_FORM.fragments.Reason"
				});
			}
			this.RDialog.then(function (oDialog) {
				this._oReason = oDialog;
				oDialog.open();
			}.bind(this));
			this.getReason();
		},
		onCloseDialogReason: function () {
			this.getView().byId("idsearchReason").setValue(null);
			this._oReason.close();
			var oFilter = new sap.ui.model.Filter("REASONID", sap.ui.model.FilterOperator.Contains, "");
			var oFilter1 = new sap.ui.model.Filter("DESCRIPTION", sap.ui.model.FilterOperator.Contains, "");
			var comFil = new sap.ui.model.Filter([oFilter, oFilter1]);
			var oList = this.getView().byId("idlistVendorID");
			oList.getBinding("items").filter(comFil, sap.ui.model.FilterType.Application);
		},
		getReason: function () {
			var me = this;
			sap.ui.core.BusyIndicator.show();
			var oModel = me.getModel("Mprsrvmodel");
			oModel.read("/ReasonSet", {
				method: "GET",
				success: function (oData, response) {
					sap.ui.core.BusyIndicator.hide();
					me.getModel().setProperty("/Reason/items", oData.results);
				}.bind(this),
				error: function (response) {
					sap.ui.core.BusyIndicator.hide();
					MessageBox.error(response.responseText);
				}.bind(this)
			});
		},
		onSelectReason: function (oEvent) {
			var DESCRIPTION = oEvent.getParameters().listItem.getDescription();
			var REASONID = oEvent.getParameters().listItem.getTitle();
			var oFilter = new sap.ui.model.Filter("REASONID", sap.ui.model.FilterOperator.Contains, "");
			var oFilter1 = new sap.ui.model.Filter("DESCRIPTION", sap.ui.model.FilterOperator.Contains, "");
			var comFil = new sap.ui.model.Filter([oFilter, oFilter1]);
			var oList = this.getView().byId("idlistReason");
			this.getView().getModel("settingsModel").setProperty("/REASONID", REASONID);
			this.getView().getModel("settingsModel").setProperty("/DESCRIPTION", DESCRIPTION);
			this.getView().byId("idReason").setValue(REASONID + '-' + DESCRIPTION);
			this.getView().byId("idTextReason").setText(REASONID + '-' + DESCRIPTION);
			this.getView().byId("idsearchReason").setValue(null);
			oList.getBinding("items").filter(comFil, sap.ui.model.FilterType.Application);
			this._oReason.close();
		},
		onSearchReason: function (oEvent) {
			if (oEvent !== undefined) {
				var query = oEvent.getParameter("value");
				var oFilter = new sap.ui.model.Filter("REASONID", sap.ui.model.FilterOperator.Contains, query);
				var oFilter1 = new sap.ui.model.Filter("DESCRIPTION", sap.ui.model.FilterOperator.Contains, query);
				var comFil = new sap.ui.model.Filter([oFilter, oFilter1]);
				var oList = this.getView().byId("idlistReason");
				oList.getBinding("items").filter(comFil, sap.ui.model.FilterType.Application);
			}
		},

		onLiveTotalAmount: function (oEvent) {
			this.getView().getModel("settingsModel").setProperty("/Amount", null);
			var sAmount = oEvent.getParameter("value");
			sAmount = sAmount.replace(/\s+/g, '');
			sap.ui.getCore().byId(oEvent.getParameter("id")).setValue(sAmount);
			var regex = /^[.0-9]+$/;
			if (!regex.test(sAmount)) {
				var removelastchar = sAmount.replace(/[^.0-9 ]/g, '');
				sap.ui.getCore().byId(oEvent.getParameter("id")).setValue(removelastchar);
				return false;
			}
		},
		onhandleChangeReqDate: function (oEvent) {
			var selectedDate = oEvent.getParameters().value;
			var selectedCompCode = this.getView().getModel("settingsModel").getProperty("/selectedCompCode");
			var vendorid = this.getView().getModel("settingsModel").getProperty("/VendorLIFNR");
			var vendorname = this.getView().getModel("settingsModel").getProperty("/VendorNAME1");
			this.getView().getModel("settingsModel").setProperty("/selectedDate", selectedDate);
			this.getView().byId("idReqdate").setValue(selectedDate);
			this.getView().byId("idTextReqDate").setText(selectedDate);
			this.getView().byId("idinputTitle").setValue(null);
			Title = "Manual Payment Request";
			this.getModel().setProperty("/Title/items", Title);
			this.getView().byId("idinputTitle").setValue(Title + '-' + selectedCompCode + '-' + vendorid + '-' + vendorname + '-' +
				selectedDate);
		},
		_onhandleValueChangeImage: function (oEvent) {
			var that = this;
			var BrowserID = oEvent.getParameters().id.split('-').pop();
			var oFileUploader = this.getView().byId(BrowserID);
			var domRef = oFileUploader.getFocusDomRef();
			var file = domRef.files[0];
			img_type = domRef.files[0].type;
			this.fileName = file.name;
			var oReader = new FileReader();
			oReader.readAsDataURL(file);
			oReader.onloadend = function () {
				var sBase64data = oReader.result;
				if (BrowserID === "i_fileUploader") {
					that.getView().byId("idDocPay").setVisible(false);
					that.getView().byId("ss").setVisible(true);
					that.getView().byId("b_upload").setVisible(true);
					that.getView().byId("Label1").setVisible(false);
					that.getView().byId("i_fileUploader").setVisible(false);
					that.getView().byId("Label2").setVisible(true);
					that.getView().byId("ss").setSrc(sBase64data);
					that.getView().byId("ss1").setSrc(sBase64data);
					that.getView().getModel("EnableModel").setProperty("/enabledResetButton", true);
					var image = that.getView().byId('ss').getSrc().replace("data:" + img_type + ";base64,", "");
					var image_type = img_type;
					dataset.push({
						EFORM_NUM: that.form_number,
						IMAGE_ID: "1",
						IMAGE_TYPE: image_type,
						IMG_CONTENT: image
					});
				} else if (BrowserID === "idBInuploader") {
					that.getView().byId("idBenInfo").setVisible(false);
					that.getView().byId("b_upload1").setVisible(true);
					that.getView().byId("idimage1").setVisible(true);
					that.getView().byId("label3").setVisible(false);
					that.getView().byId("idBInuploader").setVisible(false);
					that.getView().byId("label4").setVisible(true);
					that.getView().byId("idimage1").setSrc(sBase64data);
					that.getView().byId("idimage1Summary").setSrc(sBase64data);
					that.getView().getModel("EnableModel").setProperty("/enabledResetButton", true);
					var image = that.getView().byId('idimage1').getSrc().replace("data:" + img_type + ";base64,", "");
					var image_type = img_type;
					dataset.push({
						EFORM_NUM: that.form_number,
						IMAGE_ID: "2",
						IMAGE_TYPE: image_type,
						IMG_CONTENT: image
					});
				} else if (BrowserID === "idBankInfoUploader") {
					that.getView().byId("idBankInfoUploader").setVisible(false);
					that.getView().byId("b_upload2").setVisible(true);
					that.getView().byId("label5").setVisible(false);
					that.getView().byId("label6").setVisible(true);
					that.getView().byId("idimage2summary").setVisible(true);
					that.getView().byId("idBankingInfo").setVisible(false);
					that.getView().byId("idimage2").setVisible(true);
					that.getView().byId("idimage2").setSrc(sBase64data);
					that.getView().byId("idimage2summary").setSrc(sBase64data);
					that.getView().getModel("EnableModel").setProperty("/enabledResetButton", true);
					var image = that.getView().byId('idimage2').getSrc().replace("data:" + img_type + ";base64,", "");
					var image_type = img_type;
					dataset.push({
						EFORM_NUM: that.form_number,
						IMAGE_ID: "3",
						IMAGE_TYPE: image_type,
						IMG_CONTENT: image
					});
				} else if (BrowserID === "idInInformUploader") {
					that.getView().byId("idInInformUploader").setVisible(false);
					that.getView().byId("b_upload3").setVisible(true);
					that.getView().byId("label7").setVisible(false);
					that.getView().byId("label8").setVisible(true);
					that.getView().byId("idimage2summary").setVisible(true);
					that.getView().byId("idInvoiceInfo").setVisible(false);
					that.getView().byId("idimage3").setVisible(true);
					that.getView().byId("idimage3").setSrc(sBase64data);
					that.getView().byId("idimage3summary").setSrc(sBase64data);
					that.getView().getModel("EnableModel").setProperty("/enabledResetButton", true);
					var image = that.getView().byId('idimage3').getSrc().replace("data:" + img_type + ";base64,", "");
					var image_type = img_type;
					dataset.push({
						EFORM_NUM: that.form_number,
						IMAGE_ID: "4",
						IMAGE_TYPE: image_type,
						IMG_CONTENT: image
					});
				} else if (BrowserID === "idInvoicePOUploader") {
					that.getView().byId("idInvoicePOUploader").setVisible(false);
					that.getView().byId("b_upload4").setVisible(true);
					that.getView().byId("label9").setVisible(false);
					that.getView().byId("label10").setVisible(true);
					that.getView().byId("idInvoicePO").setVisible(false);
					that.getView().byId("idimage4").setVisible(true);
					that.getView().byId("idimage4").setSrc(sBase64data);
					that.getView().byId("idimage4summary").setSrc(sBase64data);
					that.getView().getModel("EnableModel").setProperty("/enabledResetButton", true);
					var image = that.getView().byId('idimage4').getSrc().replace("data:" + img_type + ";base64,", "");
					var image_type = img_type;
					dataset.push({
						EFORM_NUM: that.form_number,
						IMAGE_ID: "5",
						IMAGE_TYPE: image_type,
						IMG_CONTENT: image
					});
				} else if (BrowserID === "idCommuformUploader") {
					that.getView().byId("idCommuformUploader").setVisible(false);
					that.getView().byId("b_upload5").setVisible(true);
					that.getView().byId("label11").setVisible(false);
					that.getView().byId("label12").setVisible(true);
					that.getView().byId("idComInfo").setVisible(false);
					that.getView().byId("idimage5").setVisible(true);
					that.getView().byId("idimage5").setSrc(sBase64data);
					that.getView().byId("idimage5summary").setSrc(sBase64data);
					that.getView().getModel("EnableModel").setProperty("/enabledResetButton", true);
					var image = that.getView().byId('idimage5').getSrc().replace("data:" + img_type + ";base64,", "");
					var image_type = img_type;
					dataset.push({
						EFORM_NUM: that.form_number,
						IMAGE_ID: "6",
						IMAGE_TYPE: image_type,
						IMG_CONTENT: image
					});
				}
			};
		},
		onReset: function (oEvent) {
			var Buttonid = oEvent.getParameters().id.split('-').pop();
			if (Buttonid === "b_upload") {
				this.getView().byId("i_fileUploader").setVisible(true);
				this.getView().byId("idDocPay").setVisible(true);
				this.getView().byId("idDocPay").setEnabled(true);
				this.getView().byId("b_upload").setVisible(false);
				this.getView().byId("Label1").setVisible(true);
				this.getView().byId("Label2").setVisible(false);
				this.getView().byId("ss").setVisible(false);
				this.getView().byId("ss").setSrc("");
				this.getView().byId("ss1").setSrc("");
				var test = dataset.filter(function (item) {
					return item.IMAGE_ID !== "1";
				});
				dataset = test;
			}
			if (Buttonid === "b_upload1") {
				this.getView().byId("idBInuploader").setVisible(true);
				this.getView().byId("b_upload1").setVisible(false);
				this.getView().byId("label3").setVisible(true);
				this.getView().byId("label4").setVisible(false);
				this.getView().byId("idBenInfo").setVisible(true);
				this.getView().byId("idBenInfo").setEnabled(true);
				this.getView().byId("idimage1").setVisible(false);
				this.getView().byId("idimage1").setSrc("");
				this.getView().byId("idimage1Summary").setSrc("");
				var test = dataset.filter(function (item) {
					return item.IMAGE_ID !== "2";
				});
				dataset = test;
			}
			if (Buttonid === "b_upload2") {
				this.getView().byId("idBankInfoUploader").setVisible(true);
				this.getView().byId("b_upload2").setVisible(false);
				this.getView().byId("label5").setVisible(true);
				this.getView().byId("label6").setVisible(false);
				this.getView().byId("idBankingInfo").setVisible(true);
				this.getView().byId("idBankingInfo").setEnabled(true);
				this.getView().byId("idimage2").setVisible(false);
				this.getView().byId("idimage2").setSrc("");
				this.getView().byId("idimage2summary").setSrc("");
				var test = dataset.filter(function (item) {
					return item.IMAGE_ID !== "3";
				});
				dataset = test;
			}
			if (Buttonid === "b_upload3") {
				this.getView().byId("idInInformUploader").setVisible(true);
				this.getView().byId("b_upload3").setVisible(false);
				this.getView().byId("label7").setVisible(true);
				this.getView().byId("label8").setVisible(false);
				this.getView().byId("idInvoiceInfo").setVisible(true);
				this.getView().byId("idInvoiceInfo").setEnabled(true);
				this.getView().byId("idimage3").setVisible(false);
				this.getView().byId("idimage3").setSrc("");
				this.getView().byId("idimage3summary").setSrc("");
				var test = dataset.filter(function (item) {
					return item.IMAGE_ID !== "4";
				});
				dataset = test;
			}
			if (Buttonid === "b_upload4") {
				this.getView().byId("idInvoicePOUploader").setVisible(true);
				this.getView().byId("b_upload4").setVisible(false);
				this.getView().byId("label9").setVisible(true);
				this.getView().byId("label10").setVisible(false);
				this.getView().byId("idInvoicePO").setVisible(true);
				this.getView().byId("idInvoicePO").setEnabled(true);
				this.getView().byId("idimage4").setVisible(false);
				this.getView().byId("idimage4").setSrc("");
				this.getView().byId("idimage4summary").setSrc("");
				var test = dataset.filter(function (item) {
					return item.IMAGE_ID !== "5";
				});
				dataset = test;
			}
			if (Buttonid === "b_upload5") {
				this.getView().byId("idCommuformUploader").setVisible(true);
				this.getView().byId("b_upload5").setVisible(false);
				this.getView().byId("label11").setVisible(true);
				this.getView().byId("label12").setVisible(false);
				this.getView().byId("idComInfo").setVisible(true);
				this.getView().byId("idComInfo").setEnabled(true);
				this.getView().byId("idimage5").setVisible(false);
				this.getView().byId("idimage5").setSrc("");
				this.getView().byId("idimage5summary").setSrc("");
				var test = dataset.filter(function (item) {
					return item.IMAGE_ID !== "6";
				});
				dataset = test;
			}
		},

		getComments: function (contextName) {
			// var n = new sap.ui.model.Filter("EFORM_NUM", sap.ui.model.FilterOperator.EQ, contextName);
			var that = this;
			var oFilter = new sap.ui.model.Filter(
				"FORM_NO",
				sap.ui.model.FilterOperator.EQ, contextName
			);
			var oModel = that.getModel("Mprsrvmodel");
			oModel.read("/CommentSet", {
				filters: [oFilter],
				success: function (oData, response) {
					var aDataSet = [];
					oData.results.forEach(function (item, index) {
						aDataSet.push({
							COMMENTS: item.COMMENTS,
							CREATOR: item.CREATOR,
							CREATOR_NAME: item.CREATOR_NAME,
							CR_DATE: item.CR_DATE,
							FORM_NO: item.FORM_NO,
							CommentNo: item.CommentNo,
							SEQUENCE: item.SEQUENCE,
							TIME: item.TIME
						});
					});
					that.form_number = contextName;
					that.getView().getModel("commentModel").setData(aDataSet);
				}
			});
		},
		//on posting comment
		onCommentPost: function (oEvent) {
			var sCurrentUser = sap.ushell.Container.getUser().getId();
			var sCurrentUserName = sap.ushell.Container.getUser().getFullName();
			var sComment = oEvent.getParameter("value");
			var formNumber = this.getView().getModel("settingsModel").getProperty("/form_number");
			if (this.form_number === undefined || this.form_number === null || this.form_number === "") {
				this.form_number = formNumber;
			}
			var oDataSets = {
				FORM_NO: this.form_number,
				SEQUENCE: "",
				CREATOR: sCurrentUser,
				CR_DATE: "",
				TIME: "",
				COMMENTS: sComment,
				CREATOR_NAME: sCurrentUserName,
				ACTION: "Create"
			};
			var commentModel = this.getView().getModel("commentModel");
			var oDataSet = commentModel.getData();
			var sIndex = oDataSet.length;
			if (sIndex === undefined) {
				oDataSet = [];
			}
			oDataSet.splice(sIndex, 0, {
				FORM_NO: this.form_number,
				CREATOR: sCurrentUser,
				CREATOR_NAME: sCurrentUserName,
				COMMENTS: sComment
			});
			var me = this;
			var oModel = me.getModel("Mprsrvmodel");
			oModel.create("/CommentSet", oDataSets, {
				// filters: myFilter,
				success: function (oData, response) {
					var form_number = oData.FORM_NO;
					me.getComments(form_number);
					MessageBox.show(
						"Comment has been added successfully and saved under" + " " + form_number,
						MessageBox.Icon.SUCCESS,
						"Success"
					);
					me.getView().byId("pagetitle").setText('Manual Payment Request' + " " + form_number);
					me.getView().getModel("settingsModel").setProperty("/form_number", form_number);
					me.getView().byId("feedinput").setValue(null);
				},
				error: function (oError) {
					var response = JSON.parse(oError.responseText);
					MessageBox.show(
						response.error.message.value,
						MessageBox.Icon.ERROR,
						"Error"
					);
				}.bind(this)
			});
			this.getView().getModel("commentModel").setData(oDataSet);
		},
		// binding data to comment section
		commentFactory: function () {
			var oTemplate = new sap.m.FeedListItem({
				senderActive: false,
				sender: "{commentModel>CREATOR_NAME}",
				text: "{commentModel>COMMENTS}",
				showIcon: false,
				actions: new sap.m.FeedListItemAction({
					text: "Delete",
					press: [this._onPressDeleteComment, this],
					icon: "sap-icon://delete",
					key: "delete",
					enabled: "{EnableModel>/enabledComment}"
				})
			}).bindProperty("timestamp", {
				parts: [{
					path: 'commentModel>CR_DATE'
				}, {
					path: 'commentModel>TIME'
				}],
				formatter: function (sDate, sTime) {
					var datechange = sDate;
					var year = datechange.slice(0, 4);
					var mm = datechange.slice(4, 6);
					var dd = datechange.slice(6, 8);
					var append = year + "/" + mm + "/" + dd;
					if ((sDate === "00000000" || sDate === null || sDate === undefined) || (sTime === "00000000" || sTime === null ||
							sTime === undefined)) {
						var timeFormat = DateFormat.getDateTimeInstance({
							pattern: "MM/dd/yyyy hh:mm:ss a"

						});
						return timeFormat.format(new Date());
					} else {
						var timeFormat = DateFormat.getDateTimeInstance({
							pattern: "MM/dd/yyyy hh:mm:ss a"
						});
						var hour = sTime.substring(0, 2);
						var minute = sTime.substring(2, 4);
						var second = sTime.substring(4);
						var sCTime = hour + ":" + minute + ":" + second;
						return timeFormat.format(new Date(append + " " + sCTime));
					}
				}
			});
			return oTemplate;
		},
		// summary comment binding without delete button
		commentFactorySummary: function () {
			var oTemplate = new sap.m.FeedListItem({
				senderActive: false,
				sender: "{commentModel>CREATOR_NAME}",
				text: "{commentModel>COMMENTS}",
				showIcon: false,
			}).bindProperty("timestamp", {
				parts: [{
					path: 'commentModel>CR_DATE'
				}, {
					path: 'commentModel>TIME'
				}],
				formatter: function (sDate, sTime) {
					var datechange = sDate;
					var year = datechange.slice(0, 4);
					var mm = datechange.slice(4, 6);
					var dd = datechange.slice(6, 8);
					var append = year + "/" + mm + "/" + dd;
					if ((sDate === "00000000" || sDate === null || sDate === undefined) || (sTime === "00000000" || sTime === null ||
							sTime === undefined)) {
						var timeFormat = DateFormat.getDateTimeInstance({
							pattern: "MM/dd/yyyy hh:mm:ss a"

						});
						return timeFormat.format(new Date());
					} else {
						var timeFormat = DateFormat.getDateTimeInstance({
							pattern: "MM/dd/yyyy hh:mm:ss a"
						});
						var hour = sTime.substring(0, 2);
						var minute = sTime.substring(2, 4);
						var second = sTime.substring(4);
						var sCTime = hour + ":" + minute + ":" + second;
						return timeFormat.format(new Date(append + " " + sCTime));
					}
				}
			});
			return oTemplate;
		},
		//on deleting comment 
		_onPressDeleteComment: function (oEvent) {
			var c = {};
			var array = [];
			var UserName = sap.ushell.Container.getService("UserInfo").getUser().getFullName();
			var oModel = this.getModel("Mprsrvmodel");
			var sContext = oEvent.getSource().getParent().getBindingContextPath();
			var index = sContext.slice(1);
			array = this.getView().byId("commentList").getBinding("items").oList;
			if (array[index].CREATOR_NAME !== UserName) {
				MessageBox.alert("You are not authorized to delete this comment.");
				return false;
			}
			if (!array) {
				MessageBox.alert("Nothing to delete");
			} else {
				c = {};
				c.FORM_NO = this.form_number;
				c.SEQUENCE = array[index].SEQUENCE;
				c.CREATOR = "";
				c.CR_DATE = "";
				c.TIME = "";
				c.COMMENTS = array[index].COMMENTS;
				c.CREATOR_NAME = "";
				c.ACTION = "Delete";
				var that = this;
				oModel.create("/CommentSet", c, {
					async: false,
					success: function (oData, response) {
						var form_number = oData.FORM_NO;
						MessageBox.show(
							"Comment has been deleted successfully",
							MessageBox.Icon.SUCCESS,
							"Success"
						);
						that.getComments(form_number);
					},
					error: function (oError) {
						MessageBox.show(
							"Error occured while deleting comment",
							MessageBox.Icon.ERROR,
							"Error"
						);
					}
				});
			}
		},
		getattachments: function (contextName) {
			var that = this;
			var oFilter = new sap.ui.model.Filter(
				"EFORM_NUM",
				sap.ui.model.FilterOperator.EQ, contextName
			);
			var oModel = that.getModel("Mprsrvmodel");
			oModel.read("/AttachmentSet", {
				filters: [oFilter],
				success: function (oData, response) {
					that.getView().byId("t_attachment1").destroyItems();
					var counter = oData.results.length;
					var i = 0;
					for (i = 0; i < counter; i++) {
						//Date Format
						var datechange = oData.results[i].CREATION_DT;
						var year = datechange.slice(0, 4);
						var mm = datechange.slice(4, 6);
						var dd = datechange.slice(6, 8);
						var append = year + "/" + mm + "/" + dd;
						var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
							pattern: "MM/dd/yyyy"
						});
						var datab = dateFormat.format(new Date(append));
						oData.results[i].CREATION_DT = datab;
						// Time Format
						var TimeChange = oData.results[i].CREATION_TIME;
						var hours = TimeChange.slice(0, 2);
						var minute = TimeChange.slice(2, 4);
						var second = TimeChange.slice(4);
						var appendTime = hours + ":" + minute + ":" + second;
						oData.results[i].CREATION_TIME = appendTime;
						// SIZE KB
						var size = oData.results[i].FILE_SIZE;
						var SizeKb = size + " " + "KB";
						oData.results[i].FILE_SIZE = SizeKb;
						var table1 = that.getView().byId("t_attachment1");
						var data1 = new sap.m.ColumnListItem({
							cells: [
								new sap.m.Link({
									text: response.data.results[i].FILE_NAME,
									wrapping: Boolean(1),
									press: function (oEvent) {
										var that2 = that;
										var oSource = oEvent.getSource();
										var relPath = "/sap/opu/odata/sap/YFPSFIFRDD0037_MPR_EFORM_SRV/AttachmentSet(EFORM_NUM='" + contextName + "'" +
											",FILE_NAME='" + oSource.getText() + "')/$value";
										window.open(relPath, '_blank');
									}
								}),
								new sap.m.Text({
									text: response.data.results[i].CREATION_DT
								}),
								new sap.m.Text({
									text: response.data.results[i].CREATION_TIME
								}),
								new sap.m.Text({
									text: response.data.results[i].FILE_SIZE
								}),
								new sap.m.Text({
									text: response.data.results[i].CREATOR_NAME
								})
							]
						});
						table1.addItem(data1);
						that.getModel().setProperty("/summaryTable/items", oData.results);
					}
				},
				error: function (oError) {
					var response = JSON.parse(oError.responseText);
					MessageBox.show(
						response.error.message.value,
						MessageBox.Icon.ERROR,
						"Error"
					);
					sap.ui.core.BusyIndicator.hide();
				}
			});
		},
		_onhandleValueChange: function (oEvent) {
			var file_size = oEvent.mParameters.files[0].size;
			file_size = (file_size / 1024);
			this.getView().getModel("settingsModel").setProperty("/file_size", file_size);
		},
		_onhandleUploadPress: function (oEvent) {
			if (oEvent.mParameters.id.toLowerCase().indexOf("b_upload11") > -1) {
				var oFileUploader = this.getView().byId("i_fileUploader1");
				if (oFileUploader.getValue() == "") {
					MessageBox.alert("Please select the file");
					return;
				}
			}
			var formNumber = this.getView().getModel("settingsModel").getProperty("/form_number");
			if (this.form_number === undefined || this.form_number === null || this.form_number === "") {
				this.form_number = formNumber;
			}
			var url = "/sap/opu/odata/sap/YFPSFIFRDD0037_MPR_EFORM_SRV/";
			var userModel = new sap.ui.model.odata.ODataModel(url, true);
			var viewInstance = this.getView();
			if (oFileUploader.getName() == "") {
				return;
			}
			viewInstance.setBusy(true);
			// Set CSRF
			userModel.refreshSecurityToken();
			var csrf = userModel.getSecurityToken();
			//Add to header and upload
			oFileUploader.destroyHeaderParameters();
			oFileUploader.setSendXHR(true);
			var file_size = this.getView().getModel("settingsModel").getProperty("/file_size");
			var headerParma = new sap.ui.unified.FileUploaderParameter();
			var headerParma2 = new sap.ui.unified.FileUploaderParameter();
			var headerParma3 = new sap.ui.unified.FileUploaderParameter();
			headerParma2.setName('slug');
			headerParma2.setValue(oFileUploader.getValue() + '|' + this.form_number + '|' + file_size + '|' + 'MPR');
			oFileUploader.insertHeaderParameter(headerParma2);
			headerParma3.setName('Content-Type');
			headerParma3.setValue('image/jpeg');
			oFileUploader.insertHeaderParameter(headerParma3);
			headerParma.setName('x-csrf-token');
			headerParma.setValue(csrf);
			oFileUploader.addHeaderParameter(headerParma);
			oFileUploader.upload();
		},
		_onhandleUploadComplete: function (oEvent) {
			var status = oEvent.getParameter("status");
			if (status === 201) {
				var sMsg = "Upload Success";
				MessageToast.show(sMsg);
				oEvent.getSource().setValue("");
				var temp = oEvent.getParameter("response");
				this.form_number = temp.substr(temp.indexOf("EFORM_NUM='") + 11, 10);
				this.getView().getModel("settingsModel").setProperty("/form_number", this.form_number);
				var e_form_num = this.form_number;
				MessageBox.show(
					"Attachment has been added successfully and saved under" + "-" + e_form_num,
					MessageBox.Icon.SUCCESS,
					"Success"
				);
			} else {
				sMsg = "Upload Error";
			}
			var that = this;
			var viewInstance = this.getView();
			viewInstance.setBusy(false);
			that.getView().byId("pagetitle").setText('Manual Payment Request' + " " + e_form_num);
			that.getattachments(e_form_num);
		},
		_onDeleteAttachment: function (oEvent) {
			var oModel = this.getModel("Mprsrvmodel");
			var logger_name = sap.ushell.Container.getService("UserInfo").getUser().getFullName();
			var e_form_num = this.form_number;
			if (oEvent.getSource().getId().includes("b_deleteattachment1")) {
				var selected_item = this.getView().byId("t_attachment1").getSelectedItem();
			}
			if (selected_item === null) {
				MessageToast.show("Nothing to delete");
			} else {
				var filename = selected_item.getCells()[0].getText();
				if (filename !== "") {
					if (logger_name == selected_item.getCells()[4].getText()) {
						var that = this;
						oModel.remove("/AttachmentSet(EFORM_NUM='" + e_form_num + "'" + ",FILE_NAME='" + filename + "')", {
							method: "DELETE",
							success: function (oData, response) {
								that.getView().byId("t_attachment1").removeItem(selected_item);
								that.getattachments(e_form_num);
								MessageBox.alert("Attachment has been deleted succesfully");
							},
							error: function (oError) {
								var response = JSON.parse(oError.responseText);
								MessageBox.show(
									response.error.message.value,
									MessageBox.Icon.ERROR,
									"Error"
								);
								sap.ui.core.BusyIndicator.hide();
							}
						});
					} else {
						MessageBox.alert("You are not authorized to delete this attachment");
					}
				}
			}
		},
		onAddApprovers: function () {
			var selectedType = this.byId('apprType').getValue();
			var table = this.getView().byId("tblApprover");
			var logger_id = sap.ushell.Container.getService("UserInfo").getUser().getId();
			var logger_name = sap.ushell.Container.getUser().getFullName();
			var all_entries = table.getItems();
			index_counter = index_counter + 1;
			var today = new Date();
			var yyyy = today.getFullYear();
			var mm = today.getMonth() + 1; // Months start at 0!
			var dd = today.getDate();
			if (dd < 10) dd = '0' + dd;
			if (mm < 10) mm = '0' + mm;
			var formattedToday = mm + '/' + dd + '/' + yyyy;
			var num_of_entries = table.getItems().length;
			var lastIndex = table.getItems().length - 1;
			if (num_of_entries > -1) {
				this.byId('txtPosition').setProperty('visible', true);
				this.byId('ENTRY_SEQUENCE').setProperty('visible', true);
			}
			if (num_of_entries === 0) {
				var that = this;
				var data = new sap.m.ColumnListItem({
					cells: [
						new sap.m.Text({
							editable: false
						}),
						new sap.m.Input({
							showValueHelp: Boolean("true"),
							valueHelpOnly: Boolean("true"),
							id: "approver" + index_counter,
							valueHelpRequest: [that._onApproverHelpRequest, that]
						}),
						new sap.m.Text({
							text: selectedType
						}),
						new sap.m.Text({
							text: ""
						}),
						new sap.m.Text({
							text: ""
						}),
						new sap.m.Text({
							text: ""
						}),
						new sap.m.CheckBox({
							editable: false,
							selected: true
						}).data("Flag", "X"),
						new sap.m.Text({
							text: logger_name
						}),
						new sap.m.Text({
							text: formattedToday
						}),
						new sap.m.Text({
							text: ""
						}),
						new sap.m.Text({
							text: logger_id
						}),
						new sap.m.Text({
							text: ""
						})
					]
				});
				table.addItem(data);
			} else {

				var selected_item = this.getView().byId("tblApprover").getSelectedItem();
				var position = this.getView().byId("ENTRY_SEQUENCE").getValue();
				var AData = this.getModel().getProperty("/ApproverTable/items");
				var selectedItemindex = table.getItems().indexOf(table.getSelectedItem());
				var sItem = table.getSelectedItem();
				if (selected_item === null) {
					MessageBox.error("Kindly select position before adding approver");
					return false;
				}
				if (selectedItemindex === lastIndex && position === "After") {
					MessageBox.error("You can not add approver after this position");
					return false;
				}

				if (sItem.getAggregation("cells")[0].mProperties.text != undefined) {
					if (sItem.getAggregation("cells")[0].getProperty("text") === "Approved" && this.getView().byId("ENTRY_SEQUENCE").getValue() ===
						"Before" && selectedType === "Approver") {
						MessageBox.alert("You can not add approver before this position");
						return false;
					}
				}
				if (sItem.getAggregation("cells")[0].mProperties.text != undefined) {
					if (sItem.getAggregation("cells")[2].getProperty("text") === "Watcher" && this.getView().byId("ENTRY_SEQUENCE").getValue() ===
						"Before" && table.indexOfItem(sItem) === 0) {
						MessageBox.alert("You cannot add Approvers/Watchers before this position");
						return false;
					}
				}
				for (var h = 0; h < AData.length; h++) {
					var NextAction = AData[h].APPROVED;
					if (NextAction === "X") {
						if (selectedType === "Approver" && selectedItemindex < h) {
							MessageBox.alert("You can not add approver before this position");
							return false;
						}
					}
				}
				if (this.getView().byId("ENTRY_SEQUENCE").getValue() == "After") {
					var index = table.indexOfItem(selected_item) + 1;
				} else {
					if (table.indexOfItem(selected_item) > 0) {
						var index = table.indexOfItem(selected_item);
						if (index == 0) {
							index = 1;
						}
					} else {
						index = 0;
					}
				}
				var counter = 0;
				var x = 1;
				var that = this;
				for (counter = 0; counter < num_of_entries; counter++) {
					x = x + 1;
					if (counter == index) {
						var data = new sap.m.ColumnListItem({
							cells: [
								new sap.m.Text({
									editable: false
								}),
								new sap.m.Input({
									showValueHelp: Boolean("true"),
									valueHelpOnly: Boolean("true"),
									id: "approver" + index_counter,
									valueHelpRequest: [that._onApproverHelpRequest, that]
								}),
								new sap.m.Text({
									text: this.getView().byId("apprType").getValue()
								}),
								new sap.m.Text({
									text: ""
								}),
								new sap.m.Text({
									text: ""
								}),
								new sap.m.Text({
									text: ""
								}),
								new sap.m.CheckBox({
									editable: false,
									selected: true
								}).data("Flag", "X"),
								new sap.m.Text({
									text: logger_name
								}),
								new sap.m.Text({
									text: formattedToday
								}),
								new sap.m.Text({
									text: ""
								}),
								new sap.m.Text({
									text: logger_id
								}),
								new sap.m.Text({
									text: ""
								})
							]
						});
						table.addItem(data);
					}
					table.addItem(all_entries[counter]);
					if (counter === (num_of_entries - 1) && (index === num_of_entries)) {
						var data = new sap.m.ColumnListItem({
							cells: [
								new sap.m.Text({
									editable: false
								}),
								new sap.m.Input({
									showValueHelp: Boolean("true"),
									valueHelpOnly: Boolean("true"),
									id: "approver2" + index_counter,
									valueHelpRequest: [that._onApproverHelpRequest, that]
								}),
								new sap.m.Text({
									text: this.getView().byId("apprType").getValue()
								}),
								new sap.m.Text({
									text: ""
								}),
								new sap.m.Text({
									text: ""
								}),
								new sap.m.Text({
									text: ""
								}),
								new sap.m.CheckBox({
									editable: false,
									selected: true
								}).data("Flag", "X"),
								new sap.m.Text({
									text: logger_name
								}),
								new sap.m.Text({
									text: formattedToday
								}),
								new sap.m.Text({
									text: ""
								}),
								new sap.m.Text({
									text: logger_id
								}),
								new sap.m.Text({
									text: ""
								})
							]
						});
						table.addItem(data);
					}
				}
			}
		},
		_onApproverHelpRequest: function (oEvent) {
			var input_1 = oEvent.getSource();
			var me = oEvent.getSource().getParent();
			var oValueHelpDialog_Approver = new sap.m.SelectDialog({
				title: "User's list",
				items: {
					path: "/UserlistSet",
					template: new sap.m.StandardListItem({
						title: "{FULLNAME}",
						description: "{USERNAME}",
						active: true
					})
				},
				search: function (oEvent) {
					var sValue = oEvent.getParameter("value");
					var oFilter = new sap.ui.model.Filter(
						"USERNAME",
						sap.ui.model.FilterOperator.Contains, sValue
					);
					oEvent.getSource().getBinding("items").filter([oFilter]);
				},
				// On click of Confirm, value is set to input field
				confirm: function (oEvent) {
					var oSelectedItem = oEvent.getParameter("selectedItem");
					var userid = oSelectedItem.getDescription();
					if (oSelectedItem) {
						input_1.setValue(oSelectedItem.getTitle());
						me.getCells()[9].setProperty("text", userid);
					}
				}
			});
			var model = this.getModel("Mprsrvmodel");
			oValueHelpDialog_Approver.setModel(model);
			oValueHelpDialog_Approver.open();
		},
		ondeleteAapprover: function () {
			var table = this.getView().byId("tblApprover");
			var logger_name = sap.ushell.Container.getUser().getFullName();
			var selected_item = this.getView().byId("tblApprover").getSelectedItem();
			if (table.getItems().length === 0) {
				this.byId('txtPosition').setProperty('visible', true);
				this.byId('ENTRY_SEQUENCE').setProperty('visible', true);
				MessageToast.show("Add one item");
				return;
			}
			if (table.getSelectedItems().length === 0) {
				MessageBox.show(
					"Please select at least one",
					MessageBox.Icon.ERROR,
					"Error"
				);
				return;
			}
			var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
			MessageBox.confirm(
				"Do you want to delete this selected one?", {
					actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
					styleClass: bCompact ? "sapUiSizeCompact" : "",
					onClose: function (sAction) {
						if (sAction === "OK") {
							// deleting mannually added items
							if (selected_item.mAggregations.cells[0].mProperties.text == "" && selected_item.mAggregations.cells[6].mProperties.selected ==
								true) {
								if (selected_item.mAggregations.cells[7].mProperties.text === logger_name) {
									table.removeItem(selected_item);
									MessageBox.success("Deleted succesfully from the approval flow. Kindly save the form");
								} else {
									MessageBox.alert("You can only delete approvers added by you");
								}
								if (table.getItems().length === 0) {
									this.byId('txtPosition').setProperty('visible', true);
									this.byId('ENTRY_SEQUENCE').setProperty('visible', true);
								}
							} else {
								MessageBox.alert("You can not delete the group approvers");
							}

						} else {
							return false;
						}
					}
				}
			);
		},
		_onRefreshApprovers: function () {
			var that = this;
			sap.ui.core.BusyIndicator.show();
			var n = new sap.ui.model.Filter("EFORM_NUM", sap.ui.model.FilterOperator.EQ, e_form_num);
			var myFilter = [];
			myFilter.push(n);
			var oModel = that.getModel("Mprsrvmodel");
			oModel.read("/ApproverSet", {
				method: "GET",
				filters: myFilter,
				success: function (oData, response) {
					sap.ui.core.BusyIndicator.hide();
					var approverlist = oData.results;
					for (var j = 0; j < approverlist.length; j++) {
						var datechange = approverlist[j].CREATION_DT;
						var Apprdatechange = approverlist[j].APPROVED_DT;
						var ApprdTimechange = approverlist[j].APPROVED_TM;
						var year = datechange.slice(0, 4);
						var mm = datechange.slice(4, 6);
						var dd = datechange.slice(6, 8);
						var append = year + "/" + mm + "/" + dd;
						var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
							pattern: "MM/dd/yyyy"
						});
						var datab = dateFormat.format(new Date(append));
						var year1 = Apprdatechange.slice(0, 4);
						var mm1 = Apprdatechange.slice(4, 6);
						var dd1 = Apprdatechange.slice(6, 8);
						var append1 = year1 + "/" + mm1 + "/" + dd1;
						var dataAppr = dateFormat.format(new Date(append1));
						if (ApprdTimechange !== "") {
							var hrs = ApprdTimechange.slice(0, 2);
							var min = ApprdTimechange.slice(2, 4);
							var sec = ApprdTimechange.slice(4, 6);
							var hrsmin = hrs.concat(":" + min);
							var fulltime = hrsmin.concat(":" + sec);
							approverlist[j].APPROVED_TM = fulltime;
						}
						approverlist[j].CREATION_DT = datab;
						approverlist[j].APPROVED_DT = dataAppr;
						that.getModel().setProperty("/ApproverTable/items", []);
						that.getModel().setProperty("/ApproverTable/items", approverlist);
					}
				}.bind(this),
				error: function (response) {
					sap.ui.core.BusyIndicator.hide();
					MessageBox.error(response.responseText);
				}.bind(this)
			});
		},
		onSavePress: function (oEvent) {
			var that = this;
			var backenddata = this.getView().getModel("settingsModel").getProperty("/lineItemData");
			var title = that.getView().byId("idinputTitle").getValue();
			if (title === null || title === undefined) {
				title = "";
			}
			var prepare = this.getView().getModel("settingsModel").getProperty("/prepare");
			if (prepare === null || prepare === undefined || prepare === "") {
				prepare = sap.ushell.Container.getService("UserInfo").getUser().getId();
			}
			var preparefullname = that.getView().byId("idTextPreparer").getText();
			if (preparefullname === null || preparefullname === undefined) {
				preparefullname = "";
			}
			var compcodeid = that.getView().getModel("settingsModel").getProperty("/selectedCompCode");
			if (compcodeid === null || compcodeid === undefined) {
				compcodeid = "";
			}
			var CompDes = this.getView().getModel("settingsModel").getProperty("/CompDes");
			if (CompDes === null || CompDes === undefined) {
				CompDes = "";
			}
			var region = this.getView().getModel("settingsModel").getProperty("/region");
			if (region === null || region === undefined) {
				region = "";
			}
			var regionDes = this.getView().getModel("settingsModel").getProperty("/regionDes");
			if (regionDes === null || regionDes === undefined) {
				regionDes = "";
			}
			var VendorLIFNR = that.getView().getModel("settingsModel").getProperty("/VendorLIFNR");
			if (VendorLIFNR === null || VendorLIFNR === undefined) {
				VendorLIFNR = "";
			}
			var VendorNAME1 = that.getView().getModel("settingsModel").getProperty("/VendorNAME1");
			if (VendorNAME1 === null || VendorNAME1 === undefined) {
				VendorNAME1 = "";
			}
			var backendAmount = that.getView().getModel("settingsModel").getProperty("/Amount");
			if (backendAmount === "" || backendAmount === null || backendAmount === undefined) {
				var Amount = that.getView().byId("idconvertedTextAmount").getValue().replace(/[^,.0-9 ]/g, '');
				if (Amount === null || Amount === undefined) {
					Amount = "";
				}
			} else {
				Amount = backendAmount;
			}
			if (flagCurrency === true) {
				var Currency = this.getView().getModel("settingsModel").getProperty("/Currency");
				if (Currency === null || Currency === undefined) {
					Currency = "";
				}
			} else {
				Currency = that.getView().byId("idCurrency").getValue();
				if (Currency === null || Currency === undefined) {
					Currency = "";
				}
			}
			var selectedDate = that.getView().getModel("settingsModel").getProperty("/selectedDate");
			if (selectedDate === "" || selectedDate === null || selectedDate === undefined) {
				MessageBox.show(
					"Request Date is the mandatory field",
					MessageBox.Icon.ERROR,
					"Error"
				);
				this.getView().byId("idReqdate").setValueState("Error");
				return false;
			} else {
				var format = selectedDate.match(/[/]/g);
				if (format) {
					var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
						pattern: "yyyyMMdd"
					});
					this.getView().byId("idReqdate").setValueState("Success");
					var RequestDate = dateFormat.format(new Date(selectedDate));
				} else {
					RequestDate = selectedDate;
				}
			}
			var selectedPayCompCode = that.getView().getModel("settingsModel").getProperty("/selectedPayCompCode");
			if (selectedPayCompCode === null || selectedPayCompCode === undefined) {
				selectedPayCompCode = "";
			}
			var PayerCompDes = that.getView().getModel("settingsModel").getProperty("/PayerCompDes");
			if (PayerCompDes === null || PayerCompDes === undefined) {
				PayerCompDes = "";
			}
			var REASONID = that.getView().getModel("settingsModel").getProperty("/REASONID");
			if (REASONID === null || REASONID === undefined) {
				REASONID = "";
			}
			var DESCRIPTION = that.getView().getModel("settingsModel").getProperty("/DESCRIPTION");
			if (DESCRIPTION === null || DESCRIPTION === undefined) {
				DESCRIPTION = "";
			}
			var DocLink = that.getView().byId("text_Document").getValue();
			if (DocLink === null || DocLink === undefined) {
				DocLink = "";
			}
			var status = that.getView().getModel("settingsModel").getProperty("/saveStatuss");
			if (status === "" || status === undefined || status === null) {
				status = "S";
			}

			var odataModel = that.getModel("Mprsrvmodel");
			var data = {};
			data = {
				"EFORM_NUM": "",
				"TITLE": title,
				"PREPARER": prepare,
				"PREPARER_FN": preparefullname,
				"PAYER_CCODE": selectedPayCompCode,
				"PAYER_CCODE_DES": PayerCompDes,
				"REGION": region,
				"REGION_DES": regionDes,
				"VENDOR": VendorLIFNR,
				"VENDOR_NAME": VendorNAME1,
				"AMOUNT": Amount,
				"CURRENCY": Currency,
				"REQUEST_DATE": RequestDate,
				"DOC_CCODE": compcodeid,
				"DOC_CCODE_DES": CompDes,
				"REASON": REASONID,
				"REASON_DES": DESCRIPTION,
				"DOCLINK": DocLink,
				"STATUS": status,
				"STATUS_DES": "",
				"CREATE_DATE": "",
				"SUBMIT_DATE": "",
				"APPROVED_DATE": "",
				"ACTION": "Save"
			};
			var formNumber = this.getView().getModel("settingsModel").getProperty("/form_number");
			if (this.form_number === undefined || this.form_number === null || this.form_number === "") {
				this.form_number = formNumber;
			}
			if (!this.form_number) {
				this.form_number = "";
			}
			var result = [];
			var map = new Map();
			for (var item of dataset) {
				if (!map.has(item.IMAGE_ID)) {
					map.set(item.IMAGE_ID, true);
					result.push(item);
				}
			}
			data.ImageSet = [];
			for (var i = 0; i < result.length; i++) {
				result[i].EFORM_NUM = this.form_number;
			}
			data.ImageSet = result;
			var approverData = [];
			// var approvertable = this.getView().byId("tblApprover").getModel().getData();
			var i = null;
			var approved = null;
			var manual = null;
			var createdBy = "";
			var createdByName = "";
			var table = this.getView().byId("tblApprover").getItems();
			var backendApprvList = this.getModel().getProperty("/ApproverTable/items");
			for (i = 0; i < table.length; i++) {
				if (table[i].getCells()[0].getText() === "Approved")
					approved = 'X';
				else {
					approved = '';
				}
				if (approved === "X") {
					var approved_by = table[i].getCells()[11].getText();
				} else {
					var approved_by = "";
				}
				manual = table[i].getCells()[6].data("Flag");
				if (table[i].getCells()[6].getSelected() === true) {
					manual = 'X';
					if (table[i].getCells()[7].getText() === "" || table[i].getCells()[7].getText() === null) {
						createdByName = sap.ushell.Container.getUser().getFullName();
					} else {
						createdByName = table[i].getCells()[7].getText();
					}
					if (table[i].getCells()[10].getText() === "" || table[i].getCells()[10].getText() === null) {
						createdBy = sap.ushell.Container.getService("UserInfo").getUser().getId();
					} else {
						createdBy = table[i].getCells()[10].getText();
					}
				} else {
					manual = '';
					createdBy = "";
					createdByName = "";
				}
				var tempappr;
				if (table[i].getCells()[1].mProperties.value === undefined)
					tempappr = table[i].getCells()[1].getText();
				else
					tempappr = table[i].getCells()[1].getValue();
				if (tempappr === undefined || tempappr === "null" || tempappr === "") {
					MessageBox.alert("Approver field can not be empty");
					return false;
				}
				var approved_dt = table[i].getCells()[4].getText();
				var approved_tm = table[i].getCells()[5].getText().replaceAll(":", "");
				var fgdateformat = table[i].getCells()[8].getText();
				var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
					pattern: "yyyyMMdd"
				});
				var CreateDate = dateFormat.format(new Date(fgdateformat));
				var ApprovedDate = dateFormat.format(new Date(approved_dt));
				approverData.push({
					EFORM_NUM: this.form_number,
					APPR: table[i].getCells()[9].getText(),
					APPR_NAME: tempappr,
					REVIEWER_TYPE: table[i].getCells()[2].getText(),
					APPROVED: approved,
					APPROVED_BY: approved_by,
					APPROVED_BY_NAME: table[i].getCells()[3].getText(),
					APPROVED_DT: ApprovedDate,
					APPROVED_TM: approved_tm,
					SEQUENCE: String(i + 1),
					CREATED_BY: createdBy,
					CREATED_BY_NAME: createdByName,
					CREATION_DT: CreateDate,
					MANUAL: manual
				});
			}
			data.ApproverSet = [];
			data.ApproverSet = approverData;
			data.EFORM_NUM = this.form_number;
			var msg_returned = "";
			var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
			MessageBox.confirm(
				"Do you want to save the form?", {
					actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
					styleClass: bCompact ? "sapUiSizeCompact" : "",
					onClose: function (sAction) {
						if (sAction === "OK") {
							sap.ui.core.BusyIndicator.show();
							odataModel.create('/HeaderdataSet', data, {
								async: false,
								success: function (oData, response) {
									sap.ui.core.BusyIndicator.hide();
									that.form_number = oData.EFORM_NUM;
									var Apprtable = that.getView().byId("tblApprover");
									Apprtable.removeAllItems(true);
									var approverlist = oData.ApproverSet.results;
									for (var j = 0; j < approverlist.length; j++) {
										var datechange = approverlist[j].CREATION_DT;
										var Apprdatechange = approverlist[j].APPROVED_DT;
										var ApprdTimechange = approverlist[j].APPROVED_TM;
										var year = datechange.slice(0, 4);
										var mm = datechange.slice(4, 6);
										var dd = datechange.slice(6, 8);
										var append = year + "/" + mm + "/" + dd;
										var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
											pattern: "MM/dd/yyyy"
										});
										var datab = dateFormat.format(new Date(append));
										var year1 = Apprdatechange.slice(0, 4);
										var mm1 = Apprdatechange.slice(4, 6);
										var dd1 = Apprdatechange.slice(6, 8);
										var append1 = year1 + "/" + mm1 + "/" + dd1;
										var dataAppr = dateFormat.format(new Date(append1));
										if (ApprdTimechange !== "") {
											var hrs = ApprdTimechange.slice(0, 2);
											var min = ApprdTimechange.slice(2, 4);
											var sec = ApprdTimechange.slice(4, 6);
											var hrsmin = hrs.concat(":" + min);
											var fulltime = hrsmin.concat(":" + sec);
											approverlist[j].APPROVED_TM = fulltime;
										}
										approverlist[j].CREATION_DT = datab;
										approverlist[j].APPROVED_DT = dataAppr;
									}
									that.getModel().setProperty("/ApproverTable/items", []);
									that.getModel().setProperty("/ApproverTable/items", approverlist);
									e_form_num = oData.EFORM_NUM;
									that.getView().getModel("settingsModel").setProperty("/form_number", oData.EFORM_NUM);
									that.getView().byId("pagetitle").setText('Manual Payment Request - ' + oData.EFORM_NUM);
									that.getView().getModel("settingsModel").setProperty("/selectedDate", oData.REQUEST_DATE);
									that.getView().getModel("settingsModel").setProperty("/Amount", oData.AMOUNT);
									that.getView().byId("idinputTotalAmount").setValue(oData.AMOUNT);
									if (sap.ushell.Container.getService("UserInfo").getUser().getId() === oData.PREPARER) {
										that.getView().byId("submit_button").setVisible(true);
									} else {
										that.getView().byId("submit_button").setVisible(false);
									}
									if (oData.STATUS === "I") {
										that.getView().byId("submit_button").setVisible(false);
									}
									msg_returned = "Manual Payment Request " + oData.EFORM_NUM + " has been saved successfully.";
									MessageBox.success(
										msg_returned, {
											actions: [MessageBox.Action.OK],
											styleClass: bCompact ? "sapUiSizeCompact" : "",
											onClose: function (sAction) {
												if (sAction === "OK") {
													that.GetDetermineapprlogin(that.form_number);
												} else {
													return false;
												}
											}
										}
									);
								},
								error: function (oError) {
									sap.ui.core.BusyIndicator.hide();
									var response = JSON.parse(oError.responseText);
									MessageBox.show(
										response.error.message.value,
										MessageBox.Icon.ERROR,
										"Error"
									);
								}.bind(this)
							});
						} else {
							if (that.getView().byId('ss').getSrc() !== "") {
								that.getView().byId("b_upload").setVisible(true);
							} else {
								that.getView().byId("b_upload").setVisible(false);
							}
							if (that.getView().byId('idimage1').getSrc() !== "") {
								that.getView().byId("b_upload1").setVisible(true);
							} else {
								that.getView().byId("b_upload1").setVisible(false);
							}
							if (that.getView().byId('idimage2').getSrc() !== "") {
								that.getView().byId("b_upload2").setVisible(true);
							} else {
								that.getView().byId("b_upload2").setVisible(false);
							}
							if (that.getView().byId('idimage3').getSrc() !== "") {
								that.getView().byId("b_upload3").setVisible(true);
							} else {
								that.getView().byId("b_upload3").setVisible(false);
							}
							if (that.getView().byId('idimage4').getSrc() !== "") {
								that.getView().byId("b_upload4").setVisible(true);
							} else {
								that.getView().byId("b_upload4").setVisible(false);
							}
							if (that.getView().byId('idimage5').getSrc() !== "") {
								that.getView().byId("b_upload5").setVisible(true);
							} else {
								that.getView().byId("b_upload5").setVisible(false);
							}
							that.getView().getModel("EnableModel").setProperty("/enabledResetButton", true);
						}
					}
				}
			);
		},
		_onFinalSubmitPress: function () {
			var that = this;
			var backenddata = this.getView().getModel("settingsModel").getProperty("/lineItemData");
			var LoggedUser = sap.ushell.Container.getService("UserInfo").getUser().getId();
			var checkfornewform = this.getView().getModel("EnableModel").getProperty("/Getcontxt");
			if (checkfornewform === true) {
				if (backenddata.PREPARER !== LoggedUser) {
					MessageBox.show(
						"You are not authorized to submit this form",
						MessageBox.Icon.ERROR,
						"Error"
					);
					return false;
				}
			}
			var title = that.getView().byId("idinputTitle").getValue();
			if (title === "" || title === null || title === undefined) {
				this.getView().byId("idinputTitle").setValueState("Error");
				return false;
			} else {
				this.getView().byId("idinputTitle").setValueState("Success");
			}
			var prepare = this.getView().getModel("settingsModel").getProperty("/prepare");
			if (prepare === null || prepare === undefined || prepare === "") {
				prepare = sap.ushell.Container.getService("UserInfo").getUser().getId();
			}
			var preparefullname = that.getView().byId("idTextPreparer").getText();

			var compcodeid = that.getView().getModel("settingsModel").getProperty("/selectedCompCode");
			if (compcodeid === "" || compcodeid === null || compcodeid === undefined) {
				MessageBox.show(
					"Please check for all the mandatory fields",
					MessageBox.Icon.ERROR,
					"Error"
				);
				this.getView().byId("idinputPayerCompny").setValueState("Error");
				return false;
			} else {
				this.getView().byId("idinputPayerCompny").setValueState("Success");
			}
			var CompDes = this.getView().getModel("settingsModel").getProperty("/CompDes");
			var region = this.getView().getModel("settingsModel").getProperty("/region");
			if (region === "" || region === null || region === undefined) {
				this.getView().byId("idinputRegion").setValueState("Error");
				return false;
			} else {
				this.getView().byId("idinputRegion").setValueState("Success");
			}
			var regionDes = this.getView().getModel("settingsModel").getProperty("/regionDes");
			var VendorLIFNR = that.getView().getModel("settingsModel").getProperty("/VendorLIFNR");
			if (VendorLIFNR === "" || VendorLIFNR === null || VendorLIFNR === undefined) {
				MessageBox.show(
					"Please check for all the mandatory fields",
					MessageBox.Icon.ERROR,
					"Error"
				);
				this.getView().byId("idInputVendorID").setValueState("Error");
				return false;
			} else {
				this.getView().byId("idInputVendorID").setValueState("Success");
			}
			var VendorNAME1 = that.getView().getModel("settingsModel").getProperty("/VendorNAME1");
			if (VendorNAME1 === "" || VendorNAME1 === null || VendorNAME1 === undefined) {
				MessageBox.show(
					"Please check for all the mandatory fields",
					MessageBox.Icon.ERROR,
					"Error"
				);
				this.getView().byId("idinputVendorName").setValueState("Error");
				return false;
			} else {
				this.getView().byId("idinputVendorName").setValueState("Success");
			}
			var Amount = that.getView().getModel("settingsModel").getProperty("/Amount");
			if (Amount === "" || Amount === null || Amount === undefined) {
				this.getView().byId("idinputTotalAmount").setValueState("Error");
				MessageBox.show(
					"Please check for all the mandatory fields",
					MessageBox.Icon.ERROR,
					"Error"
				);
				return false;
			} else {
				this.getView().byId("idinputTotalAmount").setValueState("Success");
			}
			if (flagCurrency === true) {
				var Currency = this.getView().getModel("settingsModel").getProperty("/Currency");
				if (Currency === null || Currency === undefined || Currency === "") {
					MessageBox.show(
						"Please check for all the mandatory fields",
						MessageBox.Icon.ERROR,
						"Error"
					);
					this.getView().byId("idCurrency").setValueState("Error");
					return false;
				}
			} else {
				Currency = that.getView().byId("idCurrency").getValue();
				if (Currency === null || Currency === undefined || Currency === "") {
					MessageBox.show(
						"Please check for all the mandatory fields",
						MessageBox.Icon.ERROR,
						"Error"
					);
					this.getView().byId("idCurrency").setValueState("Error");
					return false;
				} else {
					this.getView().byId("idCurrency").setValueState("Success");
				}
			}
			var selectedDate = that.getView().getModel("settingsModel").getProperty("/selectedDate");
			if (selectedDate === "" || selectedDate === null || selectedDate === undefined) {
				MessageBox.show(
					"Please check for all the mandatory fields",
					MessageBox.Icon.ERROR,
					"Error"
				);
				this.getView().byId("idReqdate").setValueState("Error");
				return false;
			} else {
				var format = selectedDate.match(/[/]/g);
				if (format) {
					var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
						pattern: "yyyyMMdd"
					});
					this.getView().byId("idReqdate").setValueState("Success");
					var RequestDate = dateFormat.format(new Date(selectedDate));
				} else {
					RequestDate = selectedDate;
				}
			}
			var selectedPayCompCode = that.getView().getModel("settingsModel").getProperty("/selectedPayCompCode");
			if (selectedPayCompCode === "" || selectedPayCompCode === null || selectedPayCompCode === undefined) {
				MessageBox.show(
					"Please check for all the mandatory fields",
					MessageBox.Icon.ERROR,
					"Error"
				);
				this.getView().byId("idinputDocCompny").setValueState("Error");
				return false;
			} else {
				this.getView().byId("idinputDocCompny").setValueState("Success");
			}
			var PayerCompDes = that.getView().getModel("settingsModel").getProperty("/PayerCompDes");
			if (PayerCompDes === "" || PayerCompDes === null || PayerCompDes === undefined) {
				MessageBox.show(
					"Document Company Description is mandatory field",
					MessageBox.Icon.ERROR,
					"Error"
				);
				return false;
			}
			var REASONID = that.getView().getModel("settingsModel").getProperty("/REASONID");
			if (REASONID === "" || REASONID === null || REASONID === undefined) {
				MessageBox.show(
					"Please check for all the mandatory fields",
					MessageBox.Icon.ERROR,
					"Error"
				);
				this.getView().byId("idReason").setValueState("Error");
				return false;
			} else {
				this.getView().byId("idReason").setValueState("Success");
			}
			var DESCRIPTION = that.getView().getModel("settingsModel").getProperty("/DESCRIPTION");
			if (DESCRIPTION === "" || DESCRIPTION === null || DESCRIPTION === undefined) {
				MessageBox.show(
					"Reason Description is mandatory field",
					MessageBox.Icon.ERROR,
					"Error"
				);
				return false;
			}
			var DocLink = that.getView().byId("text_Document").getValue();
			var DocPayment = this.getView().byId('ss').getSrc().replace("data:" + img_type + ";base64,", "");
			if (DocPayment === "" || DocPayment === null || DocPayment === undefined) {
				MessageBox.show(
					"Documents for Payment Image is mandatory field",
					MessageBox.Icon.ERROR,
					"Error"
				);
				this.getView().byId("idDocPay").setValueState("Error");
				return false;
			}
			var BeneficiaryInfo = this.getView().byId('idimage1').getSrc().replace("data:" + img_type + ";base64,", "");
			if (BeneficiaryInfo === "" || BeneficiaryInfo === null || BeneficiaryInfo === undefined) {
				MessageBox.show(
					"Beneficiary Information Image is mandatory field",
					MessageBox.Icon.ERROR,
					"Error"
				);
				this.getView().byId("idBenInfo").setValueState("Error");
				return false;
			}
			var BankingInfo = this.getView().byId('idimage2').getSrc().replace("data:" + img_type + ";base64,", "");
			if (BankingInfo === "" || BankingInfo === null || BankingInfo === undefined) {
				MessageBox.show(
					"Banking Information Image is mandatory field",
					MessageBox.Icon.ERROR,
					"Error"
				);
				this.getView().byId("idBankingInfo").setValueState("Error");
				return false;
			}
			var InvoiceInfo = this.getView().byId('idimage3').getSrc().replace("data:" + img_type + ";base64,", "");
			if (InvoiceInfo === "" || InvoiceInfo === null || InvoiceInfo === undefined) {
				MessageBox.show(
					"Invoice Information Image is mandatory field",
					MessageBox.Icon.ERROR,
					"Error"
				);
				this.getView().byId("idInvoiceInfo").setValueState("Error");
				return false;
			}
			var InvoicePOCOFA = this.getView().byId('idimage4').getSrc().replace("data:" + img_type + ";base64,", "");
			if (InvoicePOCOFA === "" || InvoicePOCOFA === null || InvoicePOCOFA === undefined) {
				MessageBox.show(
					"Invoice/PO COFA Approval Image is mandatory field",
					MessageBox.Icon.ERROR,
					"Error"
				);
				this.getView().byId("idInvoicePO").setValueState("Error");
				return false;
			}

			this.getView().getModel("settingsModel").setProperty("/sStatuss", "I");
			var status = this.getView().getModel("settingsModel").getProperty("/sStatuss");
			var odataModel = this.getModel("Mprsrvmodel");
			var data = {};
			data = {
				"EFORM_NUM": "",
				"TITLE": title,
				"PREPARER": prepare,
				"PREPARER_FN": preparefullname,
				"DOC_CCODE": compcodeid,
				"DOC_CCODE_DES": CompDes,
				"REGION": region,
				"REGION_DES": regionDes,
				"VENDOR": VendorLIFNR,
				"VENDOR_NAME": VendorNAME1,
				"AMOUNT": Amount,
				"CURRENCY": Currency,
				"REQUEST_DATE": RequestDate,
				"PAYER_CCODE": selectedPayCompCode,
				"PAYER_CCODE_DES": PayerCompDes,
				"REASON": REASONID,
				"REASON_DES": DESCRIPTION,
				"DOCLINK": DocLink,
				"STATUS": status,
				"STATUS_DES": "",
				"CREATE_DATE": "",
				"SUBMIT_DATE": "",
				"APPROVED_DATE": "",
				"ACTION": "Submit"
			};
			var formNumber = this.getView().getModel("settingsModel").getProperty("/form_number");
			if (this.form_number === undefined || this.form_number === null || this.form_number === "") {
				this.form_number = formNumber;
			}

			if (!this.form_number) {
				this.form_number = "";
			}
			var result = [];
			var map = new Map();
			for (var item of dataset) {
				if (!map.has(item.IMAGE_ID)) {
					map.set(item.IMAGE_ID, true);
					result.push(item);
				}
			}
			data.ImageSet = [];
			for (var i = 0; i < result.length; i++) {
				result[i].EFORM_NUM = this.form_number;
			}
			data.ImageSet = result;
			var approverData = [];
			// var approvertable = this.getView().byId("tblApprover").getModel().getData();
			var i = null;
			var approved = null;
			var manual = null;
			var createdBy = "";
			var createdByName = "";
			var table = this.getView().byId("tblApprover").getItems();
			if (table.length === 0) {
				MessageBox.show(
					"System is not able to determine the approval flow",
					MessageBox.Icon.ERROR,
					"Error"
				);
				return false;
			}
			for (i = 0; i < table.length; i++) {
				if (table[i].getCells()[0].getText() === "Approved")
					approved = 'X';
				else {
					approved = '';
				}
				if (approved === "X") {
					var approved_by = table[i].getCells()[11].getText();
				} else {
					var approved_by = "";
				}
				manual = table[i].getCells()[6].data("Flag");
				if (table[i].getCells()[6].getSelected() === true) {
					manual = 'X';
					if (table[i].getCells()[7].getText() === "" || table[i].getCells()[7].getText() === null) {
						createdByName = sap.ushell.Container.getUser().getFullName();
					} else {
						createdByName = table[i].getCells()[7].getText();
					}
					if (table[i].getCells()[10].getText() === "" || table[i].getCells()[10].getText() === null) {
						createdBy = sap.ushell.Container.getService("UserInfo").getUser().getId();
					} else {
						createdBy = table[i].getCells()[10].getText();
					}
				} else {
					manual = '';
					createdBy = "";
					createdByName = "";
				}
				var tempappr;
				if (table[i].getCells()[1].mProperties.value === undefined)
					tempappr = table[i].getCells()[1].getText();
				else
					tempappr = table[i].getCells()[1].getValue();
				if (tempappr === undefined || tempappr === "null" || tempappr === "") {
					MessageBox.alert("Approver field Can not be empty");
					return false;
				}
				var approved_dt = table[i].getCells()[4].getText();
				var approved_tm = table[i].getCells()[5].getText().replaceAll(":", "");
				var fgdateformat = table[i].getCells()[8].getText();
				var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
					pattern: "yyyyMMdd"
				});
				var CreateDate = dateFormat.format(new Date(fgdateformat));
				var ApprovedDate = dateFormat.format(new Date(approved_dt));
				approverData.push({
					EFORM_NUM: this.form_number,
					APPR: table[i].getCells()[9].getText(),
					APPR_NAME: tempappr,
					REVIEWER_TYPE: table[i].getCells()[2].getText(),
					APPROVED: approved,
					APPROVED_BY: approved_by,
					APPROVED_BY_NAME: table[i].getCells()[3].getText(),
					APPROVED_DT: ApprovedDate,
					APPROVED_TM: approved_tm,
					SEQUENCE: String(i + 1),
					CREATED_BY: createdBy,
					CREATED_BY_NAME: createdByName,
					CREATION_DT: CreateDate,
					MANUAL: manual
				});
			}
			var backendApprvList = this.getModel().getProperty("/ApproverTable/items");
			data.ApproverSet = [];
			data.ApproverSet = approverData;
			data.EFORM_NUM = this.form_number;
			var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
			var msg_returned = "";
			MessageBox.confirm(
				"Do you want to submit?", {
					actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
					styleClass: bCompact ? "sapUiSizeCompact" : "",
					onClose: function (sAction) {
						if (sAction === "OK") {
							sap.ui.core.BusyIndicator.show();
							odataModel.create('/HeaderdataSet', data, {
								async: false,
								success: function (oData, response) {
									sap.ui.core.BusyIndicator.hide();
									that.getView().getModel("settingsModel").setProperty("/saveStatuss", "I");
									that.getView().getModel("settingsModel").setProperty("/form_number", oData.EFORM_NUM);
									e_form_num = oData.EFORM_NUM;
									that.getView().byId("pagetitle").setText('Manual Payment Request - ' + oData.EFORM_NUM);
									that.form_number = oData.EFORM_NUM;
									that.getView().getModel("settingsModel").setProperty("/selectedDate", oData.REQUEST_DATE);
									that.getView().getModel("settingsModel").setProperty("/Amount", oData.AMOUNT);
									that.getView().byId("idinputTotalAmount").setValue(oData.AMOUNT);
									var Apprtable = that.getView().byId("tblApprover");
									Apprtable.removeAllItems(true);
									var approverlist = oData.ApproverSet.results;
									for (var j = 0; j < approverlist.length; j++) {
										var datechange = approverlist[j].CREATION_DT;
										var Apprdatechange = approverlist[j].APPROVED_DT;
										var ApprdTimechange = approverlist[j].APPROVED_TM;
										var year = datechange.slice(0, 4);
										var mm = datechange.slice(4, 6);
										var dd = datechange.slice(6, 8);
										var append = year + "/" + mm + "/" + dd;
										var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
											pattern: "MM/dd/yyyy"
										});
										var datab = dateFormat.format(new Date(append));
										var year1 = Apprdatechange.slice(0, 4);
										var mm1 = Apprdatechange.slice(4, 6);
										var dd1 = Apprdatechange.slice(6, 8);
										var append1 = year1 + "/" + mm1 + "/" + dd1;
										var dataAppr = dateFormat.format(new Date(append1));
										if (ApprdTimechange !== "") {
											var hrs = ApprdTimechange.slice(0, 2);
											var min = ApprdTimechange.slice(2, 4);
											var sec = ApprdTimechange.slice(4, 6);
											var hrsmin = hrs.concat(":" + min);
											var fulltime = hrsmin.concat(":" + sec);
											approverlist[j].APPROVED_TM = fulltime;
										}
										approverlist[j].CREATION_DT = datab;
										approverlist[j].APPROVED_DT = dataAppr;
									}
									that.getModel().setProperty("/ApproverTable/items", []);
									that.getModel().setProperty("/ApproverTable/items", approverlist);
									that.getView().getModel("EnableModel").setProperty("/enabled", false);
									that.getView().getModel("EnableModel").setProperty("/enabledVendorID", false);
									that.getView().getModel("EnableModel").setProperty("/enabledTextAreaImage", false);
									that.getView().getModel("EnableModel").setProperty("/enabledResetButton", false);
									that.getView().byId("idCommuformUploader").setEnabled(false);
									that.getView().getModel("EnableModel").setProperty("/enabledupload", true);
									that.getView().getModel("EnableModel").setProperty("/enabledAttachment", true);
									that.getView().getModel("EnableModel").setProperty("/enabledComment", true);
									that.getView().byId("submit_button").setVisible(false);
									that.getView().byId("b_delete").setVisible(true);
									that.getView().byId("b_edit").setVisible(false);
									dataset = [];
									msg_returned = "Manual Payment Request " + oData.EFORM_NUM + " has been submitted successfully for approval.";
									MessageBox.success(
										msg_returned, {
											actions: [MessageBox.Action.OK],
											styleClass: bCompact ? "sapUiSizeCompact" : "",
											onClose: function (sAction) {
												if (sAction === "OK") {
													that.GetDetermineapprlogin(that.form_number);
												} else {
													return false;
												}
											}
										}
									);
								},
								error: function (oError) {
									sap.ui.core.BusyIndicator.hide();
									var response = JSON.parse(oError.responseText);
									MessageBox.show(
										response.error.message.value,
										MessageBox.Icon.ERROR,
										"Error"
									);
								}.bind(this)
							});
						}
					}
				}
			);
		},
		GetDetermineapprlogin: function (contextName) {
			var that = this;
			sap.ui.core.BusyIndicator.show();
			var oFilter = new sap.ui.model.Filter(
				"EFORM_NUM",
				sap.ui.model.FilterOperator.EQ, contextName
			);
			var oModel = that.getModel("Mprsrvmodel");
			oModel.read("/DetermineapprloginSet", {
				method: "GET",
				filters: [oFilter],
				success: function (oData, response) {
					sap.ui.core.BusyIndicator.hide();
					that.getModel().setProperty("/Determine/items", oData.results);
					if (oData.results[0].MSG_TYPE === "S") {
						that.getView().byId("b_approve").setVisible(true);
						that.getView().byId("b_reject").setVisible(true);
					} else {
						that.getView().byId("b_approve").setVisible(false);
						that.getView().byId("b_reject").setVisible(false);
					}

				}.bind(this),
				error: function (response) {
					sap.ui.core.BusyIndicator.hide();
					MessageBox.error(response.responseText);
				}.bind(this)
			});
		},
		_displayEmployees: function (oEvent) {
			var that = this;
			var username = oEvent.getSource().getText();
			var selected_item = oEvent.getSource().getBindingContext().getPath();
			var spath = selected_item.slice(21);
			var Index = parseInt(spath);
			var backendApprvList = this.getModel().getProperty("/ApproverTable/items");
			var sDept = backendApprvList[Index].APPR;
			var oFilterFormType = new sap.ui.model.Filter("FORMTYP", sap.ui.model.FilterOperator.EQ, "MPR");
			var oFilterRole = new sap.ui.model.Filter("ROLE", sap.ui.model.FilterOperator.EQ, sDept);
			var gatewayUrl = "/sap/opu/odata/sap/YFPSFIFRDD0037_MPR_EFORM_SRV/";
			var oModel = new sap.ui.model.odata.ODataModel(gatewayUrl, true);
			oModel.read("/ApprovergrpSet", {
				async: false,
				filters: [oFilterFormType, oFilterRole],
				success: function (oData, oResponse) {
					if (!that._oPopover) {
						that._oPopover = sap.ui.xmlfragment("com.spe.ManualPayReq.YMPR_FORM.fragments.Approvals", that);
						that.getView().addDependent(that._oPopover);
					}
					var event = oEvent.getSource();
					that._oPopover.openBy(event);
					that.getModel().setProperty("/DisplayEmployee/items", oData.results);
				},
				error: function (oError) {
					sap.m.MessageBox.show(oError.message, {
						icon: MessageBox.Icon.ERROR,
						title: "Error"
					});
				}
			});
		},
		onPressApprove: function () {
			var that = this;
			var msg_returned = "";
			var n = new sap.ui.model.Filter("EFORM_NUM", sap.ui.model.FilterOperator.EQ, that.form_number);
			var n1 = new sap.ui.model.Filter("ACTION", sap.ui.model.FilterOperator.EQ, "A");
			var myFilter = [];
			myFilter.push(n);
			myFilter.push(n1);
			var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
			MessageBox.confirm(
				"Do you want to Approve this form?", {
					actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
					styleClass: bCompact ? "sapUiSizeCompact" : "",
					onClose: function (sAction) {
						if (sAction === "OK") {
							var oModel = that.getModel("Mprsrvmodel");
							oModel.read("/ValidateapprovalSet", {
								method: "GET",
								filters: myFilter,
								success: function (oData, response) {
									var msg_type = response.data.results[0].MSG_TYPE;
									if (msg_type == "E") {
										msg_returned = response.data.results[0].MSG + ".";
									} else {
										msg_returned = "The form has been successfully approved";
									}
									var bCompact = !!that.getView().$().closest(".sapUiSizeCompact").length;
									MessageBox.success(
										msg_returned, {
											actions: [MessageBox.Action.OK],
											styleClass: bCompact ? "sapUiSizeCompact" : "",
											onClose: function (sAction) {
												if (sAction === "OK") {
													that.oRouter.navTo("default", {
														from: "ManualPayCreate1"
													}, false);
												} else {
													return false;
												}
											}
										}
									);
								},
								error: function (oError) {
									var response = JSON.parse(oError.responseText);
									MessageBox.show(
										response.error.message.value,
										MessageBox.Icon.ERROR,
										"Error"
									);
								}.bind(this)
							});
						} else {
							return false;
						}
					}
				}
			);
		},
		onPressReject: function () {
			var that = this;
			var msg_returned = "";
			var n = new sap.ui.model.Filter("EFORM_NUM", sap.ui.model.FilterOperator.EQ, that.form_number);
			var n1 = new sap.ui.model.Filter("ACTION", sap.ui.model.FilterOperator.EQ, "R");
			var myFilter = [];
			myFilter.push(n);
			myFilter.push(n1);
			var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
			MessageBox.confirm(
				"Do you want to Reject this form?", {
					actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
					styleClass: bCompact ? "sapUiSizeCompact" : "",
					onClose: function (sAction) {
						if (sAction === "OK") {
							var oModel = that.getModel("Mprsrvmodel");
							oModel.read("/ValidateapprovalSet", {
								method: "GET",
								filters: myFilter,
								success: function (oData, response) {
									var msg_type = response.data.results[0].MSG_TYPE;
									if (msg_type == "E") {
										msg_returned = response.data.results[0].MSG + ".";
									} else {
										msg_returned = "The form has been rejected successfully";
									}
									var bCompact = !!that.getView().$().closest(".sapUiSizeCompact").length;
									MessageBox.success(
										msg_returned, {
											actions: [MessageBox.Action.OK],
											styleClass: bCompact ? "sapUiSizeCompact" : "",
											onClose: function (sAction) {
												if (sAction === "OK") {
													that.oRouter.navTo("default", {
														from: "ManualPayCreate1"
													}, false);
												} else {
													return false;
												}
											}
										}
									);
								},
								error: function (oError) {
									var response = JSON.parse(oError.responseText);
									MessageBox.show(
										response.error.message.value,
										MessageBox.Icon.ERROR,
										"Error"
									);
								}.bind(this)
							});
						} else {
							return false;
						}
					}
				}
			);
		},
		onPrintPress: function () {
			var i;
			var oBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			var commtTable = this.getView().byId("commentList1").getItems();
			var appTable = this.getView().byId("tblApprover1").getItems();
			var attTable = this.getView().byId("t_attachment11").getItems();
			var imageURL = this.getView().byId("ss1").getSrc();
			var imageURL1 = this.getView().byId("idimage1").getSrc();
			var imageURL2 = this.getView().byId("idimage2").getSrc();
			var imageURL3 = this.getView().byId("idimage3").getSrc();
			var imageURL4 = this.getView().byId("idimage4").getSrc();
			var imageURL5 = this.getView().byId("idimage5").getSrc();

			var table1 = "";
			var tableApprover = "";
			var attachtable = "";
			if (commtTable.length > 0) {
				table1 =
					"<table width='100%'><thead align='left'><tr><th>" + oBundle.getText("Comments") + "</th></tr>" +
					"</thead><tr><td style='border:1px solid black;'>" + oBundle.getText("Added By") +
					"</td><td style='border:1px solid black;'>" + oBundle.getText("Comments") +
					"</td><td style='border:1px solid black;'>" +
					oBundle.getText("Added On") +
					" </td>" +
					"</td></tr>";
				for (var i = 0; i < commtTable.length; i++) {
					table1 = table1 + "<tr><td style='border:1px solid black;white-space:pre-wrap; word-wrap:break-word'nowrap >" + commtTable[i].mProperties
						.sender +
						"</td><td style='border:1px solid black;white-space:pre-wrap; word-wrap:break-word' nowrap >" +
						commtTable[i].mProperties.text + "</td><td style='border:1px solid black;'>" +
						commtTable[i].mProperties.timestamp + "</td>" +
						'</tr>';
				}
				table1 = table1 + '</table>';
			}
			if (appTable.length > 0) {
				var tableApprover =
					"<table width='100%'><thead align='left'><tr><th>" + oBundle.getText("Approvers") + "</th></tr>" +
					"</thead><tr><td style='border:1px solid black;'>" + oBundle.getText("Approved/Rejected") +
					"</td><td style='border:1px solid black;'>" + oBundle.getText("Approver") +
					"</td><td style='border:1px solid black;'>" + oBundle.getText("ReviewerType") + " </td>" +
					"<td style='border:1px solid black;'>" + oBundle.getText("Action By") +
					"</td><td style='border:1px solid black;'>" + oBundle.getText("Date") + " </td>" + "<td style='border:1px solid black;'>" +
					oBundle.getText("Time(PST)") + " </td>" + "<td style='border:1px solid black;'>" +
					oBundle.getText("ManualAddition") + " </td>" + "<td style='border:1px solid black;'>" +
					oBundle.getText("AddedBy") + " </td>" + "<td style='border:1px solid black;'>" +
					oBundle.getText("AddedOn") + " </td>"
				"</tr>";
				for (var i = 0; i < appTable.length; i++) {
					var isApproved = "";
					var isManual = "";
					if (appTable[i].mAggregations.cells[0].mProperties.text === "") {
						isApproved = "";
					} else {
						isApproved = "";
					}
					if (appTable[i].mAggregations.cells[0].mProperties.text === "Approved") {
						isApproved = "Approved";
					}
					if (appTable[i].mAggregations.cells[0].mProperties.text === "Rejected") {
						isApproved = "Rejected";
					}
					if (appTable[i].mAggregations.cells[6].mProperties.selected === true) {
						isManual = "Yes";
					} else {
						isManual = "No";
					}
					tableApprover = tableApprover +
						"<tr><td style='border:1px solid black;'>" + isApproved + "</td><td style='border:1px solid black;'> " + appTable[i].mAggregations
						.cells[1].getText() + "</td><td style='border:1px solid black;'>" +
						appTable[i].mAggregations.cells[2].getText() + "</td><td style='border:1px solid black;'>" +
						appTable[i].mAggregations.cells[3].getText() +
						"</td><td style='border:1px solid black;'>" + appTable[i].mAggregations.cells[4].getText() +
						"</td><td style='border:1px solid black;'>" + appTable[i].mAggregations.cells[5].getText() + " </td>" +
						"<td style='border:1px solid black;'>" + isManual + " </td><td style='border:1px solid black;'>" + appTable[i].mAggregations.cells[
							7].getText() + " </td><td style='border:1px solid black;'>" +
						appTable[i].mAggregations.cells[8].getText() + "</td></tr>";
				}
				tableApprover = tableApprover + "</table>"
			};
			if (attTable.length > 0) {
				attachtable =
					"<table width='100%'><thead align='left'><tr><th>" + oBundle.getText("Attachments") + "</th>" +
					"</tr></thead><tr><td style='border:1px solid black;'>" +
					oBundle.getText("FileName") + "</td><td style='border:1px solid black;'>" +
					oBundle.getText("CreationDate") + "</td><td style='border:1px solid black;'>" +
					oBundle.getText("CreationTime(PST)") +
					" </td>" +
					"<td style='border:1px solid black;'>" + oBundle.getText("FileSize") +
					"</td><td style='border:1px solid black;'>" + oBundle.getText("Creator") +
					"</td></tr>";
				for (var i = 0; i < attTable.length; i++) {
					attachtable = attachtable + "<tr><td style='border:1px solid black;'>" + attTable[i].mAggregations.cells[0].getText() +
						"</td><td style='border:1px solid black;'>" + attTable[i].mAggregations.cells[1].getText() +
						"</td><td style='border:1px solid black;'>" +
						attTable[i].mAggregations.cells[2].getText() + "</td><td style='border:1px solid black;'>" +
						attTable[i].mAggregations.cells[3].getText() + "</td>" + "<td style='border:1px solid black;'>" +
						attTable[i].mAggregations.cells[4].getText() + "</td>" +
						'</tr>';
				}
				attachtable = attachtable + '</table>';
			}
			var header1 =
				"<tr><td style='border:1px solid black;'>" + oBundle.getText("Title") + "</td><td style='border:1px solid black;'>" +
				this.getView().byId("idTextTitle").getText() + "</td></tr>" +
				"<tr><td style='border:1px solid black;'>" + oBundle.getText("Preparer") + "</td><td style='border:1px solid black;'>" +
				this.getView().byId("idTextPreparer1").getText() + "</td></tr>" +
				"<tr><td style='border:1px solid black;'>" + oBundle.getText("Payer Company code") + "</td><td style='border:1px solid black;'>" +
				this.getView().byId("idTextPaycomCode").getText() + "</td></tr>" +
				"<tr><td style='border:1px solid black;'>" + oBundle.getText("regionDes") + "</td><td style='border:1px solid black;'>" +
				this.getView().byId("idTextRegion").getText() + "</td></tr>" +
				"<tr><td style='border:1px solid black;'>" + oBundle.getText("Vendor SAP ID Number") + "</td><td style='border:1px solid black;'>" +
				this.getView().byId("idTextVendorID").getText() + "</td></tr>" +
				"<tr><td style='border:1px solid black;'>" + oBundle.getText("Vendor SAP Name") + "</td><td style='border:1px solid black;'>" +
				this.getView().byId("idTextVendorName").getText() + "</td></tr>" +
				"<tr><td style='border:1px solid black;'>" + oBundle.getText("Amount") + "</td><td style='border:1px solid black;'>" +
				this.getView().byId("idTextAmount").getText() + "</td></tr>" +
				"<tr><td style='border:1px solid black;'>" + oBundle.getText("Currency") + "</td><td style='border:1px solid black;'>" +
				this.getView().byId("idTextCurrency").getText() + "</td></tr>" +
				"<tr><td style='border:1px solid black;'>" + oBundle.getText("Request Date") + "</td><td style='border:1px solid black;'>" +
				this.getView().byId("idTextReqDate").getText() + "</td></tr>" +
				"<tr><td style='border:1px solid black;'>" + oBundle.getText("Document Company") +
				"</td><td style='border:1px solid black;'>" +
				this.getView().byId("idTextDocComp").getText() + "</td></tr>" +
				"<tr><td style='border:1px solid black;'>" + oBundle.getText("Reason") +
				"</td><td style='border:1px solid black;'>" +
				this.getView().byId("idTextReason").getText() + "</td></tr>" + "<tr><td style='border:1px solid black;'>" + oBundle.getText(
					"Document Link") + "</td><td style='border:1px solid black;'>" +
				this.getView().byId("idTextDocLink").getText() + "</td></tr>" +
				" </h1> " +
				"</body>" + "</td></tr>";
			var images =
				"<tr><td style='border:1px solid black;'>" + oBundle.getText(
					"Documents for Payment") + "</td><td style='border:1px solid black;'>" +
				"<body><img src='" + imageURL +
				"' style='width:auto;height:auto;'> <h1 style='text-align: center;'> " +
				" </h1> " +
				"</body>" + "<tr><td style='border:1px solid black;'>" + oBundle.getText(
					"Beneficiary Information") + "</td><td style='border:1px solid black;'>" + "<body><img src='" + imageURL1 +
				"' style='width:auto;height:auto;'> <h1 style='text-align: center;'> " +
				" </h1> " +
				"</body>" + "<tr><td style='border:1px solid black;'>" + oBundle.getText(
					"Banking Information") + "</td><td style='border:1px solid black;'>" + "<body><img src='" + imageURL2 +
				"' style='width:auto;height:auto;'> <h1 style='text-align: center;'> " +
				" </h1> " +
				"</body>" + "<tr><td style='border:1px solid black;'>" + oBundle.getText(
					"Invoice Information") + "</td><td style='border:1px solid black;'>" + "<body><img src='" + imageURL3 +
				"' style='width:auto;height:auto;'> <h1 style='text-align: center;'> " +
				" </h1> " +
				"</body>" + "<tr><td style='border:1px solid black;'>" + oBundle.getText(
					"Invoice/PO COFA Approval") + "</td><td style='border:1px solid black;'>" + "<body><img src='" + imageURL4 +
				"' style='width:auto;height:auto;'> <h1 style='text-align: center;'> " +
				" </h1> " +
				"</body>" + "<tr><td style='border:1px solid black;'>" + oBundle.getText(
					"Communication Information") + "</td><td style='border:1px solid black;'>" + "<body><img src='" + imageURL5 +
				"' style='width:auto;height:auto;'> <h1 style='text-align: center;'> " +
				" </h1> " +
				"</body>" + "</td></tr>";
			var header =
				"<body><table width='100%' ><tr><th style='border:1px solid black; background-color: #dddddd;'>" + this.getView().byId(
					"pagetitle")
				.getText() + "</th></tr></table>" +
				"<table width='100%'><thead align='left'><tr><th>" + oBundle.getText("Details") + "</th>" + header1 +
				"</body>";
			var itemsimage =
				"<body><table width='100%'><thead align='left'><tr><th>" + oBundle.getText("Documents") + "</th>" + images +
				"</body>";
			var cltstrng = "width=500px,height=600px";
			var wind = window.open("", cltstrng);
			wind.document.write(header + itemsimage + tableApprover + attachtable + table1);
			// wind.save();
			wind.print();
			// wind.close();
		},
		onExit: function () {
			dataset = [];
		}
	});
});