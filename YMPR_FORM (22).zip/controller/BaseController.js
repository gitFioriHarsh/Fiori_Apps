	sap.ui.define([
		"sap/ui/core/mvc/Controller",
		"sap/ui/model/json/JSONModel",
		"sap/ui/core/routing/History"
	], function (Controller, JSONModel, History) {
		"use strict";
		return Controller.extend("com.spe.ManualPayReq.YMPR_FORM.controller.BaseController", {
			getModel: function (sName) {
				return this.getOwnerComponent().getModel(sName);
			},
			getRouter: function () {
				return sap.ui.core.UIComponent.getRouterFor(this);
			}
		});
	});