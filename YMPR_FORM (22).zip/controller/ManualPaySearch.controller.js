sap.ui.define([
	"./BaseController",
	'jquery.sap.global',
	"sap/ui/model/json/JSONModel",
	'sap/ui/core/Fragment',
	"sap/m/MessageToast",
	"sap/m/MessageBox",
	"sap/ui/core/routing/History",
	"sap/ui/model/Sorter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/FilterType",
	"sap/ui/core/format/DateFormat"
], function (BaseController, jQuery, JSONModel, Fragment, MessageToast, MessageBox, History, Sorter, Filter,
	FilterOperator, FilterType, DateFormat) {
	"use strict";
	var GlobalData;
	var num;
	var clicks = 1;
	return BaseController.extend("com.spe.ManualPayReq.YMPR_FORM.controller.ManualPaySearch", {
		onInit: function (oEvent) {
			var me = this;
			var style = "sapUiSizeCompact";
			me.getView().addStyleClass(style);
			this.oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this.oRouter.attachRouteMatched(this._onObjectMatched, this);
			me.getModel().setData({
				TableData: {
					items: []
				},
				InitialuserinfoSet: {
					items: []
				},
				CompanyCodeSet: {
					items: []
				},
				VendorID: {
					items: []
				},
				UserlistSet: {
					items: []
				},
				SearchEmployee: {
					items: []
				}
			});
			var oModelSearch = new JSONModel({
				busy: false,
				lineItemData: [],
				BarAndTable: false,
				SearchButtonVisible: true,
				FooterButton: false
			});
			this.getView().setModel(oModelSearch, "settingsModel");
			this.getInitialuserinfoSet();
		},
		_onObjectMatched: function (oEvent) {
			var me = this;
			var back = oEvent.getParameter("name");
			if (back === "default") {
				me.getModel().setData({
					TableData: {
						items: []
					},
					InitialuserinfoSet: {
						items: []
					},
					CompanyCodeSet: {
						items: []
					},
					VendorID: {
						items: []
					},
					UserlistSet: {
						items: []
					},
					SearchEmployee: {
						items: []
					}
				});
				var oModelSearch = new JSONModel({
					busy: false,
					lineItemData: [],
					BarAndTable: false,
					SearchButtonVisible: true,
					FooterButton: false
				});
				this.getView().setModel(oModelSearch, "settingsModel");
				if (GlobalData !== undefined) {
					this.getModel().setProperty("/TableData/items", []);
					this.getModel().setProperty("/TableData/items", GlobalData);
				}
			}
		},
		getInitialuserinfoSet: function (selectedUser) {
			var me = this;
			var UserID = sap.ushell.Container.getService("UserInfo").getUser().getId();
			var oModel = me.getModel("Mprsrvmodel");
			oModel.read("/InitialuserinfoSet('" + UserID + "')", {
				method: "GET",
				success: function (oData, response) {
					me.getModel().setProperty("/InitialuserinfoSet/items", oData);
					me.getView().byId("idinputPrepare").setValue(oData.FIRSTNAME + " " + oData.LASTNAME);
					me.getView().getModel("settingsModel").setProperty("/idPrepare", oData.USERID);
				}.bind(this),
				error: function (response) {
					MessageBox.error(response.responseText);
				}.bind(this)
			});
		},
		onCreatePressFromSearch: function (oEvent) {
			var oRouter = this.getOwnerComponent().getRouter();
			oRouter.navTo("ManualPayCreate1", true);
		},
		onPressLink: function (oEvent) {
			var data = oEvent.getSource().getProperty("text");
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("ManualPayCreate", {
				"ID": data
			});
		},
		copy_eform: function (oEvent) {
			var selected_item = this.getView().byId("tableid").getSelectedItem();
			var eform_num = selected_item.mAggregations.cells[0].mProperties.text;
			if (eform_num !== "") {
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("ManualPayCreate", {
					ID: eform_num + '#copy'
				});
			}
		},
		onStatuschange: function (oEvent) {
			var selectedFPY = oEvent.getParameters().value;
			var selectedStatusKey = oEvent.getSource().getSelectedKey();
			this.getView().byId("form_status").setValue(selectedFPY);
			this.getView().getModel("settingsModel").setProperty("/selectedStatusKey", selectedStatusKey);
			var newval = oEvent.getParameter("newValue");
			var key = oEvent.getSource().getSelectedItem();

			if (newval !== "" && key === null) {
				oEvent.getSource().setValue("");
				oEvent.getSource().setValueState("Error");
				MessageToast.show("Please select from drop down list");
			} else {
				oEvent.getSource().setValueState("None");
			}
		},
		onValueHelpPress: function (oEvent) {
			var FilterID = oEvent.getParameters().id.split('-').pop();
			if (FilterID === "idinputPrepare") {
				var preparevaluehelp = oEvent.getParameters().id.split('-').pop();
				this.getView().getModel("settingsModel").setProperty("/preparevaluehelp", preparevaluehelp);
				if (!this.PreDialog) {
					this.PreDialog = this.loadFragment({
						name: "com.spe.ManualPayReq.YMPR_FORM.fragments.UserList"
					});
				}
				this.PreDialog.then(function (oDialog) {
					this._oPreID = oDialog;
					oDialog.open();
				}.bind(this));
				this.getUserlistSet();
			}
			if (FilterID === "idinputAppBy") {
				var AppByvaluehelp = oEvent.getParameters().id.split('-').pop();
				this.getView().getModel("settingsModel").setProperty("/AppByvaluehelp", AppByvaluehelp);
				if (!this.PreDialog) {
					this.PreDialog = this.loadFragment({
						name: "com.spe.ManualPayReq.YMPR_FORM.fragments.UserList"
					});
				}
				this.PreDialog.then(function (oDialog) {
					this._oPreID = oDialog;
					oDialog.open();
				}.bind(this));
				this.getUserlistSet();
			}
			if (FilterID === "idinputApprover") {
				var ApproverValuehelp = oEvent.getParameters().id.split('-').pop();
				this.getView().getModel("settingsModel").setProperty("/ApproverValuehelp", ApproverValuehelp);
				if (!this.PreDialog) {
					this.PreDialog = this.loadFragment({
						name: "com.spe.ManualPayReq.YMPR_FORM.fragments.UserList"
					});
				}
				this.PreDialog.then(function (oDialog) {
					this._oPreID = oDialog;
					oDialog.open();
				}.bind(this));
				this.getUserlistSet();
			}
			if (FilterID === "idinputCompany" || FilterID === "idinputDocCom") {
				var compcodeid = oEvent.getParameters().id.split('-').pop();
				this.getView().getModel("settingsModel").setProperty("/compcodeid", compcodeid);
				if (!this.CDialog) {
					this.CDialog = this.loadFragment({
						name: "com.spe.ManualPayReq.YMPR_FORM.fragments.CompanyCode"
					});
				}
				this.CDialog.then(function (oDialog) {
					this._oCCD = oDialog;
					oDialog.open();
				}.bind(this));
				this.getCompanycodeSet();
			}
			if (FilterID === "idinputVendorID") {
				var vendorID = oEvent.getParameters().id.split('-').pop();
				this.getView().getModel("settingsModel").setProperty("/vendorID", vendorID);
				if (!this.VDialog) {
					this.VDialog = this.loadFragment({
						name: "com.spe.ManualPayReq.YMPR_FORM.fragments.SearchVendorSAPID"
					});
				}
				this.VDialog.then(function (oDialog) {
					this._oVID = oDialog;
					oDialog.open();
				}.bind(this));
				var me = this;
				var name1 = "";
				var CompCode = this.getView().byId("idinputCompany").getValue();
				var oFilter = new sap.ui.model.Filter(
					"BUKRS",
					sap.ui.model.FilterOperator.EQ, CompCode
				);
				var oFilter1 = new sap.ui.model.Filter(
					"NAME1",
					sap.ui.model.FilterOperator.EQ, name1
				);
				num = "";
				num = 20;
				var oModel = me.getModel("Mprsrvmodel");
				oModel.read("/VendorSet?$skip=0&$top=" + num + "", {
					filters: [oFilter, oFilter1],
					success: function (oData, response) {
						me.getModel().setProperty("/VendorID/items", []);
						me.getModel().setProperty("/VendorID/items", oData.results);
					}
				});
			}
		},
		onNext: function () {
			if (clicks < 0) {
				clicks = 0;
				clicks += 1;
			} else {
				clicks += 1;
			};
			num = clicks * 20;
			this.getVendorIDSet();
		},
		onCloseDialogCompCode: function (oEvent) {
			this.getView().byId("idsearchCompCode").setValue(null);
			var oFilter = new sap.ui.model.Filter("BUTXT", sap.ui.model.FilterOperator.Contains, "");
			var oFilter1 = new sap.ui.model.Filter("BUKRS", sap.ui.model.FilterOperator.Contains, "");
			var comFil = new sap.ui.model.Filter([oFilter, oFilter1]);
			var oList = this.getView().byId("idlistcomp");
			oList.getBinding("items").filter(comFil, sap.ui.model.FilterType.Application);
			this._oCCD.close();
		},
		onCloseDialogVendorID: function () {
			this.getView().byId("idsearchVendorID").setValue(null);
			this._oVID.close();
		},
		onCloseDialogSearch: function (oEvent) {
			this.getView().byId("idsearchUsers").setValue(null);
			var oFilter = new sap.ui.model.Filter("FIRSTNAME", sap.ui.model.FilterOperator.Contains, "");
			var oFilter1 = new sap.ui.model.Filter("USERNAME", sap.ui.model.FilterOperator.Contains, "");
			var comFil = new sap.ui.model.Filter([oFilter, oFilter1]);
			var oList = this.getView().byId("idlist");
			oList.getBinding("items").filter(comFil, sap.ui.model.FilterType.Application);
			this._oPreID.close();

		},
		getCompanycodeSet: function () {
			var me = this;
			sap.ui.core.BusyIndicator.show();
			var oModel = me.getModel("Mprsrvmodel");
			oModel.read("/CompanycodeSet", {
				method: "GET",
				success: function (oData, response) {
					sap.ui.core.BusyIndicator.hide();
					me.getModel().setProperty("/CompanyCodeSet/items", oData.results);
				}.bind(this),
				error: function (response) {
					sap.ui.core.BusyIndicator.hide();
					MessageBox.error(response.responseText);
				}.bind(this)
			});
		},
		getVendorIDSet: function () {
			var me = this;
			var name1 = this.getView().byId("idsearchVendorID").getValue();
			var CompCode = this.getView().getModel("settingsModel").getProperty("/selectedCompCode");
			var gatewayUrl = "/sap/opu/odata/sap/YFPSFIFRDD0037_MPR_EFORM_SRV/";
			var oModel3 = new sap.ui.model.odata.ODataModel(gatewayUrl);
			var spath = "/VendorSet?$skip=0&$top=" + num + "&$filter=BUKRS eq" + "'" + CompCode + "'" + "and NAME1 eq" + "'" + name1 + "'";
			oModel3.read(spath, null, null, true, function (oData) {
				me.getModel().setProperty("/VendorID/items", []);
				me.getModel().setProperty("/VendorID/items", oData.results);
			});
		},
		getUserlistSet: function (oEvent) {
			var me = this;
			sap.ui.core.BusyIndicator.show();
			var oModel = me.getModel("Mprsrvmodel");
			oModel.read("/UserlistSet", {
				method: "GET",
				success: function (oData, response) {
					me.getModel().setProperty("/UserlistSet/items", oData.results);
					sap.ui.core.BusyIndicator.hide();
				}.bind(this),
				error: function (response) {
					MessageBox.error(response.responseText);
					sap.ui.core.BusyIndicator.hide();
				}.bind(this)
			});
		},
		_handleItemPress: function (oEvent) {
			var compcodeid = "";
			compcodeid = this.getView().getModel("settingsModel").getProperty("/compcodeid");
			var selectedCompCode = oEvent.getSource().getProperty("title");
			var oFilter = new sap.ui.model.Filter("BUTXT", sap.ui.model.FilterOperator.Contains, "");
			var oFilter1 = new sap.ui.model.Filter("BUKRS", sap.ui.model.FilterOperator.Contains, "");
			var comFil = new sap.ui.model.Filter([oFilter, oFilter1]);
			var oList = this.getView().byId("idlistcomp");
			if (compcodeid === "idinputCompany") {
				this.getView().byId("idinputCompany").setValue(selectedCompCode);
				this.getView().getModel("settingsModel").setProperty("/selectedCompCode", selectedCompCode);
				this.getView().byId("idsearchCompCode").setValue(null);
				this.getView().byId("idinputVendorID").setEditable(true);
				oList.getBinding("items").filter(comFil, sap.ui.model.FilterType.Application);
			}
			if (compcodeid === "idinputDocCom") {
				this.getView().byId("idinputDocCom").setValue(selectedCompCode);
				this.getView().getModel("settingsModel").setProperty("/selectedDocCompCode", selectedCompCode);
				this.getView().byId("idsearchCompCode").setValue(null);
				oList.getBinding("items").filter(comFil, sap.ui.model.FilterType.Application);
			}
			this._oCCD.close();
		},
		_handleSelectVendorID: function (oEvent) {
			var selectedVendorDes = oEvent.getSource().getAggregation("attributes");
			var VendorLIFNR = selectedVendorDes[0].getProperty('text');
			var VendorNAME1 = selectedVendorDes[1].getProperty('text');
			var oFilter = new sap.ui.model.Filter("LIFNR", sap.ui.model.FilterOperator.Contains, "");
			var oFilter1 = new sap.ui.model.Filter("NAME1", sap.ui.model.FilterOperator.Contains, "");
			var comFil = new sap.ui.model.Filter([oFilter, oFilter1]);
			var oList = this.getView().byId("idlistVendorID");
			this.getView().getModel("settingsModel").setProperty("/VendorLIFNR", VendorLIFNR);
			this.getView().getModel("settingsModel").setProperty("/VendorNAME1", VendorNAME1);
			this.getView().byId("idinputVendorID").setValue(VendorLIFNR);
			this.getView().byId("idinputVendorName").setValue(VendorNAME1);
			this.getView().byId("idsearchVendorID").setValue(null);
			oList.getBinding("items").filter(comFil, sap.ui.model.FilterType.Application);
			this._oVID.close();
		},
		onUserSelect: function (oEvent) {
			var preparevaluehelp = "";
			var AppByvaluehelp = "";
			var ApproverValuehelp = "";
			var selectedUser = oEvent.getParameters().listItem.getTitle();
			var selectedID = oEvent.getParameters().listItem.getDescription();
			var oFilter = new sap.ui.model.Filter("FIRSTNAME", sap.ui.model.FilterOperator.Contains, "");
			var oFilter1 = new sap.ui.model.Filter("USERNAME", sap.ui.model.FilterOperator.Contains, "");
			var comFil = new sap.ui.model.Filter([oFilter, oFilter1]);
			var oList = this.getView().byId("idlist");
			preparevaluehelp = this.getView().getModel("settingsModel").getProperty("/preparevaluehelp");
			AppByvaluehelp = this.getView().getModel("settingsModel").getProperty("/AppByvaluehelp");
			ApproverValuehelp = this.getView().getModel("settingsModel").getProperty("/ApproverValuehelp");
			if (preparevaluehelp) {
				this.getView().byId("idinputPrepare").setValue(selectedUser);
				this.getView().getModel("settingsModel").setProperty("/preparevaluehelp", null);
				this.getView().getModel("settingsModel").setProperty("/idPrepare", selectedID);
			}
			if (AppByvaluehelp) {
				this.getView().byId("idinputAppBy").setValue(selectedUser);
				this.getView().getModel("settingsModel").setProperty("/AppByvaluehelp", null);
				this.getView().getModel("settingsModel").setProperty("/idApproverBy", selectedID);
			}
			if (ApproverValuehelp) {
				this.getView().byId("idinputApprover").setValue(selectedUser);
				this.getView().getModel("settingsModel").setProperty("/ApproverValuehelp", null);
				this.getView().getModel("settingsModel").setProperty("/idApprover", selectedID);
			}
			this.getView().byId("idsearchUsers").setValue(null);
			oList.getBinding("items").filter(comFil, sap.ui.model.FilterType.Application);
			this._oPreID.close();
		},
		onSearchComanyCode: function (oEvent) {
			if (oEvent !== undefined) {
				var query = oEvent.getParameter("value");
				var oFilter = new sap.ui.model.Filter("BUTXT", sap.ui.model.FilterOperator.Contains, query);
				var oFilter1 = new sap.ui.model.Filter("BUKRS", sap.ui.model.FilterOperator.Contains, query);
				var comFil = new sap.ui.model.Filter([oFilter, oFilter1]);
				var oList = this.getView().byId("idlistcomp");
				oList.getBinding("items").filter(comFil, sap.ui.model.FilterType.Application);
			}
		},
		onSearchVendorID: function (oEvent) {
			var me = this;
			var name1 = this.getView().byId("idsearchVendorID").getValue();
			var CompCode = this.getView().getModel("settingsModel").getProperty("/selectedCompCode");
			var gatewayUrl = "/sap/opu/odata/sap/YFPSFIFRDD0037_MPR_EFORM_SRV/";
			var oModel3 = new sap.ui.model.odata.ODataModel(gatewayUrl);
			var spath = "/VendorSet?$skip=0&$top=" + num + "&$filter=BUKRS eq" + "'" + CompCode + "'" + "and NAME1 eq" + "'" + name1 + "'";
			oModel3.read(spath, null, null, true, function (oData) {
				me.getModel().setProperty("/VendorID/items", []);
				me.getModel().setProperty("/VendorID/items", oData.results);
			});
		},
		onSearchUserlist: function (oEvent) {
			if (oEvent !== undefined) {
				var query = oEvent.getParameter("value");
				var oFilter = new sap.ui.model.Filter("FIRSTNAME", sap.ui.model.FilterOperator.Contains, query);
				var oFilter1 = new sap.ui.model.Filter("USERNAME", sap.ui.model.FilterOperator.Contains, query);
				var comFil = new sap.ui.model.Filter([oFilter, oFilter1]);
				var oList = this.getView().byId("idlist");
				oList.getBinding("items").filter(comFil, sap.ui.model.FilterType.Application);
			}
		},
		onSearchPress: function () {
			var me = this;
			sap.ui.core.BusyIndicator.show();
			var Title = this.getView().byId("idinputTitle").getValue();
			var ID = this.getView().byId("idinputID").getValue();
			var Preparer = this.getView().getModel("settingsModel").getProperty("/idPrepare");
			if (!Preparer) {
				Preparer = "";
			}
			var ApprovedBy = this.getView().getModel("settingsModel").getProperty("/idApproverBy");
			if (!ApprovedBy) {
				ApprovedBy = "";
			}
			var Approver = this.getView().getModel("settingsModel").getProperty("/idApprover");
			if (!Approver) {
				Approver = "";
			}
			var PayerCompanyCode = this.getView().byId("idinputCompany").getValue();

			var VendorID = this.getView().getModel("settingsModel").getProperty("/VendorLIFNR");
			if (!VendorID) {
				var VendorID1 = this.getView().byId("idinputVendorName").getValue();
				if (!VendorID1) {
					VendorID = "";
				} else {
					VendorID = VendorID1;
				}
			}
			var VendorName = this.getView().getModel("settingsModel").getProperty("/VendorNAME1");
			if (!VendorName) {
				var VendorName1 = this.getView().byId("idinputVendorName").getValue();
				if (!VendorName1) {
					VendorName = "";
				} else {
					VendorName = VendorName1;
				}
			}
			var filterStatus = this.getView().getModel("settingsModel").getProperty("/selectedStatusKey");
			if (!filterStatus) {
				filterStatus = "";
			}
			var DocCompanyCode = this.getView().byId("idinputDocCom").getValue();

			var finalAppbydate1 = this.getView().byId("idRequestDate").getValue();
			var splitdate = finalAppbydate1.split("-");
			var fromDateAppBy = splitdate[0];
			var ToDateAppBy = splitdate[1];
			var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: "yyyyMMdd"
			});
			var finalfromAppbydate = dateFormat.format(new Date(fromDateAppBy));
			var finalToAppbydate = dateFormat.format(new Date(ToDateAppBy));

			var DateApproved = this.getView().byId("idDateApproved").getValue();
			var splitapproved = DateApproved.split("-");
			var fromDateApproved = splitapproved[0];
			var ToDateApproved = splitapproved[1];
			var dateFormat1 = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: "yyyyMMdd"
			});
			var finalFromApprdDate = dateFormat1.format(new Date(fromDateApproved));
			var finalToApprdDate = dateFormat1.format(new Date(ToDateApproved));

			var DateSubmitted = this.getView().byId("idDateSubmitted").getValue("");
			var splitSub = DateSubmitted.split("-");
			var fromDateSub = splitSub[0];
			var ToDateSub = splitSub[1];
			var dateFormat3 = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: "yyyyMMdd"
			});
			var finalFromDateSubmitted = dateFormat3.format(new Date(fromDateSub));
			var finalToDateSubmitted = dateFormat3.format(new Date(ToDateSub));

			var myfilter = [];
			var oFilter1 = new sap.ui.model.Filter(
				"TITLE",
				sap.ui.model.FilterOperator.EQ, Title
			);
			myfilter.push(oFilter1);

			var oFilter2 = new sap.ui.model.Filter(
				"EFORM_NUM",
				sap.ui.model.FilterOperator.EQ, ID
			);
			myfilter.push(oFilter2);

			var oFilter3 = new sap.ui.model.Filter(
				"APPROVE_BY",
				sap.ui.model.FilterOperator.EQ, ApprovedBy
			);
			myfilter.push(oFilter3);

			var oFilter4 = new sap.ui.model.Filter(
				"APPROVER",
				sap.ui.model.FilterOperator.EQ, Approver
			);
			myfilter.push(oFilter4);

			var oFilter5 = new sap.ui.model.Filter(
				"PAYER_CCODE",
				sap.ui.model.FilterOperator.EQ, PayerCompanyCode
			);
			myfilter.push(oFilter5);

			var oFilter6 = new sap.ui.model.Filter(
				"PREPARER",
				sap.ui.model.FilterOperator.EQ, Preparer
			);
			myfilter.push(oFilter6);

			var oFilter7 = new sap.ui.model.Filter(
				"VENDOR",
				sap.ui.model.FilterOperator.EQ, VendorID
			);
			myfilter.push(oFilter7);

			var oFilter8 = new sap.ui.model.Filter(
				"VENDOR_NAME",
				sap.ui.model.FilterOperator.EQ, VendorName
			);
			myfilter.push(oFilter8);

			var oFilter9 = new sap.ui.model.Filter(
				"STATUS",
				sap.ui.model.FilterOperator.EQ, filterStatus
			);
			myfilter.push(oFilter9);

			var oFilter10 = new sap.ui.model.Filter(
				"DOC_CCODE",
				sap.ui.model.FilterOperator.EQ, DocCompanyCode
			);
			myfilter.push(oFilter10);

			var oFilter11 = new sap.ui.model.Filter(
				"REQUEST_DATE",
				sap.ui.model.FilterOperator.BT, finalfromAppbydate, finalToAppbydate
			);
			myfilter.push(oFilter11);

			var oFilter12 = new sap.ui.model.Filter(
				"APPROVED_DATE",
				sap.ui.model.FilterOperator.BT, finalFromApprdDate, finalToApprdDate
			);
			myfilter.push(oFilter12);

			var oFilter13 = new sap.ui.model.Filter(
				"SUBMIT_DATE",
				sap.ui.model.FilterOperator.BT, finalFromDateSubmitted, finalToDateSubmitted
			);
			myfilter.push(oFilter13);

			me.getModel().setProperty("/TableData/items", []);
			me.getView().byId("tableresultid").setText(null);
			var oModel = me.getModel("Mprsrvmodel");
			oModel.read("/HeaderdataSet", {
				method: "GET",
				filters: myfilter,
				success: function (oData, response) {
					sap.ui.core.BusyIndicator.hide();
					// MessageToast.show("Got" + "-" + "(" + oData.results.length + ")" + "-" + "Line items");
					var oDataDate = oData.results;
					me.formatDate(oDataDate);
					GlobalData = oData.results;
					me.getModel().setProperty("/TableData/items", GlobalData);
					me.getView().byId("tableresultid").setText("Total Results" + "-" + "(" + oData.results.length + ")");

				}.bind(this),
				error: function (response) {
					MessageBox.error(response.responseText);
					sap.ui.core.BusyIndicator.hide();
				}.bind(this)
			});
		},
		formatDate: function (oDataDate) {
			var me = this;
			for (var i = 0; i < oDataDate.length; i++) {
				var datechange = oDataDate[i].REQUEST_DATE;
				var year = datechange.slice(0, 4);
				var mm = datechange.slice(4, 6);
				var dd = datechange.slice(6, 8);
				var append = year + "/" + mm + "/" + dd;
				var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
					pattern: "MM/dd/yyyy"
				});
				var datab = dateFormat.format(new Date(append));
				oDataDate[i].REQUEST_DATE = datab;
				me.getModel().setProperty("/TableData/items", oDataDate);
			}
		},
		clear_fields: function () {
			this.getView().getModel("settingsModel").setProperty("/idPrepare", null);
			this.getView().getModel("settingsModel").setProperty("/preparevaluehelp", null);
			this.getView().getModel("settingsModel").setProperty("/AppByvaluehelp", null);
			this.getView().getModel("settingsModel").setProperty("/ApproverValuehelp", null);
			this.getView().getModel("settingsModel").setProperty("/compcodeid", null);
			this.getView().getModel("settingsModel").setProperty("/vendorID", null);
			this.getView().getModel("settingsModel").setProperty("/selectedCompCode", null);
			this.getView().getModel("settingsModel").setProperty("/selectedDocCompCode", null);
			this.getView().getModel("settingsModel").setProperty("/VendorLIFNR", null);
			this.getView().getModel("settingsModel").setProperty("/VendorNAME1", null);
			this.getView().getModel("settingsModel").setProperty("/idApproverBy", null);
			this.getView().getModel("settingsModel").setProperty("/idApprover", null);
			this.getView().getModel("settingsModel").setProperty("/selectedStatusKey", []);

			this.getView().byId("idinputTitle").setValue("");
			this.getView().byId("idinputID").setValue("");
			this.getView().byId("idinputPrepare").setValue("");
			this.getView().byId("idinputAppBy").setValue("");
			this.getView().byId("idinputApprover").setValue("");
			this.getView().byId("idinputCompany").setValue("");
			this.getView().byId("idinputVendorID").setValue("");
			this.getView().byId("idinputVendorName").setValue("");
			this.getView().byId("idinputDocCom").setValue("");
			this.getView().byId("form_status").setSelectedKey(null);
			this.getView().byId("idRequestDate").setValue("");
			this.getView().byId("idDateApproved").setValue("");
			this.getView().byId("idDateSubmitted").setValue("");
		},
		report_records: function (oEvent) {
			var model = this.getModel("Mprsrvmodel");
			var eform_num = this.getView().byId("idinputID").getValue();
			var Title = this.getView().byId("idinputTitle").getValue();
			var Preparer = this.getView().getModel("settingsModel").getProperty("/idPrepare");
			if (!Preparer) {
				Preparer = "";
			}
			var ApprovedBy = this.getView().getModel("settingsModel").getProperty("/idApproverBy");
			if (!ApprovedBy) {
				ApprovedBy = "";
			}
			var Approver = this.getView().getModel("settingsModel").getProperty("/idApprover");
			if (!Approver) {
				Approver = "";
			}
			var PayerCompanyCode = this.getView().byId("idinputCompany").getValue();

			var VendorID = this.getView().getModel("settingsModel").getProperty("/VendorLIFNR");
			if (!VendorID) {
				var VendorID1 = this.getView().byId("idinputVendorName").getValue();
				if (!VendorID1) {
					VendorID = "";
				} else {
					VendorID = VendorID1;
				}
			}
			var VendorName = this.getView().getModel("settingsModel").getProperty("/VendorNAME1");
			if (!VendorName) {
				var VendorName1 = this.getView().byId("idinputVendorName").getValue();
				if (!VendorName1) {
					VendorName = "";
				} else {
					VendorName = VendorName1;
				}
			}
			var filterStatus = this.getView().getModel("settingsModel").getProperty("/selectedStatusKey");
			if (!filterStatus) {
				filterStatus = "";
			}
			var DocCompanyCode = this.getView().byId("idinputDocCom").getValue();

			var finalAppbydate1 = this.getView().byId("idRequestDate").getValue();
			var splitdate = finalAppbydate1.split("-");
			var fromDateAppBy = splitdate[0];
			var ToDateAppBy = splitdate[1];
			var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: "yyyyMMdd"
			});
			var finalfromAppbydate = dateFormat.format(new Date(fromDateAppBy));
			var finalToAppbydate = dateFormat.format(new Date(ToDateAppBy));

			var DateApproved = this.getView().byId("idDateApproved").getValue();
			var splitapproved = DateApproved.split("-");
			var fromDateApproved = splitapproved[0];
			var ToDateApproved = splitapproved[1];
			var dateFormat1 = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: "yyyyMMdd"
			});
			var finalFromApprdDate = dateFormat1.format(new Date(fromDateApproved));
			var finalToApprdDate = dateFormat1.format(new Date(ToDateApproved));

			var DateSubmitted = this.getView().byId("idDateSubmitted").getValue("");
			var splitSub = DateSubmitted.split("-");
			var fromDateSub = splitSub[0];
			var ToDateSub = splitSub[1];
			var dateFormat3 = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: "yyyyMMdd"
			});
			var finalFromDateSubmitted = dateFormat3.format(new Date(fromDateSub));
			var finalToDateSubmitted = dateFormat3.format(new Date(ToDateSub));
			var relPath = "/sap/opu/odata/sap/YFPSFIFRDD0037_MPR_EFORM_SRV/HeaderdataSet?$filter=EFORM_NUM eq '" + eform_num +
				"'and TITLE eq '" + Title +
				"'and APPROVE_BY eq '" + ApprovedBy +
				"'and APPROVER eq '" + Approver +
				"'and (REQUEST_DATE ge '" + finalfromAppbydate +
				"'and REQUEST_DATE le '" + finalToAppbydate +
				"')and (APPROVED_DATE ge '" + finalFromApprdDate +
				"'and APPROVED_DATE le '" + finalToApprdDate +
				"')and PREPARER eq '" + Preparer +
				"'and PAYER_CCODE eq '" + PayerCompanyCode +
				"'and STATUS eq '" + filterStatus +
				"'and VENDOR eq '" + VendorID +
				"'and VENDOR_NAME eq '" + VendorName +
				"'and DOC_CCODE eq '" + DocCompanyCode +
				"'and (SUBMIT_DATE ge '" + finalFromDateSubmitted +
				"'and SUBMIT_DATE le '" + finalToDateSubmitted +
				"')&$format=xlsx";
			var encodeUrl = encodeURI(relPath);
			sap.m.URLHelper.redirect(encodeUrl, true);
		},
		_displayEmployees: function (oEvent) {
			var that = this;
			var username = oEvent.getSource().getText();
			var selected_item = oEvent.getSource().getBindingContext().getPath();
			var spath = selected_item.slice(17);
			var Index = parseInt(spath);
			var backendApprvList = this.getModel().getProperty("/TableData/items");
			var sDept = backendApprvList[Index].APPROVER;
			var oFilterFormType = new sap.ui.model.Filter("FORMTYP", sap.ui.model.FilterOperator.EQ, "MPR");
			var oFilterRole = new sap.ui.model.Filter("ROLE", sap.ui.model.FilterOperator.EQ, sDept);
			var gatewayUrl = "/sap/opu/odata/sap/YFPSFIFRDD0037_MPR_EFORM_SRV/";
			var oModel = new sap.ui.model.odata.ODataModel(gatewayUrl, true);
			oModel.read("/ApprovergrpSet", {
				async: false,
				filters: [oFilterFormType, oFilterRole],
				success: function (oData, oResponse) {
					if (!that._oPopover) {
						that._oPopover = sap.ui.xmlfragment("com.spe.ManualPayReq.YMPR_FORM.fragments.SearchApprovals", that);
						that.getView().addDependent(that._oPopover);
					}
					var event = oEvent.getSource();
					that._oPopover.openBy(event);
					that.getModel().setProperty("/SearchEmployee/items", oData.results);
				},
				error: function (oError) {
					sap.m.MessageBox.show(oError.message, {
						icon: MessageBox.Icon.ERROR,
						title: "Error"
					});
				}
			});
		},
		onExit: function () {
			GlobalData = "";
		}
	});
});