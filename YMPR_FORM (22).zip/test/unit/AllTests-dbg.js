sap.ui.define([
	"com/spe/ManualPayReq/YMPR_FORM/test/unit/controller/ManualPaySearch.controller"
], function () {
	"use strict";
});