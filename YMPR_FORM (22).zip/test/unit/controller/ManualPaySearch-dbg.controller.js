/*global QUnit*/

sap.ui.define([
	"com/spe/ManualPayReq/YMPR_FORM/controller/ManualPaySearch.controller"
], function (Controller) {
	"use strict";

	QUnit.module("ManualPaySearch Controller");

	QUnit.test("I should test the ManualPaySearch controller", function (assert) {
		var oAppController = new Controller();
		oAppController.onInit();
		assert.ok(oAppController);
	});

});