sap.ui.define([], function () {
	"use strict";
	return {

		chkBoxValidation: function (sFlag) {

			if (sFlag === "X") {
				return true;
			} else {
				return false;
			}
		},
		ApprReject: function (APPROVED) {

			if (APPROVED === "X") {
				return "Approved";
			}
			if (APPROVED === "R") {
				return "Rejected";
			} else {
				return "";
			}
		}
	};
});