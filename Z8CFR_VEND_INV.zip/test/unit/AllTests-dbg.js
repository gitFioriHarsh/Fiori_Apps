sap.ui.define([
	"com/alcon/FSR-00053091/test/unit/controller/View1.controller"
], function () {
	"use strict";
});