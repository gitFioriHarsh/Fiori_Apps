sap.ui.define([
	"./BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/Sorter",
	"sap/ui/model/FilterOperator",
	"sap/m/GroupHeaderListItem",
	"sap/ui/Device",
	"sap/ui/core/Fragment",
	"../model/formatter",
	"sap/ui/export/library",
	"sap/ui/export/Spreadsheet"
], function (BaseController, JSONModel, Filter, Sorter, FilterOperator, GroupHeaderListItem, Device, Fragment, formatter, library,
	Spreadsheet) {
	"use strict";
	var EdmType = library.EdmType;
	return BaseController.extend("com.alcon.vendInv.controller.Master", {

		formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the master list controller is instantiated. It sets up the event handling for the master/detail communication and other lifecycle tasks.
		 * @public
		 */
		onInit: function () {

			var oList = this.byId("list");

			var oViewModel = this._createViewModel(),
				// Put down master list's original value for busy indicator delay,
				// so it can be restored later on. Busy handling on the master list is
				// taken care of by the master list itself.
				iOriginalBusyDelay = oList.getBusyIndicatorDelay();

			this._oList = oList;
			// keeps the filter and search state
			this._oListFilterState = {
				aFilter: [],
				aSearch: []
			};
			this.setModel(oViewModel, "masterView");
			// Make sure, busy indication is showing immediately so there is no
			// break after the busy indication for loading the view's meta data is
			// ended (see promise 'oWhenMetadataIsLoaded' in AppController)
			oList.attachEventOnce("updateFinished", function () {
				// Restore original busy indicator delay for the list
				oViewModel.setProperty("/delay", iOriginalBusyDelay);
			});
			this.getView().addEventDelegate({
				onBeforeFirstShow: function () {
					this.getOwnerComponent().oListSelector.setBoundMasterList(oList);
				}.bind(this)
			});

			this.getRouter().getRoute("View2").attachPatternMatched(this._onObjectMatched, this);
			if (this.getOwnerComponent().applId) {

				this.getRouter().attachBypassed(this.onBypassed, this);
			}
		},

		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */
		/**
		 * After list data is available, this handler method updates the
		 * master list counter
		 * @param {sap.ui.base.Event} oEvent the update finished event
		 * @public
		 */
		onUpdateFinished: function (oEvent) {
			//Refresh the selection		
			oEvent.getSource().removeSelections();
			// update the master list object counter after new data is loaded
			this._updateListItemCount(oEvent.getParameter("total"));
			//Selectiong the first record of master list
			var oListPath = this.getView().byId("list");
			var firstItem = oListPath.getItems()[0];
			oListPath.setSelectedItem(firstItem, true);
			var firstRecord;
			if (oListPath.getItems().length !== 0) {
				firstRecord = oListPath.getItems().valueOf("Ebeln")[0].getTitle();
				// object header set
				this.getView().byId("oheader").setText(firstRecord);
				var oVData = sap.ui.getCore().getModel("vendor").getData(),
					oBukrs = oVData.CompanyCode,
					oVendor = oVData.vendorNo;
				var val = "Bukrs=" + "'" + oBukrs + "'",
					val1 = "Lifnr=" + "'" + oVendor + "'",
					val2 = "Ebeln=" + "'" + firstRecord + "'";
				var path = "/getPoHeaderSet(" + val + "," + val1 + "," + val2 + ")";
				// object header set
				this.getView().byId("oheader").setText(firstRecord);
				this.getView().byId("oheadComp").setText(oBukrs + "-" + oVData.companyName);
				this.getView().byId("oheadVend").setText(oVendor + "-" + oVData.vendorName);
				var oDate = new Date();
				this.getView().byId("oheadDate").setText(formatter.dateFormat1(oDate));

				this.oBinding(path);
			}

		},
		/* onListUpdateFinished: function(oevent){
			var oTable = this.getView().byId("lineItemsList");
		var i,olast;
			
		var olength = oevent.getParameters().total;
		 olast = olength - 1;
		for( i=0;i < olength; i++)
		{
		if (i === olast)
		{
		oTable.getAggregation("items")[i].destroy();
		}
		 }
		}, */
		onListUpdateFinished1: function (oevent) {
			var oTable = this.getView().byId("PayDataList");
			var i, j, k, valueExist;

			var olength = oevent.getParameters().total;
			for (i = 0; i < olength; i++) {
				for (k = 0; k < oTable.getItems(0).length; k++) {
					valueExist = "";
					var oitem = oTable.getItems(0);
					var oCell = oitem[k].getCells();
					for (j = 1; j < oCell.length & valueExist === ""; j++) {
						if (oCell[j].getText() !== "") {
							valueExist = oCell[j].getText();
						}
					}
					if (valueExist === "") {
						oTable.getAggregation("items")[k].destroy();
					}
				}
			}
		},
		/**
		 * Event handler for the master search field. Applies current
		 * filter value and triggers a new search. If the search field's
		 * 'refresh' button has been pressed, no new search is triggered
		 * and the list binding is refresh instead.
		 * @param {sap.ui.base.Event} oEvent the search event
		 * @public
		 */
		onSearch: function (oEvent) {
			if (oEvent.getParameters().refreshButtonPressed) {
				// Search field's 'refresh' button has been pressed.
				// This is visible if you select any master list item.
				// In this case no new search is triggered, we only
				// refresh the list binding.
				this.onRefresh();
				return;
			}

			var sQuery = oEvent.getParameter("query");
			var oVData = sap.ui.getCore().getModel("vendor").getData();
			var fromDate = new Date(oVData.fromDate.getTime() - oVData.fromDate.getTimezoneOffset() * 60 * 1000);

			if (sQuery) {
				this._oListFilterState.aSearch = [new Filter("Ebeln", FilterOperator.Contains, sQuery),
					new Filter("Bukrs", FilterOperator.EQ, oVData.CompanyCode),
					new Filter("Lifnr", FilterOperator.EQ, oVData.vendorNo),
					new Filter({
						path: "IRDATS",
						operator: FilterOperator.BT,
						value1: fromDate,
						value2: oVData.toDate
					})
				];
			} else {
				this._oListFilterState.aSearch = [
					new Filter("Bukrs", FilterOperator.EQ, oVData.CompanyCode),
					new Filter("Lifnr", FilterOperator.EQ, oVData.vendorNo),
					new Filter({
						path: "IRDATS",
						operator: FilterOperator.BT,
						value1: fromDate,
						value2: oVData.toDate
					})

				];
			}
			this._applyFilterSearch();

		},

		/**
		 * Event handler for refresh event. Keeps filter, sort
		 * and group settings and refreshes the list binding.
		 * @public
		 */
		onRefresh: function () {
			this._oList.getBinding().refresh();
		},

		/**
		 * Event handler for the filter, sort and group buttons to open the ViewSettingsDialog.
		 * @param {sap.ui.base.Event} oEvent the button press event
		 * @public
		 */
		onOpenViewSettings: function (oEvent) {
			var sDialogTab = "filter";
			if (oEvent.getSource() instanceof sap.m.Button) {
				var sButtonId = oEvent.getSource().getId();
				if (sButtonId.match("sort")) {
					sDialogTab = "sort";
				} else if (sButtonId.match("group")) {
					sDialogTab = "group";
				}
			}
			// load asynchronous XML fragment
			if (!this.byId("viewSettingsDialog")) {
				Fragment.load({
					id: this.getView().getId(),
					name: "com.alcon.vendInv.view.ViewSettingsDialog",
					controller: this
				}).then(function (oDialog) {
					// connect dialog to the root view of this component (models, lifecycle)
					this.getView().addDependent(oDialog);
					oDialog.addStyleClass(this.getOwnerComponent().getContentDensityClass());
					oDialog.open(sDialogTab);
				}.bind(this));
			} else {
				this.byId("viewSettingsDialog").open(sDialogTab);
			}
		},

		/**
		 * Event handler called when ViewSettingsDialog has been confirmed, i.e.
		 * has been closed with 'OK'. In the case, the currently chosen filters, sorters or groupers
		 * are applied to the master list, which can also mean that they
		 * are removed from the master list, in case they are
		 * removed in the ViewSettingsDialog.
		 * @param {sap.ui.base.Event} oEvent the confirm event
		 * @public
		 */
		onConfirmViewSettingsDialog: function (oEvent) {

			this._applySortGroup(oEvent);
		},

		/**
		 * Apply the chosen sorter and grouper to the master list
		 * @param {sap.ui.base.Event} oEvent the confirm event
		 * @private
		 */
		_applySortGroup: function (oEvent) {
			var mParams = oEvent.getParameters(),
				sPath,
				bDescending,
				aSorters = [];
			sPath = mParams.sortItem.getKey();
			bDescending = mParams.sortDescending;
			aSorters.push(new Sorter(sPath, bDescending));
			this._oList.getBinding("items").sort(aSorters);
		},

		/**
		 * Event handler for the list selection event
		 * @param {sap.ui.base.Event} oEvent the list selectionChange event
		 * @public
		 */
		onSelectionChange: function (oEvent) {
			//		var oList = oEvent.getSource(),
			//	bSelected = oEvent.getParameter("selected");

			var bSelected = oEvent.getParameter("listItem");
			// Set object header
			this.getView().byId("oheader").setText(bSelected.getTitle());
			var path = bSelected.getBindingContextPath();
			//	var spath = path + '/poInvoiceDetails';
			this.oBinding(path);

		},
		oBinding: function (oPath) {
			var oInvTable = this.getView().byId("lineItemInvList");
			oInvTable.bindElement(oPath);
			//	var oTotalFld = this.getView().byId("totalCount");
			//	var iItemsCount = oInvTable.getItems().length;
			//	var iCellCount = oInvTable.getItems()[iItemsCount-1].getCells().length;
			//	oTotalFld.setNumber("Total: " + oInvTable.getItems()[iItemsCount-1].getCells()[iCellCount-1].getNumber());
			//	oTotalFld.setNumberUnit(oInvTable.getItems()[iItemsCount-1].getCells()[iCellCount-1].getUnit());
			this.getView().byId("accPayList").bindElement(oPath);
	//		var oTable = this.getView().byId("PayDataList");
		//	var oTable = this.getView().byId("PayDataList");
		/*	if (oTable !== undefined) {
				var olength = oTable.getItems(0).length,
					i;
				//Refreshing the table						
				for (i = 0; i < olength; i++) {
					oTable.getAggregation("items")[0].destroy();
				}
			}*/
			this.getView().byId("PayDataList").bindElement(oPath);
			this.getView().byId("poItemTab").bindElement(oPath);
			
		},
		_onObjectMatched: function (oEvent) {
			var error = ["", null, undefined];
			if (error.includes(this.getOwnerComponent().applId)) {
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("View1");
			} else {
				this.resourceBundle = this.getView().getModel("i18n").getResourceBundle();
				var sObjectId = oEvent.getParameter("arguments").objectId;
				var oVData = sap.ui.getCore().getModel("vendor").getData();
				var oFromDate = oVData.fromDate;
				var oToDate = oVData.toDate;

				var oVendor = oVData.vendorNo,
					//	lowDate1 = oVData.lowDate,
					//	fromDate = lowDate1.split('-', 10)[0],
					//	toDate = lowDate1.split('-', 10)[1],
					lowDate,
					highDate;

				if (oFromDate !== null) {
					lowDate = new Date(oFromDate.getTime() - oFromDate.getTimezoneOffset() * 60 * 1000);
					highDate = oToDate;
					//	var lowDate2 = fromDate.trim();
					//	var highDate2 = toDate.trim();
					//lowDate = new Date(lowDate2);
					//	highDate = new Date(highDate2);
					//	lowDate = lowDate.setDate(lowDate.getDate() + 1);
					//highDate = highDate.setDate(highDate.getDate() + 1);
				}
				//{
				if (lowDate === "" || lowDate === undefined) {
					lowDate = null;
					highDate = null;
				}

				var aFilters = [new Filter("Bukrs", FilterOperator.Contains, sObjectId),
					new Filter("Lifnr", FilterOperator.Contains, oVendor),
					new Filter({
						path: "IRDATS",
						operator: FilterOperator.BT,
						value1: lowDate,
						value2: highDate
					})
				];
				var i;
				if (oVData.poLow) {
					aFilters.push(
						new Filter({
							path: "Ebeln",
							operator: FilterOperator.EQ,
							value1: oVData.poLow
						})
					);
				} else {
					for (i = 0; i < oVData.poArray.length; i++) {
						aFilters.push(
							new Filter({
								path: "Ebeln",
								operator: FilterOperator.EQ,
								value1: oVData.poArray[i].getText()
							})
						);
					}
				}

				var oViewModel = this.getModel("masterView");
				this._oList.getBinding("items").filter(aFilters, "Application");
				// changes the noDataText of the list in case there are no filter results
				if (aFilters.length !== 0) {
					var oData = this.byId("lineItemInvList");
					if (oData !== undefined) {
						var oTable = this.byId("lineItemInvList");
						if (oTable.isBound("rows")) {

							oTable.unbindRows();

						}
					}
					oViewModel.setProperty("/noDataText", this.getResourceBundle().getText("masterListNoDataWithFilterOrSearchText"));
				} else if (this._oListFilterState.aSearch.length > 0) {
					// only reset the no data text to default when no new search was triggered
					oViewModel.setProperty("/noDataText", this.getResourceBundle().getText("masterListNoDataText"));
				}
			}
		},
		/**
		 * Event handler for the bypassed event, which is fired when no routing pattern matched.
		 * If there was an object selected in the master list, that selection is removed.
		 * @public
		 */
		onBypassed: function () {
			this._oList.removeSelections(true);
		},

		/**
		 * Used to create GroupHeaders with non-capitalized caption.
		 * These headers are inserted into the master list to
		 * group the master list's items.
		 * @param {Object} oGroup group whose text is to be displayed
		 * @public
		 * @returns {sap.m.GroupHeaderListItem} group header with non-capitalized caption.
		 */
		createGroupHeader: function (oGroup) {
			return new GroupHeaderListItem({
				title: oGroup.text,
				upperCase: false
			});
		},

		/**
		 * Event handler for navigating back.
		 * We navigate back in the browser historz
		 * @public
		 */
		onNavBack: function () {
			// eslint-disable-next-line sap-no-history-manipulation
			history.go(-1);
		},
		onBack: function () {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("View1");
		},

		/* =========================================================== */
		/* begin: internal methods                                     */
		/* =========================================================== */
		_createViewModel: function () {
			return new JSONModel({
				isFilterBarVisible: false,
				filterBarLabel: "",
				delay: 0,
				title: this.getResourceBundle().getText("masterTitleCount", [0]),
				noDataText: this.getResourceBundle().getText("masterListNoDataText"),
				sortBy: "Ebeln",
				groupBy: "None"
			});
		},

		_onMasterMatched: function () {
			//Set the layout property of the FCL control to 'OneColumn'
			this.getModel("appView").setProperty("/layout", "OneColumn");
		},

		/**
		 * Shows the selected item on the detail page
		 * On phones a additional history entry is created
		 * @param {sap.m.ObjectListItem} oItem selected Item
		 * @private
		 */
		_showDetail: function (oItem) {
			var bReplace = !Device.system.phone;
			// set the layout property of FCL control to show two columns
			this.getModel("appView").setProperty("/layout", "TwoColumnsMidExpanded");
			this.getRouter().navTo("object", {
				objectId: oItem.getBindingContext().getProperty("Ebeln")
			}, bReplace);
		},

		/**
		 * Sets the item count on the master list header
		 * @param {integer} iTotalItems the total number of items in the list
		 * @private
		 */
		_updateListItemCount: function (iTotalItems) {
			var sTitle;
			// only update the counter if the length is final
			if (iTotalItems === 0) {
				var val;
				var path = "/getPoHeaderSet(" + val + ")";
				this.oBinding(path);
			}
			if (this._oList.getBinding("items").isLengthFinal()) {
				sTitle = this.getResourceBundle().getText("masterTitleCount", [iTotalItems]);
				this.getModel("masterView").setProperty("/title", sTitle);
			}
		},

		/**
		 * Internal helper method to apply both filter and search state together on the list binding
		 * @private
		 */
		_applyFilterSearch: function () {
			var aFilters = this._oListFilterState.aSearch.concat(this._oListFilterState.aFilter),
				oViewModel = this.getModel("masterView");
			this._oList.getBinding("items").filter(aFilters, "Application");
			// changes the noDataText of the list in case there are no filter results
			if (aFilters.length !== 0) {
				oViewModel.setProperty("/noDataText", this.getResourceBundle().getText("masterListNoDataWithFilterOrSearchText"));
			} else if (this._oListFilterState.aSearch.length > 0) {
				// only reset the no data text to default when no new search was triggered
				oViewModel.setProperty("/noDataText", this.getResourceBundle().getText("masterListNoDataText"));
			}
		},

		/**
		 * Internal helper method that sets the filter bar visibility property and the label's caption to be shown
		 * @param {string} sFilterBarText the selected filter value
		 * @private
		 */
		_updateFilterBar: function (sFilterBarText) {
			var oViewModel = this.getModel("masterView");
			oViewModel.setProperty("/isFilterBarVisible", (this._oListFilterState.aFilter.length > 0));
			oViewModel.setProperty("/filterBarLabel", this.getResourceBundle().getText("masterFilterBarText", [sFilterBarText]));
		},
		/* Toggle between full and non full screen mode.
		 */
		toggleFullScreen: function () {
			var bFullScreen = this.getModel("appView").getProperty("/actionButtonsInfo/midColumn/fullScreen");
			this.getModel("appView").setProperty("/actionButtonsInfo/midColumn/fullScreen", !bFullScreen);
			if (!bFullScreen) {
				// store current layout and go full screen
				this.getModel("appView").setProperty("/previousLayout", this.getModel("appView").getProperty("/layout"));
				this.getModel("appView").setProperty("/layout", "MidColumnFullScreen");
			} else {
				// reset to previous layout
				this.getModel("appView").setProperty("/layout", this.getModel("appView").getProperty("/previousLayout"));
			}
		},
		//Create column configuration for export table
		createColumnConfig: function () {
			var aCols = [];
			aCols.push({
				label: this.resourceBundle.getText("excelCompCode"),
				property: ["Bukrs", "Totald"],
				template: "{0} {1}",
				textAlign: "right"
			});
			aCols.push({
				label: this.resourceBundle.getText("excelVendorID"),
				property: "vendorNo",
				textAlign: "right"
			});
			aCols.push({
				label: this.resourceBundle.getText("excelPO"),
				property: "Ebeln",
				textAlign: "right"
			});
			aCols.push({
				label: this.resourceBundle.getText("Invfidoc"),
				property: "BelnrFi",
				textAlign: "right"
			});

			aCols.push({
				label: this.resourceBundle.getText("InvdetailColumn8"),
				property: "Xblnr",
				textAlign: "right"
			});

			aCols.push({
				label: this.resourceBundle.getText("InvdetailColumn9"),
				property: "Dabrz",
				type: EdmType.Date,
				textAlign: "right"
			});

			aCols.push({
				label: this.resourceBundle.getText("InvdetailColumn3"),
				property: "Budat",
				type: EdmType.Date,
				textAlign: "right"
			});

			aCols.push({
				label: this.resourceBundle.getText("InvdetailColumn4"),
				property: "Wrbtr",
				type: EdmType.Number,
				scale: 2,
				delimiter: true,
				textAlign: "right"
			});
			aCols.push({
				label: this.resourceBundle.getText("detailColumn5"),
				property: "Waers",
				textAlign: "left"
			});

			aCols.push({
				label: this.resourceBundle.getText("AccdetailColumn2"),
				property: "Zbd1t",
				type: EdmType.Date,
				textAlign: "right"
			});
			aCols.push({
				label: this.resourceBundle.getText("Accpayind"),
				property: "FieldZbd1t",
				textAlign: "right"
			});
			aCols.push({
				label: this.resourceBundle.getText("AccdetailColumn3"),
				property: "FieldAction",
				textAlign: "right"
			});
			aCols.push({
				label: this.resourceBundle.getText("AccdetailColumn4"),
				property: "FieldPlayblk",
				textAlign: "right"
			});
			aCols.push({
				label: this.resourceBundle.getText("PaydetailColumn1"),
				property: "Augbl",
				textAlign: "right"
			});
			aCols.push({
				label: this.resourceBundle.getText("PaydetailColumn3"),
				property: "Bldat",
				type: EdmType.Date,
				textAlign: "right"
			});
			aCols.push({
				label: this.resourceBundle.getText("PaydetailColumn4"),
				property: "FieldPlayMthd",
				textAlign: "right"
			});
			aCols.push({
				label: this.resourceBundle.getText("PaydetailColumn5"),
				property: "Check",
				textAlign: "right"
			});
			aCols.push({
				label: this.resourceBundle.getText("PaydetailColumn6"),
				property: "Date",
				type: EdmType.Date,
				textAlign: "right"
			});
			return aCols;
		},
		//Table content export
		onExport: function () {
			var aCols, oSettings, oSheet;
			var oModel1 = this.getOwnerComponent().getModel();
			var busyDialog = new sap.m.BusyDialog();
			var that = this;
			var oVData = sap.ui.getCore().getModel("vendor").getData(),
				oBukrs = oVData.CompanyCode;
			var oFromDate = oVData.fromDate;
			var oToDate = oVData.toDate;

			var oVendor = oVData.vendorNo,
				lowDate,
				highDate;

			if (oFromDate !== null) {
				lowDate = new Date(oFromDate.getTime() - oFromDate.getTimezoneOffset() * 60 * 1000);
				highDate = oToDate;
			}
			if (lowDate === "" || lowDate === undefined) {
				lowDate = null;
				highDate = null;
			}

			var aFilters = [new Filter("Bukrs", FilterOperator.Contains, oBukrs),
				new Filter("Lifnr", FilterOperator.Contains, oVendor),
				new Filter({
					path: "IRDATS",
					operator: FilterOperator.BT,
					value1: lowDate,
					value2: highDate
				})
			];
			var i;
			if (oVData.poLow) {
				aFilters.push(
					new Filter({
						path: "Ebeln",
						operator: FilterOperator.EQ,
						value1: oVData.poLow
					})
				);
			} else {
				for (i = 0; i < oVData.poArray.length; i++) {
					aFilters.push(
						new Filter({
							path: "Ebeln",
							operator: FilterOperator.EQ,
							value1: oVData.poArray[i].getText()
						})
					);
				}
			}
			var sPath = "/getPoalldetailsSet";
			busyDialog.open();
			oModel1.read(sPath, {
				filters: aFilters,
				success: function (oData) {
					busyDialog.close();
					var aPODetails = oData.results;
					for (var j = 0; j < aPODetails.length; j++) {
						aPODetails[j].FieldZbd1t = formatter.statDesc(aPODetails[j].Zbd1t, aPODetails[j].Stat, aPODetails[j].Zlspr, aPODetails[j].BlartClr, aPODetails[j].Stblg);
						aPODetails[j].FieldAction = formatter.setActionNeeded(aPODetails[j].Zbd1t, aPODetails[j].Stat, aPODetails[j].Zlspr);
						aPODetails[j].FieldPlayblk = formatter.concatDesc(aPODetails[j].Zlspr, aPODetails[j].Textl);
						aPODetails[j].FieldPlayMthd = formatter.concatDesc(aPODetails[j].Zlsch, aPODetails[j].Text1);
						if (j !== aPODetails.length - 1) {
							aPODetails[j].Bukrs = oBukrs;
							aPODetails[j].vendorNo = oVendor;
						}
					}

					aCols = that.createColumnConfig();
					oSettings = {
						workbook: {
							columns: aCols
						},
						dataSource: aPODetails,
						fileName: "Table.xlsx"
					};

					oSheet = new Spreadsheet(oSettings);
					oSheet.build().finally(function () {
						oSheet.destroy();
					});
					//that.getView().setModel(oModel);
				},
				error: function (oError) {
					busyDialog.close();
					var errorMsg = JSON.parse(oError.responseText);
					sap.m.MessageToast.show(errorMsg.error.message.value);
				}
			});
		},
		onInvoiceImage: function (oEvent) {
			var sCompCode = sap.ui.getCore().getModel("vendor").getData().CompanyCode;
			var sBelnr = oEvent.getSource().getParent().getCells()[0].getItems()[0].getText(); //"5000000007";
			var sFisYr = oEvent.getSource().getParent().getCells()[3].getText().split(", ")[1];

			var aFilters = [
				new Filter("Bukrs", FilterOperator.Contains, sCompCode),
				new Filter("Belnr", FilterOperator.Contains, sBelnr),
				new Filter("FiscalYear", FilterOperator.Contains, sFisYr)
			];
			var oModel1 = this.getOwnerComponent().getModel();
			var that = this;
			var oButton = oEvent.getSource(),
				oView = this.getView();
			if (!this.oPopover) {
				this.oPopover = Fragment.load({
					name: "com.alcon.vendInv.fragments.InvoiceImage",
					controller: this
				}).then(function (oPopover) {
					oView.addDependent(oPopover);
					return oPopover;
				});
			}
			oModel1.read("/getInvoiceAttachmentSet", {
				filters: aFilters,
				success: function (oData) {
					var oModel = new JSONModel({
						"AttachmentSet": oData.results
					});
					that.oPopover.then(function (oPopover) {
						oPopover.setModel(oModel);
						oPopover.openBy(oButton);
					});
				},
				error: function (oError) {
					var errorMsg = JSON.parse(oError.responseText);
					sap.m.MessageToast.show(errorMsg.error.message.value);
				}
			});
		},

		onLinkPress: function (oEvent) {

			var oModel1 = this.getOwnerComponent().getModel();
			var sDocId = oEvent.getSource().getBindingContext().getObject().Arc_doc_id;
			var sMimeType = oEvent.getSource().getBindingContext().getObject().Mimetype;
			var sArchiveId = oEvent.getSource().getBindingContext().getObject().ArchiveId;
			sMimeType = sMimeType.replace("/", "_");
			var sUrl = "/getInvoicecontentSet(Arc_doc_id='" + sDocId + "',Mimetype='" + sMimeType + "',ArchiveID='" + sArchiveId + "')/$value";
			var url = oModel1._getServerUrl() + oModel1.sServiceUrl + sUrl;
			this.oPopover.then(function (oPopover) {
				oPopover.close(oEvent.getSource());
			});
			window.open(url);
		},
		
		createColumnPOItemConfig: function () {
			var aCols = [];
			
			
			aCols.push({
				label: this.resourceBundle.getText("excelPONum"),
				property: "Eblen",
				textAlign: "right"
			});
			aCols.push({
				label: this.resourceBundle.getText("excelItemNo"),
				property: ["Item"],
				textAlign: "right"
			});
			aCols.push({
				label: this.resourceBundle.getText("excelShortText"),
				property: "ShortText",
				textAlign: "right"
			});
			aCols.push({
				label: this.resourceBundle.getText("excelDelDate"),
				property: "DelDate",
				type: EdmType.Date,
				textAlign: "right"
			});
			aCols.push({
				label: this.resourceBundle.getText("excelOU"),
				property: "OrdUnit",
				textAlign: "right"
			});

			aCols.push({
				label: this.resourceBundle.getText("excelPOQty"),
				property: "PoQty",
				textAlign: "right"
			});

			aCols.push({
				label: this.resourceBundle.getText("excelGRQty"),
				property: "GrQty",
				textAlign: "right"
			});

			aCols.push({
				label: this.resourceBundle.getText("excelIRQty"),
				property: "IrQty",
				textAlign: "right"
			});

			aCols.push({
				label: this.resourceBundle.getText("excelNetValue"),
				property: "NetPrice",
				textAlign: "right"
			});
		
			return aCols;
		},
		
		onPOItemExport : function(){
				var aCols, oRowBinding, oSettings, oSheet, oTable;

			if (!this._oTable) {
				this._oTable = this.byId('poItemTab');
			}

			oTable = this._oTable;
			oRowBinding = oTable.getBinding('items');
			aCols = this.createColumnPOItemConfig();

			var oModel = oRowBinding.getModel();

			oSettings = {
				workbook: {
					columns: aCols
				},
				dataSource: {
					type: 'odata',
					dataUrl: oRowBinding.getDownloadUrl ? oRowBinding.getDownloadUrl() : null,
					serviceUrl: this._sServiceUrl,
					headers: oModel.getHeaders ? oModel.getHeaders() : null,
					count: oRowBinding.getLength ? oRowBinding.getLength() : null,
					useBatch: true // Default for ODataModel V2
				},
				fileName: "PO_"+this._oTable.getBindingContext().getProperty('Ebeln')+"_Items.xlsx",
				worker: true // We need to disable worker because we are using a MockServer as OData Service
			};

			oSheet = new Spreadsheet(oSettings);
			oSheet.build().finally(function() {
				oSheet.destroy();
			});
			
		}
	});
});