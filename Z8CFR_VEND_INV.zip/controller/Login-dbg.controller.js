sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/ColumnListItem",
	"sap/ui/model/Filter",
	"sap/m/Label",
	"sap/m/Token",
	"sap/m/MessageToast",
	"sap/m/MessageBox",
	"sap/ui/model/FilterOperator",
	"sap/ui/core/Fragment",
	"sap/ui/model/type/String"
], function (Controller, ColumnListItem, Filter, Label, Token, MessageToast, MessageBox,
	FilterOperator, Fragment, typeString) {
	"use strict";
	var busyDialog = new sap.m.BusyDialog();
	var gv_radio;
	return Controller.extend("com.alcon.vendInv.controller.Login", {
		onInit: function () {
			
			if (gv_radio !== 1) {

				//reference document disable  
				this.getView().byId("ref").setVisible(false);
				this.getView().byId("reflabel").setVisible(false);
				//      this.getView().byId("invDate").setVisible(false);
			} else {
				this.getView().byId("ref").setVisible(true);
				this.getView().byId("reflabel").setVisible(true);

				//po document disable  
				this.getView().byId("po").setVisible(false);
				this.getView().byId("polabel").setVisible(false);
				this.getView().byId("poDate").setText("Posting Date");
			}

			this.getFooterText();
			this.getDefaultCompCode();
			this.orgText = "UI5 was created by professionals for modern developers to build state of the art web applications. It comes with all features needed to cover most current application requirements. The UI5 core offers a solid foundation that simplifies your work by managing many aspects of modern development behind the scenes:";
			if(this.orgText.length > 100){
			this.a =	this.orgText.substring(0,100)+"...  ";
			this.getView().byId("txtHeldp1").setText(this.a);
			this.getView().byId("linkId").setVisible(true);
			this.getView().byId("linkId").setText("More");
			}else{
			this.getView().byId("txtHeldp1").setText(this.orgText);
		//	this.getView("linkId").setVisible();	
			}
			

		},
		onLinkPressMore:function(oEvent){
			if(oEvent.getSource().getText() === "More"){
			this.getView().byId("txtHeldp1").setText("");
			this.getView().byId("txtHeldp1").setText(this.orgText);
			this.getView().byId("linkId").setText("Less");
			
			}else{
				this.getView().byId("txtHeldp1").setText("");
				this.getView().byId("txtHeldp1").setText(this.a);
			this.getView().byId("linkId").setText("More");
			
			}
		},
		onBeforeRendering: function () {
			var oVModel = sap.ui.getCore().getModel("vendor");
			if (oVModel !== undefined) {
				var oVData = oVModel.getData();
				this.byId("ccod").setValue(oVData.CompanyCode);
				this.byId("nameText").setText(oVData.companyName);
				this.byId("name1").setText(oVData.vendorName);
				this.getView().byId("VID").setValue(oVData.vendorNo);
				this.getView().byId("DRS1").setDateValue(oVData.fromDate);
				this.getView().byId("DRS1").setSecondDateValue(oVData.toDate);
				if (this.getView().byId("po").setValue(oVData.poLow) === "") {
					this.getView().byId("po").setValue(oVData.poArray);
				}

				this.getView().byId("ref").setValue(oVData.refLow);
				this.getView().byId("refrb").setSelected(oVData.refrb);

				this.getView().byId("txtHelp1").setText(oVData.ftext);
				this.getView().byId("lnkHelp").setHref(oVData.href);
			}
		},

		onSelectradio: function (evt) {
			gv_radio = evt.getParameter("selectedIndex");
			if (gv_radio === 1) {
				//invisible purchase document input range	
				this.getView().byId("po").setVisible(false);
				this.getView().byId("polabel").setVisible(false);
				//reference document enable  
				this.getView().byId("ref").setVisible(true);
				this.getView().byId("reflabel").setVisible(true);

				this.getView().byId("poDate").setText("Invoice / Credit Memo Date");
			} else {
				// po number enable
				this.getView().byId("po").setVisible(true);
				this.getView().byId("polabel").setVisible(true);
				//reference document disable  
				this.getView().byId("ref").setVisible(false);
				this.getView().byId("reflabel").setVisible(false);

				this.getView().byId("poDate").setText("PO Issued Date");
			}
		},

		pressDet: function (evt) {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			//"Invoice Report"
			var oBukrs = this.getView().byId("ccod").getValue(),
				refLow = this.getView().byId("ref").getValue();

			//	      highdate
			var oVendor = this.getView().byId("VID").getValue(),
				oFromDate = this.getView().byId("DRS1").getDateValue(),
				oToDate = this.getView().byId("DRS1").getSecondDateValue(),
				lowDate = this.getView().byId("DRS1").getValue(),
				poLow = this.getView().byId("po").getTokens();
			if (poLow.length === 0) {
				poLow = this.getView().byId("po").getValue();
			}

			// Data filling to read selection data in PO Report / Invoice Report  
			var viewCartData = {
				"CompanyCode": oBukrs,
				"companyName": this.getView().byId("nameText").getText(),
				"vendorNo": oVendor,
				"vendorName": this.getView().byId("name1").getText(),
				"fromDate": oFromDate,
				"toDate": oToDate,
				"lowDate": lowDate,
				"poLow": this.getView().byId("po").getValue(),
				"poArray": this.getView().byId("po").getTokens(),
				"refLow": this.getView().byId("ref").getValue(),
				"refrb": this.getView().byId("refrb").getSelected(),
				"ftext": this.getView().byId("txtHelp1").getText(),
				"href": this.getView().byId("lnkHelp").getHref()

			};
			var oModel = new sap.ui.model.json.JSONModel(viewCartData);
			sap.ui.getCore().setModel(oModel, "vendor");
			if (oBukrs === "") {
				var oInput = this.getView().byId("ccod");
				oInput.setValueState(sap.ui.core.ValueState.Error);
				MessageToast.show("Please enter Company Code");
			} else if (oVendor === "") {
				var oInput1 = this.getView().byId("VID");
				oInput1.setValueState(sap.ui.core.ValueState.Error);
				MessageToast.show("Please enter Vendor Number");
			} else if (lowDate) {
				//var lowDate1 = new Date(lowDate.split("-", 10)[0].trim()),
				//	highDate = new Date(lowDate.split("-", 10)[1].trim()),
				//	var	lowDate1 = this.getView().byId("DRS1").getFrom(),
				//	highDate = this.getView().byId("DRS1").getTo();
				var diff = oFromDate - oToDate,
					diffD = Math.ceil(diff / (1000 * 60 * 60 * 24));
				if (diffD > 180) {
					this.getView().byId("DRS1").setValueState(sap.ui.core.ValueState.Error);
					MessageToast.show("Date range should not be more than 6 Months");
				}
			}
			if (diffD <= 180 || diffD === undefined) {
				if (oBukrs !== "" & oVendor !== "") {
					if (gv_radio !== 1) {

						if (lowDate === "" & poLow === "") {
							this.byId("po").setValueState(sap.ui.core.ValueState.Error);
							this.byId("DRS1").setValueState(sap.ui.core.ValueState.Error);
							MessageToast.show("Please enter Date or PO number");
						} else {
							this.byId("po").setValueState("None");
							this.byId("DRS1").setValueState("None");
							this.getOwnerComponent().applId = "002";

							oRouter.navTo("View2", {
								objectId: oBukrs
							});
						}
					} else {

						if (lowDate === "" & refLow === "") {
							this.byId("ref").setValueState(sap.ui.core.ValueState.Error);
							this.byId("DRS1").setValueState(sap.ui.core.ValueState.Error);
							MessageToast.show("Please enter Date or Reference number");
						} else {
							this.byId("ref").setValueState("None");
							this.byId("DRS1").setValueState("None");
							this.getOwnerComponent().applId = "003";
							oRouter.navTo("View3", {
								objectId: oBukrs
							});
						}
					}
				}
			}
		},
		onChange: function () {
			var oThat = this;
			busyDialog.open();
			busyDialog.setText("Fetching");
			oThat.byId("ccod").setValueState("None");
			var oBukrs = this.getView().byId("ccod").getValue();
			//Clear the company code
			if (oBukrs === "") {
				oThat.byId("ccod").setValueState("None");
				oThat.getView().byId("nameText").setText("");
				busyDialog.close();
			} else {
				var val = "'" + oBukrs + "'";
				var val1 = "/searchHelp_BukrsSet(" + val + ")";
				var oModel1 = this.getOwnerComponent().getModel();
				oModel1.read(val1, {
					success: function (oData, oResponse) {
						oThat.byId("ccod").setValueState("None");
						oThat.getView().byId("nameText").setText(oData.Butxt);
						var cCode1 = oBukrs;
						var oModel = new sap.ui.model.json.JSONModel(cCode1);
						oThat.getView().setModel(oModel, "cCode");
						busyDialog.close();
					},
					error: function (oError) {
						oThat.byId("ccod").setValueState("Error");
						oThat.getView().byId("nameText").setText("");
						var errorMsg = JSON.parse(oError.responseText);
						MessageToast.show(errorMsg.error.message.value);
						busyDialog.close();
					}

				});
			}
		},
		onChange1: function (evt) {
			var oThat = this;
			oThat.byId("ccod").setValueState("None");
			var oVendor = this.getView().byId("VID").getValue();
			oVendor = oVendor.trim();
			//Clear the company code
			if (oVendor === "") {
				oThat.byId("VID").setValueState("None");
				oThat.getView().byId("name1").setText("");
			} else {
				busyDialog.open();
				busyDialog.setText("Fetching");
				var val = "'" + oVendor + "'";
				var val1 = "/searchHelp_vendorSet(" + val + ")";
				var oModel1 = this.getOwnerComponent().getModel();
				oModel1.read(val1, {
					success: function (oData, oResponse) {
						oThat.byId("VID").setValueState("None");
						oThat.getView().byId("name1").setText(oData.mcod1);
						busyDialog.close();
					},
					error: function (oError) {
						oThat.byId("VID").setValueState("Error");
						oThat.getView().byId("name1").setText("");
						var errorMsg = JSON.parse(oError.responseText);
						MessageToast.show(errorMsg.error.message.value);
						busyDialog.close();
					}
				});
			}
		},
		onSearch: function (oEvent) {

			var sInputValue = oEvent.getSource().getValue();
			this.inputId = oEvent.getSource().getId();
			this.byId("ccod").setValueState("None");
			this.oDialog = sap.ui.xmlfragment("com.alcon.vendInv.fragments.ValueHelpTable", this);
			this.getView().addDependent(this.oDialog);
			this.oDialog.open(sInputValue);

		},
		onValueHelpRequest: function (oEvent) {
			var sInputValue = oEvent.getSource().getValue();
			var path;
			var oTableStdListTemplate, oBukrs;
			this.byId("VID").setValueState("None");
			oBukrs = this.getView().byId("ccod").getValue();
			if (oBukrs) {
				this.inputId = oEvent.getSource().getId();
				this.oDialog = sap.ui.xmlfragment("com.alcon.vendInv.fragments.vendorValueHelp", this);

				path = "/searchHelp_vendorSet";
				oTableStdListTemplate = new sap.m.ColumnListItem({
					cells: [
						new sap.m.Text({
							wrapping:true,
							text: "{LIFNR}"
						}),
						new sap.m.Text({
							wrapping:true,
							text: "{mcod1}"
						}),
						new sap.m.Text({
							wrapping:true,
							text: "{Stcd1}"
						}),
						new sap.m.Text({
							wrapping:true,
							text: "{Bankl}"
						}),
						new sap.m.Text({
							wrapping:true,
							text: "{Bankn}"
						})
					]
				});
				
			var aFilter = [ new sap.ui.model.Filter("Bukrs", sap.ui.model.FilterOperator.EQ, oBukrs)];
				this.oDialog.unbindAggregation("items");
				if(sInputValue !== ""){
					aFilter.push(new sap.ui.model.Filter("LIFNR", sap.ui.model.FilterOperator.EQ, sInputValue));
				}
				this.oDialog.bindAggregation("items", {
					path: path,
					template: oTableStdListTemplate,
					filters: aFilter
				}); // }// open value help dialog filtered by the input value

				this.getView().addDependent(this.oDialog);
				this.oDialog.open(sInputValue);
			} else {
				this.byId("ccod").setValueState(sap.ui.core.ValueState.Error);
				MessageToast.show("Please enter Company code");
			}
		},
		onValueHelpRequested: function (oEvent) {
			//	var aCols = this.oColModel.getData().cols;
			//			this._oBasicSearchField = new SearchField({
			//				showSearchButton: false
			//			});

			Fragment.load({
				name: "com.alcon.vendInv.fragments.vendorValueHelp",
				controller: this
			}).then(function name(oFragment) {
				this._oValueHelpDialog = oFragment;
				this.getView().addDependent(this._oValueHelpDialog);

				this._oValueHelpDialog.setRangeKeyFields([{
					label: "Vendor",
					key: "VendorId",
					type: "string",
					typeInstance: new typeString({}, {
						maxLength: 7
					})
				}]);

				//				this._oValueHelpDialog.getFilterBar().setBasicSearch(this._oBasicSearchField);

				/*					this._oValueHelpDialog.getTableAsync().then(function (oTable) {
									oTable.setModel(this.oProductsModel);
									oTable.setModel(this.oColModel, "columns");

									if (oTable.bindRows) {
										oTable.bindAggregation("rows", "/searchHelp_vendorSet");
									}

								if (oTable.bindItems) {
										oTable.bindAggregation("items", "/searchHelp_vendorSet", function () {
											return new ColumnListItem({
												cells: aCols.map(function (column) {
													return new Label({ text: "{" + column.template + "}" });
												})
											});
										});
									}

									this._oValueHelpDialog.update();
								}.bind(this)); */
				/*
				var path;var oTableStdListTemplate,oFilterTableNo, oBukrs;	
				this.byId("VID").setValueState("None");
				oBukrs = this.getView().byId("ccod").getValue();
				path = "/searchHelp_vendorSet";
				oTableStdListTemplate = new sap.m.StandardListItem({title: "{LIFNR}",description: "{name1}"});// //create a filter for the binding
				 
				oFilterTableNo = new sap.ui.model.Filter("Bukrs", sap.ui.model.FilterOperator.EQ, oBukrs);
				this.oDialog.unbindAggregation("items");
				this.oDialog.bindAggregation("items", {
				path: path,
				template: oTableStdListTemplate,
				filters: [oFilterTableNo]}
				);// }// open value help dialog filtered by the input value
				*/
				//	this._oValueHelpDialog.setTokens(this._oMultiInput.getTokens());
				this._oValueHelpDialog.open();
			}.bind(this));

		},
		onPoValueHelp: function (oEvent) {

			var path;
			var oTableStdListTemplate, oFilterTableNo, oBukrs, oVendor;
			oBukrs = this.getView().byId("ccod").getValue();
			oVendor = this.getView().byId("VID").getValue();
			if (oBukrs !== "" & oVendor !== "") {
				var sInputValue = oEvent.getSource().getValue();
				this.inputId = oEvent.getSource().getId();
				this.byId("po").setValueState("None");
				this.oDialog = sap.ui.xmlfragment("com.alcon.vendInv.fragments.poValueHelp", this);
				path = "/searchHelp_POSet";
				oTableStdListTemplate = new sap.m.StandardListItem({
					title: "{Ebeln}"
				}); // //create a filter for the binding

				oFilterTableNo = [new Filter("Bukrs", FilterOperator.EQ, oBukrs),
					new Filter("Lifnr", FilterOperator.EQ, oVendor)
				];
				this.oDialog.unbindAggregation("items");
				this.oDialog.bindAggregation("items", {
						path: path,
						template: oTableStdListTemplate,
						filters: oFilterTableNo
					}
					//}
				); // }// open value help dialog filtered by the input value

				this.getView().addDependent(this.oDialog);
				this.oDialog.open(sInputValue);
			} else {
				if (oBukrs === "") {
					this.byId("ccod").setValueState(sap.ui.core.ValueState.Error);
					MessageToast.show("Please enter Company code");
				} else {
					this.byId("VID").setValueState(sap.ui.core.ValueState.Error);
					MessageToast.show("Please enter Vendor Number");
				}
			}
		},
		handleTableValueHelpConfirm: function (e) {
			var s = e.getParameter("selectedItem");
			if (s) {
				this.byId(this.inputId).setValue(s.getBindingContext().getObject().Bukrs);
				this.getView().byId("nameText").setText(s.getBindingContext().getObject().Butxt);

				this.readRefresh(e);
			}
			this.oDialog.destroy();
		},
		handleTableValueHelpCancel: function (evt) {
			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				var oInput = this.byId(this.inputId);
				oInput.setValue(oSelectedItem.getTitle());
				evt.getSource().getBinding("items").filter([]);
			}
		},
		handleTableValueHelpSearch: function (evt) {
			var sValue = evt.getParameter("value"),
				path = evt.getParameter("itemsBinding").sPath,
				oFilter;
			if (path === "/searchHelp_BukrsSet") {
				if (sValue !== "") {
					oFilter = [
						new Filter("Bukrs",
							sap.ui.model.FilterOperator.Contains, sValue),
						new Filter("Butxt", FilterOperator.Contains, sValue)
					];

					this.oDialog.getBinding("items").filter(oFilter);
				} else {
					this.oDialog.getBinding("items").filter();
				}
			} else if (path === "/searchHelp_vendorSet") {
				if (sValue !== "") {
					var InputFilter = new sap.ui.model.Filter({
						filters: [
							new Filter("LIFNR", FilterOperator.Contains, sValue),
							new Filter("mcod1", FilterOperator.Contains, sValue),
							new Filter("Stcd1", FilterOperator.Contains, sValue),
							new Filter("Bankl", FilterOperator.Contains, sValue),
							new Filter("Bankn", FilterOperator.Contains, sValue)
						],
						and: true
					});

					evt.getSource().getBinding("items").filter([InputFilter]);
					///	evt.getSource().getBinding("items").filter(oFilter);
				} else {
					this.oDialog.getBinding("items").filter();
					var oItem = this.oDialog.getBinding("items");
					if(oItem.aApplicationFilters.length === 2){
						oItem.aApplicationFilters.splice(1,1);
					}
				}
			} else {
				if (sValue !== "") {
					oFilter = new Filter(
						"Ebeln",
						sap.ui.model.FilterOperator.Contains, sValue);
					this.oDialog.getBinding("items").filter([oFilter]);
				} else {
					this.oDialog.getBinding("items").filter();
				}
			}
		},
		handleTableValueHelpConfirm1: function (e) {
			var s = e.getParameter("selectedItem");
			if (s) {
				this.byId(this.inputId).setValue(s.getBindingContext().getObject().LIFNR);
				this.getView().byId("name1").setText(s.getBindingContext().getObject().mcod1);

				//this.readRefresh(e);
			}
			this.oDialog.destroy();
		},

		handleTableValueHelpConfirm2: function (evt) {
			var aSelectedItems = evt.getParameter("selectedItems"),
				oMultiInput = this.byId("po");

			if (aSelectedItems && aSelectedItems.length > 0) {
				aSelectedItems.forEach(function (oItem) {
					oMultiInput.addToken(new Token({
						text: oItem.getTitle()
					}));
				});
			}

		},
		//Date picker validation
		handleChange: function (oEvent) {
			var
				bValid = oEvent.getParameter("valid"),
				oEventSource = oEvent.getSource();
			//	oEventSource.setDisplayFormat("dd/mm/yyyy");

			this._iEvent++;

			if (bValid) {
				oEventSource.setValueState(sap.ui.core.ValueState.None);
			} else {
				oEventSource.setValueState(sap.ui.core.ValueState.Error);
				MessageToast.show("Error Valid Date");
			}
		},

		handlePO: function (oEvent) {
			var oPO = oEvent.getSource();
			var oLow = this.getView().byId("po").getValue(),
				oHigh = this.getView().byId("pohigh").getValue();
			if (oHigh < oLow) {
				oPO.setValueState(sap.ui.core.ValueState.Error);
				MessageToast.show("Lower limit is greater than upper limit");
			} else {
				this.byId("pohigh").setValueState("None");
			}
		},
		handleRef: function (oEvent) {
			var oPO = oEvent.getSource();
			var oLow = this.getView().byId("ref").getValue(),
				oHigh = this.getView().byId("refhigh").getValue();
			if (oHigh < oLow) {
				oPO.setValueState(sap.ui.core.ValueState.Error);
				MessageToast.show("Lower limit is greater than upper limit");
			} else {
				this.byId("refhigh").setValueState("None");
			}
		},
		getFooterText: function () {

			var oThat = this;
			var name = "X";
			if (this.getView().byId("txtHelp1").getText() === "") {
				var oModel = oThat.getOwnerComponent().getModel();
				oModel.read("/linkhelpSet(Data='" + name + "')", {
					success: function (oData, oResponse) {

						oThat.byId("txtHelp1").setText(oData.Value);
						oThat.byId("lnkHelp").setHref(oData.Link);
					}
				});
			}
		},
		onExit: function () {
			//Destroy the input fields
			if(sap.ui.getCore().getModel("vendor") !== undefined) {
				sap.ui.getCore().getModel("vendor").destroy();
			}
		},

		//Get default company code on initial load
		getDefaultCompCode: function () {
			var oModel1 = this.getOwnerComponent().getModel();
			var that = this;
			if (this.getView().byId("ccod").getValue() === "") {
			busyDialog.open();
			oModel1.read("/getCompanyCodeSet(Bukrs='')", {
				success: function (oData) {
					that.byId("ccod").setValue(oData.Bukrs);
					that.onChange();
					busyDialog.close();
				},
				error: function (oError) {
					busyDialog.close();
				}
			});
			}
		}

	});
});