sap.ui.define([
	"./BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/Sorter",
	"sap/ui/model/FilterOperator",
	"sap/m/GroupHeaderListItem",
	"sap/ui/Device",
	"sap/ui/core/Fragment",
	"../model/formatter",
	"sap/ui/export/Spreadsheet",
	"sap/ui/export/library"
], function (BaseController, JSONModel, Filter, Sorter, FilterOperator, GroupHeaderListItem, Device, Fragment, formatter, Spreadsheet,
	library) {
	"use strict";
	var EdmType = library.EdmType;
	return BaseController.extend("com.alcon.vendInv.controller.Master", {

		formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the master list controller is instantiated. It sets up the event handling for the master/detail communication and other lifecycle tasks.
		 * @public
		 */
		onInit: function () {

			// Control state model
			var oList = this.byId("lineItemsList");

			//	var oViewModel = this._createViewModel();
			// Put down master list's original value for busy indicator delay,
			// so it can be restored later on. Busy handling on the master list is
			// taken care of by the master list itself.
			//	iOriginalBusyDelay = oList.getBusyIndicatorDelay();

			this._oList = oList;

			//this.setModel(oViewModel, "masterView");
			// Make sure, busy indication is showing immediately so there is no
			// break after the busy indication for loading the view's meta data is
			// ended (see promise 'oWhenMetadataIsLoaded' in AppController)
			//	oList.attachEventOnce("updateFinished", function(){
			// Restore original busy indicator delay for the list
			//	oViewModel.setProperty("/delay", iOriginalBusyDelay);
			//});
			this.getRouter().getRoute("View3").attachPatternMatched(this._onObjectMatched, this);
			if (this.getOwnerComponent().applId) {
				this.getRouter().attachBypassed(this.onBypassed, this);
			}
		},

		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */

		/**
		 * After list data is available, this handler method updates the
		 * master list counter
		 * @param {sap.ui.base.Event} oEvent the update finished event
		 * @public
		 */

		onUpdateFinished: function () {
			var oVData = sap.ui.getCore().getModel("vendor").getData(),
				oBukrs = oVData.CompanyCode,
				oVendor = oVData.vendorNo;
			this.getView().byId("oheadComp").setText(oBukrs + "-" + oVData.companyName);
			this.getView().byId("oheadVend").setText(oVendor);
			this.getView().byId("oheader").setText(oVData.vendorName);
			var oDate = new Date();
			this.getView().byId("oheadDate").setText(formatter.dateFormat1(oDate));
		},

		onListUpdateFinished1: function (oevent) {
			var oTable = this.getView().byId("PaymentlineItem");
			var i, j, k, valueExist;
			var olength = oevent.getParameters().total;
			for (i = 0; i < olength; i++) {
				for (k = 0; k < oTable.getItems(0).length; k++) {
					var oitem = oTable.getItems();
					valueExist = "";
					var oCell = oitem[k].getCells();
					for (j = 1; j < oCell.length & valueExist === ""; j++) {
						if (oCell[j].getText() !== "") {
							valueExist = oCell[j].getText();
						}
					}
					if (valueExist === "") {
						oTable.getAggregation("items")[k].destroy();
					}
				}
			}
		},
		/**
		 * Event handler for the master search field. Applies current
		 * filter value and triggers a new search. If the search field's
		 * 'refresh' button has been pressed, no new search is triggered
		 * and the list binding is refresh instead.
		 * @param {sap.ui.base.Event} oEvent the search event
		 * @public
		 */
		/*	onSearch: function (oEvent) {
				if (oEvent.getParameters().refreshButtonPressed) {
					// Search field's 'refresh' button has been pressed.
					// This is visible if you select any master list item.
					// In this case no new search is triggered, we only
					// refresh the list binding.
					this.onRefresh();
					return;
				}

				var sQuery = oEvent.getParameter("query");
				var oVData = sap.ui.getCore().getModel("vendor").getData();

				if (sQuery) {
					this._oListFilterState.aSearch = [new Filter("Xblnr", FilterOperator.Contains, sQuery),
						new Filter("Bukrs", FilterOperator.EQ, oVData.CompanyCode),
						new Filter("Lifnr", FilterOperator.EQ, oVData.vendorNo)

					];
				} else {
					this._oListFilterState.aSearch = [
						new Filter("Bukrs", FilterOperator.EQ, oVData.CompanyCode),
						new Filter("Lifnr", FilterOperator.EQ, oVData.vendorNo)
					];
				}
				this._applyFilterSearch();

			},*/

		/**
		 * Event handler for refresh event. Keeps filter, sort
		 * and group settings and refreshes the list binding.
		 * @public
		 */
		/*onRefresh: function () {
			this._oList.getBinding("items").refresh();
		},*/

		/**
		 * Event handler for the filter, sort and group buttons to open the ViewSettingsDialog.
		 * @param {sap.ui.base.Event} oEvent the button press event
		 * @public
		 */
		/*onOpenViewSettings: function (oEvent) {
			var sDialogTab = "filter";
			if (oEvent.getSource() instanceof sap.m.Button) {
				var sButtonId = oEvent.getSource().getId();
				if (sButtonId.match("sort")) {
					sDialogTab = "sort";
				} else if (sButtonId.match("group")) {
					sDialogTab = "group";
				}
			}
			// load asynchronous XML fragment
			if (!this.byId("viewSettingsDialog")) {
				Fragment.load({
					id: this.getView().getId(),
					name: "com.alcon.vendInv.view.ViewSettingsDialog1",
					controller: this
				}).then(function (oDialog) {
					// connect dialog to the root view of this component (models, lifecycle)
					this.getView().addDependent(oDialog);
					oDialog.addStyleClass(this.getOwnerComponent().getContentDensityClass());
					oDialog.open(sDialogTab);
				}.bind(this));
			} else {
				this.byId("viewSettingsDialog").open(sDialogTab);
			}
		},*/

		/**
		 * Event handler called when ViewSettingsDialog has been confirmed, i.e.
		 * has been closed with 'OK'. In the case, the currently chosen filters, sorters or groupers
		 * are applied to the master list, which can also mean that they
		 * are removed from the master list, in case they are
		 * removed in the ViewSettingsDialog.
		 * @param {sap.ui.base.Event} oEvent the confirm event
		 * @public
		 */
		/*onConfirmViewSettingsDialog: function (oEvent) {

			this._applySortGroup(oEvent);
		},*/

		/**
		 * Apply the chosen sorter and grouper to the master list
		 * @param {sap.ui.base.Event} oEvent the confirm event
		 * @private
		 */
		/*_applySortGroup: function (oEvent) {
			var mParams = oEvent.getParameters(),
				sPath,
				bDescending,
				aSorters = [];
			sPath = mParams.sortItem.getKey();
			bDescending = mParams.sortDescending;
			aSorters.push(new Sorter(sPath, bDescending));
			this._oList.getBinding("items").sort(aSorters);
		},*/

		/**
		 * Event handler for the list selection event
		 * @param {sap.ui.base.Event} oEvent the list selectionChange event
		 * @public
		 */
		/*onSelectionChange: function (oEvent) {
			//	var oList = oEvent.getSource(),
			//		bSelected = oEvent.getParameter("selected");
			var bSelected = oEvent.getParameter("listItem");
			// Set object header
			this.getView().byId("oheader").setText(bSelected.getTitle());
			var path = bSelected.getBindingContextPath();
			this.oBinding(path);
			this.onUpdateFinished();

		},*/
		/*oBinding: function (oPath) {

			this.getView().byId("lineItemsList").bindElement(oPath);
			this.getView().byId("lineItemInvList").bindElement(oPath);
			var oTable = this.getView().byId("PaymentlineItem");
			if (oTable !== undefined) {
				var olength = oTable.getItems(0).length,
					i;
				//Refreshing the table						
				for (i = 0; i < olength; i++) {
					oTable.getAggregation("items")[0].destroy();
				}
			}
			this.getView().byId("PaymentlineItem").bindElement(oPath);

		},*/
		/**
		 * Event handler for the bypassed event, which is fired when no routing pattern matched.
		 * If there was an object selected in the master list, that selection is removed.
		 * @public
		 */
		/*onBypassed: function () {
			this._oList.removeSelections(true);
		},*/

		/**
		 * Used to create GroupHeaders with non-capitalized caption.
		 * These headers are inserted into the master list to
		 * group the master list's items.
		 * @param {Object} oGroup group whose text is to be displayed
		 * @public
		 * @returns {sap.m.GroupHeaderListItem} group header with non-capitalized caption.
		 */
		/*createGroupHeader: function (oGroup) {
			return new GroupHeaderListItem({
				title: oGroup.text,
				upperCase: false
			});
		},*/

		/**
		 * Event handler for navigating back.
		 * We navigate back in the browser historz
		 * @public
		 */
		onNavBack: function () {
			// eslint-disable-next-line sap-no-history-manipulation
			history.go(-1);
		},
		onBack: function () {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("View1");
		},
		/* =========================================================== */
		/* begin: internal methods                                     */
		/* =========================================================== */

		/*_createViewModel: function () {
			return new JSONModel({
				isFilterBarVisible: false,
				filterBarLabel: "",
				delay: 0,
				title: this.getResourceBundle().getText("masterTitleCount1", [0]),
				noDataText: this.getResourceBundle().getText("masterListNoDataText1"),
				sortBy: "Bukrs",
				groupBy: "None"
			});
		},*/

		/**
		 * Shows the selected item on the detail page
		 * On phones a additional history entry is created
		 * @param {sap.m.ObjectListItem} oItem selected Item
		 * @private
		 */
		/*_showDetail: function (oItem) {
			var bReplace = !Device.system.phone;
			// set the layout property of FCL control to show two columns
			this.getModel("appView").setProperty("/layout", "TwoColumnsMidExpanded");
			this.getRouter().navTo("object", {
				objectId: oItem.getBindingContext().getProperty("Xblnr")
			}, bReplace);
		},*/

		/**
		 * Sets the item count on the master list header
		 * @param {integer} iTotalItems the total number of items in the list
		 * @private
		 */
		/*	_updateListItemCount : function (iTotalItems) {
			var sTitle;
			// only update the counter if the length is final
			if (iTotalItems === 0)
			{
//Setting dummy path since there is no data found in master page just for refreshing		
				var val;
				var path =		"/getInvoiceHeaderSet(" + val + ")";
this.oBinding(path);
			}
			if (this._oList.getBinding("items").isLengthFinal()) {
				sTitle = this.getResourceBundle().getText("masterTitleCount1", [iTotalItems]);
				this.getModel("masterView").setProperty("/title", sTitle);
			}
		},*/

		/**
		 * Internal helper method to apply both filter and search state together on the list binding
		 * @private
		 */
		/*_applyFilterSearch: function () {
			var aFilters = this._oListFilterState.aSearch.concat(this._oListFilterState.aFilter),
				oViewModel = this.getModel("masterView");
			this._oList.getBinding("items").filter(aFilters, "Application");
			// changes the noDataText of the list in case there are no filter results
			if (aFilters.length !== 0) {
				oViewModel.setProperty("/noDataText", this.getResourceBundle().getText("masterListNoDataWithFilterOrSearchT1"));
			} else if (this._oListFilterState.aSearch.length > 0) {
				// only reset the no data text to default when no new search was triggered
				oViewModel.setProperty("/noDataText", this.getResourceBundle().getText("masterListNoDataText1"));
			}
		},*/
		_onObjectMatched: function (oEvent) {
			var error = ["", null, undefined];
			if (error.includes(this.getOwnerComponent().applId)) {
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("View1");
			} else {
				this.resourceBundle = this.getView().getModel("i18n").getResourceBundle();
				var sObjectId = oEvent.getParameter("arguments").objectId;
				var oVData = sap.ui.getCore().getModel("vendor").getData();
				this.getView().setModel(sap.ui.getCore().getModel("vendor"));
				var oFromDate = oVData.fromDate;
				var oToDate = oVData.toDate;

				var oVendor = oVData.vendorNo;

				if (oFromDate !== null) {
					var lowDate = new Date(oFromDate.getTime() - oFromDate.getTimezoneOffset() * 60 * 1000);
					var highDate = oToDate;
				}
				//if highDate is blank passing low date as high date since ODATA request is expected highdate as mandatory
				if (highDate === "" || highDate === undefined) {
					if (lowDate === "" || lowDate === undefined) {
						lowDate = null;
						//"0000-00-00T00:00:00";
						highDate = null;
					} else {
						highDate = lowDate;
					}
				}
				var aFilters = [
					new Filter("Bukrs", FilterOperator.Contains, sObjectId),
					new Filter("Lifnr", FilterOperator.Contains, oVendor),
					new Filter({
						path: "IRDATS",
						operator: FilterOperator.BT,
						value1: lowDate,
						value2: highDate
					}),
					new Filter({
						path: "Xblnr",
						operator: FilterOperator.BT,
						value1: oVData.refLow,
						value2: oVData.refLow
					})
				];

				this.readCall(aFilters);
				this.onUpdateFinished();
			}
		},

		readCall: function (aFilters) {
			var oModel1 = this.getOwnerComponent().getModel(),
				oInvoicedata = [];
			var busyDialog = new sap.m.BusyDialog();
			var that = this,
				top = 500,
				count = 0;
			busyDialog.open();
			oModel1.read("/getInovicealldetailsSet", {
				filters: aFilters,
				urlParameters: {
					"skip": count,
					"$top": top
				},
				success: function (oData) {
					busyDialog.close();
					for (var i = 0; i < oData.results.length; i++) {
						if (oData.results[i].Xblnr !== "" || i === oData.results.length - 1) {
							oInvoicedata.push(oData.results[i]);
						}
					}
					var oModel = new sap.ui.model.json.JSONModel({
						"getInvoiceDetails": oInvoicedata
					});
					that.getView().setModel(oModel);
				},
				error: function (oError) {
					busyDialog.close();
					var errorMsg = JSON.parse(oError.responseText);
					sap.m.MessageToast.show(errorMsg.error.message.value);
				}
			});
		},
		/**
		 * Internal helper method that sets the filter bar visibility property and the label's caption to be shown
		 * @param {string} sFilterBarText the selected filter value
		 * @private
		 */
		/*_updateFilterBar: function (sFilterBarText) {
			var oViewModel = this.getModel("masterView");
			oViewModel.setProperty("/isFilterBarVisible", (this._oListFilterState.aFilter.length > 0));
			oViewModel.setProperty("/filterBarLabel", this.getResourceBundle().getText("masterFilterBarText", [sFilterBarText]));
		},*/
		//Create column configuration for export table
		createColumnConfig: function () {
			var aCols = [];
			aCols.push({
				label: this.resourceBundle.getText("excelCompCode"),
				property: ["Bukrs", "Totald"],
				template: "{0} {1}",
				textAlign: "right"
			});
			aCols.push({
				label: this.resourceBundle.getText("excelVendorID"),
				property: "Lifnr",
				textAlign: "right"
			});
			
			aCols.push({
				label: this.resourceBundle.getText("Invfidoc"),
				property: "Belnr",
				textAlign: "right"
			});

			aCols.push({
				label: this.resourceBundle.getText("InvdetailColumn8"),
				property: "Xblnr",
				textAlign: "right"
			});

			aCols.push({
				label: this.resourceBundle.getText("InvdetailColumn9"),
				property: "Dabrz",
				type: EdmType.Date,
				textAlign: "right"
			});

			aCols.push({
				label: this.resourceBundle.getText("InvdetailColumn3"),
				property: "Budat",
				type: EdmType.Date,
				textAlign: "right"
			});

			aCols.push({
				label: this.resourceBundle.getText("InvdetailColumn4"),
				property: "Wrbtr",
				textAlign: "right",
				type: EdmType.Number,
				scale: 2,
				delimiter: true
			});
			aCols.push({
				label: this.resourceBundle.getText("detailColumn5"),
				property: "Waers",
				textAlign: "left"
			});

			aCols.push({
				label: this.resourceBundle.getText("AccdetailColumn2"),
				property: "Zbd1t",
				type: EdmType.Date,
				textAlign: "right"
			});
			aCols.push({
				label: this.resourceBundle.getText("Accpayind"),
				property: "FieldZbd1t",
				textAlign: "right"
			});
			aCols.push({
				label: this.resourceBundle.getText("AccdetailColumn3"),
				property: "FieldAction",
				textAlign: "right"
			});
			aCols.push({
				label: this.resourceBundle.getText("AccdetailColumn4"),
				property: "FieldPlayblk",
				textAlign: "right"
			});
			aCols.push({
				label: this.resourceBundle.getText("PaydetailColumn1"),
				property: "Augbl",
				textAlign: "right"
			});
			aCols.push({
				label: this.resourceBundle.getText("PaydetailColumn3"),
				property: "Bldat",
				type: EdmType.Date,
				textAlign: "right"
			});
			aCols.push({
				label: this.resourceBundle.getText("PaydetailColumn4"),
				property: "FieldPlayMthd",
				textAlign: "right"
			});
			aCols.push({
				label: this.resourceBundle.getText("PaydetailColumn5"),
				property: "Check",
				textAlign: "right"
			});
			aCols.push({
				label: this.resourceBundle.getText("PaydetailColumn6"),
				property: "Date",
				type: EdmType.Date,
				textAlign: "right"
			});
			return aCols;
		},
		//Table content export
		onExport: function () {
			var aCols, oSettings, oSheet;

			aCols = this.createColumnConfig();
			var aInvoiceDet = this.getView().getModel().getData().getInvoiceDetails;

			aInvoiceDet.forEach(function (element) {
				element.FieldZbd1t = formatter.statDesc(element.Zbd1t, element.Stat, element.Zlspr, element.BlartClr, element.Stblg);
				element.FieldAction = formatter.setActionNeeded(element.Zbd1t, element.Stat, element.Zlspr);
				element.FieldPlayblk = formatter.concatDesc(element.Zlspr, element.Textl);
				element.FieldPlayMthd = formatter.concatDesc(element.Zlsch, element.Text1);
			});
			oSettings = {
				workbook: {
					columns: aCols
				},
				dataSource: aInvoiceDet,
				fileName: "Table.xlsx"
			};

			oSheet = new Spreadsheet(oSettings);
			oSheet.build().finally(function () {
				oSheet.destroy();
			});
		},
		onInvoiceImage: function (oEvent) {
			var sCompCode = sap.ui.getCore().getModel("vendor").getData().CompanyCode;
			var sBelnr = oEvent.getSource().getParent().getCells()[0].getItems()[0].getText(); //"5000000007";
			var sFisYr = oEvent.getSource().getParent().getCells()[3].getText().split(", ")[1];
			var aFilters = [
				new Filter("Bukrs", FilterOperator.Contains, sCompCode),
				new Filter("Belnr", FilterOperator.Contains, sBelnr),
				new Filter("FiscalYear", FilterOperator.Contains, sFisYr)
			];
			var oModel1 = this.getOwnerComponent().getModel();
			var that = this;
			var oButton = oEvent.getSource(),
				oView = this.getView();
			if (!this.oPopover) {
				this.oPopover = Fragment.load({
					name: "com.alcon.vendInv.fragments.InvoiceImage",
					controller: this
				}).then(function (oPopover) {
					oView.addDependent(oPopover);
					return oPopover;
				});
			}
			oModel1.read("/getInvoiceAttachmentSet", {
				filters: aFilters,
				success: function (oData) {
					var oModel = new JSONModel({
						"AttachmentSet": oData.results
					});
					that.oPopover.then(function (oPopover) {
						oPopover.setModel(oModel);
						oPopover.openBy(oButton);
					});
				},
				error: function (oError) {
					var errorMsg = JSON.parse(oError.responseText);
					sap.m.MessageToast.show(errorMsg.error.message.value);
				}
			});
		},

		onLinkPress: function (oEvent) {

			var oModel1 = this.getOwnerComponent().getModel();
			var sDocId = oEvent.getSource().getBindingContext().getObject().Arc_doc_id;
			var sArchiveId = oEvent.getSource().getBindingContext().getObject().ArchiveId;
			var sMimeType = oEvent.getSource().getBindingContext().getObject().Mimetype;
			sMimeType = sMimeType.replace("/","_");
			var sUrl = "/getInvoicecontentSet(Arc_doc_id='" + sDocId + "',Mimetype='" + sMimeType + "',ArchiveID='" + sArchiveId + "')/$value";
			var url = oModel1._getServerUrl() + oModel1.sServiceUrl + sUrl;
			this.oPopover.then(function (oPopover) {
				oPopover.close(oEvent.getSource());
			});
			window.open(url);
		}
	});

});