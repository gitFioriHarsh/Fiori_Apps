sap.ui.define([
	"sap/ui/model/json/JSONModel",
	"sap/ui/Device"
], function (JSONModel, Device) {
	"use strict";

	return {

		createDeviceModel: function () {
				// Create Model Instance of the oData service
/*		var oModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/Z8CF_VENDINV_SRV",{
		headers: {
			"x-csrf-token":false
		},
		"tokenHandling": true,
		"tokenHandlingForGet": true
		}
		);
		sap.ui.getCore().setModel(oModel, "myModel");
   var myModel = sap.ui.getCore().getModel("myModel");
/*		myModel.setHeaders({
			"X-Requested-With" : false,
			"disableHeadRequestForToken" : true,
			"x-csrf-token":false
		}); */
	
		var oModel = new JSONModel(Device);
/*            myModel.disableHeadRequestForToken = true;
            oModel.useBatch = true;
            oModel.tokenHandling = false;
             oModel.disableHeadRequestForToken = true; */
			oModel.setDefaultBindingMode("OneWay");
   return oModel;
		}

	};
});