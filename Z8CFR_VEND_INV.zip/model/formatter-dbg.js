sap.ui.define([], function () {
	"use strict";
	return {
		/**
		 * Rounds the currency value to 2 digits
		 *
		 * @public
		 * @param {string} sValue value to be formatted
		 * @returns {string} formatted currency value with 2 digits
		 */
		currencyValue: function (sValue) {
			if (!sValue) {
				return "";
			}
			return "Total" + sValue;
			//	return parseFloat(sValue).toFixed(2
		},
		InvoiceImgVisible: function (sTotal, sHasAttachment) {
			if (sHasAttachment & sTotal === "") {
				return true;
			} else {
				return false;
			}
		},

		dateFormat: function (sValue) {
			if (!sValue) {
				return "";
			}
			var oFormat = sap.ui.core.format.DateFormat.getInstance({
				format: "yMMMd"
			});

			return oFormat.format(sValue, true);

		},
		dateFormat3: function (oValue) {
			if (!oValue) {
				return "";
			}
			var iMonth = String((oValue.getUTCMonth() + 1)).padStart(2, "0");
			var iDate = String(oValue.getUTCDate()).padStart(2, "0");
			return iDate + "." + iMonth + "." + oValue.getUTCFullYear();
		},

		dateFormat1: function (oValue) {
			if (!oValue) {
				return "";
			}
			var sDate = oValue.toDateString();
			var sTimeLong = oValue.toTimeString();
			var sTime = sTimeLong.split("G")[0];

			return sDate + " / " + sTime;

		},

		concatDesc: function (sValue1, svalue2) {
			if (svalue2) {
				if (sValue1) {
					return sValue1.concat(" - " + svalue2);
				} else {
					return svalue2;
				}
			} else {
				return sValue1;
			}
		},
		setStatus: function (sValue1, sValue2, sValue3, sValue4, sValue5) {
			if (sValue5 !== "") {
				return "gray";
			} else {
				if (!sValue1 & !sValue2) {
					return "white";
				} else {
					if (sValue4 === "CL") {
						return "gray";
					} else {
						if (sValue2 === "Paid/Cleared") {
							return "green";
						} else {
							var todayDate = new Date();
							if (sValue1 < todayDate) {
								return "red";
							} else if (sValue1 >= todayDate & sValue3 !== "") {
								return "yellow";
							} else if (sValue1 >= todayDate & sValue3 === "") {
								return "darkblue";
							} else {
								return "";
							}
						}
					}
				}
			}
		},
		statDesc: function (sValue1, sValue2, sValue3, sValue4, sValue5) {
			if (sValue5 !== "") {
				return "Cancelled";
			} else {
				if (!sValue1 & !sValue2) {
					return " ";
				} else {
					if (sValue4 === "CL") {
						return "Cancelled";
					} else {
						if (sValue2 === "Paid/Cleared") {
							return "Paid";
						} else {
							var todayDate = new Date();
							if (sValue1 < todayDate) {
								return "Overdue";
							} else if (sValue1 >= todayDate & !sValue3) {
								return "Not due yet";
							} else {
								return "Not due yet";
							}
						}
					}
				}
			}
		},
		setActionNeeded: function (sValue1, sValue2, sValue3, sValue4) {
			if (!sValue1 & !sValue2) {
				return "";
			} else {
				if (sValue2 === "Paid/Cleared") {
					return "No Action";
				} else if (sValue2 === "Cancelled") {
					return "No Action";
				} else if (sValue4 === "CL") {
					return "No Action";
				} else {
					var todayDate = new Date();
					if (sValue1 < todayDate) {
						return "Review / Resolve Block";
					} else if (sValue1 >= todayDate & !sValue3) {
						return "No Action";
					} else {
						return "Resolve Block";
					}
				}
			}
		}
	};
});