sap.ui.define([
	"./BaseController",
	'jquery.sap.global',
	"sap/ui/core/Fragment",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageBox",
	"sap/m/Token",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/core/format/DateFormat",
	"sap/m/MessageToast"
], function (BaseController, jQuery, Fragment, JSONModel, MessageBox, Token, Filter, FilterOperator, DateFormat, MessageToast) {
	"use strict";
	var FName;
	var LName;
	var email;
	return BaseController.extend("com.spe.YIC_FORM.controller.ChangeIC", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.spe.YIC_FORM.view.ChangeIC
		 */
		onInit: function () {
			var me = this;
			var style = "sapUiSizeCompact";
			me.getView().addStyleClass(style);
			var commentModel = new JSONModel();
			this.getView().setModel(commentModel, "commentModel");
			var approverModelChange = new JSONModel();
			this.getView().setModel(approverModelChange, "approverModelChange");
			var CCModel = new JSONModel();
			this.getView().setModel(CCModel, "CCModel");
			var StdModel = new JSONModel();
			this.getView().setModel(StdModel, "StdModel");
			var MDMAdetails = new JSONModel();
			this.getView().setModel(MDMAdetails, "MDMAdetails");
			var GoaDetails = new JSONModel();
			this.getView().setModel(GoaDetails, "GoaDetails");
			var fdDetails = new JSONModel();
			this.getView().setModel(fdDetails, "fdDetails");
			var viewDataModel = new JSONModel();
			this.getView().setModel(viewDataModel, "viewDataModel");
			FName = sap.ushell.Container.getUser().getFirstName();
			LName = sap.ushell.Container.getUser().getLastName();
			email = sap.ushell.Container.getUser().getEmail();
			// FName = "Harshvardhan";
			// LName = "Kumar";
			// email = "Harshvardhan_kumar@spe.sony.com";
			this.getView().byId("fnameIdChng").setValue(FName);
			this.getView().byId("lnameIdChng").setValue(LName);
			this.getView().byId("emailIdChng").setValue(email);
			this.oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this.oRouter.attachRouteMatched(this._onObjectMatched, this);
		},
		_onObjectMatched: function (oEvent) {
			var me = this;
			var userModel = me.getModel("ICsrvmodel");
			var contextName = oEvent.getParameters().arguments.context;
			if (contextName !== undefined) {
				debugger;
				var that = this;
				var n = new sap.ui.model.Filter("EFORM_NUM", sap.ui.model.FilterOperator.EQ, contextName);
				var myFilter = [];
				myFilter.push(n);
				var oModel = this.getModel("ICsrvmodel");
				oModel.read("/eFormHeaderSet", {
					filters: myFilter,
					success: function (oData, response) {
					MessageToast.show("Work In Progress eFormHeaderSet");	
					}
				});
			} else {
				MessageToast.show("Work In Progress");
			}
		},
		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf com.spe.YIC_FORM.view.ChangeIC
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf com.spe.YIC_FORM.view.ChangeIC
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf com.spe.YIC_FORM.view.ChangeIC
		 */
		//	onExit: function() {
		//
		//	}

	});

});