sap.ui.define([
	"./BaseController",
	'jquery.sap.global',
	"sap/ui/core/Fragment",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageBox",
	"sap/m/Token",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/core/format/DateFormat",
	"sap/m/MessageToast"
], function (BaseController, jQuery, Fragment, JSONModel, MessageBox, Token, Filter, FilterOperator, DateFormat, MessageToast) {
	"use strict";
	var FName;
	var LName;
	var email;
	return BaseController.extend("com.spe.YIC_FORM.controller.CreateIC", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.spe.YIC_FORM.view.CreateIC
		 */
		onInit: function () {
			var me = this;
			var style = "sapUiSizeCompact";
			me.getView().addStyleClass(style);
			var commentModel = new JSONModel();
			this.getView().setModel(commentModel, "commentModel");
			var InterCopanyModel = new JSONModel();
			this.getView().setModel(InterCopanyModel, "InterCopanyModel");
			me.getModel().setData({
				InitialuserinfoSet: {
					items: []
				},
				ProfitCenterSet: {
					items: []
				},
				Title: {
					items: []
				},
				VendorID: {
					items: []
				},
				Currency: {
					items: []
				},
				Reason: {
					items: []
				},
				DisplayEmployee: {
					items: []
				},
				summaryTable: {
					items: []
				},
				ApproverTable: {
					items: []
				},
				Determine: {
					items: []
				}
			});
			var oModel = new JSONModel({
				busy: false,
				lineItemData: [],
				BarAndTable: false,
				SearchButtonVisible: true,
				FooterButton: false
			});
			this.getView().setModel(oModel, "settingsModel");
			var InterCopanyModel = new JSONModel();
			this.getView().setModel(InterCopanyModel, "InterCopanyModel");
			var commentModel = new JSONModel();
			this.getView().setModel(commentModel, "commentModel");
			var EnableModel = new JSONModel();
			this.getView().setModel(EnableModel, "EnableModel");
			FName = sap.ushell.Container.getUser().getFirstName();
			LName = sap.ushell.Container.getUser().getLastName();
			email = sap.ushell.Container.getUser().getEmail();
			// FName = "Harshvardhan";
			// LName = "Kumar";
			// email = "Harshvardhan_kumar@spe.sony.com";
			this.getView().byId("fnameId").setValue(FName);
			this.getView().byId("lnameId").setValue(LName);
			this.getView().byId("emailId").setValue(email);
			this.oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this.oRouter.attachRouteMatched(this._onObjectMatched, this);
		},
		_onObjectMatched: function (oEvent) {
			var me = this;
			var userModel = me.getModel("ICsrvmodel");
			var contextName = oEvent.getParameters().arguments.context;
			if (contextName !== undefined) {
				debugger;
				form_number = contextName;
				var that = this;
				var n = new sap.ui.model.Filter("EFORM_NUM", sap.ui.model.FilterOperator.EQ, contextName);
				var myFilter = [];
				myFilter.push(n);
				var oModel = this.getModel("ICsrvmodel");
				oModel.read("/eFormHeaderSet", {
					filters: myFilter,
					success: function (oData, response) {
						MessageToast.show("Work In Progress eFormHeaderSet");
					}
				});
			} else {
				MessageToast.show("Work in Progress");
			}
		},
		onBPselect: function (oEvent) {
			var aaa = oEvent.getParameters().selectedItem.mProperties.text;
			this.getView().byId("bpInfoId").setVisible(true);
			this.getView().byId("bpTitleId").setText("Business Partner: " + aaa);
		},
		onPressGo: function (oEvent) {
			this.getView().byId("bpLblSelection").setVisible(true);
			this.getView().byId("bpSelection").setVisible(true);
		},
		onscreenchangeMDMA: function () {
			this.getView().byId("actioncolumnid").setVisible(true);
			this.getView().byId("Processedcolumnid").setVisible(true);
			this.getView().byId("bpInfoId").setVisible(true);
			this.getView().byId("demobtnid").setVisible(true);
			this.getView().byId("demobtnnid").setVisible(false);
			this.getView().byId("BPcolumnid").setVisible(true);
		},
		onscreenchangeUser: function () {
			this.getView().byId("actioncolumnid").setVisible(false);
			this.getView().byId("Processedcolumnid").setVisible(false);
			this.getView().byId("bpInfoId").setVisible(false);
			this.getView().byId("demobtnid").setVisible(false);
			this.getView().byId("demobtnnid").setVisible(true);
			this.getView().byId("BPcolumnid").setVisible(false);
		},
		onVHelpCompCode: function (oEvent) {
			var userName = oEvent.getSource();
			var that = this;
			var me = oEvent.getSource().getParent();
			var oValueHelpDialog_RespDiv = new sap.m.SelectDialog({
				title: "Select Company code",
				items: {
					path: "/C_CompanyCodeValueHelp",
					template: new sap.m.StandardListItem({
						title: "{CompanyCode}",
						description: "{CompanyCodeName}"
					})
				},
				//Shipping Point can be searched using Search Bar
				search: function (oEvent) {
					var sValue = oEvent.getParameter("value");
					var oFilter = new sap.ui.model.Filter(
						"CompanyCode",
						sap.ui.model.FilterOperator.Contains, sValue
					);
					oEvent.getSource().getBinding("items").filter([oFilter]);
				},

				confirm: function (oEvent) {
					var oSelectedItem = oEvent.getParameter("selectedItem");
					if (oSelectedItem) {
						userName.setValue(oSelectedItem.getTitle());
						userName.data("key", oSelectedItem.getTitle());
						me.getCells()[1].setValue("");
						me.getCells()[2].setProperty("text", "");
						me.getCells()[3].setValue("");
						me.getCells()[4].setProperty("text", "");
					}
				}
			});
			// }
			var model = this.getOwnerComponent().getModel("ICsrvmodel");
			oValueHelpDialog_RespDiv.setModel(model);
			oValueHelpDialog_RespDiv.open();
		},
		onVHelpCompCode2: function (oEvent) {
			var userName = oEvent.getSource();
			var that = this;
			var me = oEvent.getSource().getParent();
			var oValueHelpDialog_RespDiv = new sap.m.SelectDialog({
				title: "Select Company code",
				items: {
					path: "/C_CompanyCodeValueHelp",
					template: new sap.m.StandardListItem({
						title: "{CompanyCode}",
						description: "{CompanyCodeName}"
					})
				},
				//Shipping Point can be searched using Search Bar
				search: function (oEvent) {
					var sValue = oEvent.getParameter("value");
					var oFilter = new sap.ui.model.Filter(
						"CompanyCode",
						sap.ui.model.FilterOperator.Contains, sValue
					);
					oEvent.getSource().getBinding("items").filter([oFilter]);
				},

				confirm: function (oEvent) {
					var oSelectedItem = oEvent.getParameter("selectedItem");
					if (oSelectedItem) {
						userName.setValue(oSelectedItem.getTitle());
						userName.data("key", oSelectedItem.getTitle());
					}
				}
			});
			// }
			var model = this.getOwnerComponent().getModel("ICsrvmodel");
			oValueHelpDialog_RespDiv.setModel(model);
			oValueHelpDialog_RespDiv.open();
		},
		onAddCompCodes: function () {
			var me = this;
			var that = this;
			var table = this.getView().byId("tblCompcodeid");
			var data = new sap.m.ColumnListItem({
				cells: [
					new sap.m.Input({
						editable: true,
						value: "",
						width: "12em",
						showValueHelp: Boolean("true"),
						valueHelpOnly: Boolean("true"),
						valueHelpRequest: [that.onVHelpCompCode, that]
					}),
					new sap.m.Input({
						editable: true,
						value: "",
						width: "12em",
						showValueHelp: Boolean("true"),
						valueHelpOnly: Boolean("true"),
						valueHelpRequest: [that.onVHelpProfitCenter, that]
					}),
					new sap.m.Text({
						text: ""
					}),
					new sap.m.Input({
						editable: true,
						value: "",
						width: "12em",
						showValueHelp: Boolean("true"),
						valueHelpOnly: Boolean("true"),
						valueHelpRequest: [that.onVHelpCompCode2, that]
					}),
					new sap.m.Text({
						text: ""
					}),
					new sap.ui.core.Icon({

					}),
				]
			});
			table.addItem(data);
		},
		onVHelpProfitCenter: function (oEvent) {
			var that = this;
			var PCName = oEvent.getSource();
			var me = oEvent.getSource().getParent();
			var compcode = me.getCells()[0].mProperties.value;
			var tableCC = that.getView().byId("tblCompcodeid").getItems();
			var pcDateFormat = DateFormat.getDateTimeInstance({
				pattern: "yyyy-MM-dd" + "T" + "hh:mm:ss"
			});
			var OwnPcDate = pcDateFormat.format(new Date());
			var oModel = that.getModel("ICsrvmodel");
			oModel.read("/GetControlingAreaSet('" + compcode + "')", {
				method: "GET",
				success: function (oData, response) {
					var conAreaFilter = oData.ControllingArea;
					var myfilterNew = [];
					var oFilternNew = new sap.ui.model.Filter("Language", sap.ui.model.FilterOperator.EQ, "EN");
					myfilterNew.push(oFilternNew);
					var oFilternNew1 = new sap.ui.model.Filter("ControllingArea", sap.ui.model.FilterOperator.EQ, conAreaFilter);
					myfilterNew.push(oFilternNew1);
					var oFilternNew2 = new sap.ui.model.Filter("ValidityEndDate", sap.ui.model.FilterOperator.GE, OwnPcDate);
					myfilterNew.push(oFilternNew2);
					var oValueHelpDialog_RespDiv = new sap.m.SelectDialog({
						title: "Profit Center for Controlling Area:" +" "+ conAreaFilter,
						items: {
							path: "/A_ProfitCenterText",
							filters: myfilterNew,
							template: new sap.m.StandardListItem({
								title: "{ProfitCenter}",
								description: "{ProfitCenterLongName}"
							})
						},
						search: function (oEvent) {
							var sValue = oEvent.getParameter("value");
							var oFilter = new sap.ui.model.Filter("ProfitCenter", sap.ui.model.FilterOperator.Contains, sValue);
							oEvent.getSource().getBinding("items").filter(oFilter);
						},
						confirm: function (oEvent) {
							var oSelectedItem = oEvent.getParameter("selectedItem");
							var selectedProfitCenter = oSelectedItem.getTitle();
							var selectedDesPC = oSelectedItem.getDescription();
							if (oSelectedItem) {
								PCName.setValue(oSelectedItem.getTitle());
							}
							var myfilterNew = [];
							var oFilternNew = new sap.ui.model.Filter("CompanyCode1", sap.ui.model.FilterOperator.EQ, compcode);
							myfilterNew.push(oFilternNew);
							var oFilternNew1 = new sap.ui.model.Filter("ProfitCenter", sap.ui.model.FilterOperator.EQ, selectedProfitCenter);
							myfilterNew.push(oFilternNew1);
							var oFilternNew2 = new sap.ui.model.Filter("ControllingArea", sap.ui.model.FilterOperator.EQ, conAreaFilter);
							myfilterNew.push(oFilternNew2);
							// return false;
							var oModel = that.getModel("ICsrvmodel");
							// sap.ui.core.BusyIndicator.show();
							oModel.read("/eFormBPInformationSet", {
								method: "GET",
								filters: myfilterNew,
								success: function (oData, response) {
									sap.ui.core.BusyIndicator.hide();
									var BPNumber = oData.results[0].BusinessPartner;
									var Action = oData.results[0].Actiion;
									MessageToast.show("GOT BP & ACTION");
									me.getCells()[2].setProperty("text", BPNumber);
									me.getCells()[4].setProperty("text", Action);
									var tableCC = that.getView().byId("tblCompcodeid").getItems();
								}.bind(this),
								error: function (response) {
									sap.ui.core.BusyIndicator.hide();
									MessageBox.error(response.responseText);
								}.bind(this)
							});
						}
					});
					var model = this.getModel("ICsrvmodel");
					oValueHelpDialog_RespDiv.setModel(model);
					oValueHelpDialog_RespDiv.open();
				}.bind(this),
				error: function (response) {
					MessageBox.error(response.responseText);
				}.bind(this)
			});
		},
		InterCompanyFactory: function (sId, oContext) {
			if (!oContext.getProperty("isInput")) {
				var oTemplate = new sap.m.ColumnListItem({
					cells: [
						new sap.m.Input({
							showValueHelp: true,
							value: "{InterCopanyModel>APPRNAME}",
							enabled: true,
							valueHelpRequest: [this.userValueHelpRequest, this]
						}).data("key", "{InterCopanyModel>APPR_ID}"),
						new sap.m.Text({
							text: "{InterCopanyModel>REVIEWER_TYPE}"
						}),
						new sap.m.Text({
							text: "{InterCopanyModel>ACT_NAME}"
						}),
						new sap.m.Text({
							text: "{InterCopanyModel>ACTION}"
						}),
						new sap.m.Text({
							text: "{InterCopanyModel>ACTION_DATE}"
						}),
						new sap.m.Text({
							text: "{InterCopanyModel>ACTION_TIME}"
						})
					]
				});

			} else {
				var oTemplate = new sap.m.ColumnListItem({
					cells: [
						new sap.m.Link({
							text: "{InterCopanyModel>APPRNAME}",
							press: [this._displayEmployees, this],
							wrapping: true
						}),

						new sap.m.Text({
							// enabled: "{EnableModel>/allow}",
							// enabled: true,
							text: "{InterCopanyModel>REVIEWER_TYPE}",
							// showValueHelp: false
							//valueHelpRequest: [this.conAreaValueHelpRequest, this]

						}),
						new sap.m.Text({
							text: "{InterCopanyModel>ACT_NAME}"

						}),
						new sap.m.Text({
							text: "{InterCopanyModel>ACTION}"
						}),
						new sap.m.Text({
							text: "{InterCopanyModel>ACTION_DATE}"
						}),
						new sap.m.Text({
							text: "{InterCopanyModel>ACTION_TIME}"
						})
					]
				});
			}
			return oTemplate;
		},
		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf com.spe.YIC_FORM.view.CreateIC
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf com.spe.YIC_FORM.view.CreateIC
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf com.spe.YIC_FORM.view.CreateIC
		 */
		//	onExit: function() {
		//
		//	}

	});

});