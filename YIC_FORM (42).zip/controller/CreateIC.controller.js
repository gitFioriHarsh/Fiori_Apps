sap.ui.define([
	"./BaseController",
	'jquery.sap.global',
	"sap/ui/core/Fragment",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageBox",
	"sap/m/Token",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/core/format/DateFormat",
	"sap/m/MessageToast"
], function (BaseController, jQuery, Fragment, JSONModel, MessageBox, Token, Filter, FilterOperator, DateFormat, MessageToast) {
	"use strict";
	var FName;
	var LName;
	var email;
	var form_number = "";
	var e_form_num;
	var file_size;
	var statusSaveSub;
	var Createdby;
	var conAreaFilter;
	var Formstatus;
	var currnAppr;
	return BaseController.extend("com.spe.YIC_FORM.controller.CreateIC", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.spe.YIC_FORM.view.CreateIC
		 */
		onInit: function () {
			var me = this;
			var style = "sapUiSizeCompact";
			me.getView().addStyleClass(style);
			me.getModel().setData({
				Reason: {
					items: []
				},
				DisplayEmployee: {
					items: []
				},
				ApproverTable: {
					items: []
				},
				Determine: {
					items: []
				}
			});
			var InterCopanyModel = new JSONModel();
			this.getView().setModel(InterCopanyModel, "InterCopanyModel");
			var commentModel = new JSONModel();
			this.getView().setModel(commentModel, "commentModel");
			var EnableModel = new JSONModel();
			this.getView().setModel(EnableModel, "EnableModel");
			var CMIdetails = new JSONModel();
			this.getView().setModel(CMIdetails, "CMIdetails");
			var MDMAdetails = new JSONModel();
			this.getView().setModel(MDMAdetails, "MDMAdetails");
			var GoaDetails = new JSONModel();
			this.getView().setModel(GoaDetails, "GoaDetails");
			var viewDataModel = new JSONModel();
			this.getView().setModel(viewDataModel, "viewDataModel");
			var approverModel = new JSONModel();
			this.getView().setModel(approverModel, "approverModel");
			var BPInfoModel = new JSONModel();
			this.getView().setModel(BPInfoModel, "BPInfoModel");
			FName = sap.ushell.Container.getUser().getFirstName();
			LName = sap.ushell.Container.getUser().getLastName();
			email = sap.ushell.Container.getUser().getEmail();
			// FName = "Harshvardhan";
			// LName = "Kumar";
			// email = "Harshvardhan_kumar@spe.sony.com";
			this.getView().byId("fnameId").setValue(FName);
			this.getView().byId("lnameId").setValue(LName);
			this.getView().byId("emailId").setValue(email);
			this.oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this.oRouter.attachRouteMatched(this._onObjectMatched, this);
		},
		_onObjectMatched: function (oEvent) {
			var that = this;
			this.form_number = "";
			var contextName = oEvent.getParameters().arguments.context;
			var table = this.getView().byId("tblCompcodeid");
			this.mdmnr_appr = contextName;
			if (contextName !== undefined) {
				debugger;
				table.removeSelections();
				this.form_number = contextName;
				form_number = contextName;
				that.getView().byId("idEditICNode").setVisible(true);
				that.getView().byId("bpInfoId").setVisible(false);
				that.getdetailsCMI();
				that.getMDMAdetails();
				that.getdetailsGoa();
				that.getContextBackendData(contextName);
			} else {
				table.removeSelections();
				that.getView().byId("locId").setEnabled(true);
				that.getView().byId("phoneId").setEnabled(true);
				that.getView().byId("brsiId").setEnabled(true);
				that.getView().byId("idEditICNode").setVisible(false);
				that.getView().byId("bpInfoId").setVisible(false);
				var oTableModel = this.getView().getModel("InterCopanyModel");
				var oDataSet = oTableModel.getData();
				var oDataSet = [];
				oDataSet.push({
					CompanyCode1: "",
					ProfitCenter: "",
					BusinessPartner: "",
					CompanyCode2: "",
					Actiion: "",
					Processed: ""
				});
				this.getView().byId("pageId").setTitle("Create / Extend IC 2 step Settled Relationship");
				this.getView().byId("fnameId").setValue(FName);
				this.getView().byId("lnameId").setValue(LName);
				this.getView().byId("emailId").setValue(email);
				this.getView().byId("locId").setValue("");
				this.getView().byId("phoneId").setValue("");
				this.getView().byId("brsiId").setValue("");
				this.getView().byId("idstatus").setValue("");
				this.getView().getModel("viewDataModel").setData(null);
				this.getView().getModel("InterCopanyModel").setData(oDataSet);
				this.getView().getModel("commentModel").setData(null);
				this.getView().getModel("approverModel").setData(null);
				this.getView().getModel("BPInfoModel").setData([]);
				this.getView().byId("t_attachmentIC").destroyItems();
				this.getView().byId("idButtonSave").setVisible(true);
				this.getView().byId("idButtonSubmit").setVisible(true);
				this.getView().byId("idButtonwithdraw").setVisible(false);
				this.getView().byId("idButtonApprove").setVisible(false);
				this.getView().byId("idButtonReject").setVisible(false);
				this.getView().byId("idButtonupdate").setVisible(false);
				this.getView().byId("idButtoncomplete").setVisible(false);
				this.getView().byId("idButtonMaintain").setVisible(false);
				this.getView().byId("actioncolumnid").setVisible(false);
				this.getView().byId("Processedcolumnid").setVisible(false);
				this.getView().byId("BPcolumnid").setVisible(false);
				this.getView().byId("idApproverToolbar").setVisible(true);
				this.getView().byId("idBPInfoToolbar").setVisible(true);
			}
		},
		getContextBackendData: function (contextName) {
			var that = this;
			var cmiUserList = [];
			cmiUserList = this.getView().getModel("CMIdetails").getData();
			var mdmaUserList = [];
			mdmaUserList = this.getView().getModel("MDMAdetails").getData();
			var goaUserList = [];
			goaUserList = this.getView().getModel("GoaDetails").getData();
			var oModel = that.getModel("ICsrvmodel");
			oModel.read("/eFormHeaderSet('" + contextName + "')", {
				method: "GET",
				urlParameters: {
					"$expand": "eFormBPInformationSet,eFormCommentSet,eFormApproverSet,eFormBPDetailsSet"
				},
				success: function (oData, response) {
					that.getView().byId("pageId").setTitle('Create / Extend IC 2 step Settled Relationship' + ':' + " " + oData.EFORM_NUM);
					that.getView().byId("fnameId").setValue(oData.FirstName);
					that.getView().byId("lnameId").setValue(oData.Lastname);
					that.getView().byId("emailId").setValue(oData.eMailAddress);
					that.getView().byId("locId").setValue(oData.Location);
					that.getView().byId("phoneId").setValue(oData.Tel_Number);
					that.getView().byId("brsiId").setValue(oData.Reason);
					that.getView().byId("idstatus").setValue(oData.Status_Desc);
					Formstatus = oData.Status;
					currnAppr = oData.CurrentApprover;
					that.getView().getModel("InterCopanyModel").setData(oData.eFormBPInformationSet.results);
					that.getView().getModel("commentModel").setData(oData.eFormCommentSet.results);
					that.getView().getModel("viewDataModel").setData(oData);
					that.getView().getModel("BPInfoModel").setProperty('/BPInformationData', oData.eFormBPDetailsSet.results);
					that.getView().getModel("BPInfoModel").setProperty('/BPInformationCopyData', JSON.parse(JSON.stringify(oData.eFormBPDetailsSet
						.results)));
					that.getApproversData(oData.EFORM_NUM, oData.Status);
					that.getattachments(contextName);
					that.getComments(oData.EFORM_NUM);
					that.makeEditableFalse();

					// Buttons Visibility
					if (oData.CreatedBy !== sap.ushell.Container.getService("UserInfo").getUser().getId()) {
						that.getView().byId("idButtonSave").setVisible(false);
						that.getView().byId("idButtonSubmit").setVisible(false);
						that.getView().byId("locId").setEnabled(false);
						that.getView().byId("phoneId").setEnabled(false);
						that.getView().byId("brsiId").setEnabled(false);
					}
					if (oData.Status === "02" || oData.Status === "03") {
						that.getView().byId("locId").setEnabled(false);
						that.getView().byId("phoneId").setEnabled(false);
						that.getView().byId("brsiId").setEnabled(false);
						that.getView().byId("idButtonSave").setVisible(false);
						that.getView().byId("idButtonSubmit").setVisible(false);
						that.getView().byId("idButtonupdate").setVisible(true);
						that.getView().byId("idButtonApprove").setVisible(true);
						that.getView().byId("idButtonReject").setVisible(true);
						that.getView().byId("idButtoncomplete").setVisible(false);
						that.getView().byId("idButtonMaintain").setVisible(false);
						that.getView().byId("idApproverToolbar").setVisible(true);
						that.getView().byId("idBPInfoToolbar").setVisible(false);
						if (oData.CreatedBy === sap.ushell.Container.getService("UserInfo").getUser().getId()) {
							that.getView().byId("idButtonwithdraw").setVisible(true);
							that.getView().byId("idButtonupdate").setVisible(true);
						}
						for (var m = 0; m < mdmaUserList.length; m++) {
							if (mdmaUserList[m].Name === sap.ushell.Container.getService("UserInfo").getUser().getId()) {
								that.getView().byId("idButtonMaintain").setVisible(false);
								that.getView().byId("actioncolumnid").setVisible(true);
								that.getView().byId("Processedcolumnid").setVisible(true);
								that.getView().byId("BPcolumnid").setVisible(true);
								that.getView().byId("idBPInfoToolbar").setVisible(true);
							}
						}
					}
					if (oData.Status === "04") {
						that.getView().byId("locId").setEnabled(false);
						that.getView().byId("phoneId").setEnabled(false);
						that.getView().byId("brsiId").setEnabled(false);
						that.getView().byId("idButtonSave").setVisible(false);
						that.getView().byId("idButtonSubmit").setVisible(false);
						that.getView().byId("idButtonupdate").setVisible(false);
						that.getView().byId("idButtonwithdraw").setVisible(false);
						that.getView().byId("idButtonApprove").setVisible(false);
						that.getView().byId("idButtonReject").setVisible(false);
						that.getView().byId("idButtoncomplete").setVisible(false);
						that.getView().byId("idButtonMaintain").setVisible(false);
						that.getView().byId("idApproverToolbar").setVisible(false);
						that.getView().byId("idBPInfoToolbar").setVisible(false);
						for (var m = 0; m < mdmaUserList.length; m++) {
							if (mdmaUserList[m].Name === sap.ushell.Container.getService("UserInfo").getUser().getId()) {
								that.getView().byId("idButtonupdate").setVisible(true);
								that.getView().byId("idButtonMaintain").setVisible(true);
								that.getView().byId("actioncolumnid").setVisible(true);
								that.getView().byId("Processedcolumnid").setVisible(true);
								that.getView().byId("BPcolumnid").setVisible(true);
							}
						}
					}
					if (oData.Status === "05") {
						that.getView().byId("locId").setEnabled(false);
						that.getView().byId("phoneId").setEnabled(false);
						that.getView().byId("brsiId").setEnabled(false);
						that.getView().byId("idButtonSave").setVisible(false);
						that.getView().byId("idButtonSubmit").setVisible(false);
						that.getView().byId("idButtonApprove").setVisible(false);
						that.getView().byId("idButtonReject").setVisible(false);
						that.getView().byId("idButtonupdate").setVisible(false);
						that.getView().byId("idButtoncomplete").setVisible(false);
						that.getView().byId("idButtonMaintain").setVisible(false);
						that.getView().byId("idButtonwithdraw").setVisible(false);
						that.getView().byId("idApproverToolbar").setVisible(false);
						that.getView().byId("idBPInfoToolbar").setVisible(false);
					}
					if (oData.Status === "07") {
						that.getView().byId("BPcolumnid").setVisible(true);
						that.getView().byId("actioncolumnid").setVisible(true);
						that.getView().byId("Processedcolumnid").setVisible(true);
					}
					if (oData.Status === "07" || oData.Status === "10") {
						that.getView().byId("locId").setEnabled(false);
						that.getView().byId("phoneId").setEnabled(false);
						that.getView().byId("brsiId").setEnabled(false);
						that.getView().byId("idButtonSave").setVisible(false);
						that.getView().byId("idButtonSubmit").setVisible(false);
						that.getView().byId("idButtonApprove").setVisible(false);
						that.getView().byId("idButtonReject").setVisible(false);
						that.getView().byId("idButtonupdate").setVisible(false);
						that.getView().byId("idButtoncomplete").setVisible(false);
						that.getView().byId("idButtonMaintain").setVisible(false);
						that.getView().byId("idApproverToolbar").setVisible(false);
						that.getView().byId("idBPInfoToolbar").setVisible(false);
					}
					if (oData.Status === "09") {
						that.getView().byId("locId").setEnabled(false);
						that.getView().byId("phoneId").setEnabled(false);
						that.getView().byId("brsiId").setEnabled(false);
						that.getView().byId("idButtonSave").setVisible(false);
						that.getView().byId("idButtonSubmit").setVisible(false);
						that.getView().byId("idButtonApprove").setVisible(false);
						that.getView().byId("idButtonReject").setVisible(false);
						that.getView().byId("idButtonupdate").setVisible(false);
						that.getView().byId("idButtonMaintain").setVisible(false);
						that.getView().byId("idButtonwithdraw").setVisible(false);
						that.getView().byId("idApproverToolbar").setVisible(false);
						that.getView().byId("idBPInfoToolbar").setVisible(false);
						for (var m = 0; m < mdmaUserList.length; m++) {
							if (mdmaUserList[m].Name === sap.ushell.Container.getService("UserInfo").getUser().getId()) {
								that.getView().byId("idButtoncomplete").setVisible(true);
								that.getView().byId("actioncolumnid").setVisible(true);
								that.getView().byId("BPcolumnid").setVisible(true);
								that.getView().byId("actioncolumnid").setVisible(true);
								that.getView().byId("Processedcolumnid").setVisible(true);
							}
						}
					}
					var LoggedUserid = sap.ushell.Container.getService("UserInfo").getUser().getId();
					// var LoggedUserid = "SGUHA2"
					var ApproverspersonsArray = [];
					var concatall = ApproverspersonsArray.concat(cmiUserList, goaUserList, mdmaUserList);
					var error = false;
					concatall.forEach(function (enteredQr) {
						if (enteredQr.Name === LoggedUserid) {
							error = true;
						}
					}.bind(this));
					if (error === false && (oData.Status === "02" || oData.Status === "03")) {
						that.getView().byId("idButtonupdate").setVisible(false);
						that.getView().byId("idButtonApprove").setVisible(false);
						that.getView().byId("idButtonReject").setVisible(false);
					}

					if (error === true && (oData.Status === "02" || oData.Status === "03")) {
						that.getView().byId("idButtonupdate").setVisible(true);
						that.getView().byId("idButtonApprove").setVisible(true);
						that.getView().byId("idButtonReject").setVisible(true);
					}
				}.bind(this),
				error: function (oData) {
					var strResponse = oData.responseText;
					var strErrorDetail = strResponse.substring(strResponse.indexOf("error"));
					var strStatusMsg = strErrorDetail.split(",")[2];
					var strFullStatus = strStatusMsg;
					var strStatus = strFullStatus.substring(strFullStatus.indexOf("message") + 10) + "";
					var strStatus1 = strStatus.slice(0, -2) + "";
					MessageBox.error(strStatus1);
				}.bind(this)
			});
		},
		onEditInterCompany: function () {
			var that = this;
			that.makeEditableTrue();
			that.getView().byId("idshowICNode").setVisible(true);
			that.getView().byId("idEditICNode").setVisible(false);
		},
		onDisplayInterCompany: function () {
			var that = this;
			that.makeEditableFalse();
			that.getView().byId("idshowICNode").setVisible(false);
			that.getView().byId("idEditICNode").setVisible(true);
			table.setMode(sap.m.ListMode.Delete); // Delete mode selection
			table.setMode(sap.m.ListMode.SingleSelectLeft); // Put it back.
		},
		makeEditableFalse: function () {
			var that = this;
			var tableCC = that.getView().byId("tblCompcodeid").getItems();
			for (var i = 0; i < tableCC.length; i++) {
				tableCC[i].getCells()[0].setEditable(false);
				tableCC[i].getCells()[1].setEditable(false);
				tableCC[i].getCells()[3].setEditable(false);
			}
		},
		makeEditableTrue: function () {
			var that = this;
			var tableCC = that.getView().byId("tblCompcodeid").getItems();
			for (var i = 0; i < tableCC.length; i++) {
				tableCC[i].getCells()[0].setEditable(true);
				tableCC[i].getCells()[1].setEditable(true);
				tableCC[i].getCells()[3].setEditable(true);
			}
		},
		onscreenchangeMDMA: function () {
			var table = this.getView().byId("tblCompcodeid");
			table.removeSelections();
			this.getView().byId("actioncolumnid").setVisible(true);
			this.getView().byId("Processedcolumnid").setVisible(true);
			this.getView().byId("bpInfoId").setVisible(true);
			this.getView().byId("demobtnid").setVisible(true);
			this.getView().byId("demobtnnid").setVisible(false);
			this.getView().byId("BPcolumnid").setVisible(true);
		},
		onscreenchangeUser: function () {
			var table = this.getView().byId("tblCompcodeid");
			table.removeSelections();
			this.getView().byId("actioncolumnid").setVisible(false);
			this.getView().byId("Processedcolumnid").setVisible(false);
			this.getView().byId("bpInfoId").setVisible(false);
			this.getView().byId("demobtnid").setVisible(false);
			this.getView().byId("demobtnnid").setVisible(true);
			this.getView().byId("BPcolumnid").setVisible(false);
		},
		onSelectBPInfo: function (oEvent) {
			var mdmaUserList = [];
			mdmaUserList = this.getView().getModel("MDMAdetails").getData();
			var oSource = oEvent.getSource();
			var oBPInfoModel = this.getView().getModel("BPInfoModel");
			var oSelectedItem = oSource.getSelectedItem();
			var sPath = oSelectedItem.getBindingContextPath();
			var oBPInfoSelectedItem = oBPInfoModel.getProperty("/BPInformationData" + sPath);
			oBPInfoModel.setProperty("/BPInfoSelectedItem", oBPInfoSelectedItem);
			this.getView().getModel("BPInfoModel").refresh();
			for (var m = 0; m < mdmaUserList.length; m++) {
				if (mdmaUserList[m].Name === sap.ushell.Container.getService("UserInfo").getUser().getId() && currnAppr === "MDMA") {
					this.getView().byId("bpInfoId").setVisible(true);
				}
			}
		},
		onVHelpCompCode: function (oEvent) {
			var that = this;
			var userName = oEvent.getSource();
			var me = oEvent.getSource().getParent();
			var ColumnName = oEvent.getSource().mBindingInfos.value.parts[0].path;
			var compcode = me.getCells()[0].mProperties.value;
			var selectedProfitCenter = me.getCells()[1].mProperties.value;
			var table = that.getView().byId("tblCompcodeid");
			var tableCC = that.getView().byId("tblCompcodeid").getItems();
			var sContext = oEvent.getSource().getParent().getBindingContextPath();
			var index = sContext.slice(1);
			var spath = parseInt(index);
			if (ColumnName === "CompanyCode2") {
				if (selectedProfitCenter === "" || selectedProfitCenter === null | selectedProfitCenter === undefined) {
					MessageBox.error("Please select Profit center");
					return false;
				}
			}
			var me = oEvent.getSource().getParent();
			// var ColumnName = oEvent.getSource().mBindingInfos.value.parts[0].path;
			var oValueHelpDialog_RespDiv = new sap.m.SelectDialog({
				title: "Select Company code",
				items: {
					path: "/C_CompanyCodeValueHelp",
					template: new sap.m.StandardListItem({
						title: "{CompanyCode}",
						description: "{CompanyCodeName}"
					})
				},
				//Company code can be searched using Search Bar
				search: function (oEvent) {
					var sValue = oEvent.getParameter("value");
					var oFilter = new sap.ui.model.Filter(
						"CompanyCode",
						sap.ui.model.FilterOperator.Contains, sValue
					);
					oEvent.getSource().getBinding("items").filter([oFilter]);
				},

				confirm: function (oEvent) {
					var oSelectedItem = oEvent.getParameter("selectedItem");
					var comcode2 = oSelectedItem.getTitle();
					if (oSelectedItem) {
						userName.setValue(oSelectedItem.getTitle());
						userName.data("key", oSelectedItem.getTitle());
						if (ColumnName === "CompanyCode1") {
							me.getCells()[1].setValue("");
							me.getCells()[2].setProperty("text", "");
							me.getCells()[3].setValue("");
							me.getCells()[4].setProperty("text", "");
						}
						if (ColumnName === "CompanyCode2") {
							if (me.getCells()[0].mProperties.value === oSelectedItem.getTitle()) {
								MessageBox.error("Company Code 2 and Company code 1 can not be same.");
								me.getCells()[3].setValue("");
								return false;
							}
							var myfilterNew = [];
							var oFilternNew = new sap.ui.model.Filter("CompanyCode1", sap.ui.model.FilterOperator.EQ, compcode);
							myfilterNew.push(oFilternNew);
							var oFilternNew1 = new sap.ui.model.Filter("CompanyCode2", sap.ui.model.FilterOperator.EQ, comcode2);
							myfilterNew.push(oFilternNew1);
							var oFilternNew2 = new sap.ui.model.Filter("ProfitCenter", sap.ui.model.FilterOperator.EQ, selectedProfitCenter);
							myfilterNew.push(oFilternNew2);
							var oFilternNew3 = new sap.ui.model.Filter("ControllingArea", sap.ui.model.FilterOperator.EQ, conAreaFilter);
							myfilterNew.push(oFilternNew3);
							// return false;
							var oModel = that.getModel("ICsrvmodel");
							oModel.read("/eFormBPInformationSet", {
								method: "GET",
								filters: myfilterNew,
								success: function (oData, response) {
									var BPNumber = oData.results[0].BusinessPartner;
									var Action = oData.results[0].Actiion;
									var table = that.getView().byId("tblCompcodeid");
									for (var i = 0; i <= table.getItems().length - 1; i++) {
										if (spath === i) {
											table.mAggregations.items[i].getCells()[2].setText(BPNumber);
											table.mAggregations.items[i].getCells()[4].setText(Action);
										}
									}
								}.bind(this),
								error: function (oError) {
									var table = that.getView().byId("tblCompcodeid");
									for (var i = 0; i <= table.getItems().length - 1; i++) {
										if (spath === i) {
											// table.mAggregations.items[i].getCells()[0].setValue("");
											// table.mAggregations.items[i].getCells()[1].setValue("");
											table.mAggregations.items[i].getCells()[3].setValue("");
										}
									}
									var response = JSON.parse(oError.responseText);
									MessageBox.show(
										response.error.message.value,
										MessageBox.Icon.ERROR,
										"Error"
									);
								}.bind(this)
							});
						}
					}
				}
			});
			// }
			var model = this.getOwnerComponent().getModel("ICsrvmodel");
			oValueHelpDialog_RespDiv.setModel(model);
			oValueHelpDialog_RespDiv.open();
		},
		onVHelpCompCodeBP: function (oEvent) {
			var that = this;
			var userName = oEvent.getSource();
			var oValueHelpDialog_RespDiv = new sap.m.SelectDialog({
				title: "Select Company code",
				items: {
					path: "/C_CompanyCodeValueHelp",
					template: new sap.m.StandardListItem({
						title: "{CompanyCode}",
						description: "{CompanyCodeName}"
					})
				},
				//Company code can be searched using Search Bar
				search: function (oEvent) {
					var sValue = oEvent.getParameter("value");
					var oFilter = new sap.ui.model.Filter(
						"CompanyCode",
						sap.ui.model.FilterOperator.Contains, sValue
					);
					oEvent.getSource().getBinding("items").filter([oFilter]);
				},
				confirm: function (oEvent) {
					var oSelectedItem = oEvent.getParameter("selectedItem");
					var comcode2 = oSelectedItem.getTitle();
					if (oSelectedItem) {
						userName.setValue(oSelectedItem.getTitle());
						userName.data("key", oSelectedItem.getTitle());
					}
				}
			});
			// }
			var model = this.getOwnerComponent().getModel("ICsrvmodel");
			oValueHelpDialog_RespDiv.setModel(model);
			oValueHelpDialog_RespDiv.open();
		},
		onVHelpCountry: function (oEvent) {
			var that = this;
			var userName = oEvent.getSource();
			var oValueHelpDialog_RespDiv = new sap.m.SelectDialog({
				title: "Select Country",
				items: {
					path: "/I_CountryText",
					template: new sap.m.StandardListItem({
						title: "{Country}",
						description: "{CountryName}"
					})
				},
				//Company code can be searched using Search Bar
				search: function (oEvent) {
					var sValue = oEvent.getParameter("value");
					var oFilter = new sap.ui.model.Filter(
						"CountryName",
						sap.ui.model.FilterOperator.Contains, sValue
					);
					oEvent.getSource().getBinding("items").filter([oFilter]);
				},
				confirm: function (oEvent) {
					var oSelectedItem = oEvent.getParameter("selectedItem");
					var comcode2 = oSelectedItem.getTitle();
					if (oSelectedItem) {
						userName.setValue(oSelectedItem.getTitle());
						userName.data("key", oSelectedItem.getTitle());
					}
				}
			});
			// }
			var model = this.getOwnerComponent().getModel("ICsrvmodel");
			oValueHelpDialog_RespDiv.setModel(model);
			oValueHelpDialog_RespDiv.open();
		},
		onVHelpRegion: function (oEvent) {
			var that = this;
			var userName = oEvent.getSource();
			var oValueHelpDialog_RespDiv = new sap.m.SelectDialog({
				title: "Select Region",
				items: {
					path: "/I_PrepaymentRegionText",
					template: new sap.m.StandardListItem({
						title: "{Region}",
						description: "{RegionName}"
					})
				},
				//Company code can be searched using Search Bar
				search: function (oEvent) {
					var sValue = oEvent.getParameter("value");
					var oFilter = new sap.ui.model.Filter(
						"RegionName",
						sap.ui.model.FilterOperator.Contains, sValue
					);
					oEvent.getSource().getBinding("items").filter([oFilter]);
				},
				confirm: function (oEvent) {
					var oSelectedItem = oEvent.getParameter("selectedItem");
					var comcode2 = oSelectedItem.getTitle();
					if (oSelectedItem) {
						userName.setValue(oSelectedItem.getTitle());
						userName.data("key", oSelectedItem.getTitle());
					}
				}
			});
			// }
			var model = this.getOwnerComponent().getModel("ICsrvmodel");
			oValueHelpDialog_RespDiv.setModel(model);
			oValueHelpDialog_RespDiv.open();
		},
		onVHelpTimeZone: function (oEvent) {
			var that = this;
			var userName = oEvent.getSource();
			var oValueHelpDialog_RespDiv = new sap.m.SelectDialog({
				title: "Select TimeZone",
				items: {
					path: "/I_TimeZoneText",
					template: new sap.m.StandardListItem({
						title: "{TimeZoneID}",
						description: "{TimeZoneText}"
					})
				},
				//Company code can be searched using Search Bar
				search: function (oEvent) {
					var sValue = oEvent.getParameter("value");
					var oFilter = new sap.ui.model.Filter(
						"TimeZoneID",
						sap.ui.model.FilterOperator.Contains, sValue
					);
					oEvent.getSource().getBinding("items").filter([oFilter]);
				},
				confirm: function (oEvent) {
					var oSelectedItem = oEvent.getParameter("selectedItem");
					var comcode2 = oSelectedItem.getTitle();
					if (oSelectedItem) {
						userName.setValue(oSelectedItem.getTitle());
						userName.data("key", oSelectedItem.getTitle());
					}
				}
			});
			// }
			var model = this.getOwnerComponent().getModel("ICsrvmodel");
			oValueHelpDialog_RespDiv.setModel(model);
			oValueHelpDialog_RespDiv.open();
		},
		onAddCompCodes: function () {
			var me = this;
			var that = this;
			var table = this.getView().byId("tblCompcodeid");
			var oTableModel = this.getView().getModel("InterCopanyModel");
			var oDataSets = oTableModel.getData();
			var oDataSet = [];
			var HHH = oDataSet.concat(oDataSets);
			HHH.push({
				CompanyCode1: "",
				ProfitCenter: "",
				BusinessPartner: "",
				CompanyCode2: "",
				Actiion: "",
				Processed: ""
			});
			this.getView().getModel("InterCopanyModel").setData(HHH);
		},
		onVHelpProfitCenter: function (oEvent) {
			var that = this;
			var PCName = oEvent.getSource();
			var me = oEvent.getSource().getParent();
			var compcode = me.getCells()[0].mProperties.value;
			if (compcode === "" || compcode === null | compcode === undefined) {
				MessageBox.error("Please select company code 1");
				return false;
			}
			var pcDateFormat = DateFormat.getDateTimeInstance({
				pattern: "yyyy-MM-dd" + "T" + "hh:mm:ss"
			});
			var OwnPcDate = pcDateFormat.format(new Date());
			var oModel = that.getModel("ICsrvmodel");
			oModel.read("/GetControlingAreaSet('" + compcode + "')", {
				method: "GET",
				success: function (oData, response) {
					conAreaFilter = oData.ControllingArea;
					var myfilterNew = [];
					var oFilternNew = new sap.ui.model.Filter("Language", sap.ui.model.FilterOperator.EQ, "EN");
					myfilterNew.push(oFilternNew);
					var oFilternNew1 = new sap.ui.model.Filter("ControllingArea", sap.ui.model.FilterOperator.EQ, conAreaFilter);
					myfilterNew.push(oFilternNew1);
					var oFilternNew2 = new sap.ui.model.Filter("ValidityEndDate", sap.ui.model.FilterOperator.GE, OwnPcDate);
					myfilterNew.push(oFilternNew2);
					var oValueHelpDialog_RespDiv = new sap.m.SelectDialog({
						title: "Profit Center for Controlling Area:" + " " + conAreaFilter,
						items: {
							path: "/A_ProfitCenterText",
							filters: myfilterNew,
							template: new sap.m.StandardListItem({
								title: "{ProfitCenter}",
								description: "{ProfitCenterLongName}"
							})
						},
						search: function (oEvent) {
							var sValue = oEvent.getParameter("value");
							var oFilter = new sap.ui.model.Filter("ProfitCenter", sap.ui.model.FilterOperator.Contains, sValue);
							oEvent.getSource().getBinding("items").filter(oFilter);
						},
						confirm: function (oEvent) {
							var oSelectedItem = oEvent.getParameter("selectedItem");
							var selectedProfitCenter = oSelectedItem.getTitle();
							var selectedDesPC = oSelectedItem.getDescription();
							if (oSelectedItem) {
								PCName.setValue(oSelectedItem.getTitle());
								me.getCells()[2].setProperty("text", "");
								me.getCells()[3].setValue("");
								me.getCells()[4].setProperty("text", "");
							}
						}
					});
					var model = this.getModel("ICsrvmodel");
					oValueHelpDialog_RespDiv.setModel(model);
					oValueHelpDialog_RespDiv.open();
				}.bind(this),
				error: function (response) {
					MessageBox.error(response.responseText);
				}.bind(this)
			});
		},
		onDeleteInterCompany: function () {
			var that = this;
			var table = this.getView().byId("tblCompcodeid");
			var selected_item = this.getView().byId("tblCompcodeid").getSelectedItems();
			var oTableModel = this.getView().getModel("InterCopanyModel");
			var oDataSets = oTableModel.getData();
			var oSelected = table.getSelectedContextPaths();
			var index = oSelected[0].slice(1);
			var spath = parseInt(index);
			if (spath === 0) {
				MessageBox.alert("Can not delete the first row");
				return false;
			}
			if (selected_item.length !== 0) {
				MessageBox.warning("Please verify selected items will be deleted from screen.", {
					actions: ["Continue", "Verify"],
					emphasizedAction: "Continue",
					onClose: function (sAction) {
						if (sAction == "Continue") {
							oDataSets.splice(spath, 1);
							that.getView().getModel("InterCopanyModel").setData(oDataSets);
							table.removeSelections();
							MessageBox.success("Deleted succesfully. Please hit update or save button");
						} else {}
					}.bind(this)
				});
			} else {
				MessageBox.show("Please select a row for deletion");
			}
		},
		InterCompanyFactory: function () {
			debugger;
			var that = this;
			var oTemplate = new sap.m.ColumnListItem({
				cells: [
					new sap.m.Input({
						editable: true,
						value: "{InterCopanyModel>CompanyCode1}",
						width: "12em",
						showValueHelp: Boolean("true"),
						valueHelpOnly: Boolean("true"),
						valueHelpRequest: [that.onVHelpCompCode, that]
					}),
					new sap.m.Input({
						editable: true,
						value: "{InterCopanyModel>ProfitCenter}",
						width: "12em",
						showValueHelp: Boolean("true"),
						valueHelpOnly: Boolean("true"),
						valueHelpRequest: [that.onVHelpProfitCenter, that]
					}),
					new sap.m.Text({
						text: "{InterCopanyModel>BusinessPartner}"
					}),
					new sap.m.Input({
						editable: true,
						value: "{InterCopanyModel>CompanyCode2}",
						width: "12em",
						showValueHelp: Boolean("true"),
						valueHelpOnly: Boolean("true"),
						valueHelpRequest: [that.onVHelpCompCode, that]
					}),
					new sap.m.Text({
						text: "{InterCopanyModel>Actiion}"
					}),
					new sap.ui.core.Icon({
						src: "{= %{InterCopanyModel>Processed} === 'S' ? 'sap-icon://message-success' : %{InterCopanyModel>Processed} === 'E' ? 'sap-icon://message-error' : ''}"
					}),
				]
			});
			return oTemplate;
		},
		onButtonSaveSubmit: function (oEvent) {
			var that = this;
			var tableCC = that.getView().byId("tblCompcodeid").getItems();
			var ModelData = that.getView().getModel("InterCopanyModel").getData();
			var ModelBPData = that.getView().getModel("BPInfoModel").getData();
			var buttonText = oEvent.getSource().getProperty("text");
			var fNameTxt = that.getView().byId("fnameId").getValue();
			var LNameTxt = that.getView().byId("lnameId").getValue();
			var emailTxt = that.getView().byId("emailId").getValue();
			var locTxt = that.getView().byId("locId").getValue();
			var phoneNum = that.getView().byId("phoneId").getValue();
			var reasonTxt = that.getView().byId("brsiId").getValue();
			var odataModel = this.getModel("ICsrvmodel");
			var submitDate;
			var data = {};
			// Headers validation check for mandatory fiels
			if (fNameTxt === "" || fNameTxt === null || fNameTxt === undefined) {
				MessageBox.show(
					"First Name is Mandatory fields.",
					MessageBox.Icon.ERROR,
					"Error"
				);
				return false;
			}
			if (LNameTxt === "" || LNameTxt === null || LNameTxt === undefined) {
				MessageBox.show(
					"Last Name is Mandatory fields.",
					MessageBox.Icon.ERROR,
					"Error"
				);
				return false;
			}
			if (emailTxt === "" || emailTxt === null || emailTxt === undefined) {
				MessageBox.show(
					"Email is Mandatory fields.",
					MessageBox.Icon.ERROR,
					"Error"
				);
				return false;
			}
			if (reasonTxt === "" || reasonTxt === null || reasonTxt === undefined) {
				MessageBox.show(
					"Business Reasons and Special Instructions is Mandatory fields.",
					MessageBox.Icon.ERROR,
					"Error"
				);
				return false;
			}

			//Business Partner Information Table Line Items validation check for mandatory fiels
			for (var i = 0; i < tableCC.length; i++) {
				if (tableCC[i].getCells()[0].getValue() === "") {
					tableCC[i].getCells()[0].setValueState("Error");
					return false;
				} else if (tableCC[i].getCells()[1].getValue() === "") {
					tableCC[i].getCells()[1].setValueState("Error");
					return false;
				} else if (tableCC[i].getCells()[3].getValue() === "") {
					tableCC[i].getCells()[3].setValueState("Error");
					return false;
				}
			}
			for (var i = 0; i < tableCC.length; i++) {
				for (var j = i + 1; j < tableCC.length; j++) {
					if (tableCC[i].getCells()[0].getValue() === tableCC[j].getCells()[0].getValue() && tableCC[i].getCells()[1].getValue() ===
						tableCC[j].getCells()[1].getValue() && tableCC[i].getCells()[3].getValue() === tableCC[j].getCells()[3].getValue()) {
						MessageBox.alert("Duplicate Items found");
						tableCC[j].getCells()[0].setValueState("Error");
						tableCC[j].getCells()[1].setValueState("Error");
						tableCC[j].getCells()[3].setValueState("Error");
						return false;
					}
				}
			}
			if (buttonText === "Save") {
				statusSaveSub = "01";
				submitDate = "";
				MessageToast.show("Work in Progress for save");
			}
			if (buttonText === "Submit") {
				MessageToast.show("Work in Progress for Submit");
				statusSaveSub = "02";
				var SubDateFormat = DateFormat.getDateTimeInstance({
					pattern: "yyyyMMdd" + "T" + "hhmmss"
						// pattern: "yyyy-MM-dd" + "T" + "hh:mm:ss"
				});
				submitDate = SubDateFormat.format(new Date());
			} else if (buttonText === "Withdraw") {
				statusSaveSub = "10";
			} else if (buttonText === "Complete") {
				statusSaveSub = "07";
			}
			if (locTxt === null || locTxt === undefined) {
				locTxt = "";
			}
			if (phoneNum === null || phoneNum === undefined) {
				phoneNum = "";
			}
			if (reasonTxt === null || reasonTxt === undefined) {
				reasonTxt = "";
			}

			var prepare = Createdby;
			if (prepare === null || prepare === undefined || prepare === "") {
				prepare = sap.ushell.Container.getService("UserInfo").getUser().getId();
			}
			var datetimeFormat = DateFormat.getDateTimeInstance({
				// pattern: "yyyyMMdd" + "T" + "hhmmss"
				pattern: "yyyy-MM-dd" + "T" + "hh:mm:ss"
			});
			var submitDateTime = datetimeFormat.format(new Date());
			var stringSubDt = submitDateTime.toString();
			data = {
				"Status": statusSaveSub,
				"EFORM_NUM": this.form_number,
				"Rtype": "CR",
				"FirstName": fNameTxt,
				"Lastname": LNameTxt,
				"Location": locTxt,
				"Tel_Number": phoneNum,
				"eMailAddress": emailTxt,
				"Reason": reasonTxt,
				"CreatedBy": prepare,
				"CreatedDateTime": submitDateTime,
				"SubmittedOn": submitDate,
				"Status_Desc": "",
				"Status_User": "",
				"Status_Username": "",
				"StatusDateTime": "",
				"CreationDate_From": "",
				"CreationDate_To": "",
			};
			var BPInformationData = [];
			for (i = 0; i < tableCC.length; i++) {
				BPInformationData.push({
					EFORM_NUM: this.form_number,
					CompanyCode1: tableCC[i].getCells()[0].getValue(),
					ProfitCenter: tableCC[i].getCells()[1].getValue(),
					ControllingArea: "",
					BusinessPartner: tableCC[i].getCells()[2].getText(),
					CompanyCode2: tableCC[i].getCells()[3].getValue(),
					Actiion: tableCC[i].getCells()[4].getText(),
					Processed: "",
				});
			}
			data.eFormBPInformationSet = [];
			data.eFormBPInformationSet = BPInformationData;
			// if (form_number !== "" && buttonText === "Complete") {
			// 	data.eFormBPDetailsSet = [];
			// 	// data.eFormBPDetailsSet = ModelBPData.BPInformationData;
			// } else {
			data.eFormBPDetailsSet = [];
			// }
			var commentModel = this.getView().getModel("commentModel").getData();
			if (commentModel === null || commentModel === undefined) {
				commentModel = "";
			}
			data.eFormCommentSet = [];
			for (var k = 0; k < commentModel.length; k++) {
				var D = {};
				D.EFORM_NUM = this.form_number;
				D.comments = commentModel[k].comments;
				D.CreatorId = commentModel[k].CreatorId;
				D.CreatorName = commentModel[k].CreatorName;
				D.CommentNo = commentModel[k].CommentNo;
				D.CommentDate = "";
				D.CommentTime = "";
				D.Rtype = "SH";
				data.eFormCommentSet[k] = D;
			}

			var approverDataModel = this.getView().getModel("approverModel").getData();
			if (approverDataModel === null || approverDataModel === undefined) {
				approverDataModel = "";
			}
			var table = this.getView().byId("tblApprover").getItems();
			var i = null;
			for (i = 0; i < table.length; i++) {
				var tempappr;
				if (table[i].getCells()[0].mProperties.value === undefined)
					tempappr = table[i].getCells()[0].getText();
				else
					tempappr = table[i].getCells()[0].getValue();
				if (tempappr === undefined || tempappr === "null" || tempappr === "") {
					MessageBox.alert("Approver field Can not be empty");
					return false;
				}
			}
			data.eFormApproverSet = [];
			for (var i = 0; i < approverDataModel.length; i++) {
				var D = {};
				D.MDMNR = this.form_number;
				D.APPR_ID = approverDataModel[i].APPR_ID;
				D.APPREMAIL = "";
				D.APPRCONTACT = "";
				D.APPRDIV = "";
				D.REVIEWER_TYPE = approverDataModel[i].REVIEWER_TYPE;
				D.SEQUENCE = String(i + 1);
				D.ACTION = approverDataModel[i].ACTION;
				D.ACTION_DATE = approverDataModel[i].ACTION_DATE;
				var datab = D.ACTION_DATE;
				var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
					pattern: "yyyyMMdd"
				});
				var actionDate = dateFormat.format(new Date(datab));
				D.ACTION_DATE = actionDate;
				D.ACTION_TIME = approverDataModel[i].ACTION_TIME;
				D.ACTION_BY = approverDataModel[i].ACTION_BY;
				D.GRP = "";
				D.ACT_NAME = approverDataModel[i].ACT_NAME;
				D.APPRNAME = approverDataModel[i].APPRNAME;

				D.MANUAL = approverDataModel[i].MANUAL;
				data.eFormApproverSet[i] = D;
			}
			var change = "";
			var msg = "";
			if (buttonText === "Save") {
				msg = "Please Verify the details before";
				change = "saving the Inter Company Details.";
			}
			if (buttonText === "Submit") {
				msg = "Please Verify the details before";
				change = "submitting the Inter Company Details.";
			}
			if (buttonText === "Withdraw") {
				msg = "Do you want to withdraw";
				change = "this Inter Company form?";
			}
			if (buttonText === "Complete") {
				msg = "Do you want to complete";
				change = "this Inter Company form?";
			}
			MessageBox.warning(
				msg + " " + change, {
					actions: ["Continue", "Verify"],
					emphasizedAction: "Continue",
					onClose: function (sAction) {
						if (sAction == "Continue") {
							odataModel.create("/eFormHeaderSet", data, {
								async: false,
								success: function (oData, response) {
									that.form_number = oData.EFORM_NUM;
									if (buttonText === "Save") {
										that.getView().byId("pageId").setTitle("Create / Extend IC 2 step Settled Relationship - " + that.form_number);
										Createdby = oData.CreatedBy;
										that.getApproversData(that.form_number, oData.Status);
										that.getView().getModel("viewDataModel").setData(oData);
										that.getView().byId("idstatus").setValue(oData.Status_Desc);
										MessageBox.show(
											"Inter Company Form " + oData.EFORM_NUM +
											" has been saved successfully. Kindly submit form for Approval.",
											MessageBox.Icon.SUCCESS,
											"Success"
										);
									} else if (buttonText === "Complete") {
										that.getView().byId("pageId").setTitle("Create / Extend IC 2 step Settled Relationship - " + that.form_number);
										MessageBox.show(
											"Inter Company Form " + oData.EFORM_NUM + " Complete successfully.", {
												icon: MessageBox.Icon.SUCCESS,
												title: "Success",
												onClose: function (oAction) {
													that.oRouter.navTo("SearchIC", true);
												}
											}
										);
									} else if (buttonText === "Withdraw") {
										that.getView().byId("pageId").setTitle("Create / Extend IC 2 step Settled Relationship - " + that.form_number);
										MessageBox.show(
											"Inter Company Form " + oData.EFORM_NUM + " Withdraw successfully.", {
												icon: MessageBox.Icon.SUCCESS,
												title: "Success",
												onClose: function (oAction) {
													that.oRouter.navTo("SearchIC", true);
												}
											}
										);
									} else {
										that.getView().byId("pageId").setTitle("Create / Extend IC 2 step Settled Relationship - " + that.form_number);
										MessageBox.show(
											"Inter Company Form " + oData.EFORM_NUM + " submitted successfully.", {
												icon: MessageBox.Icon.SUCCESS,
												title: "Success",
												onClose: function (oAction) {
													that.oRouter.navTo("SearchIC", true);
												}
											}
										);
									}
								},
								error: function (oError) {
									sap.ui.core.BusyIndicator.hide();
									var response = JSON.parse(oError.responseText);
									MessageBox.show(
										response.error.message.value,
										MessageBox.Icon.ERROR,
										"Error"
									);
								}.bind(this)
							});
						} else {
							return false;
						}
					}.bind(this)
				});
		},
		getattachments: function (contextName) {
			var n = new sap.ui.model.Filter("MDMNR", sap.ui.model.FilterOperator.EQ, contextName);
			var myFilter = [];
			myFilter.push(n);

			var url = "/sap/opu/odata/sap/YFPSFIFRDD0040_IC_FORM_SRV/";
			var model = new sap.ui.model.odata.ODataModel(url, true);
			var relPath = "/AttachmentSet";
			var that = this;
			model.read(relPath, {
				filters: myFilter,
				success: function (oData, response) {
					that.getView().byId("t_attachmentIC").destroyItems();
					var counter = oData.results.length;
					var i = 0;
					for (i = 0; i < counter; i++) {
						var table1 = that.getView().byId("t_attachmentIC");
						var data1 = new sap.m.ColumnListItem({
							cells: [
								new sap.m.Link({
									text: response.data.results[i].FileName,
									wrapping: Boolean(1),
									press: function (oEvent) {
										var oSource = oEvent.getSource();
										var relPath = "/sap/opu/odata/sap/YFPSFIFRDD0040_IC_FORM_SRV/AttachmentSet(MDMNR='" + contextName + "'" +
											",FileName='" + oSource.getText() + "')/$value";
										window.open(relPath, '_blank');
									}
								}),
								new sap.m.Text({
									text: response.data.results[i].CreatedDate
								}),
								new sap.m.Text({
									text: response.data.results[i].CreatedAt
								}),
								new sap.m.Text({
									text: response.data.results[i].FileSize
								}),
								new sap.m.Text({
									text: response.data.results[i].CreatedByName
								}),
								new sap.m.Text({
									text: response.data.results[i].CreatedBy
								})
							]
						});
						table1.addItem(data1);
					}
				},
				error: function (oError) {
					var response = JSON.parse(oError.responseText);
					MessageBox.show(
						response.error.message.value,
						MessageBox.Icon.ERROR,
						"Error"
					);
					sap.ui.core.BusyIndicator.hide();
				}
			});
		},
		_onDeleteAttachment: function (oEvent) {
			debugger;
			var url = "/sap/opu/odata/sap/YFPSFIFRDD0040_IC_FORM_SRV/";
			var model = new sap.ui.model.odata.ODataModel(url, true);
			var selected_item = this.getView().byId("t_attachmentIC").getSelectedItem();
			if (selected_item !== null) {
				var filename = selected_item.mAggregations.cells[0].mProperties.text;
				if (filename !== "") {
					if (selected_item.mAggregations.cells[5].mProperties.text == sap.ushell.Container.getUser().getId()) {
						var that = this;
						model.remove("/AttachmentSet(MDMNR='" + this.form_number + "'" + ",FileName='" + filename + "')", {
							success: function (oData, response) {
								that.getView().byId("t_attachmentIC").removeItem(selected_item);
								MessageBox.alert("Attachment deleted successfully.");
							},
							error: function (oError) {
								var response = JSON.parse(oError.responseText);
								MessageBox.show(
									response.error.message.value,
									MessageBox.Icon.ERROR,
									"Error"
								);
								sap.ui.core.BusyIndicator.hide();
							}
						});
					} else {
						MessageBox.show(
							"You can not delete this Attachment",
							MessageBox.Icon.ERROR,
							"Error"
						);
					}
				}
			} else {
				MessageBox.show("Please select for deletion");
				return false;
			}
		},
		_onhandleValueChange: function (oEvent) {
			debugger;
			file_size = oEvent.mParameters.files[0].size;
			file_size = (file_size / 1024);
		},
		_onhandleUploadPress: function (oEvent) {
			debugger;
			var table = this.getView().byId("t_attachmentIC");
			if (oEvent.mParameters.id.indexOf("b_uploadIC") > -1) {
				var oFileUploader = this.getView().byId("i_fileUploaderIC");
				if (oFileUploader.getValue() == "") {
					MessageBox.alert("Please select the Template.");
					return;
				}
			}
			var url = "/sap/opu/odata/sap/YFPSFIFRDD0040_IC_FORM_SRV/";
			var fileModel = new sap.ui.model.odata.ODataModel(url, true);
			var viewInstance = this.getView();
			if (oFileUploader.getName() == "") {
				return;
			}
			viewInstance.setBusy(true);
			// Set CSRF
			fileModel.refreshSecurityToken();
			var csrf = fileModel.getSecurityToken();
			//Add to header and upload
			oFileUploader.destroyHeaderParameters();
			oFileUploader.setSendXHR(true);
			var headerParma = new sap.ui.unified.FileUploaderParameter();
			var headerParma2 = new sap.ui.unified.FileUploaderParameter();
			var headerParma3 = new sap.ui.unified.FileUploaderParameter();
			headerParma2.setName('slug');
			headerParma2.setValue(oFileUploader.getValue() + '|' + this.form_number + '|' + file_size + '|' + 'CR' + '|' + 'ICR');
			oFileUploader.insertHeaderParameter(headerParma2);
			headerParma3.setName('Content-Type');
			oFileUploader.insertHeaderParameter(headerParma3);
			headerParma.setName('x-csrf-token');
			headerParma.setValue(csrf);
			oFileUploader.addHeaderParameter(headerParma);
			oFileUploader.upload();
		},
		_onhandleUploadComplete: function (oEvent) {
			var that = this;
			var status = oEvent.getParameter("status");
			var response = oEvent.getParameter("response");
			var fileNm = oEvent.getParameter("fileName");
			if (status === 201) {
				var sMsg = "Upload Success";
				MessageToast.show(sMsg);
				oEvent.getSource().setValue("");
				var temp = oEvent.getParameter("response");
				// this.form_number = temp.substr(temp.indexOf("MDMNR=") + 7, 10);
				// this.form_number = temp.substr(temp.indexOf("EFORM_NUM=") + 11, 10);
				e_form_num = this.form_number;
				MessageBox.show(
					"Attachment added successfully and saved under " + e_form_num + ".",
					MessageBox.Icon.SUCCESS,
					"Success"
				);
				that.getView().byId("pageId").setTitle("Create / Extend IC 2 step Settled Relationship -" + e_form_num);
			} else {
				sMsg = "Upload Error";
				MessageToast.show(sMsg);
			}

			var viewInstance = this.getView();
			viewInstance.setBusy(false);
			viewInstance.setBusy(false);
			that.getattachments(e_form_num);
		},
		getComments: function (contextName) {
			var n = new sap.ui.model.Filter("EFORM_NUM", sap.ui.model.FilterOperator.EQ, contextName);
			var myFilter = [];
			myFilter.push(n);
			var that = this;
			var oModel = this.getModel("ICsrvmodel");
			oModel.read("/eFormCommentSet", {
				filters: myFilter,
				success: function (oData, response) {
					// var data = oData.results;
					var aDataSet = [];
					oData.results.forEach(function (item, index) {
						aDataSet.push({
							CreatorId: item.CreatorId,
							CreatorName: item.CreatorName,
							CommentDate: item.CommentDate,
							CommentTime: item.CommentTime,
							comments: item.comments,
							CommentNo: item.CommentNo
						});
					});
					that.form_number = contextName;
					that.getView().getModel("commentModel").setData(aDataSet);
				}
			});
		},
		onCommentPost: function (oEvent) {
			var sComment = oEvent.getParameter("value");
			var oDataSets = {
				EFORM_NUM: this.form_number,
				CreatorId: "",
				CreatorName: "",
				comments: sComment,
				Rtype: "CR"
			};
			var commentModel = this.getView().getModel("commentModel");
			var oDataSet = commentModel.getData();
			if (oDataSet === null || oDataSet === undefined) {
				oDataSet = [];
			}
			var sIndex = oDataSet.length;
			if (sIndex === undefined) {
				oDataSet = [];
			}
			oDataSet.splice(sIndex, 0, {
				FORM_NO: this.Form_Num,
				CreatorId: "",
				CreatorName: "",
				Comments: sComment,
				Rtype: "CR"
			});
			var that = this;
			//	var oModel = this.getOwnerComponent().getModel("CostCentersrv");
			var oModel = that.getModel("ICsrvmodel");
			oModel.create("/eFormCommentSet", oDataSets, {
				// filters: myFilter,
				success: function (oData, response) {
					sap.ui.core.BusyIndicator.hide();
					form_number = oData.EFORM_NUM;
					that.getComments(form_number);
					MessageBox.show(
						"Comment added successfully and saved under" + "-" + form_number + ".",
						MessageBox.Icon.SUCCESS,
						"Success"
					);
					that.getView().byId("pageId").setTitle("Create / Extend IC 2 step Settled Relationship - " + form_number);
					that.getView().byId("feedinputIC").setValue(null);
				}
			});
			this.getView().getModel("commentModel").setData(oDataSet);
		},
		commentFactory: function () {
			var oTemplate = new sap.m.FeedListItem({
				senderActive: false,
				sender: "{commentModel>CreatorName}",
				text: "{commentModel>comments}",
				showIcon: false,
				actions: new sap.m.FeedListItemAction({
					text: "Delete",
					press: [this.onDeleteComment, this],
					icon: "sap-icon://delete",
					key: "delete"
				})
			}).bindProperty("timestamp", {
				parts: [{
					path: 'commentModel>CommentDate'
				}, {
					path: 'commentModel>CommentTime'
				}],
				formatter: function (sDate, sTime) {
					var datechange = sDate;
					var year = datechange.slice(0, 4);
					var mm = datechange.slice(4, 6);
					var dd = datechange.slice(6, 8);
					var append = year + "/" + mm + "/" + dd;
					if ((sDate === "00000000" || sDate === null || sDate === undefined) || (sTime === "00000000" || sTime === null ||
							sTime === undefined)) {
						var timeFormat = DateFormat.getDateTimeInstance({
							pattern: "MM/dd/yyyy hh:mm:ss a"

						});
						return timeFormat.format(new Date());
					} else {
						var timeFormat = DateFormat.getDateTimeInstance({
							pattern: "MM/dd/yyyy hh:mm:ss a"
						});
						var hour = sTime.substring(0, 2);
						var minute = sTime.substring(2, 4);
						var second = sTime.substring(4);
						var sCTime = hour + ":" + minute + ":" + second;
						return timeFormat.format(new Date(append + " " + sCTime));
					}
				}
			});
			return oTemplate;
		},
		onDeleteComment: function (oEvent) {
			var sContext = oEvent.getSource().getParent().getBindingContextPath();
			var array = this.getView().getModel("commentModel").getData();
			if (array[sContext.substr(1)].CreatorId != sap.ushell.Container.getService("UserInfo").getUser().getId()) {
				// if (array[sContext.substr(1)].CreatorId != "MPAPPUSETTI") {
				MessageBox.show(
					"You are not authorized to delete this comment.",
					MessageBox.Icon.ERROR,
					"Error"
				);
			} else {
				var that = this;
				var commentNo = array[sContext.substr(1)].CommentNo;
				var StrComment = commentNo.toString();
				var oModel = this.getModel("ICsrvmodel");
				oModel.remove("/eFormCommentSet(EFORM_NUM='" + that.form_number + "'" + ",CommentNo='" + StrComment +
					"')", {
						success: function (data) {
							var array = that.getView().getModel("commentModel").getData();
							array.splice(sContext.substr(1), 1);
							that.getView().getModel("commentModel").setData(array);
							MessageBox.show(
								"This comment has been deleted successfully.",
								MessageBox.Icon.SUCCESS,
								"Success"
							);
							that.getView().byId("feedinputIC").setValue(null);
						},
						error: function (error) {
							var response = JSON.parse(error.responseText);
							MessageBox.show(
								response.error.message.value,
								MessageBox.Icon.ERROR,
								"Error"
							);
						}
					});
			}
		},
		userValueHelpRequest: function (oEvent) {
			var userName = oEvent.getSource();
			var oValueHelpDialog_RespDiv = new sap.m.SelectDialog({
				title: "Users List",
				items: {
					path: "/C_GHOUserNameVH",
					template: new sap.m.StandardListItem({
						title: "{FullName}",
						description: "{UserID}",
						//active: true
					})
				},
				//Shipping Point can be searched using Search Bar
				search: function (oEvent) {
					var sValue = oEvent.getParameter("value");
					var oFilter = new sap.ui.model.Filter(
						"FullName",
						//	"mc_namefir",
						sap.ui.model.FilterOperator.Contains, sValue
					);
					oEvent.getSource().getBinding("items").filter([oFilter]);
				},

				confirm: function (oEvent) {
					var oSelectedItem = oEvent.getParameter("selectedItem");
					if (oSelectedItem) {
						userName.setValue(oSelectedItem.getTitle());
						userName.data("key", oSelectedItem.getDescription());
						//	createdBy_Id = oSelectedItem.getDescription();
					}
				}
			});
			// }
			var model = this.getOwnerComponent().getModel("ICsrvmodel");
			oValueHelpDialog_RespDiv.setModel(model);
			oValueHelpDialog_RespDiv.open();

		},
		aproverFactory: function (sId, oContext) {
			if (!oContext.getProperty("isInput")) {
				var oTemplate = new sap.m.ColumnListItem({
					cells: [
						new sap.m.Input({
							showValueHelp: true,
							value: "{approverModel>APPRNAME}",
							enabled: true,
							valueHelpRequest: [this.userValueHelpRequest, this]
						}).data("key", "{approverModel>APPR_ID}"),
						new sap.m.Text({
							text: "{approverModel>REVIEWER_TYPE}"
						}),
						new sap.m.Text({
							text: "{approverModel>ACT_NAME}"
						}),
						new sap.m.Text({
							text: "{approverModel>ACTION}"
						}),
						new sap.m.Text({
							text: "{approverModel>ACTION_DATE}"
						}),
						new sap.m.Text({
							text: "{approverModel>ACTION_TIME}"
						})
					]
				});

			} else {
				var oTemplate = new sap.m.ColumnListItem({
					cells: [
						new sap.m.Link({
							text: "{approverModel>APPRNAME}",
							press: [this._displayEmployees, this],
							wrapping: true
						}),

						new sap.m.Text({
							// enabled: "{EnableModel>/allow}",
							// enabled: true,
							text: "{approverModel>REVIEWER_TYPE}",
							// showValueHelp: false
							//valueHelpRequest: [this.conAreaValueHelpRequest, this]

						}),
						new sap.m.Text({
							text: "{approverModel>ACT_NAME}"

						}),
						new sap.m.Text({
							text: "{approverModel>ACTION}"
						}),
						new sap.m.Text({
							text: "{approverModel>ACTION_DATE}"
						}),
						new sap.m.Text({
							text: "{approverModel>ACTION_TIME}"
						})
					]
				});
			}
			return oTemplate;
		},
		_displayEmployees: function (oEvent) {
			var that = this;
			var sDept = oEvent.getSource().getText();
			if (sDept === "MDMA" || sDept === "GOA" || sDept === "CMI") {
				var oFilterFormType = new sap.ui.model.Filter("FormTyp", sap.ui.model.FilterOperator.EQ, "ICR");
				var oFilterRole = new sap.ui.model.Filter("Role", sap.ui.model.FilterOperator.EQ, sDept);
				var gatewayUrl = "/sap/opu/odata/sap/YFPSFIFRDD0040_IC_FORM_SRV/";
				var oModel = new sap.ui.model.odata.ODataModel(gatewayUrl, true);
				oModel.read("/eFormApproverGrpSet", {
					async: false,
					filters: [oFilterFormType, oFilterRole],
					success: function (oData, oResponse) {

						if (!that._oPopover) {
							that._oPopover = sap.ui.xmlfragment("com.spe.YIC_FORM.Fragments.Approvals", that);
							that.getView().addDependent(that._oPopover);
						}
						var event = oEvent.getSource();
						that._oPopover.openBy(event);
						var oModellist = new sap.ui.model.json.JSONModel();
						oModellist.setData(oData);
						that._oPopover.setModel(oModellist);
					},
					error: function (oError) {
						sap.m.MessageBox.show(oError.message, {
							icon: MessageBox.Icon.ERROR,
							title: "Error"
						});
					}
				});
			} else {
				return false;
			}

		},
		getApproversData: function (contextName, statuss) {
			var n = new sap.ui.model.Filter("MDMNR", sap.ui.model.FilterOperator.EQ, contextName);
			var myFilter = [];
			myFilter.push(n);
			var that = this;
			var oModel = this.getModel("ICsrvmodel");
			oModel.read("/eFormApproverSet", {
				filters: myFilter,
				success: function (oData, response) {
					if (oData.results.length > 0) {
						//	that.getView().byId("approverCR").setVisible(true);
						var aDataSet = [];
						oData.results.forEach(function (item, index) {
							var sStatus;
							if (item.ACTION === "A") {
								sStatus = "Approved";
							} else if (item.ACTION === "R") {
								sStatus = "Rejected";
							} else {
								sStatus = "";
							}
							var datab = item.ACTION_DATE;
							var datbi = item.ACTION_TIME;
							if (datab != "" && datbi != "") {
								var formatDate = datab.match(/[/]/g);
								if (formatDate === null) {
									var date1 = datab.slice(6, 8);
									var month = datab.slice(4, 6);
									var year = datab.slice(0, 4);
									var monthdate = month.concat("/" + date1);
									var fulldate = monthdate.concat("/" + year);
									item.ACTION_DATE = fulldate;
								}
								var formatTime = datbi.match(/[:]/g);
								if (formatTime === null) {
									var hrs = datbi.slice(0, 2);
									var min = datbi.slice(2, 4);
									var sec = datbi.slice(4, 6);
									var hrsmin = hrs.concat(":" + min);
									var fulltime = hrsmin.concat(":" + sec);
									item.ACTION_TIME = fulltime;
								}
							}
							aDataSet.push({
								APPR_ID: item.APPR_ID,
								REVIEWER_TYPE: item.REVIEWER_TYPE,
								APPREMAIL: item.APPREMAIL,
								SEQUENCE: item.SEQUENCE,
								ACTION: sStatus,
								ACTION_DATE: item.ACTION_DATE,
								ACTION_TIME: item.ACTION_TIME,
								ACTION_BY: item.ACTION_BY,
								GRP: item.GRP,
								APPRCONTACT: item.APPRCONTACT,
								APPRDIV: item.APPRDIV,
								APPRNAME: item.APPRNAME,
								isInput: true,
								ACT_NAME: item.ACT_NAME,
								ADDED_BY: item.ADDED_BY
							});
						});
						that.form_number = contextName;
						that.getView().getModel("approverModel").setData(null);
						that.getView().getModel("approverModel").setData(aDataSet);
					}
				},
				error: function (error) {
					var response = JSON.parse(error.responseText);
					MessageBox.show(
						response.error.message.value,
						MessageBox.Icon.ERROR,
						"Error"
					);
				}
			});
		},
		getdetailsCMI: function (oEvent) {
			var that = this;
			var oFilterFormType = new sap.ui.model.Filter("FormTyp", sap.ui.model.FilterOperator.EQ, "ICR");
			var oFilterRole = new sap.ui.model.Filter("Role", sap.ui.model.FilterOperator.EQ, "CMI");
			var gatewayUrl = "/sap/opu/odata/sap/YFPSFIFRDD0040_IC_FORM_SRV/";
			var oModel = new sap.ui.model.odata.ODataModel(gatewayUrl, true);
			oModel.read("/eFormApproverGrpSet", {
				async: false,
				filters: [oFilterFormType, oFilterRole],
				success: function (oData, oResponse) {
					that.getView().getModel("CMIdetails").setData(oData.results);
				},
				error: function (oError) {
					sap.m.MessageBox.show(oError.message, {
						icon: MessageBox.Icon.ERROR,
						title: "Error"
					});
				}
			});
		},
		getMDMAdetails: function (oEvent) {
			var that = this;
			var oFilterFormType = new sap.ui.model.Filter("FormTyp", sap.ui.model.FilterOperator.EQ, "ICR");
			var oFilterRole = new sap.ui.model.Filter("Role", sap.ui.model.FilterOperator.EQ, "MDMA");
			var gatewayUrl = "/sap/opu/odata/sap/YFPSFIFRDD0040_IC_FORM_SRV/";
			var oModel = new sap.ui.model.odata.ODataModel(gatewayUrl, true);
			oModel.read("/eFormApproverGrpSet", {
				async: false,
				filters: [oFilterFormType, oFilterRole],
				success: function (oData, oResponse) {
					that.getView().getModel("MDMAdetails").setData(oData.results);
				},
				error: function (oError) {
					sap.m.MessageBox.show(oError.message, {
						icon: MessageBox.Icon.ERROR,
						title: "Error"
					});
				}
			});
		},
		getdetailsGoa: function (oEvent) {
			var that = this;
			var oFilterFormType = new sap.ui.model.Filter("FormTyp", sap.ui.model.FilterOperator.EQ, "ICR");
			var oFilterRole = new sap.ui.model.Filter("Role", sap.ui.model.FilterOperator.EQ, "GOA");
			var gatewayUrl = "/sap/opu/odata/sap/YFPSFIFRDD0040_IC_FORM_SRV/";
			var oModel = new sap.ui.model.odata.ODataModel(gatewayUrl, true);
			oModel.read("/eFormApproverGrpSet", {
				async: false,
				filters: [oFilterFormType, oFilterRole],
				success: function (oData, oResponse) {
					that.getView().getModel("GoaDetails").setData(oData.results);
				},
				error: function (oError) {
					sap.m.MessageBox.show(oError.message, {
						icon: MessageBox.Icon.ERROR,
						title: "Error"
					});
				}
			});
		},
		onAddApprovers: function (oEvent) {
			debugger;
			this.getMDMAdetails();
			this.getdetailsGoa();
			this.getdetailsCMI();
			var data = this.getView().getModel("viewDataModel").getData();
			var AData = this.getView().getModel("approverModel").getData();
			var actionData = [];
			actionData = AData;
			var appStatusMdma = actionData.slice(-1);

			if (data[0] === undefined) {
				var sStatus = data.Status;
			} else {
				sStatus = data[0].Status;
			}
			if (appStatusMdma[0].ACTION === "Approved") {
				MessageBox.alert("You cannot add Approvers once MDMA has Approved.");
				return false;
			}
			if (AData.length !== undefined && sStatus !== undefined) {
				var ApproverspersonsArray = [];
				for (var i = 0; i < AData.length; i++) {
					var D = {};
					D.APPR_ID = AData[i].APPR_ID;
					ApproverspersonsArray[i] = D;
				}
				var Goalist = [];
				var mdmalist = [];
				var CMIlist = [];
				Goalist = this.getView().getModel("GoaDetails").getData();
				mdmalist = this.getView().getModel("MDMAdetails").getData();
				CMIlist = this.getView().getModel("CMIdetails").getData();
				for (var b = 0; b < Goalist.length; b++) {
					var G = {};
					G.Name = Goalist[b].Name;
					Goalist[b] = G;
				}
				for (var k = 0; k < mdmalist.length; k++) {
					var M = {};
					M.Name = mdmalist[k].Name;
					mdmalist[k] = M;
				}
				var concatall = ApproverspersonsArray.concat(CMIlist, Goalist, mdmalist);
				var LoggedUserid = sap.ushell.Container.getService("UserInfo").getUser().getId();
				var error = false;
				concatall.forEach(function (enteredQr) {
					if (enteredQr.APPR_ID === LoggedUserid) {
						error = true;
					}
					if (enteredQr.Name === LoggedUserid) {
						error = true;
					}
				}.bind(this));
				if (Createdby === LoggedUserid) {
					error = true;
				}
				if (error === false) {
					MessageToast.show("User Not Authorized to add Approvers");
					return false;
				}
			}

			//
			var selectedType = this.byId("apprType").getValue();
			var positionType = this.byId("ENTRY_SEQUENCE").getValue();
			var table = this.getView().byId("tblApprover");
			var sItem = table.getSelectedItem();
			// var all_entries = table.getItems();
			var num_of_entries = table.getItems().length;
			var sIndex;
			var selectedItemindex = table.getItems().indexOf(table.getSelectedItem());
			if (num_of_entries === 0 && sItem == undefined) {
				sIndex = 0;
				var oDataSet = [];
				oDataSet.splice(sIndex, 0, {
					APPR_ID: "",
					APPRNAME: "",
					APPREMAIL: "",
					APPRCONTACT: "",
					APPRDIV: "",
					REVIEWER_TYPE: selectedType,
					isInput: false,
					ACTION: "",
					ACT_NAME: "",
					ACTION_DATE: "",
					ACTION_TIME: "",
					MANUAL: "X",
					ADDED_BY: LoggedUserid

				});
				this.getView().getModel("approverModel").setData(oDataSet);
			} else if (sItem != undefined && num_of_entries > 0) {
				if (sItem.getAggregation("cells")[0].mProperties.text != undefined) {
					if (sItem.getAggregation("cells")[3].getProperty("text") === "Approved" && this.getView().byId("ENTRY_SEQUENCE").getValue() ===
						"Before" && selectedType === "APPROVER") {
						MessageBox.alert("You cannot add before approved status");
						return false;
					}
				}
				if (sItem.getAggregation("cells")[0].mProperties.text != undefined) {
					if (sItem.getAggregation("cells")[1].getProperty("text") === "WATCHER" && this.getView().byId("ENTRY_SEQUENCE").getValue() ===
						"Before" && table.indexOfItem(sItem) === 0) {
						MessageBox.alert("You cannot add Approvers/Watchers Before First Line");
						return false;
					}
				}
				if (sItem.getAggregation("cells")[0].mProperties.text != undefined) {
					if (sItem.getAggregation("cells")[0].getProperty("text") === "MDMA" && this.getView().byId("ENTRY_SEQUENCE").getValue() ===
						"After" && table.indexOfItem(sItem) != "0") {
						MessageBox.alert("You cannot add Approvers/Watchers after MDMA ");
						return false;
					}
				}
				for (var h = 0; h < AData.length; h++) {
					var NextAction = AData[h].ACTION;
					if (NextAction === "Approved") {
						if (selectedType === "APPROVER" && sItem.getAggregation("cells")[3].getProperty("text") !== "Approved" && selectedItemindex < h) {
							MessageBox.alert("You cannot add Approvers before approved status");
							return false;
						}
					}
				}
				sIndex = table.getItems().indexOf(table.getSelectedItem());
				sIndex = (positionType === "Before") ? Number(sIndex) : Number(sIndex +
					1);

				var oTableModel = this.getView().getModel("approverModel");
				var oDataSet = oTableModel.getData();
				oDataSet.splice(sIndex, 0, {
					APPR_ID: "",
					APPRNAME: "",
					APPREMAIL: "",
					APPRCONTACT: "",
					APPRDIV: "",
					REVIEWER_TYPE: selectedType,
					isInput: false,
					ACTION: "",
					ACT_NAME: "",
					ACTION_DATE: "",
					ACTION_TIME: "",
					MANUAL: "X",
					ADDED_BY: LoggedUserid

				});
				this.getView().getModel("approverModel").setData(oDataSet);
			} else {
				MessageToast.show("Please select an approver");
			}

		},
		deleteApprovers: function (oEvent) {
			this.getMDMAdetails();
			this.getdetailsGoa();
			this.getdetailsCMI();
			var data = this.getView().getModel("viewDataModel").getData();
			var AData = this.getView().getModel("approverModel").getData();
			if (data[0] === undefined) {
				var sStatus = data.Status;
			} else {
				sStatus = data[0].Status;
			}

			if (AData.length !== undefined && sStatus !== undefined) {
				var oParent = oEvent.getSource().getParent();
				var oPar_Parent = oParent.getParent().getId();
				var oTableId = sap.ui.getCore().byId(oPar_Parent);
				var selected_item = oTableId.getSelectedItem();
				var array = this.getView().getModel("approverModel").getData();
				var array2 = [];
				var table = this.getView().byId("tblApprover");
				var selectedItemindex = table.getItems().indexOf(table.getSelectedItem());
				//deleting mannually added items
				var sContext = selected_item.getBindingContextPath();
				array2 = array.splice(sContext.substr(1), 1);
				var approver = array2[0].APPR_ID;
				var statusapproved = array2[0].ACTION;
				var AddBy = array2[0].ADDED_BY;
				var LoggedUserid = sap.ushell.Container.getService("UserInfo").getUser().getId();

				if (selectedItemindex === 0) {
					MessageToast.show("You can not delete predefined watcher from Approval List");
					return false;
				}
				if (approver === "MDMA" || approver === "GOA" || approver === "CMI" || statusapproved === "Approved") {
					var selectedIndex1 = sContext.split("/")[1];
					var selectedIndex = parseInt(selectedIndex1);
					array.splice(selectedIndex, 0, array2[0]);
					MessageToast.show("You can not delete predefined approvers or Approved Status from Approval List");
					return false;
				}
				this.getView().getModel("approverModel").setData(array);
				var sqNo = array2[0].SEQUENCE;
				var seqNum = sqNo.replace(/\s/g, "");
				var ApproverspersonsArray = [];
				for (var i = 0; i < AData.length; i++) {
					var D = {};
					D.APPR_ID = AData[i].APPR_ID;
					ApproverspersonsArray[i] = D;
				}
				var mdmalist = [];
				var Goalist = [];
				var CMIlist = [];
				Goalist = this.getView().getModel("GoaDetails").getData();
				mdmalist = this.getView().getModel("MDMAdetails").getData();
				CMIlist = this.getView().getModel("CMIdetails").getData();
				for (var b = 0; b < Goalist.length; b++) {
					var G = {};
					G.Name = Goalist[b].Name;
					Goalist[b] = G;
				}
				for (var k = 0; k < mdmalist.length; k++) {
					var M = {};
					M.Name = mdmalist[k].Name;
					mdmalist[k] = M;
				}
				var concatall = ApproverspersonsArray.concat(CMIlist, Goalist, mdmalist);
				var error = false;
				concatall.forEach(function (enteredQr) {
					if (enteredQr.APPR_ID === LoggedUserid) {
						error = true;
					}
					if (enteredQr.Name === LoggedUserid) {
						error = true;
					}
				}.bind(this));
				if (AddBy === LoggedUserid) {
					error = true;
				}
				if (error === false) {
					MessageToast.show("User Not Authorized to Delete Approvers");
					var selectedIndex1 = sContext.split("/")[1];
					var selectedIndex = parseInt(selectedIndex1);
					array.splice(selectedIndex, 0, array2[0]);
					this.getView().getModel("approverModel").setData(array);
					return false;
				}
			}
			if (error === true) {
				var that = this;
				var oModel = this.getModel("ICsrvmodel");
				oModel.remove("/eFormApproverSet(MDMNR='" + that.form_number + "'" + ",SEQUENCE='" + seqNum +
					"')", {
						method: "DELETE",
						success: function (oData, response) {
							MessageBox.success("This Selected Approver has been deleted successfully.");
							//  this.getView().getModel("approverModel").setData(array);
							that.getApproversData(that.form_number, data.Status);
						}.bind(this),
						error: function (response) {
							var response = JSON.parse(response.responseText);
							MessageBox.show(
								response.error.message.value,
								MessageBox.Icon.ERROR,
								"Error"
							);
							sap.ui.core.BusyIndicator.hide();
						}.bind(this)
					});

			} else {
				var selectedIndex1 = sContext.split("/")[1];
				var selectedIndex = parseInt(selectedIndex1);
				array.splice(selectedIndex, 0, array2[0]);
				MessageToast.show("You are not Authorized to Delete selected Approver.");
				this.getView().getModel("approverModel").setData(array);
				return false;
			}
		},
		onButtonupdate: function (oEvent) {
			var that = this;
			var tableCC = that.getView().byId("tblCompcodeid").getItems();
			var ModelData = that.getView().getModel("InterCopanyModel").getData();
			var ModelBPData = that.getView().getModel("BPInfoModel").getData();
			var buttonText = oEvent.getSource().getProperty("text");
			var fNameTxt = that.getView().byId("fnameId").getValue();
			var LNameTxt = that.getView().byId("lnameId").getValue();
			var emailTxt = that.getView().byId("emailId").getValue();
			var locTxt = that.getView().byId("locId").getValue();
			var phoneNum = that.getView().byId("phoneId").getValue();
			var reasonTxt = that.getView().byId("brsiId").getValue();
			var changesByU = sap.ushell.Container.getService("UserInfo").getUser().getId();
			var prepareU = Createdby;
			if (prepareU === null || prepareU === undefined || prepareU === "") {
				prepareU = sap.ushell.Container.getService("UserInfo").getUser().getId();
			}
			var odataModel = this.getModel("ICsrvmodel");
			var submitDate;
			var data = {};
			//Business Partner Information Table Line Items validation check for mandatory fiels
			for (var i = 0; i < tableCC.length; i++) {
				if (tableCC[i].getCells()[0].getValue() === "") {
					tableCC[i].getCells()[0].setValueState("Error");
					return false;
				} else if (tableCC[i].getCells()[1].getValue() === "") {
					tableCC[i].getCells()[1].setValueState("Error");
					return false;
				} else if (tableCC[i].getCells()[3].getValue() === "") {
					tableCC[i].getCells()[3].setValueState("Error");
					return false;
				}
			}
			for (var i = 0; i < tableCC.length; i++) {
				for (var j = i + 1; j < tableCC.length; j++) {
					if (tableCC[i].getCells()[0].getValue() === tableCC[j].getCells()[0].getValue() && tableCC[i].getCells()[1].getValue() ===
						tableCC[j].getCells()[1].getValue() && tableCC[i].getCells()[3].getValue() === tableCC[j].getCells()[3].getValue()) {
						MessageBox.alert("Duplicate Items found");
						tableCC[j].getCells()[0].setValueState("Error");
						tableCC[j].getCells()[1].setValueState("Error");
						tableCC[j].getCells()[3].setValueState("Error");
						return false;
					}
				}
			}
			if (locTxt === null || locTxt === undefined) {
				locTxt = "";
			}
			if (phoneNum === null || phoneNum === undefined) {
				phoneNum = "";
			}
			if (reasonTxt === null || reasonTxt === undefined) {
				reasonTxt = "";
			}
			var datetimeFormat = DateFormat.getDateTimeInstance({
				// pattern: "yyyyMMdd" + "T" + "hhmmss"
				pattern: "yyyy-MM-dd" + "T" + "hh:mm:ss"
			});
			var submitDateTime = datetimeFormat.format(new Date());
			var stringSubDt = submitDateTime.toString();
			data = {
				"Status": Formstatus,
				"EFORM_NUM": this.form_number,
				"Rtype": "CR",
				"FirstName": fNameTxt,
				"Lastname": LNameTxt,
				"Location": locTxt,
				"Tel_Number": phoneNum,
				"eMailAddress": emailTxt,
				"Reason": reasonTxt,
				"CreatedDateTime": submitDateTime,
				"SubmittedOn": submitDate,
				"Update": "X",
				"UpdateBy": changesByU,
				"CreatedBy": prepareU,
				"Status_Desc": "",
				"Status_User": "",
				"Status_Username": "",
				"StatusDateTime": "",
				"CreationDate_From": "",
				"CreationDate_To": "",
			};
			var BPInformationData = [];
			for (i = 0; i < tableCC.length; i++) {
				BPInformationData.push({
					EFORM_NUM: this.form_number,
					CompanyCode1: tableCC[i].getCells()[0].getValue(),
					ProfitCenter: tableCC[i].getCells()[1].getValue(),
					ControllingArea: "",
					BusinessPartner: tableCC[i].getCells()[2].getText(),
					CompanyCode2: tableCC[i].getCells()[3].getValue(),
					Actiion: tableCC[i].getCells()[4].getText(),
					Processed: "",
				});
			}
			data.eFormBPInformationSet = [];
			data.eFormBPInformationSet = BPInformationData;
			var commentModel = this.getView().getModel("commentModel").getData();
			if (commentModel === null || commentModel === undefined) {
				commentModel = "";
			}
			data.eFormCommentSet = [];
			for (var k = 0; k < commentModel.length; k++) {
				var D = {};
				D.EFORM_NUM = this.form_number;
				D.comments = commentModel[k].comments;
				D.CreatorId = commentModel[k].CreatorId;
				D.CreatorName = commentModel[k].CreatorName;
				D.CommentNo = commentModel[k].CommentNo;
				D.CommentDate = "";
				D.CommentTime = "";
				D.Rtype = "SH";
				data.eFormCommentSet[k] = D;
			}

			var approverDataModel = this.getView().getModel("approverModel").getData();
			if (approverDataModel === null || approverDataModel === undefined) {
				approverDataModel = "";
			}
			var table = this.getView().byId("tblApprover").getItems();
			var i = null;
			for (i = 0; i < table.length; i++) {
				var tempappr;
				if (table[i].getCells()[0].mProperties.value === undefined)
					tempappr = table[i].getCells()[0].getText();
				else
					tempappr = table[i].getCells()[0].getValue();
				if (tempappr === undefined || tempappr === "null" || tempappr === "") {
					MessageBox.alert("Approver field Can not be empty");
					return false;
				}
			}
			data.eFormApproverSet = [];
			for (var i = 0; i < approverDataModel.length; i++) {
				var D = {};
				D.MDMNR = this.form_number;
				D.APPR_ID = approverDataModel[i].APPR_ID;
				D.APPREMAIL = "";
				D.APPRCONTACT = "";
				D.APPRDIV = "";
				D.REVIEWER_TYPE = approverDataModel[i].REVIEWER_TYPE;
				D.SEQUENCE = String(i + 1);
				D.ACTION = approverDataModel[i].ACTION;
				D.ACTION_DATE = approverDataModel[i].ACTION_DATE;
				var datab = D.ACTION_DATE;
				var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
					pattern: "yyyyMMdd"
				});
				var actionDate = dateFormat.format(new Date(datab));
				D.ACTION_DATE = actionDate;
				D.ACTION_TIME = approverDataModel[i].ACTION_TIME;
				D.ACTION_BY = approverDataModel[i].ACTION_BY;
				D.GRP = "";
				D.ACT_NAME = approverDataModel[i].ACT_NAME;
				D.APPRNAME = approverDataModel[i].APPRNAME;

				D.MANUAL = approverDataModel[i].MANUAL;
				data.eFormApproverSet[i] = D;
			}
			data.eFormBPDetailsSet = [];
			if (JSON.stringify(ModelBPData.BPInformationData) !== JSON.stringify(ModelBPData.BPInformationCopyData)) {
				MessageBox.warning(
					"Do you want to save Business partner changes?", {
						actions: ["Yes", "No"],
						emphasizedAction: "Yes",
						onClose: function (sAction) {
							if (sAction == "Yes") {
								sap.ui.core.BusyIndicator.show();
								data.eFormBPDetailsSet = ModelBPData.BPInformationData;
								odataModel.create("/eFormHeaderSet", data, {
									async: false,
									success: function (oData, response) {
										sap.ui.core.BusyIndicator.hide();
										MessageBox.show(
											"Changes saved successfully.",
											MessageBox.Icon.SUCCESS,
											"Success"
										);
										var Apprtable = that.getView().byId("tblApprover");
										Apprtable.removeAllItems(true);
										that.getView().getModel("approverModel").setData(null);
										that.getView().getModel("approverModel").setData(oData.eFormApproverSet.results);
										that.getApproversData(that.form_number, data.Status);
										that.getView().byId("idshowICNode").setVisible(true);
										that.getView().byId("idEditICNode").setVisible(false);
										that.makeEditableFalse();
									},
									error: function (oError) {
										sap.ui.core.BusyIndicator.hide();
										var ArrayError = [];
										var strResponse = oError.responseText;
										var strErrorDetail = strResponse.substr(strResponse.indexOf("errordetails"));
										var strStatusMsg = strErrorDetail.split(",");
										for (var i = 0; i < strStatusMsg.length; i++) {
											if (strStatusMsg[i].match(/message":"/gi)) {
												var strStatus = strStatusMsg[i].substring(strStatusMsg[i].indexOf("message") + 10);
												ArrayError.push(strStatus);
											}
										}
										ArrayError.pop();
										var errorDisplay = {
											"results": ArrayError
										};
										if (!that._oDialog1) {
											that._oDialog1 = sap.ui.xmlfragment("com.spe.YIC_FORM.Fragments.AutoErrors", that);
											that.getView().addDependent(that._oDialog1);
										}
										that._oDialog1.open();
										var oModellist1 = new sap.ui.model.json.JSONModel();
										oModellist1.setData(errorDisplay);
										that._oDialog1.setModel(oModellist1);

									}.bind(this)
								});
							} else {
								return false;
							}
						}.bind(this)
					});
			} else {
				sap.ui.core.BusyIndicator.show();
				odataModel.create("/eFormHeaderSet", data, {
					async: false,
					success: function (oData, response) {
						sap.ui.core.BusyIndicator.hide();
						MessageBox.show(
							"Changes saved successfully.",
							MessageBox.Icon.SUCCESS,
							"Success"
						);
						var Apprtable = that.getView().byId("tblApprover");
						Apprtable.removeAllItems(true);
						that.getView().getModel("approverModel").setData(null);
						that.getView().getModel("approverModel").setData(oData.eFormApproverSet.results);
						that.getApproversData(that.form_number, data.Status);
					},
					error: function (oError) {
						sap.ui.core.BusyIndicator.hide();
						var ArrayError = [];
						var strResponse = oError.responseText;
						var strErrorDetail = strResponse.substr(strResponse.indexOf("errordetails"));
						var strStatusMsg = strErrorDetail.split(",");
						for (var i = 0; i < strStatusMsg.length; i++) {
							if (strStatusMsg[i].match(/message":"/gi)) {
								var strStatus = strStatusMsg[i].substring(strStatusMsg[i].indexOf("message") + 10);
								ArrayError.push(strStatus);
							}
						}
						ArrayError.pop();
						var errorDisplay = {
							"results": ArrayError
						};
						if (!that._oDialog1) {
							that._oDialog1 = sap.ui.xmlfragment("com.spe.YIC_FORM.Fragments.AutoErrors", that);
							that.getView().addDependent(that._oDialog1);
						}
						that._oDialog1.open();
						var oModellist1 = new sap.ui.model.json.JSONModel();
						oModellist1.setData(errorDisplay);
						that._oDialog1.setModel(oModellist1);

					}.bind(this)
				});
			}
		},
		onButtonApprove: function (event) {
			var that = this;
			MessageBox.warning("Please verify field(s) in the Request form.", {
				actions: ["Continue", "Verify"],
				emphasizedAction: "Continue",
				onClose: function (sAction) {
					if (sAction == "Continue") {
						var msg_returned = "";
						var sValue = jQuery.sap.getUriParameters().get("SOURCE");
						var url = "/sap/opu/odata/sap/YFPSFIFRDD0040_IC_FORM_SRV/";
						var oModelData = new sap.ui.model.odata.ODataModel(url, true);
						var relPath = "/eFormValidateApprovalSet?$filter=EFORM_NUM eq '" + this.mdmnr_appr + "' and ACTION eq 'A'";
						var that = this;
						oModelData.read(relPath, null, [], false, function (oData, response) {

							var msg_type = response.data.results[0].MSG_TYPE;
							if (msg_type == "E") {
								msg_returned = response.data.results[0].MSG + ".";
							} else {
								msg_returned = "The eForm has been successfully approved.";
							}
							new Promise(function (fnResolve) {
								sap.m.MessageBox.confirm(msg_returned, {
									title: "Confirm Navigation",
									actions: ["OK"],
									onClose: function (sActionClicked) {
										if (sActionClicked === "OK") {
											that.oRouter.navTo("SearchIC", true);
										}
									}
								});
							});

						});
					} else {

					}
				}.bind(this)
			});
		},
		onButtonReject: function () {
			var msg_returned = "";
			var sValue = jQuery.sap.getUriParameters().get("SOURCE");
			MessageBox.warning("Do you really want to Reject?", {
				actions: ["YES", "NO"],
				emphasizedAction: "YES",
				onClose: function (sAction) {
					if (sAction == "YES") {
						var url = "/sap/opu/odata/sap/YFPSFIFRDD0040_IC_FORM_SRV/";
						var oModelData = new sap.ui.model.odata.ODataModel(url, true);
						var relPath = "/eFormValidateApprovalSet?$filter=EFORM_NUM eq '" + this.mdmnr_appr + "' and ACTION eq 'R'";
						var that = this;
						oModelData.read(relPath, null, [], false, function (oData, response) {
							var msg_type = response.data.results[0].MSG_TYPE;
							if (msg_type == "E") {
								// MessageBox.error(response.data.results[0].MSG);
								msg_returned = response.data.results[0].MSG + ".";
							} else {
								msg_returned = "The eForm has been Rejected.";
							}
							new Promise(function (fnResolve) {
								sap.m.MessageBox.confirm(msg_returned, {
									title: "Confirm Navigation",
									actions: ["OK"],
									onClose: function (sActionClicked) {
										if (sActionClicked === "OK") {
											that.oRouter.navTo("SearchIC", true);
										}
									}
								});
							});
						});
					} else {
						MessageToast.show("Rejection cancelled");
					}
				}.bind(this)
			});
			//	this.oRouter.navTo("SearchBankKey", true);
		},
		onButtonMaintain: function (oEvent) {
			var that = this;
			var tableCC = that.getView().byId("tblCompcodeid").getItems();
			var ModelData = that.getView().getModel("InterCopanyModel").getData();
			var ModelBPData = that.getView().getModel("BPInfoModel").getData();
			var buttonText = oEvent.getSource().getProperty("text");
			var fNameTxt = that.getView().byId("fnameId").getValue();
			var LNameTxt = that.getView().byId("lnameId").getValue();
			var emailTxt = that.getView().byId("emailId").getValue();
			var locTxt = that.getView().byId("locId").getValue();
			var phoneNum = that.getView().byId("phoneId").getValue();
			var reasonTxt = that.getView().byId("brsiId").getValue();
			var odataModel = this.getModel("ICsrvmodel");
			var submitDate;
			var data = {};
			// Headers validation check for mandatory fiels
			if (fNameTxt === "" || fNameTxt === null || fNameTxt === undefined) {
				MessageBox.show(
					"First Name is Mandatory fields.",
					MessageBox.Icon.ERROR,
					"Error"
				);
				return false;
			}
			if (LNameTxt === "" || LNameTxt === null || LNameTxt === undefined) {
				MessageBox.show(
					"Last Name is Mandatory fields.",
					MessageBox.Icon.ERROR,
					"Error"
				);
				return false;
			}
			if (emailTxt === "" || emailTxt === null || emailTxt === undefined) {
				MessageBox.show(
					"Email is Mandatory fields.",
					MessageBox.Icon.ERROR,
					"Error"
				);
				return false;
			}
			if (reasonTxt === "" || reasonTxt === null || reasonTxt === undefined) {
				MessageBox.show(
					"Business Reasons and Special Instructions is Mandatory fields.",
					MessageBox.Icon.ERROR,
					"Error"
				);
				return false;
			}

			//Business Partner Information Table Line Items validation check for mandatory fiels
			for (var i = 0; i < tableCC.length; i++) {
				if (tableCC[i].getCells()[0].getValue() === "") {
					tableCC[i].getCells()[0].setValueState("Error");
					return false;
				} else if (tableCC[i].getCells()[1].getValue() === "") {
					tableCC[i].getCells()[1].setValueState("Error");
					return false;
				} else if (tableCC[i].getCells()[3].getValue() === "") {
					tableCC[i].getCells()[3].setValueState("Error");
					return false;
				}
			}
			for (var i = 0; i < tableCC.length; i++) {
				for (var j = i + 1; j < tableCC.length; j++) {
					if (tableCC[i].getCells()[0].getValue() === tableCC[j].getCells()[0].getValue() && tableCC[i].getCells()[1].getValue() ===
						tableCC[j].getCells()[1].getValue() && tableCC[i].getCells()[3].getValue() === tableCC[j].getCells()[3].getValue()) {
						MessageBox.alert("Duplicate Items found");
						tableCC[j].getCells()[0].setValueState("Error");
						tableCC[j].getCells()[1].setValueState("Error");
						tableCC[j].getCells()[3].setValueState("Error");
						return false;
					}
				}
			}
			if (buttonText === "Save") {
				statusSaveSub = "01";
				submitDate = "";
				MessageToast.show("Work in Progress for save");
			}
			if (buttonText === "Submit") {
				MessageToast.show("Work in Progress for Submit");
				statusSaveSub = "02";
				var SubDateFormat = DateFormat.getDateTimeInstance({
					pattern: "yyyyMMdd" + "T" + "hhmmss"
						// pattern: "yyyy-MM-dd" + "T" + "hh:mm:ss"
				});
				submitDate = SubDateFormat.format(new Date());
			} else if (buttonText === "Withdraw") {
				statusSaveSub = "10";
			} else if (buttonText === "Complete") {
				statusSaveSub = "07";
			}
			if (locTxt === null || locTxt === undefined) {
				locTxt = "";
			}
			if (phoneNum === null || phoneNum === undefined) {
				phoneNum = "";
			}
			if (reasonTxt === null || reasonTxt === undefined) {
				reasonTxt = "";
			}

			var prepare = Createdby;
			if (prepare === null || prepare === undefined || prepare === "") {
				prepare = sap.ushell.Container.getService("UserInfo").getUser().getId();
			}
			var datetimeFormat = DateFormat.getDateTimeInstance({
				// pattern: "yyyyMMdd" + "T" + "hhmmss"
				pattern: "yyyy-MM-dd" + "T" + "hh:mm:ss"
			});
			var submitDateTime = datetimeFormat.format(new Date());
			var stringSubDt = submitDateTime.toString();
			data = {
				"Status": "09",
				"EFORM_NUM": this.form_number,
				"Rtype": "CR",
				"FirstName": fNameTxt,
				"Lastname": LNameTxt,
				"Location": locTxt,
				"Tel_Number": phoneNum,
				"eMailAddress": emailTxt,
				"Reason": reasonTxt,
				"CreatedBy": prepare,
				"CreatedDateTime": submitDateTime,
				"SubmittedOn": submitDate,
				"Status_Desc": "",
				"Status_User": "",
				"Status_Username": "",
				"StatusDateTime": "",
				"CreationDate_From": "",
				"CreationDate_To": "",
			};
			var BPInformationData = [];
			for (i = 0; i < tableCC.length; i++) {
				BPInformationData.push({
					EFORM_NUM: this.form_number,
					CompanyCode1: tableCC[i].getCells()[0].getValue(),
					ProfitCenter: tableCC[i].getCells()[1].getValue(),
					ControllingArea: "",
					BusinessPartner: tableCC[i].getCells()[2].getText(),
					CompanyCode2: tableCC[i].getCells()[3].getValue(),
					Actiion: tableCC[i].getCells()[4].getText(),
					Processed: "",
				});
			}
			data.eFormBPInformationSet = [];
			data.eFormBPInformationSet = BPInformationData;
			data.eFormBPDetailsSet = [];
			var commentModel = this.getView().getModel("commentModel").getData();
			if (commentModel === null || commentModel === undefined) {
				commentModel = "";
			}
			data.eFormCommentSet = [];
			for (var k = 0; k < commentModel.length; k++) {
				var D = {};
				D.EFORM_NUM = this.form_number;
				D.comments = commentModel[k].comments;
				D.CreatorId = commentModel[k].CreatorId;
				D.CreatorName = commentModel[k].CreatorName;
				D.CommentNo = commentModel[k].CommentNo;
				D.CommentDate = "";
				D.CommentTime = "";
				D.Rtype = "SH";
				data.eFormCommentSet[k] = D;
			}

			var approverDataModel = this.getView().getModel("approverModel").getData();
			if (approverDataModel === null || approverDataModel === undefined) {
				approverDataModel = "";
			}
			var table = this.getView().byId("tblApprover").getItems();
			var i = null;
			for (i = 0; i < table.length; i++) {
				var tempappr;
				if (table[i].getCells()[0].mProperties.value === undefined)
					tempappr = table[i].getCells()[0].getText();
				else
					tempappr = table[i].getCells()[0].getValue();
				if (tempappr === undefined || tempappr === "null" || tempappr === "") {
					MessageBox.alert("Approver field Can not be empty");
					return false;
				}
			}
			data.eFormApproverSet = [];
			for (var i = 0; i < approverDataModel.length; i++) {
				var D = {};
				D.MDMNR = this.form_number;
				D.APPR_ID = approverDataModel[i].APPR_ID;
				D.APPREMAIL = "";
				D.APPRCONTACT = "";
				D.APPRDIV = "";
				D.REVIEWER_TYPE = approverDataModel[i].REVIEWER_TYPE;
				D.SEQUENCE = String(i + 1);
				D.ACTION = approverDataModel[i].ACTION;
				D.ACTION_DATE = approverDataModel[i].ACTION_DATE;
				var datab = D.ACTION_DATE;
				var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
					pattern: "yyyyMMdd"
				});
				var actionDate = dateFormat.format(new Date(datab));
				D.ACTION_DATE = actionDate;
				D.ACTION_TIME = approverDataModel[i].ACTION_TIME;
				D.ACTION_BY = approverDataModel[i].ACTION_BY;
				D.GRP = "";
				D.ACT_NAME = approverDataModel[i].ACT_NAME;
				D.APPRNAME = approverDataModel[i].APPRNAME;

				D.MANUAL = approverDataModel[i].MANUAL;
				data.eFormApproverSet[i] = D;
			}
			odataModel.create("/eFormHeaderSet", data, {
				async: false,
				success: function (oData, response) {
					sap.ui.core.BusyIndicator.hide();
					var msg_type = oData.MsgID;

					if (msg_type == "E") {
						MessageBox.show(
							"Error",
							MessageBox.Icon.ERROR,
							"Error"
						);
					}
					if (msg_type == "W") {
						sap.m.MessageBox.warning("Warning.", {
							title: "Warning",
							actions: ["OK"],
							onClose: function (sActionClicked) {
								if (sActionClicked === "OK") {
									that.oRouter.navTo("SearchIC", true);
								}
							}
						});
					}
					if (msg_type == "S") {
						sap.m.MessageBox.success("Inter Company has been maintained successfully", {
							title: "Success",
							actions: ["OK"],
							onClose: function (sActionClicked) {
								if (sActionClicked === "OK") {
									that.oRouter.navTo("SearchIC", true);
								}
							}
						});
					}
				},
				error: function (oError) {
					debugger;
					var ArrayError = [];
					var strResponse = oError.responseText;
					var strErrorDetail = strResponse.substr(strResponse.indexOf("errordetails"));
					var strStatusMsg = strErrorDetail.split(",");
					for (var i = 0; i < strStatusMsg.length; i++) {
						if (strStatusMsg[i].match(/message":"/gi)) {
							var strStatus = strStatusMsg[i].substring(strStatusMsg[i].indexOf("message") + 10);
							ArrayError.push(strStatus);
						}
					}
					ArrayError.pop();
					var errorDisplay = {
						"results": ArrayError
					};
					if (!that._oDialog1) {
						that._oDialog1 = sap.ui.xmlfragment("com.spe.YIC_FORM.Fragments.AutoErrors", that);
						that.getView().addDependent(that._oDialog1);
					}
					that._oDialog1.open();
					var oModellist1 = new sap.ui.model.json.JSONModel();
					oModellist1.setData(errorDisplay);
					that._oDialog1.setModel(oModellist1);

				}.bind(this)
			});
		},
		onCloseDialog1: function () {
				var that = this;
				this._oDialog1.close();
			}
			/**
			 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
			 * (NOT before the first rendering! onInit() is used for that one!).
			 * @memberOf com.spe.YIC_FORM.view.CreateIC
			 */
			//	onBeforeRendering: function() {
			//
			//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf com.spe.YIC_FORM.view.CreateIC
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf com.spe.YIC_FORM.view.CreateIC
		 */
		//	onExit: function() {
		//
		//	}

	});

});