sap.ui.define([
	"./BaseController",
	'jquery.sap.global',
	"sap/ui/core/Fragment",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageBox",
	"sap/m/Token",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/core/format/DateFormat",
	"sap/m/MessageToast"
], function (BaseController, jQuery, Fragment, JSONModel, MessageBox, Token, Filter, FilterOperator, DateFormat, MessageToast) {
	"use strict";
	var FName;
	var LName;
	var email;
	var file_size;
	var e_form_num;
	var form_number = "";
	var Formstatus;
	var currnAppr;
	var statusSaveSub;
	var Createdby;
	var conAreaFilter;
	var currnAppr;
	var clicks = 1;
	var num;
	var backendBPData;
	return BaseController.extend("com.spe.YIC_FORM.controller.ChangeIC", {

		onInit: function () {
			var me = this;
			var style = "sapUiSizeCompact";
			me.getView().addStyleClass(style);
			me.getModel().setData({
				BPID: {
					items: []
				},
				DisplayEmployee: {
					items: []
				},
				ApproverTable: {
					items: []
				},
				Determine: {
					items: []
				}
			});
			var InterCopanyModel = new JSONModel();
			this.getView().setModel(InterCopanyModel, "InterCopanyModel");
			var commentModel = new JSONModel();
			this.getView().setModel(commentModel, "commentModel");
			var EnableModel = new JSONModel();
			this.getView().setModel(EnableModel, "EnableModel");
			var approverModelChange = new JSONModel();
			this.getView().setModel(approverModelChange, "approverModelChange");
			var CCModel = new JSONModel();
			this.getView().setModel(CCModel, "CCModel");
			var StdModel = new JSONModel();
			this.getView().setModel(StdModel, "StdModel");
			var CMIdetails = new JSONModel();
			this.getView().setModel(CMIdetails, "CMIdetails");
			var MDMAdetails = new JSONModel();
			this.getView().setModel(MDMAdetails, "MDMAdetails");
			var GoaDetails = new JSONModel();
			this.getView().setModel(GoaDetails, "GoaDetails");
			var viewDataModel = new JSONModel();
			this.getView().setModel(viewDataModel, "viewDataModel");
			var BPInfModelChng = new JSONModel();
			this.getView().setModel(BPInfModelChng, "BPInfModelChng");
			FName = sap.ushell.Container.getUser().getFirstName();
			LName = sap.ushell.Container.getUser().getLastName();
			email = sap.ushell.Container.getUser().getEmail();
			// FName = "Harshvardhan";
			// LName = "Kumar";
			// email = "Harshvardhan_kumar@spe.sony.com";
			this.getView().byId("fnameIdChng").setValue(FName);
			this.getView().byId("lnameIdChng").setValue(LName);
			this.getView().byId("emailIdChng").setValue(email);
			this.oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this.oRouter.attachRouteMatched(this._onObjectMatched, this);
		},
		_onObjectMatched: function (oEvent) {
			var that = this;
			var userModel = that.getModel("ICsrvmodel");
			var back = oEvent.getParameter("name");
			that.getModel().setData({
				BPID: {
					items: []
				},
				DisplayEmployee: {
					items: []
				},
				ApproverTable: {
					items: []
				},
				Determine: {
					items: []
				}
			});
			this.form_number = "";
			var contextName = oEvent.getParameters().arguments.context;
			this.form_number = contextName;
			var table = this.getView().byId("SimpleFormChng00");
			this.mdmnr_appr = contextName;
			var contextName = oEvent.getParameters().arguments.context;
			if (contextName !== undefined) {
				debugger;
				this.form_number = contextName;
				form_number = contextName;
				that.getdetailsCMI();
				that.getMDMAdetails();
				that.getdetailsGoa();
				that.getContextBackendData(contextName);
			} else {
				MessageToast.show("Work In Progress");
				this.getView().byId("pageIdChng").setTitle("Change IC 2 step Settled Relationship");
				this.getView().byId("t_attachmentChng").destroyItems();
				this.getView().byId("fnameIdChng").setValue(FName);
				this.getView().byId("lnameIdChng").setValue(LName);
				this.getView().byId("emailIdChng").setValue(email);
				this.getView().byId("locIdChng").setEnabled(true);
				this.getView().byId("phoneIdChng").setEnabled(true);
				this.getView().byId("brsiIdChng").setEnabled(true);
				this.getView().byId("BPChng").setEnabled(true);
				this.getView().byId("idbuttonGo").setEnabled(true);
				this.getView().byId("locIdChng").setValue("");
				this.getView().byId("phoneIdChng").setValue("");
				this.getView().byId("brsiIdChng").setValue("");
				this.getView().byId("BPChng").setValue("");
				this.getView().byId("idstatusChng").setValue("");
				this.getModel().setProperty("/BPID/items", []);
				this.getView().getModel("viewDataModel").setData(null);
				this.getView().getModel("commentModel").setData(null);
				this.getView().getModel("approverModelChange").setData(null);
				this.getView().getModel("BPInfModelChng").setData([]);
				this.getView().byId("buttonSaveChng").setVisible(true);
				this.getView().byId("buttonSubmitChng").setVisible(true);
				this.getView().byId("withdrawChng").setVisible(false);
				this.getView().byId("approveChng").setVisible(false);
				this.getView().byId("rejectChange").setVisible(false);
				this.getView().byId("updateChng").setVisible(false);
				this.getView().byId("completeChng").setVisible(false);
				this.getView().byId("maintainChange").setVisible(false);
				this.getView().getModel("EnableModel").setProperty("/enabled", true);
				this.getView().getModel("BPInfModelChng").setProperty('/BPInfoSelectedItem', null);
			}
		},
		getContextBackendData: function (contextName) {
			var that = this;
			var cmiUserList = [];
			cmiUserList = this.getView().getModel("CMIdetails").getData();
			var mdmaUserList = [];
			mdmaUserList = this.getView().getModel("MDMAdetails").getData();
			var goaUserList = [];
			goaUserList = this.getView().getModel("GoaDetails").getData();
			var oModel = that.getModel("ICsrvmodel");
			oModel.read("/eFormHeaderSet('" + contextName + "')", {
				method: "GET",
				urlParameters: {
					"$expand": "eFormBPInformationSet,eFormCommentSet,eFormApproverSet,eFormBPDetailsSet"
				},
				success: function (oData, response) {
					that.getView().byId("pageIdChng").setTitle('Change IC 2 step Settled Relationship' + ':' + " " + oData.EFORM_NUM);
					that.getView().byId("fnameIdChng").setValue(oData.FirstName);
					that.getView().byId("lnameIdChng").setValue(oData.Lastname);
					that.getView().byId("emailIdChng").setValue(oData.eMailAddress);
					that.getView().byId("locIdChng").setValue(oData.Location);
					that.getView().byId("phoneIdChng").setValue(oData.Tel_Number);
					that.getView().byId("brsiIdChng").setValue(oData.Reason);
					that.getView().byId("BPChng").setValue(oData.BPNumber);
					that.getView().byId("idstatusChng").setValue(oData.Status_Desc);
					Formstatus = oData.Status;
					currnAppr = oData.CurrentApprover;
					backendBPData = oData.eFormBPDetailsSet.results[0];
					that.getView().getModel("InterCopanyModel").setData(oData.eFormBPInformationSet.results);
					that.getView().getModel("commentModel").setData(oData.eFormCommentSet.results);
					that.getView().getModel("viewDataModel").setData(oData);
					that.getView().getModel("BPInfModelChng").setProperty('/BPInfoSelectedItem', null);
					that.getView().getModel("BPInfModelChng").setProperty('/BPInfoSelectedItem', oData.eFormBPDetailsSet.results[0]);
					that.getApproversData(oData.EFORM_NUM, oData.Status);
					that.getattachments(contextName);
					that.getComments(oData.EFORM_NUM);
					if (oData.CreatedBy !== sap.ushell.Container.getService("UserInfo").getUser().getId()) {
						that.getView().byId("buttonSaveChng").setVisible(false);
						that.getView().byId("buttonSubmitChng").setVisible(false);
						that.getView().byId("locIdChng").setEnabled(false);
						that.getView().byId("phoneIdChng").setEnabled(false);
						that.getView().byId("brsiIdChng").setEnabled(false);
						that.getView().getModel("EnableModel").setProperty("/enabled", false);
						that.getView().byId("BPChng").setEnabled(false);
						that.getView().byId("idbuttonGo").setEnabled(false);
					}
					// Buttons Visibility
					if (oData.Status === "02" || oData.Status === "03") {
						that.getView().byId("locIdChng").setEnabled(false);
						that.getView().byId("phoneIdChng").setEnabled(false);
						that.getView().byId("brsiIdChng").setEnabled(false);
						that.getView().byId("BPChng").setEnabled(false);
						that.getView().byId("idbuttonGo").setEnabled(false);
						that.getView().byId("buttonSaveChng").setVisible(false);
						that.getView().byId("buttonSubmitChng").setVisible(false);
						that.getView().byId("updateChng").setVisible(true);
						that.getView().byId("approveChng").setVisible(true);
						that.getView().byId("rejectChange").setVisible(true);
						that.getView().byId("completeChng").setVisible(false);
						that.getView().byId("maintainChange").setVisible(false);
						if (oData.CreatedBy === sap.ushell.Container.getService("UserInfo").getUser().getId()) {
							that.getView().byId("withdrawChng").setVisible(true);
							that.getView().byId("updateChng").setVisible(true);
							that.getView().getModel("EnableModel").setProperty("/enabled", false);
						}
						for (var m = 0; m < mdmaUserList.length; m++) {
							if (mdmaUserList[m].Name === sap.ushell.Container.getService("UserInfo").getUser().getId()) {
								that.getView().getModel("EnableModel").setProperty("/enabled", true);
							}
						}
					}
					if (oData.Status === "04") {
						that.getView().byId("locIdChng").setEnabled(false);
						that.getView().byId("phoneIdChng").setEnabled(false);
						that.getView().byId("brsiIdChng").setEnabled(false);
						that.getView().byId("BPChng").setEnabled(false);
						that.getView().byId("idbuttonGo").setEnabled(false);
						that.getView().getModel("EnableModel").setProperty("/enabled", false);
						that.getView().byId("buttonSaveChng").setVisible(false);
						that.getView().byId("buttonSubmitChng").setVisible(false);
						that.getView().byId("updateChng").setVisible(false);
						that.getView().byId("withdrawChng").setVisible(false);
						that.getView().byId("approveChng").setVisible(false);
						that.getView().byId("rejectChange").setVisible(false);
						that.getView().byId("completeChng").setVisible(false);
						that.getView().byId("maintainChange").setVisible(false);
						for (var m = 0; m < mdmaUserList.length; m++) {
							if (mdmaUserList[m].Name === sap.ushell.Container.getService("UserInfo").getUser().getId()) {
								that.getView().byId("maintainChange").setVisible(true);
							}
						}
					}
					if (oData.Status === "05") {
						that.getView().byId("locIdChng").setEnabled(false);
						that.getView().byId("phoneIdChng").setEnabled(false);
						that.getView().byId("brsiIdChng").setEnabled(false);
						that.getView().byId("BPChng").setEnabled(false);
						that.getView().byId("idbuttonGo").setEnabled(false);
						that.getView().getModel("EnableModel").setProperty("/enabled", false);
						that.getView().byId("buttonSaveChng").setVisible(false);
						that.getView().byId("buttonSubmitChng").setVisible(false);
						that.getView().byId("approveChng").setVisible(false);
						that.getView().byId("rejectChange").setVisible(false);
						that.getView().byId("updateChng").setVisible(false);
						that.getView().byId("completeChng").setVisible(false);
						that.getView().byId("maintainChange").setVisible(false);
						that.getView().byId("withdrawChng").setVisible(false);
					}
					if (oData.Status === "07" || oData.Status === "10") {
						that.getView().byId("locIdChng").setEnabled(false);
						that.getView().byId("phoneIdChng").setEnabled(false);
						that.getView().byId("brsiIdChng").setEnabled(false);
						that.getView().byId("BPChng").setEnabled(false);
						that.getView().byId("idbuttonGo").setEnabled(false);
						that.getView().getModel("EnableModel").setProperty("/enabled", false);
						that.getView().byId("buttonSaveChng").setVisible(false);
						that.getView().byId("buttonSubmitChng").setVisible(false);
						that.getView().byId("approveChng").setVisible(false);
						that.getView().byId("rejectChange").setVisible(false);
						that.getView().byId("updateChng").setVisible(false);
						that.getView().byId("completeChng").setVisible(false);
						that.getView().byId("maintainChange").setVisible(false);
					}
					if (oData.Status === "09") {
						that.getView().byId("locIdChng").setEnabled(false);
						that.getView().byId("phoneIdChng").setEnabled(false);
						that.getView().byId("brsiIdChng").setEnabled(false);
						that.getView().byId("BPChng").setEnabled(false);
						that.getView().byId("idbuttonGo").setEnabled(false);
						that.getView().getModel("EnableModel").setProperty("/enabled", false);
						that.getView().byId("buttonSaveChng").setVisible(false);
						that.getView().byId("buttonSubmitChng").setVisible(false);
						that.getView().byId("approveChng").setVisible(false);
						that.getView().byId("rejectChange").setVisible(false);
						that.getView().byId("updateChng").setVisible(false);
						that.getView().byId("maintainChange").setVisible(false);
						that.getView().byId("withdrawChng").setVisible(false);
						for (var m = 0; m < mdmaUserList.length; m++) {
							if (mdmaUserList[m].Name === sap.ushell.Container.getService("UserInfo").getUser().getId()) {
								that.getView().byId("completeChng").setVisible(true);
								that.getView().getModel("EnableModel").setProperty("/enabled", false);
							}
						}
					}
					var LoggedUserid = sap.ushell.Container.getService("UserInfo").getUser().getId();
					// var LoggedUserid = "SGUHA2"
					var ApproverspersonsArray = [];
					var concatall = ApproverspersonsArray.concat(cmiUserList, goaUserList, mdmaUserList); //Here GOA & MDMA users can delete the manual approvers
					var error = false;
					concatall.forEach(function (enteredQr) {
						if (enteredQr.APPR_ID === LoggedUserid) {
							error = true;
						}
						if (enteredQr.Name === LoggedUserid) {
							error = true;
						}
					}.bind(this));
					if (error === false && (oData.Status === "02" || oData.Status === "03")) {
						that.getView().byId("updateChng").setVisible(false);
						that.getView().byId("approveChng").setVisible(false);
						that.getView().byId("rejectChange").setVisible(false);
						that.getView().getModel("EnableModel").setProperty("/enabled", false);
						that.getView().byId("BPChng").setEnabled(false);
						that.getView().byId("idbuttonGo").setEnabled(false);
						return false;
					}
					if (error === true && (oData.Status === "02" || oData.Status === "03")) {
						that.getView().byId("updateChng").setVisible(true);
						that.getView().byId("approveChng").setVisible(true);
						that.getView().byId("rejectChange").setVisible(true);
						that.getView().byId("BPChng").setEnabled(false);
						that.getView().byId("idbuttonGo").setEnabled(false);
					}
				}.bind(this),
				error: function (oData) {
					var strResponse = oData.responseText;
					var strErrorDetail = strResponse.substring(strResponse.indexOf("error"));
					var strStatusMsg = strErrorDetail.split(",")[2];
					var strFullStatus = strStatusMsg;
					var strStatus = strFullStatus.substring(strFullStatus.indexOf("message") + 10) + "";
					var strStatus1 = strStatus.slice(0, -2) + "";
					MessageBox.error(strStatus1);
				}.bind(this)
			});
		},
		//Code for f4 help for BP input
		onValueHelpBP: function (oEvent) {
			if (!this.VDialog) {
				this.VDialog = this.loadFragment({
					name: "com.spe.YIC_FORM.Fragments.BPDetails"
				});
			}
			this.VDialog.then(function (oDialog) {
				this._oVID = oDialog;
				oDialog.open();
			}.bind(this));
			var me = this;
			var num = 20;
			var oModel = me.getModel("ICsrvmodel");
			oModel.read("/eFormBPDetailsSet?$skip=0&$top=" + num + "", {
				// filters: [oFilter],
				success: function (oData, response) {
					me.getModel().setProperty("/BPID/items", []);
					me.getModel().setProperty("/BPID/items", oData.results);
				}
			});
		},
		onNext: function () {
			if (clicks < 0) {
				clicks = 0;
				clicks += 1;
			} else {
				clicks += 1;
			};
			num = clicks * 20;
			this.getBPIDSet();
		},
		getBPIDSet: function () {
			var me = this;
			var gatewayUrl = "/sap/opu/odata/sap/YFPSFIFRDD0040_IC_FORM_SRV/";
			var oModel3 = new sap.ui.model.odata.ODataModel(gatewayUrl);
			var spath = "/eFormBPDetailsSet?$skip=0&$top=" + num + "";
			oModel3.read(spath, null, null, true, function (oData) {
				me.getModel().setProperty("/BPID/items", []);
				me.getModel().setProperty("/BPID/items", oData.results);
			});
		},

		_handleSelectVendorID: function (oEvent) {
			var BPNumber = oEvent.getSource().getTitle();
			var selectedBPDes = oEvent.getSource().getAggregation("attributes");
			var a = selectedBPDes[0].getProperty('text');
			this.getView().byId("BPChng").setValue(BPNumber);
			this._oVID.close();
		},
		onSearchBPID: function (oEvent) {
			var me = this;
			var BPNumber = this.getView().byId("idsearchBPID").getValue();
			var gatewayUrl = "/sap/opu/odata/sap/YFPSFIFRDD0040_IC_FORM_SRV/";
			var oModel3 = new sap.ui.model.odata.ODataModel(gatewayUrl);
			var spath = "/eFormBPDetailsSet?$filter=BPNumber eq" + "'" + BPNumber + "'";
			oModel3.read(spath, null, null, true, function (oData) {
				me.getModel().setProperty("/BPID/items", []);
				me.getModel().setProperty("/BPID/items", oData.results);
			});
		},
		onCloseDialogBPID: function () {
			this.getView().byId("idsearchBPID").setValue(null);
			this._oVID.close();
		},
		//End of Code for f4 help for BP input
		//Stating of code for GO button for BP 
		onButtonGo: function () {
			var BPNumber = this.getView().byId("BPChng").getValue();
			// var BPNumber = "C102510003";
			var oBPInfModelChng = this.getView().getModel("BPInfModelChng");
			var n = new sap.ui.model.Filter("BPNumber", sap.ui.model.FilterOperator.EQ, BPNumber);
			var myFilter = [];
			myFilter.push(n);
			var that = this;
			var oModel = this.getModel("ICsrvmodel");
			oModel.read("/eFormBPDetailsSet", {
				filters: myFilter,
				success: function (oData, response) {
					var oBPInfoItem = oData.results[0];
					oBPInfModelChng.setProperty("/BPInfoSelectedItem", null);
					oBPInfModelChng.setProperty("/BPInfoSelectedItem", oBPInfoItem);
					backendBPData = oBPInfoItem;
					that.getView().getModel("BPInfModelChng").refresh();
				}.bind(this),
				error: function (response) {
					MessageBox.error(response.responseText);
				}.bind(this)
			});
		},
		//End of GO button

		//Start of Upload attachment Data
		getattachments: function (contextName) {
			var n = new sap.ui.model.Filter("MDMNR", sap.ui.model.FilterOperator.EQ, contextName);
			var myFilter = [];
			myFilter.push(n);
			var url = "/sap/opu/odata/sap/YFPSFIFRDD0040_IC_FORM_SRV/";
			var model = new sap.ui.model.odata.ODataModel(url, true);
			var relPath = "/AttachmentSet";
			var that = this;
			model.read(relPath, {
				filters: myFilter,
				success: function (oData, response) {
					that.getView().byId("t_attachmentChng").destroyItems();
					var counter = oData.results.length;
					var i = 0;
					for (i = 0; i < counter; i++) {
						var table1 = that.getView().byId("t_attachmentChng");
						var data1 = new sap.m.ColumnListItem({
							cells: [
								new sap.m.Link({
									text: response.data.results[i].FileName,
									wrapping: Boolean(1),
									press: function (oEvent) {
										var oSource = oEvent.getSource();
										var relPath = "/sap/opu/odata/sap/YFPSFIFRDD0040_IC_FORM_SRV/AttachmentSet(MDMNR='" + contextName + "'" +
											",FileName='" + oSource.getText() + "')/$value";
										window.open(relPath, '_blank');
									}
								}),
								new sap.m.Text({
									text: response.data.results[i].CreatedDate
								}),
								new sap.m.Text({
									text: response.data.results[i].CreatedAt
								}),
								new sap.m.Text({
									text: response.data.results[i].FileSize
								}),
								new sap.m.Text({
									text: response.data.results[i].CreatedByName
								}),
								new sap.m.Text({
									text: response.data.results[i].CreatedBy
								})
							]
						});
						table1.addItem(data1);
					}
				},
				error: function (oError) {
					var response = JSON.parse(oError.responseText);
					MessageBox.show(
						response.error.message.value,
						MessageBox.Icon.ERROR,
						"Error"
					);
					sap.ui.core.BusyIndicator.hide();
				}
			});
		},
		_onDeleteAttachment: function (oEvent) {
			debugger;
			var url = "/sap/opu/odata/sap/YFPSFIFRDD0040_IC_FORM_SRV/";
			var model = new sap.ui.model.odata.ODataModel(url, true);
			var selected_item = this.getView().byId("t_attachmentChng").getSelectedItem();
			if (selected_item !== null) {
				var filename = selected_item.mAggregations.cells[0].mProperties.text;
				if (filename !== "") {
					if (selected_item.mAggregations.cells[5].mProperties.text == sap.ushell.Container.getUser().getId()) {
						// if (selected_item.mAggregations.cells[5].mProperties.text === "MPAPPUSETTI") {
						var that = this;
						model.remove("/AttachmentSet(MDMNR='" + this.form_number + "'" + ",FileName='" + filename + "')", {
							success: function (oData, response) {
								that.getView().byId("t_attachmentChng").removeItem(selected_item);
								MessageBox.alert("Attachment deleted successfully.");
							},
							error: function (oError) {
								var response = JSON.parse(oError.responseText);
								MessageBox.show(
									response.error.message.value,
									MessageBox.Icon.ERROR,
									"Error"
								);
								sap.ui.core.BusyIndicator.hide();
							}
						});
					} else {
						MessageBox.show(
							"You can not delete this Attachment",
							MessageBox.Icon.ERROR,
							"Error"
						);
					}
				}
			} else {
				MessageBox.show("Please select for deletion");
				return false;
			}
		},
		_onhandleValueChange: function (oEvent) {
			debugger;
			file_size = oEvent.mParameters.files[0].size;
			file_size = (file_size / 1024);
		},
		_onhandleUploadPress: function (oEvent) {
			debugger;
			var table = this.getView().byId("t_attachmentChng");
			if (oEvent.mParameters.id.indexOf("b_uploadChng") > -1) {
				var oFileUploader = this.getView().byId("i_fileUploaderChng");
				if (oFileUploader.getValue() == "") {
					MessageBox.alert("Please select the Template.");
					return;
				}
			}
			var url = "/sap/opu/odata/sap/YFPSFIFRDD0040_IC_FORM_SRV/";
			var fileModel = new sap.ui.model.odata.ODataModel(url, true);
			var viewInstance = this.getView();
			if (oFileUploader.getName() == "") {
				return;
			}
			viewInstance.setBusy(true);
			// Set CSRF
			fileModel.refreshSecurityToken();
			var csrf = fileModel.getSecurityToken();
			//Add to header and upload
			oFileUploader.destroyHeaderParameters();
			oFileUploader.setSendXHR(true);
			var headerParma = new sap.ui.unified.FileUploaderParameter();
			var headerParma2 = new sap.ui.unified.FileUploaderParameter();
			var headerParma3 = new sap.ui.unified.FileUploaderParameter();
			headerParma2.setName('slug');
			headerParma2.setValue(oFileUploader.getValue() + '|' + this.form_number + '|' + file_size + '|' + 'ED' + '|' + 'ICR');
			oFileUploader.insertHeaderParameter(headerParma2);
			headerParma3.setName('Content-Type');
			oFileUploader.insertHeaderParameter(headerParma3);
			headerParma.setName('x-csrf-token');
			headerParma.setValue(csrf);
			oFileUploader.addHeaderParameter(headerParma);
			oFileUploader.upload();
		},
		_onhandleUploadComplete: function (oEvent) {
			var that = this;
			var status = oEvent.getParameter("status");
			var response = oEvent.getParameter("response");
			var fileNm = oEvent.getParameter("fileName");
			if (status === 201) {
				var sMsg = "Upload Success";
				MessageToast.show(sMsg);
				oEvent.getSource().setValue("");
				var temp = oEvent.getParameter("response");
				// this.form_number = temp.substr(temp.indexOf("MDMNR=") + 7, 10);
				// this.form_number = temp.substr(temp.indexOf("EFORM_NUM=") + 11, 10);
				e_form_num = this.form_number;
				MessageBox.show(
					"Attachment added successfully and saved under " + e_form_num + ".",
					MessageBox.Icon.SUCCESS,
					"Success"
				);
				that.getView().byId("pageIdChng").setTitle("Change IC 2 step Settled Relationship -" + e_form_num);
			} else {
				sMsg = "Upload Error";
				MessageToast.show(sMsg);
			}

			var viewInstance = this.getView();
			viewInstance.setBusy(false);
			viewInstance.setBusy(false);
			that.getattachments(e_form_num);
		},
		//End of the Upload code
		userValueHelpRequest: function (oEvent) {
			var userName = oEvent.getSource();
			var oValueHelpDialog_RespDiv = new sap.m.SelectDialog({
				title: "Users List",
				items: {
					path: "/C_GHOUserNameVH",
					template: new sap.m.StandardListItem({
						title: "{FullName}",
						description: "{UserID}",
						//active: true
					})
				},
				//Shipping Point can be searched using Search Bar
				search: function (oEvent) {
					var sValue = oEvent.getParameter("value");
					var oFilter = new sap.ui.model.Filter(
						"FullName",
						//	"mc_namefir",
						sap.ui.model.FilterOperator.Contains, sValue
					);
					oEvent.getSource().getBinding("items").filter([oFilter]);
				},

				confirm: function (oEvent) {
					var oSelectedItem = oEvent.getParameter("selectedItem");
					if (oSelectedItem) {
						userName.setValue(oSelectedItem.getTitle());
						userName.data("key", oSelectedItem.getDescription());
						//	createdBy_Id = oSelectedItem.getDescription();
					}
				}
			});
			// }
			var model = this.getOwnerComponent().getModel("ICsrvmodel");
			oValueHelpDialog_RespDiv.setModel(model);
			oValueHelpDialog_RespDiv.open();

		},
		aproverFactory: function (sId, oContext) {
			if (!oContext.getProperty("isInput")) {
				var oTemplate = new sap.m.ColumnListItem({
					cells: [
						new sap.m.Input({
							showValueHelp: true,
							value: "{approverModelChange>APPRNAME}",
							enabled: true,
							valueHelpRequest: [this.userValueHelpRequest, this]
						}).data("key", "{approverModelChange>APPR_ID}"),
						new sap.m.Text({
							text: "{approverModelChange>REVIEWER_TYPE}"
						}),
						new sap.m.Text({
							text: "{approverModelChange>ACT_NAME}"
						}),
						new sap.m.Text({
							text: "{approverModelChange>ACTION}"
						}),
						new sap.m.Text({
							text: "{approverModelChange>ACTION_DATE}"
						}),
						new sap.m.Text({
							text: "{approverModelChange>ACTION_TIME}"
						})
					]
				});

			} else {
				var oTemplate = new sap.m.ColumnListItem({
					cells: [
						new sap.m.Link({
							text: "{approverModelChange>APPRNAME}",
							press: [this._displayEmployees, this],
							wrapping: true
						}),
						new sap.m.Text({
							text: "{approverModelChange>REVIEWER_TYPE}",
						}),
						new sap.m.Text({
							text: "{approverModelChange>ACT_NAME}"
						}),
						new sap.m.Text({
							text: "{approverModelChange>ACTION}"
						}),
						new sap.m.Text({
							text: "{approverModelChange>ACTION_DATE}"
						}),
						new sap.m.Text({
							text: "{approverModelChange>ACTION_TIME}"
						})
					]
				});
			}
			return oTemplate;
		},
		_displayEmployees: function (oEvent) {
			var that = this;
			var sDept = oEvent.getSource().getText();
			if (sDept === "MDMA" || sDept === "GOA" || sDept === "CMI") {
				var oFilterFormType = new sap.ui.model.Filter("FormTyp", sap.ui.model.FilterOperator.EQ, "ICR");
				var oFilterRole = new sap.ui.model.Filter("Role", sap.ui.model.FilterOperator.EQ, sDept);
				var gatewayUrl = "/sap/opu/odata/sap/YFPSFIFRDD0040_IC_FORM_SRV/";
				var oModel = new sap.ui.model.odata.ODataModel(gatewayUrl, true);
				oModel.read("/eFormApproverGrpSet", {
					async: false,
					filters: [oFilterFormType, oFilterRole],
					success: function (oData, oResponse) {

						if (!that._oPopover) {
							that._oPopover = sap.ui.xmlfragment("com.spe.YIC_FORM.Fragments.Approvals", that);
							that.getView().addDependent(that._oPopover);
						}
						var event = oEvent.getSource();
						that._oPopover.openBy(event);
						var oModellist = new sap.ui.model.json.JSONModel();
						oModellist.setData(oData);
						that._oPopover.setModel(oModellist);
					},
					error: function (oError) {
						sap.m.MessageBox.show(oError.message, {
							icon: MessageBox.Icon.ERROR,
							title: "Error"
						});
					}
				});
			} else {
				return false;
			}

		},
		getApproversData: function (contextName, statuss) {
			var n = new sap.ui.model.Filter("MDMNR", sap.ui.model.FilterOperator.EQ, contextName);
			var myFilter = [];
			myFilter.push(n);
			var that = this;
			var oModel = this.getModel("ICsrvmodel");
			oModel.read("/eFormApproverSet", {
				filters: myFilter,
				success: function (oData, response) {
					if (oData.results.length > 0) {
						//	that.getView().byId("approverCR").setVisible(true);
						var aDataSet = [];
						oData.results.forEach(function (item, index) {
							var sStatus;
							if (item.ACTION === "A") {
								sStatus = "Approved";
							} else if (item.ACTION === "R") {
								sStatus = "Rejected";
							} else {
								sStatus = "";
							}
							var datab = item.ACTION_DATE;
							var datbi = item.ACTION_TIME;
							if (datab != "" && datbi != "") {
								var formatDate = datab.match(/[/]/g);
								if (formatDate === null) {
									var date1 = datab.slice(6, 8);
									var month = datab.slice(4, 6);
									var year = datab.slice(0, 4);
									var monthdate = month.concat("/" + date1);
									var fulldate = monthdate.concat("/" + year);
									item.ACTION_DATE = fulldate;
								}
								var formatTime = datbi.match(/[:]/g);
								if (formatTime === null) {
									var hrs = datbi.slice(0, 2);
									var min = datbi.slice(2, 4);
									var sec = datbi.slice(4, 6);
									var hrsmin = hrs.concat(":" + min);
									var fulltime = hrsmin.concat(":" + sec);
									item.ACTION_TIME = fulltime;
								}
							}
							aDataSet.push({
								APPR_ID: item.APPR_ID,
								REVIEWER_TYPE: item.REVIEWER_TYPE,
								APPREMAIL: item.APPREMAIL,
								SEQUENCE: item.SEQUENCE,
								ACTION: sStatus,
								ACTION_DATE: item.ACTION_DATE,
								ACTION_TIME: item.ACTION_TIME,
								ACTION_BY: item.ACTION_BY,
								GRP: item.GRP,
								APPRCONTACT: item.APPRCONTACT,
								APPRDIV: item.APPRDIV,
								APPRNAME: item.APPRNAME,
								isInput: true,
								ACT_NAME: item.ACT_NAME,
								ADDED_BY: item.ADDED_BY
							});
						});
						that.form_number = contextName;
						that.getView().getModel("approverModelChange").setData(null);
						that.getView().getModel("approverModelChange").setData(aDataSet);
					}
				},
				error: function (error) {
					var response = JSON.parse(error.responseText);
					MessageBox.show(
						response.error.message.value,
						MessageBox.Icon.ERROR,
						"Error"
					);
				}
			});
		},
		getdetailsCMI: function (oEvent) {
			var that = this;
			var oFilterFormType = new sap.ui.model.Filter("FormTyp", sap.ui.model.FilterOperator.EQ, "ICR");
			var oFilterRole = new sap.ui.model.Filter("Role", sap.ui.model.FilterOperator.EQ, "CMI");
			var gatewayUrl = "/sap/opu/odata/sap/YFPSFIFRDD0040_IC_FORM_SRV/";
			var oModel = new sap.ui.model.odata.ODataModel(gatewayUrl, true);
			oModel.read("/eFormApproverGrpSet", {
				async: false,
				filters: [oFilterFormType, oFilterRole],
				success: function (oData, oResponse) {
					that.getView().getModel("CMIdetails").setData(oData.results);
				},
				error: function (oError) {
					sap.m.MessageBox.show(oError.message, {
						icon: MessageBox.Icon.ERROR,
						title: "Error"
					});
				}
			});
		},
		getMDMAdetails: function (oEvent) {
			var that = this;
			var oFilterFormType = new sap.ui.model.Filter("FormTyp", sap.ui.model.FilterOperator.EQ, "ICR");
			var oFilterRole = new sap.ui.model.Filter("Role", sap.ui.model.FilterOperator.EQ, "MDMA");
			var gatewayUrl = "/sap/opu/odata/sap/YFPSFIFRDD0040_IC_FORM_SRV/";
			var oModel = new sap.ui.model.odata.ODataModel(gatewayUrl, true);
			oModel.read("/eFormApproverGrpSet", {
				async: false,
				filters: [oFilterFormType, oFilterRole],
				success: function (oData, oResponse) {
					that.getView().getModel("MDMAdetails").setData(oData.results);
				},
				error: function (oError) {
					sap.m.MessageBox.show(oError.message, {
						icon: MessageBox.Icon.ERROR,
						title: "Error"
					});
				}
			});
		},
		getdetailsGoa: function (oEvent) {
			var that = this;
			var oFilterFormType = new sap.ui.model.Filter("FormTyp", sap.ui.model.FilterOperator.EQ, "ICR");
			var oFilterRole = new sap.ui.model.Filter("Role", sap.ui.model.FilterOperator.EQ, "GOA");
			var gatewayUrl = "/sap/opu/odata/sap/YFPSFIFRDD0040_IC_FORM_SRV/";
			var oModel = new sap.ui.model.odata.ODataModel(gatewayUrl, true);
			oModel.read("/eFormApproverGrpSet", {
				async: false,
				filters: [oFilterFormType, oFilterRole],
				success: function (oData, oResponse) {
					that.getView().getModel("GoaDetails").setData(oData.results);
				},
				error: function (oError) {
					sap.m.MessageBox.show(oError.message, {
						icon: MessageBox.Icon.ERROR,
						title: "Error"
					});
				}
			});
		},
		onAddApprovers: function (oEvent) {
			debugger;
			this.getMDMAdetails();
			this.getdetailsGoa();
			this.getdetailsCMI();
			var data = this.getView().getModel("viewDataModel").getData();
			var AData = this.getView().getModel("approverModelChange").getData();
			var actionData = [];
			actionData = AData;
			var appStatusMdma = actionData.slice(-1);

			if (data[0] === undefined) {
				var sStatus = data.Status;
			} else {
				sStatus = data[0].Status;
			}
			if (appStatusMdma[0].ACTION === "Approved") {
				MessageBox.alert("You cannot add Approvers once MDMA has Approved.");
				return false;
			}
			if (AData.length !== undefined && sStatus !== undefined) {
				var ApproverspersonsArray = [];
				for (var i = 0; i < AData.length; i++) {
					var D = {};
					D.APPR_ID = AData[i].APPR_ID;
					ApproverspersonsArray[i] = D;
				}
				var Goalist = [];
				var mdmalist = [];
				var CMIlist = [];
				Goalist = this.getView().getModel("GoaDetails").getData();
				mdmalist = this.getView().getModel("MDMAdetails").getData();
				CMIlist = this.getView().getModel("CMIdetails").getData();
				for (var b = 0; b < Goalist.length; b++) {
					var G = {};
					G.Name = Goalist[b].Name;
					Goalist[b] = G;
				}
				for (var k = 0; k < mdmalist.length; k++) {
					var M = {};
					M.Name = mdmalist[k].Name;
					mdmalist[k] = M;
				}
				var concatall = ApproverspersonsArray.concat(CMIlist, Goalist, mdmalist);
				var LoggedUserid = sap.ushell.Container.getService("UserInfo").getUser().getId();
				var error = false;
				concatall.forEach(function (enteredQr) {
					if (enteredQr.APPR_ID === LoggedUserid) {
						error = true;
					}
					if (enteredQr.Name === LoggedUserid) {
						error = true;
					}
				}.bind(this));
				if (Createdby === LoggedUserid) {
					error = true;
				}
				if (error === false) {
					MessageToast.show("User Not Authorized to add Approvers");
					return false;
				}
			}
			var selectedType = this.byId("apprTypeChng").getValue();
			var positionType = this.byId("ENTRY_SEQUENCEChng").getValue();
			var table = this.getView().byId("tblApproverChng");
			var sItem = table.getSelectedItem();
			// var all_entries = table.getItems();
			var num_of_entries = table.getItems().length;
			var sIndex;
			var selectedItemindex = table.getItems().indexOf(table.getSelectedItem());
			if (num_of_entries === 0 && sItem == undefined) {
				sIndex = 0;
				var oDataSet = [];
				oDataSet.splice(sIndex, 0, {
					APPR_ID: "",
					APPRNAME: "",
					APPREMAIL: "",
					APPRCONTACT: "",
					APPRDIV: "",
					REVIEWER_TYPE: selectedType,
					isInput: false,
					ACTION: "",
					ACT_NAME: "",
					ACTION_DATE: "",
					ACTION_TIME: "",
					MANUAL: "X",
					ADDED_BY: LoggedUserid

				});
				this.getView().getModel("approverModelChange").setData(oDataSet);
			} else if (sItem != undefined && num_of_entries > 0) {
				if (sItem.getAggregation("cells")[0].mProperties.text != undefined) {
					if (sItem.getAggregation("cells")[3].getProperty("text") === "Approved" && this.getView().byId("ENTRY_SEQUENCEChng").getValue() ===
						"Before" && selectedType === "APPROVER") {
						MessageBox.alert("You cannot add before approved status");
						return false;
					}
				}
				if (sItem.getAggregation("cells")[0].mProperties.text != undefined) {
					if (sItem.getAggregation("cells")[1].getProperty("text") === "WATCHER" && this.getView().byId("ENTRY_SEQUENCEChng").getValue() ===
						"Before" && table.indexOfItem(sItem) === 0) {
						MessageBox.alert("You cannot add Approvers/Watchers Before First Line");
						return false;
					}
				}
				if (sItem.getAggregation("cells")[0].mProperties.text != undefined) {
					if (sItem.getAggregation("cells")[0].getProperty("text") === "MDMA" && this.getView().byId("ENTRY_SEQUENCEChng").getValue() ===
						"After" && table.indexOfItem(sItem) != "0") {
						MessageBox.alert("You cannot add Approvers/Watchers after MDMA ");
						return false;
					}
				}
				for (var h = 0; h < AData.length; h++) {
					var NextAction = AData[h].ACTION;
					if (NextAction === "Approved") {
						if (selectedType === "APPROVER" && sItem.getAggregation("cells")[3].getProperty("text") !== "Approved" && selectedItemindex < h) {
							MessageBox.alert("You cannot add Approvers before approved status");
							return false;
						}
					}
				}
				sIndex = table.getItems().indexOf(table.getSelectedItem());
				sIndex = (positionType === "Before") ? Number(sIndex) : Number(sIndex +
					1);

				var oTableModel = this.getView().getModel("approverModelChange");
				var oDataSet = oTableModel.getData();
				oDataSet.splice(sIndex, 0, {
					APPR_ID: "",
					APPRNAME: "",
					APPREMAIL: "",
					APPRCONTACT: "",
					APPRDIV: "",
					REVIEWER_TYPE: selectedType,
					isInput: false,
					ACTION: "",
					ACT_NAME: "",
					ACTION_DATE: "",
					ACTION_TIME: "",
					MANUAL: "X",
					ADDED_BY: LoggedUserid

				});
				this.getView().getModel("approverModelChange").setData(oDataSet);
			} else {
				MessageToast.show("Please select an approver");
			}

		},
		deleteApprovers: function (oEvent) {
			this.getMDMAdetails();
			this.getdetailsGoa();
			this.getdetailsCMI();
			var data = this.getView().getModel("viewDataModel").getData();
			var AData = this.getView().getModel("approverModelChange").getData();
			if (data[0] === undefined) {
				var sStatus = data.Status;
			} else {
				sStatus = data[0].Status;
			}

			if (AData.length !== undefined && sStatus !== undefined) {
				var oParent = oEvent.getSource().getParent();
				var oPar_Parent = oParent.getParent().getId();
				var oTableId = sap.ui.getCore().byId(oPar_Parent);
				var selected_item = oTableId.getSelectedItem();
				var array = this.getView().getModel("approverModelChange").getData();
				var array2 = [];
				var table = this.getView().byId("tblApproverChng");
				var selectedItemindex = table.getItems().indexOf(table.getSelectedItem());
				var sContext = selected_item.getBindingContextPath();
				array2 = array.splice(sContext.substr(1), 1);
				var approver = array2[0].APPR_ID;
				var statusapproved = array2[0].ACTION;
				var AddBy = array2[0].ADDED_BY;
				var LoggedUserid = sap.ushell.Container.getService("UserInfo").getUser().getId();
				if (selectedItemindex === 0) {
					MessageToast.show("You can not delete predefined watcher from Approval List");
					return false;
				}
				if (approver === "MDMA" || approver === "GOA" || approver === "CMI" || statusapproved === "Approved") {
					var selectedIndex1 = sContext.split("/")[1];
					var selectedIndex = parseInt(selectedIndex1);
					array.splice(selectedIndex, 0, array2[0]);
					MessageToast.show("You can not delete predefined approvers or Approved Status from Approval List");
					return false;
				}
				this.getView().getModel("approverModelChange").setData(array);
				var sqNo = array2[0].SEQUENCE;
				var seqNum = sqNo.replace(/\s/g, "");
				var ApproverspersonsArray = [];
				for (var i = 0; i < AData.length; i++) {
					var D = {};
					D.APPR_ID = AData[i].APPR_ID;
					ApproverspersonsArray[i] = D;
				}
				var mdmalist = [];
				var Goalist = [];
				var CMIlist = [];
				Goalist = this.getView().getModel("GoaDetails").getData();
				mdmalist = this.getView().getModel("MDMAdetails").getData();
				CMIlist = this.getView().getModel("CMIdetails").getData();
				for (var b = 0; b < Goalist.length; b++) {
					var G = {};
					G.Name = Goalist[b].Name;
					Goalist[b] = G;
				}
				for (var k = 0; k < mdmalist.length; k++) {
					var M = {};
					M.Name = mdmalist[k].Name;
					mdmalist[k] = M;
				}
				var concatall = ApproverspersonsArray.concat(CMIlist, Goalist, mdmalist); //Here GOA & MDMA users can delete the manual approvers
				var error = false;
				concatall.forEach(function (enteredQr) {
					if (enteredQr.APPR_ID === LoggedUserid) {
						error = true;
					}
					if (enteredQr.Name === LoggedUserid) {
						error = true;
					}
				}.bind(this));
				if (AddBy === LoggedUserid) {
					error = true;
				}
				if (error === false) {
					MessageToast.show("User Not Authorized to Delete Approvers");
					var selectedIndex1 = sContext.split("/")[1];
					var selectedIndex = parseInt(selectedIndex1);
					array.splice(selectedIndex, 0, array2[0]);
					this.getView().getModel("approverModelChange").setData(array);
					return false;
				}
			}
			if (error === true) {
				var that = this;
				var oModel = this.getModel("ICsrvmodel");
				oModel.remove("/eFormApproverSet(MDMNR='" + that.form_number + "'" + ",SEQUENCE='" + seqNum +
					"')", {
						method: "DELETE",
						success: function (oData, response) {
							MessageBox.success("This Selected Approver has been deleted successfully.");
							//  this.getView().getModel("approverModelChange").setData(array);
							that.getApproversData(that.form_number, data.Status);
						}.bind(this),
						error: function (response) {
							var response = JSON.parse(response.responseText);
							MessageBox.show(
								response.error.message.value,
								MessageBox.Icon.ERROR,
								"Error"
							);
							sap.ui.core.BusyIndicator.hide();
						}.bind(this)
					});

			} else {
				var selectedIndex1 = sContext.split("/")[1];
				var selectedIndex = parseInt(selectedIndex1);
				array.splice(selectedIndex, 0, array2[0]);
				MessageToast.show("You are not Authorized to Delete selected Approver.");
				this.getView().getModel("approverModelChange").setData(array);
				return false;
			}
		},
		//Staring of status functionality
		getComments: function (contextName) {
			var n = new sap.ui.model.Filter("EFORM_NUM", sap.ui.model.FilterOperator.EQ, contextName);
			var myFilter = [];
			myFilter.push(n);
			var that = this;
			var oModel = this.getModel("ICsrvmodel");
			oModel.read("/eFormCommentSet", {
				filters: myFilter,
				success: function (oData, response) {
					var aDataSet = [];
					oData.results.forEach(function (item, index) {
						aDataSet.push({
							CreatorId: item.CreatorId,
							CreatorName: item.CreatorName,
							CommentDate: item.CommentDate,
							CommentTime: item.CommentTime,
							comments: item.comments,
							CommentNo: item.CommentNo
						});
					});
					that.form_number = contextName;
					that.getView().getModel("commentModel").setData(aDataSet);
				}
			});
		},
		onCommentPost: function (oEvent) {
			var sComment = oEvent.getParameter("value");
			var oDataSets = {
				EFORM_NUM: this.form_number,
				CreatorId: "",
				CreatorName: "",
				comments: sComment,
				Rtype: "ED"
			};
			var commentModel = this.getView().getModel("commentModel");
			var oDataSet = commentModel.getData();
			if (oDataSet === null || oDataSet === undefined) {
				oDataSet = [];
			}
			var sIndex = oDataSet.length;
			if (sIndex === undefined) {
				oDataSet = [];
			}
			oDataSet.splice(sIndex, 0, {
				FORM_NO: this.Form_Num,
				CreatorId: "",
				CreatorName: "",
				Comments: sComment,
				Rtype: "ED"
			});
			var that = this;
			var oModel = that.getModel("ICsrvmodel");
			oModel.create("/eFormCommentSet", oDataSets, {
				// filters: myFilter,
				success: function (oData, response) {
					sap.ui.core.BusyIndicator.hide();
					form_number = oData.EFORM_NUM;
					that.getComments(form_number);
					MessageBox.show(
						"Comment added successfully and saved under" + "-" + form_number + ".",
						MessageBox.Icon.SUCCESS,
						"Success"
					);
					that.getView().byId("pageIdChng").setTitle("Change IC 2 step Settled Relationship - " + form_number);
					that.getView().byId("feedinputChng").setValue(null);
				}
			});
			this.getView().getModel("commentModel").setData(oDataSet);
		},
		commentFactory: function () {
			var oTemplate = new sap.m.FeedListItem({
				senderActive: false,
				sender: "{commentModel>CreatorName}",
				text: "{commentModel>comments}",
				showIcon: false,
				actions: new sap.m.FeedListItemAction({
					text: "Delete",
					press: [this.onDeleteComment, this],
					icon: "sap-icon://delete",
					key: "delete"
				})
			}).bindProperty("timestamp", {
				parts: [{
					path: 'commentModel>CommentDate'
				}, {
					path: 'commentModel>CommentTime'
				}],
				formatter: function (sDate, sTime) {
					var datechange = sDate;
					var year = datechange.slice(0, 4);
					var mm = datechange.slice(4, 6);
					var dd = datechange.slice(6, 8);
					var append = year + "/" + mm + "/" + dd;
					if ((sDate === "00000000" || sDate === null || sDate === undefined) || (sTime === "00000000" || sTime === null ||
							sTime === undefined)) {
						var timeFormat = DateFormat.getDateTimeInstance({
							pattern: "MM/dd/yyyy hh:mm:ss a"

						});
						return timeFormat.format(new Date());
					} else {
						var timeFormat = DateFormat.getDateTimeInstance({
							pattern: "MM/dd/yyyy hh:mm:ss a"
						});
						var hour = sTime.substring(0, 2);
						var minute = sTime.substring(2, 4);
						var second = sTime.substring(4);
						var sCTime = hour + ":" + minute + ":" + second;
						return timeFormat.format(new Date(append + " " + sCTime));
					}
				}
			});
			return oTemplate;
		},
		onDeleteComment: function (oEvent) {
			var sContext = oEvent.getSource().getParent().getBindingContextPath();
			var array = this.getView().getModel("commentModel").getData();
			if (array[sContext.substr(1)].CreatorId != sap.ushell.Container.getService("UserInfo").getUser().getId()) {
				// if (array[sContext.substr(1)].CreatorId != "MPAPPUSETTI") {
				MessageBox.show(
					"You are not authorized to delete this comment.",
					MessageBox.Icon.ERROR,
					"Error"
				);
			} else {
				var that = this;
				var commentNo = array[sContext.substr(1)].CommentNo;
				var StrComment = commentNo.toString();
				var oModel = this.getModel("ICsrvmodel");
				oModel.remove("/eFormCommentSet(EFORM_NUM='" + that.form_number + "'" + ",CommentNo='" + StrComment +
					"')", {
						success: function (data) {
							var array = that.getView().getModel("commentModel").getData();
							array.splice(sContext.substr(1), 1);
							that.getView().getModel("commentModel").setData(array);
							MessageBox.show(
								"This comment has been deleted successfully.",
								MessageBox.Icon.SUCCESS,
								"Success"
							);
							that.getView().byId("feedinputChng").setValue(null);
						},
						error: function (error) {
							var response = JSON.parse(error.responseText);
							MessageBox.show(
								response.error.message.value,
								MessageBox.Icon.ERROR,
								"Error"
							);
						}
					});
			}
		},
		onVHelpCCompCodeBP: function (oEvent) {
			var that = this;
			var userName = oEvent.getSource();
			var oValueHelpDialog_RespDiv = new sap.m.SelectDialog({
				title: "Select Company code",
				items: {
					path: "/C_CompanyCodeValueHelp",
					template: new sap.m.StandardListItem({
						title: "{CompanyCode}",
						description: "{CompanyCodeName}"
					})
				},
				//Company code can be searched using Search Bar
				search: function (oEvent) {
					var sValue = oEvent.getParameter("value");
					var oFilter = new sap.ui.model.Filter(
						"CompanyCode",
						sap.ui.model.FilterOperator.Contains, sValue
					);
					oEvent.getSource().getBinding("items").filter([oFilter]);
				},
				confirm: function (oEvent) {
					var oSelectedItem = oEvent.getParameter("selectedItem");
					var CountryReg;
					var Region;
					var Timezone;
					var V_CompanyCode;
					var CustCCcode = that.getView().getModel("BPInfModelChng").getProperty('/BPInfoSelectedItem');
					if (CustCCcode !== null) {
						CountryReg = CustCCcode.CountryReg;
						Region = CustCCcode.Region;
						Timezone = CustCCcode.Timezone;
						V_CompanyCode = CustCCcode.V_CompanyCode;
					}
					var comcode2 = oSelectedItem.getTitle();
					if (backendBPData === null || backendBPData === "" || backendBPData === undefined) {
						if (oSelectedItem) {
							var oDataSet = [];
							oDataSet.push({
								C_CompanyCode: oSelectedItem.getTitle(),
								V_CompanyCode: V_CompanyCode,
								CountryReg: CountryReg,
								Region: Region,
								Timezone: Timezone

							});
							that.getView().getModel("BPInfModelChng").setProperty('/BPInfoSelectedItem', oDataSet[0]);
							that.getView().getModel("BPInfModelChng").refresh();
						}
					} else {
						var expandData = backendBPData;
						expandData.C_CompanyCode = oSelectedItem.getTitle();
						that.getView().getModel("BPInfModelChng").refresh();
					}
				}
			});
			// }
			var model = this.getOwnerComponent().getModel("ICsrvmodel");
			oValueHelpDialog_RespDiv.setModel(model);
			oValueHelpDialog_RespDiv.open();
		},
		onVHelpVCompCodeBP: function (oEvent) {
			var that = this;
			var userName = oEvent.getSource();
			var oValueHelpDialog_RespDiv = new sap.m.SelectDialog({
				title: "Select Company code",
				items: {
					path: "/C_CompanyCodeValueHelp",
					template: new sap.m.StandardListItem({
						title: "{CompanyCode}",
						description: "{CompanyCodeName}"
					})
				},
				//Company code can be searched using Search Bar
				search: function (oEvent) {
					var sValue = oEvent.getParameter("value");
					var oFilter = new sap.ui.model.Filter(
						"CompanyCode",
						sap.ui.model.FilterOperator.Contains, sValue
					);
					oEvent.getSource().getBinding("items").filter([oFilter]);
				},
				confirm: function (oEvent) {
					var oSelectedItem = oEvent.getParameter("selectedItem");
					var CountryReg;
					var Region;
					var Timezone;
					var C_CompanyCode;
					var VenCCcode = that.getView().getModel("BPInfModelChng").getProperty('/BPInfoSelectedItem');
					if (VenCCcode !== null) {
						CountryReg = VenCCcode.CountryReg;
						Region = VenCCcode.Region;
						Timezone = VenCCcode.Timezone;
						C_CompanyCode = VenCCcode.C_CompanyCode;
					}
					var comcode2 = oSelectedItem.getTitle();
					if (backendBPData === null || backendBPData === "" || backendBPData === undefined) {
						if (oSelectedItem) {
							var oDataSet = [];
							oDataSet.push({
								V_CompanyCode: oSelectedItem.getTitle(),
								C_CompanyCode: C_CompanyCode,
								CountryReg: CountryReg,
								Region: Region,
								Timezone: Timezone

							});
							that.getView().getModel("BPInfModelChng").setProperty('/BPInfoSelectedItem', oDataSet[0]);
							that.getView().getModel("BPInfModelChng").refresh();
						}
					} else {
						var expandData = backendBPData;
						expandData.V_CompanyCode = oSelectedItem.getTitle();
						that.getView().getModel("BPInfModelChng").refresh();
					}
				}
			});
			// }
			var model = this.getOwnerComponent().getModel("ICsrvmodel");
			oValueHelpDialog_RespDiv.setModel(model);
			oValueHelpDialog_RespDiv.open();
		},
		//End of status Functionality
		// Value help for Cuntry
		onVHelpCountry: function (oEvent) {
			var that = this;
			var userName = oEvent.getSource();
			var oValueHelpDialog_Country = new sap.m.SelectDialog({
				title: "Select Country",
				items: {
					path: "/I_CountryText",
					template: new sap.m.StandardListItem({
						title: "{Country}",
						description: "{CountryName}"
					})
				},
				//Company code can be searched using Search Bar
				search: function (oEvent) {
					var sValue = oEvent.getParameter("value");
					var oFilter = new sap.ui.model.Filter(
						"CountryName",
						sap.ui.model.FilterOperator.Contains, sValue
					);
					oEvent.getSource().getBinding("items").filter([oFilter]);
				},
				confirm: function (oEvent) {
					var oSelectedItem = oEvent.getParameter("selectedItem");
					var V_CompanyCode;
					var C_CompanyCode;
					var abc = that.getView().getModel("BPInfModelChng").getProperty('/BPInfoSelectedItem');
					if (abc !== null) {
						C_CompanyCode = abc.C_CompanyCode;
						V_CompanyCode = abc.V_CompanyCode;
					}
					if (backendBPData === "" || backendBPData === undefined || backendBPData === null) {
						if (oSelectedItem) {
							var oDataSet = [];
							oDataSet.push({
								CountryReg: oSelectedItem.getTitle(),
								Region: "",
								Timezone: "",
								C_CompanyCode: C_CompanyCode,
								V_CompanyCode: V_CompanyCode

							});
							that.getView().getModel("BPInfModelChng").setProperty('/BPInfoSelectedItem', oDataSet[0]);
							that.getView().getModel("BPInfModelChng").refresh();
						}
					} else {
						var expandData = backendBPData;
						expandData.CountryReg = oSelectedItem.getTitle();
						that.getView().getModel("BPInfModelChng").refresh();
					}
				}
			});
			// }
			var model = this.getOwnerComponent().getModel("ICsrvmodel");
			oValueHelpDialog_Country.setModel(model);
			oValueHelpDialog_Country.open();
		},
		//End of value help for country
		// Value help for Region
		onVHelpRegion: function (oEvent) {
			var that = this;
			var CountryRegn
			var C_CompanyCode;
			var V_CompanyCode
			var Country = that.getView().getModel("BPInfModelChng").getProperty('/BPInfoSelectedItem');
			if (Country !== null) {
				CountryRegn = Country.CountryReg;
				C_CompanyCode = Country.C_CompanyCode;
				V_CompanyCode = Country.V_CompanyCode;
			}
			if (Country === null || CountryRegn === undefined) {
				sap.m.MessageBox.error("Please Select the Country/Reg", {
					title: "Error",
					actions: ["OK"],
					onClose: function (sActionClicked) {
						if (sActionClicked === "OK") {
							return false;
						}
					}
				});
			} else {
				var userName = oEvent.getSource();
				var oValueHelpDialog_Region = new sap.m.SelectDialog({
					title: "Select Region",
					items: {
						path: "/I_PrepaymentRegionText",
						template: new sap.m.StandardListItem({
							title: "{Region}",
							description: "{RegionName}"
						})
					},
					//Company code can be searched using Search Bar
					search: function (oEvent) {
						var sValue = oEvent.getParameter("value");
						var oFilter = new sap.ui.model.Filter(
							"RegionName",
							sap.ui.model.FilterOperator.Contains, sValue
						);
						oEvent.getSource().getBinding("items").filter([oFilter]);
					},
					confirm: function (oEvent) {
						var oSelectedItem = oEvent.getParameter("selectedItem");
						if (backendBPData === "" || backendBPData === undefined || backendBPData === null) {
							if (oSelectedItem) {
								var oDataSet = [];
								oDataSet.push({
									CountryReg: CountryRegn,
									Region: oSelectedItem.getDescription(),
									Timezone: "",
									C_CompanyCode: C_CompanyCode,
									V_CompanyCode: V_CompanyCode
								});
								that.getView().getModel("BPInfModelChng").setProperty('/BPInfoSelectedItem', oDataSet[0]);
								that.getView().getModel("BPInfModelChng").refresh();
							}
						} else {
							var expandData = backendBPData;
							expandData.Region = oSelectedItem.getDescription();
							that.getView().getModel("BPInfModelChng").refresh();
						}
					}
				});
				// }
				var model = this.getOwnerComponent().getModel("ICsrvmodel");
				oValueHelpDialog_Region.setModel(model);
				oValueHelpDialog_Region.open();
			}
		},
		//End of value help for Region
		// Value help for TimeZone
		onVHelpTimeZone: function (oEvent) {
			var that = this;
			var CountryRegn;
			var Region;
			var C_CompanyCode;
			var V_CompanyCode;
			var onVHelpTimeZoneModel = that.getView().getModel("BPInfModelChng").getProperty('/BPInfoSelectedItem');
			if (onVHelpTimeZoneModel !== null) {
				CountryRegn = onVHelpTimeZoneModel.CountryReg;
				Region = onVHelpTimeZoneModel.Region;
				C_CompanyCode = onVHelpTimeZoneModel.C_CompanyCode;
				V_CompanyCode = onVHelpTimeZoneModel.V_CompanyCode;
			}
			if (onVHelpTimeZoneModel === null || CountryRegn === undefined || CountryRegn === "") {
				sap.m.MessageBox.error("Please Select Country/Reg ", {
					title: "Error",
					actions: ["OK"],
					onClose: function (sActionClicked) {
						if (sActionClicked === "OK") {
							return false;
						}
					}
				});
			} else if (onVHelpTimeZoneModel === null || Region === undefined || Region === "") {
				sap.m.MessageBox.error("Please Select  Region", {
					title: "Error",
					actions: ["OK"],
					onClose: function (sActionClicked) {
						if (sActionClicked === "OK") {
							return false;
						}
					}
				});
			} else {
				var userName = oEvent.getSource();
				var oValueHelpDialog_Region = new sap.m.SelectDialog({
					title: "Select TimeZone",
					items: {
						path: "/I_TimeZoneText",
						template: new sap.m.StandardListItem({
							title: "{TimeZoneID}",
							description: "{TimeZoneText}"
						})
					},
					//Company code can be searched using Search Bar
					search: function (oEvent) {
						var sValue = oEvent.getParameter("value");
						var oFilter = new sap.ui.model.Filter(
							"TimeZoneID",
							sap.ui.model.FilterOperator.Contains, sValue
						);
						oEvent.getSource().getBinding("items").filter([oFilter]);
					},
					confirm: function (oEvent) {
						var oSelectedItem = oEvent.getParameter("selectedItem");

						if ((backendBPData === "" || backendBPData === undefined || backendBPData === null)) {
							if (oSelectedItem) {
								var oDataSet = [];
								oDataSet.push({
									CountryReg: CountryRegn,
									Region: Region,
									Timezone: oSelectedItem.getTitle(),
									C_CompanyCode: C_CompanyCode,
									V_CompanyCode: V_CompanyCode
								});
								that.getView().getModel("BPInfModelChng").setProperty('/BPInfoSelectedItem', oDataSet[0]);
								that.getView().getModel("BPInfModelChng").refresh();
							}
						} else {
							var expandData = backendBPData;
							expandData.Timezone = oSelectedItem.getTitle();
							that.getView().getModel("BPInfModelChng").refresh();
						}
					}
				});
				// }
				var model = this.getOwnerComponent().getModel("ICsrvmodel");
				oValueHelpDialog_Region.setModel(model);
				oValueHelpDialog_Region.open();
			}
		},
		//End of value help for TimeZone
		//on SaveSubmit functionality
		onButtonSaveSubmit: function (oEvent) {
			var that = this;
			// var tableCC = that.getView().byId("tblCompcodeid").getItems();
			var ModelData = that.getView().getModel("InterCopanyModel").getData();
			var ModelBPData = that.getView().getModel("BPInfModelChng").getData();
			var buttonText = oEvent.getSource().getProperty("text");
			var fNameTxt = that.getView().byId("fnameIdChng").getValue();
			var LNameTxt = that.getView().byId("lnameIdChng").getValue();
			var emailTxt = that.getView().byId("emailIdChng").getValue();
			var locTxt = that.getView().byId("locIdChng").getValue();
			var phoneNum = that.getView().byId("phoneIdChng").getValue();
			var BPnumber = that.getView().byId("BPChng").getValue();
			var reasonTxt = that.getView().byId("brsiIdChng").getValue();
			var odataModel = this.getModel("ICsrvmodel");
			var submitDate;
			var data = {};
			// Headers validation check for mandatory fiels
			if (fNameTxt === "" || fNameTxt === null || fNameTxt === undefined) {
				MessageBox.show(
					"First Name is Mandatory fields.",
					MessageBox.Icon.ERROR,
					"Error"
				);
				return false;
			}
			if (LNameTxt === "" || LNameTxt === null || LNameTxt === undefined) {
				MessageBox.show(
					"Last Name is Mandatory fields.",
					MessageBox.Icon.ERROR,
					"Error"
				);
				return false;
			}
			if (emailTxt === "" || emailTxt === null || emailTxt === undefined) {
				MessageBox.show(
					"Email is Mandatory fields.",
					MessageBox.Icon.ERROR,
					"Error"
				);
				return false;
			}
			if (reasonTxt === "" || reasonTxt === null || reasonTxt === undefined) {
				MessageBox.show(
					"Business Reasons and Special Instructions is Mandatory fields.",
					MessageBox.Icon.ERROR,
					"Error"
				);
				return false;
			}
			if (buttonText === "Save") {
				statusSaveSub = "01";
				submitDate = "";
				MessageToast.show("Work in Progress for save");
			}
			if (buttonText === "Submit") {
				MessageToast.show("Work in Progress for Submit");
				statusSaveSub = "02";
				var SubDateFormat = DateFormat.getDateTimeInstance({
					pattern: "yyyyMMdd" + "T" + "hhmmss"
						// pattern: "yyyy-MM-dd" + "T" + "hh:mm:ss"
				});
				submitDate = SubDateFormat.format(new Date());
			} else if (buttonText === "Withdraw") {
				statusSaveSub = "10";
			} else if (buttonText === "Complete") {
				statusSaveSub = "07";
			}
			if (locTxt === null || locTxt === undefined) {
				locTxt = "";
			}
			if (phoneNum === null || phoneNum === undefined) {
				phoneNum = "";
			}
			if (reasonTxt === null || reasonTxt === undefined) {
				reasonTxt = "";
			}

			var prepare = Createdby;
			if (prepare === null || prepare === undefined || prepare === "") {
				prepare = sap.ushell.Container.getService("UserInfo").getUser().getId();
				// prepare ="MPAPPUSETTI";
			}
			var datetimeFormat = DateFormat.getDateTimeInstance({
				// pattern: "yyyyMMdd" + "T" + "hhmmss"
				pattern: "yyyy-MM-dd" + "T" + "hh:mm:ss"
			});
			var submitDateTime = datetimeFormat.format(new Date());
			var stringSubDt = submitDateTime.toString();
			data = {
				"Status": statusSaveSub,
				"EFORM_NUM": this.form_number,
				"Rtype": "ED",
				"FirstName": fNameTxt,
				"Lastname": LNameTxt,
				"Location": locTxt,
				"Tel_Number": phoneNum,
				"eMailAddress": emailTxt,
				"Reason": reasonTxt,
				"CreatedBy": prepare,
				"CreatedDateTime": submitDateTime,
				"SubmittedOn": submitDate,
				"Status_Desc": "",
				"Status_User": "",
				"Status_Username": "",
				"StatusDateTime": "",
				"CreationDate_From": "",
				"CreationDate_To": "",
				"BPNumber": BPnumber
			};
			var oDataSet = [];
			oDataSet.push({
				BusinessPartner: BPnumber
			});

			data.eFormBPInformationSet = [];
			data.eFormBPInformationSet = oDataSet;
			data.eFormBPDetailsSet = [];
			data.eFormBPDetailsSet[0] = ModelBPData.BPInfoSelectedItem;
			var commentModel = this.getView().getModel("commentModel").getData();
			if (commentModel === null || commentModel === undefined) {
				commentModel = "";
			}
			data.eFormCommentSet = [];
			for (var k = 0; k < commentModel.length; k++) {
				var D = {};
				D.EFORM_NUM = this.form_number;
				D.comments = commentModel[k].comments;
				D.CreatorId = commentModel[k].CreatorId;
				D.CreatorName = commentModel[k].CreatorName;
				D.CommentNo = commentModel[k].CommentNo;
				D.CommentDate = "";
				D.CommentTime = "";
				D.Rtype = "SH";
				data.eFormCommentSet[k] = D;
			}

			var approverDataModel = this.getView().getModel("approverModelChange").getData();
			if (approverDataModel === null || approverDataModel === undefined) {
				approverDataModel = "";
			}
			var table = this.getView().byId("tblApproverChng").getItems();
			var i = null;
			for (i = 0; i < table.length; i++) {
				var tempappr;
				if (table[i].getCells()[0].mProperties.value === undefined)
					tempappr = table[i].getCells()[0].getText();
				else
					tempappr = table[i].getCells()[0].getValue();
				if (tempappr === undefined || tempappr === "null" || tempappr === "") {
					MessageBox.alert("Approver field Can not be empty");
					return false;
				}
			}
			data.eFormApproverSet = [];
			for (var i = 0; i < approverDataModel.length; i++) {
				var D = {};
				D.MDMNR = this.form_number;
				D.APPR_ID = approverDataModel[i].APPR_ID;
				D.APPREMAIL = "";
				D.APPRCONTACT = "";
				D.APPRDIV = "";
				D.REVIEWER_TYPE = approverDataModel[i].REVIEWER_TYPE;
				D.SEQUENCE = String(i + 1);
				D.ACTION = approverDataModel[i].ACTION;
				D.ACTION_DATE = approverDataModel[i].ACTION_DATE;
				var datab = D.ACTION_DATE;
				var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
					pattern: "yyyyMMdd"
				});
				var actionDate = dateFormat.format(new Date(datab));
				D.ACTION_DATE = actionDate;
				D.ACTION_TIME = approverDataModel[i].ACTION_TIME;
				D.ACTION_BY = approverDataModel[i].ACTION_BY;
				D.GRP = "";
				D.ACT_NAME = approverDataModel[i].ACT_NAME;
				D.APPRNAME = approverDataModel[i].APPRNAME;

				D.MANUAL = approverDataModel[i].MANUAL;
				data.eFormApproverSet[i] = D;
			}
			var change = "";
			var msg = "";
			if (buttonText === "Save") {
				msg = "Please Verify the details before";
				change = "saving the Inter Company Details.";
			}
			if (buttonText === "Submit") {
				msg = "Please Verify the details before";
				change = "submitting the Inter Company Details.";
			}
			if (buttonText === "Withdraw") {
				msg = "Do you want to withdraw";
				change = "this Inter Company form?";
			}
			if (buttonText === "Complete") {
				msg = "Do you want to complete";
				change = "this Inter Company form?";
			}
			MessageBox.warning(
				msg + " " + change, {
					actions: ["Continue", "Verify"],
					emphasizedAction: "Continue",
					onClose: function (sAction) {
						if (sAction == "Continue") {
							odataModel.create("/eFormHeaderSet", data, {
								async: false,
								success: function (oData, response) {
									that.form_number = oData.EFORM_NUM;
									if (buttonText === "Save") {
										that.getView().byId("pageIdChng").setTitle("Change IC 2 step Settled Relationship - " + that.form_number);
										Createdby = oData.CreatedBy;
										that.getApproversData(that.form_number, oData.Status);
										that.getView().getModel("viewDataModel").setData(oData);
										that.getView().byId("idstatusChng").setValue(oData.Status_Desc);
										MessageBox.show(
											"Inter Company Form " + oData.EFORM_NUM +
											" has been saved successfully. Kindly submit form for Approval.",
											MessageBox.Icon.SUCCESS,
											"Success"
										);
									} else if (buttonText === "Complete") {
										that.getView().byId("pageIdChng").setTitle("Change IC 2 step Settled Relationship - " + that.form_number);
										MessageBox.show(
											"Inter Company Form " + oData.EFORM_NUM + " Complete successfully.", {
												icon: MessageBox.Icon.SUCCESS,
												title: "Success",
												onClose: function (oAction) {
													that.oRouter.navTo("SearchIC", true);
												}
											}
										);
									} else if (buttonText === "Withdraw") {
										that.getView().byId("pageIdChng").setTitle("Change IC 2 step Settled Relationship - " + that.form_number);
										MessageBox.show(
											"Inter Company Form " + oData.EFORM_NUM + " Withdraw successfully.", {
												icon: MessageBox.Icon.SUCCESS,
												title: "Success",
												onClose: function (oAction) {
													that.oRouter.navTo("SearchIC", true);
												}
											}
										);
									} else {
										that.getView().byId("pageIdChng").setTitle("Change IC 2 step Settled Relationship - " + that.form_number);
										MessageBox.show(
											"Inter Company Form " + oData.EFORM_NUM + " submitted successfully.", {
												icon: MessageBox.Icon.SUCCESS,
												title: "Success",
												onClose: function (oAction) {
													that.oRouter.navTo("SearchIC", true);
												}
											}
										);
									}
								},
								error: function (oError) {
									sap.ui.core.BusyIndicator.hide();
									var response = JSON.parse(oError.responseText);
									MessageBox.show(
										response.error.message.value,
										MessageBox.Icon.ERROR,
										"Error"
									);
								}.bind(this)
							});
						} else {
							return false;
						}
					}.bind(this)
				});
		},
		//End of SaveSubmit Functionality
		//Start of update
		onPressUpdateBtn: function (oEvent) {
			var that = this;
			var ModelData = that.getView().getModel("InterCopanyModel").getData();
			var ModelBPData = that.getView().getModel("BPInfModelChng").getData();
			var buttonText = oEvent.getSource().getProperty("text");
			var fNameTxt = that.getView().byId("fnameIdChng").getValue();
			var LNameTxt = that.getView().byId("lnameIdChng").getValue();
			var emailTxt = that.getView().byId("emailIdChng").getValue();
			var locTxt = that.getView().byId("locIdChng").getValue();
			var phoneNum = that.getView().byId("phoneIdChng").getValue();
			var BPnumber = that.getView().byId("BPChng").getValue();
			var reasonTxt = that.getView().byId("brsiIdChng").getValue();
			var changesByU = sap.ushell.Container.getService("UserInfo").getUser().getId();
			var prepareU = Createdby;
			if (prepareU === null || prepareU === undefined || prepareU === "") {
				prepareU = sap.ushell.Container.getService("UserInfo").getUser().getId();
			}
			var odataModel = this.getModel("ICsrvmodel");
			var submitDate;
			var data = {};
			//Business Partner Information Table Line Items validation check for mandatory fiels

			if (locTxt === null || locTxt === undefined) {
				locTxt = "";
			}
			if (phoneNum === null || phoneNum === undefined) {
				phoneNum = "";
			}
			if (reasonTxt === null || reasonTxt === undefined) {
				reasonTxt = "";
			}
			var datetimeFormat = DateFormat.getDateTimeInstance({
				// pattern: "yyyyMMdd" + "T" + "hhmmss"
				pattern: "yyyy-MM-dd" + "T" + "hh:mm:ss"
			});
			var submitDateTime = datetimeFormat.format(new Date());
			var stringSubDt = submitDateTime.toString();
			data = {
				"Status": Formstatus,
				"EFORM_NUM": this.form_number,
				"Rtype": "ED",
				"FirstName": fNameTxt,
				"Lastname": LNameTxt,
				"Location": locTxt,
				"Tel_Number": phoneNum,
				"eMailAddress": emailTxt,
				"Reason": reasonTxt,
				"CreatedDateTime": submitDateTime,
				"SubmittedOn": submitDate,
				"Update": "X",
				"UpdateBy": changesByU,
				"CreatedBy": prepareU,
				"Status_Desc": "",
				"Status_User": "",
				"Status_Username": "",
				"StatusDateTime": "",
				"CreationDate_From": "",
				"CreationDate_To": "",
				"BPNumber": BPnumber
			};
			var oDataSet = [];
			oDataSet.push({
				BusinessPartner: BPnumber
			});
			data.eFormBPInformationSet = [];
			data.eFormBPInformationSet = oDataSet;

			data.eFormBPDetailsSet = [];
			data.eFormBPDetailsSet[0] = ModelBPData.BPInfoSelectedItem;

			var commentModel = this.getView().getModel("commentModel").getData();
			if (commentModel === null || commentModel === undefined) {
				commentModel = "";
			}
			data.eFormCommentSet = [];
			for (var k = 0; k < commentModel.length; k++) {
				var D = {};
				D.EFORM_NUM = this.form_number;
				D.comments = commentModel[k].comments;
				D.CreatorId = commentModel[k].CreatorId;
				D.CreatorName = commentModel[k].CreatorName;
				D.CommentNo = commentModel[k].CommentNo;
				D.CommentDate = "";
				D.CommentTime = "";
				D.Rtype = "SH";
				data.eFormCommentSet[k] = D;
			}

			var approverDataModel = this.getView().getModel("approverModelChange").getData();
			if (approverDataModel === null || approverDataModel === undefined) {
				approverDataModel = "";
			}
			var table = this.getView().byId("tblApproverChng").getItems();
			var i = null;
			for (i = 0; i < table.length; i++) {
				var tempappr;
				if (table[i].getCells()[0].mProperties.value === undefined)
					tempappr = table[i].getCells()[0].getText();
				else
					tempappr = table[i].getCells()[0].getValue();
				if (tempappr === undefined || tempappr === "null" || tempappr === "") {
					MessageBox.alert("Approver field Can not be empty");
					return false;
				}
			}
			data.eFormApproverSet = [];
			for (var i = 0; i < approverDataModel.length; i++) {
				var D = {};
				D.MDMNR = this.form_number;
				D.APPR_ID = approverDataModel[i].APPR_ID;
				D.APPREMAIL = "";
				D.APPRCONTACT = "";
				D.APPRDIV = "";
				D.REVIEWER_TYPE = approverDataModel[i].REVIEWER_TYPE;
				D.SEQUENCE = String(i + 1);
				D.ACTION = approverDataModel[i].ACTION;
				D.ACTION_DATE = approverDataModel[i].ACTION_DATE;
				var datab = D.ACTION_DATE;
				var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
					pattern: "yyyyMMdd"
				});
				var actionDate = dateFormat.format(new Date(datab));
				D.ACTION_DATE = actionDate;
				D.ACTION_TIME = approverDataModel[i].ACTION_TIME;
				D.ACTION_BY = approverDataModel[i].ACTION_BY;
				D.GRP = "";
				D.ACT_NAME = approverDataModel[i].ACT_NAME;
				D.APPRNAME = approverDataModel[i].APPRNAME;

				D.MANUAL = approverDataModel[i].MANUAL;
				data.eFormApproverSet[i] = D;
			}
			sap.ui.core.BusyIndicator.show();
			odataModel.create("/eFormHeaderSet", data, {
				async: false,
				success: function (oData, response) {
					sap.ui.core.BusyIndicator.hide();
					MessageBox.show(
						"Changes saved successfully.",
						MessageBox.Icon.SUCCESS,
						"Success"
					);
					var Apprtable = that.getView().byId("tblApproverChng");
					Apprtable.removeAllItems(true);
					that.getView().getModel("approverModelChange").setData(null);
					that.getView().getModel("approverModelChange").setData(oData.eFormApproverSet.results);
					that.getView().getModel("BPInfModelChng").setProperty('/BPInfoSelectedItem', null);
					that.getView().getModel("BPInfModelChng").setProperty('/BPInfoSelectedItem', oData.eFormBPDetailsSet.results[0]);
					that.getApproversData(that.form_number, data.Status);
				},
				error: function (oError) {
					sap.ui.core.BusyIndicator.hide();
					var ArrayError = [];
					var strResponse = oError.responseText;
					var strErrorDetail = strResponse.substr(strResponse.indexOf("errordetails"));
					var strStatusMsg = strErrorDetail.split(",");
					for (var i = 0; i < strStatusMsg.length; i++) {
						if (strStatusMsg[i].match(/message":"/gi)) {
							var strStatus = strStatusMsg[i].substring(strStatusMsg[i].indexOf("message") + 10);
							ArrayError.push(strStatus);
						}
					}
					ArrayError.pop();
					var errorDisplay = {
						"results": ArrayError
					};
					if (!that._oDialog1) {
						that._oDialog1 = sap.ui.xmlfragment("com.spe.YIC_FORM.Fragments.AutoErrors", that);
						that.getView().addDependent(that._oDialog1);
					}
					that._oDialog1.open();
					var oModellist1 = new sap.ui.model.json.JSONModel();
					oModellist1.setData(errorDisplay);
					that._oDialog1.setModel(oModellist1);

				}.bind(this)
			});

		},
		//End of update

		//Start of Approve functionality
		onPressApproveBtn: function (event) {
			var that = this;
			MessageBox.warning("Please verify field(s) in the Request form.", {
				actions: ["Continue", "Verify"],
				emphasizedAction: "Continue",
				onClose: function (sAction) {
					if (sAction == "Continue") {
						var msg_returned = "";
						var sValue = jQuery.sap.getUriParameters().get("SOURCE");
						var url = "/sap/opu/odata/sap/YFPSFIFRDD0040_IC_FORM_SRV/";
						var oModelData = new sap.ui.model.odata.ODataModel(url, true);
						var relPath = "/eFormValidateApprovalSet?$filter=EFORM_NUM eq '" + this.mdmnr_appr + "' and ACTION eq 'A'";
						var that = this;
						oModelData.read(relPath, null, [], false, function (oData, response) {

							var msg_type = response.data.results[0].MSG_TYPE;
							if (msg_type == "E") {
								msg_returned = response.data.results[0].MSG + ".";
							} else {
								msg_returned = "The eForm has been successfully approved.";
							}
							new Promise(function (fnResolve) {
								sap.m.MessageBox.confirm(msg_returned, {
									title: "Confirm Navigation",
									actions: ["OK"],
									onClose: function (sActionClicked) {
										if (sActionClicked === "OK") {
											that.oRouter.navTo("SearchIC", true);
										}
									}
								});
							});

						});
					} else {

					}
				}.bind(this)
			});
		},
		//End of Approve functionality
		//Start of Reject functionality
		onButtonReject: function () {
			var msg_returned = "";
			var sValue = jQuery.sap.getUriParameters().get("SOURCE");
			MessageBox.warning("Do you really want to Reject?", {
				actions: ["YES", "NO"],
				emphasizedAction: "YES",
				onClose: function (sAction) {
					if (sAction == "YES") {
						var url = "/sap/opu/odata/sap/YFPSFIFRDD0040_IC_FORM_SRV/";
						var oModelData = new sap.ui.model.odata.ODataModel(url, true);
						var relPath = "/eFormValidateApprovalSet?$filter=EFORM_NUM eq '" + this.mdmnr_appr + "' and ACTION eq 'R'";
						var that = this;
						oModelData.read(relPath, null, [], false, function (oData, response) {
							var msg_type = response.data.results[0].MSG_TYPE;
							if (msg_type == "E") {
								// MessageBox.error(response.data.results[0].MSG);
								msg_returned = response.data.results[0].MSG + ".";
							} else {
								msg_returned = "The eForm has been Rejected.";
							}
							new Promise(function (fnResolve) {
								sap.m.MessageBox.confirm(msg_returned, {
									title: "Confirm Navigation",
									actions: ["OK"],
									onClose: function (sActionClicked) {
										if (sActionClicked === "OK") {
											that.oRouter.navTo("SearchIC", true);
										}
									}
								});
							});
						});
					} else {
						MessageToast.show("Rejection cancelled");
					}
				}.bind(this)
			});
			//	this.oRouter.navTo("SearchBankKey", true);
		},
		//End of Reject functionality
		//Start of maintain Functionality
		onPressMaintainBtn: function (oEvent) {
			var that = this;
			// var tableCC = that.getView().byId("tblCompcodeid").getItems();
			var ModelData = that.getView().getModel("InterCopanyModel").getData();
			var ModelBPData = that.getView().getModel("BPInfModelChng").getData();
			var buttonText = oEvent.getSource().getProperty("text");
			var fNameTxt = that.getView().byId("fnameIdChng").getValue();
			var LNameTxt = that.getView().byId("lnameIdChng").getValue();
			var emailTxt = that.getView().byId("emailIdChng").getValue();
			var locTxt = that.getView().byId("locIdChng").getValue();
			var phoneNum = that.getView().byId("phoneIdChng").getValue();
			var BPnumber = that.getView().byId("BPChng").getValue();
			var reasonTxt = that.getView().byId("brsiIdChng").getValue();
			var odataModel = this.getModel("ICsrvmodel");
			var submitDate;
			var data = {};
			// Headers validation check for mandatory fiels
			if (fNameTxt === "" || fNameTxt === null || fNameTxt === undefined) {
				MessageBox.show(
					"First Name is Mandatory fields.",
					MessageBox.Icon.ERROR,
					"Error"
				);
				return false;
			}
			if (LNameTxt === "" || LNameTxt === null || LNameTxt === undefined) {
				MessageBox.show(
					"Last Name is Mandatory fields.",
					MessageBox.Icon.ERROR,
					"Error"
				);
				return false;
			}
			if (emailTxt === "" || emailTxt === null || emailTxt === undefined) {
				MessageBox.show(
					"Email is Mandatory fields.",
					MessageBox.Icon.ERROR,
					"Error"
				);
				return false;
			}
			if (reasonTxt === "" || reasonTxt === null || reasonTxt === undefined) {
				MessageBox.show(
					"Business Reasons and Special Instructions is Mandatory fields.",
					MessageBox.Icon.ERROR,
					"Error"
				);
				return false;
			}

			//Business Partner Information Table Line Items validation check for mandatory fiels

			if (buttonText === "Save") {
				statusSaveSub = "01";
				submitDate = "";
				MessageToast.show("Work in Progress for save");
			}
			if (buttonText === "Submit") {
				MessageToast.show("Work in Progress for Submit");
				statusSaveSub = "02";
				var SubDateFormat = DateFormat.getDateTimeInstance({
					pattern: "yyyyMMdd" + "T" + "hhmmss"
						// pattern: "yyyy-MM-dd" + "T" + "hh:mm:ss"
				});
				submitDate = SubDateFormat.format(new Date());
			} else if (buttonText === "Withdraw") {
				statusSaveSub = "10";
			} else if (buttonText === "Complete") {
				statusSaveSub = "07";
			}
			if (locTxt === null || locTxt === undefined) {
				locTxt = "";
			}
			if (phoneNum === null || phoneNum === undefined) {
				phoneNum = "";
			}
			if (reasonTxt === null || reasonTxt === undefined) {
				reasonTxt = "";
			}

			var prepare = Createdby;
			if (prepare === null || prepare === undefined || prepare === "") {
				prepare = sap.ushell.Container.getService("UserInfo").getUser().getId();
			}
			var datetimeFormat = DateFormat.getDateTimeInstance({
				// pattern: "yyyyMMdd" + "T" + "hhmmss"
				pattern: "yyyy-MM-dd" + "T" + "hh:mm:ss"
			});
			var submitDateTime = datetimeFormat.format(new Date());
			var stringSubDt = submitDateTime.toString();
			data = {
				"Status": "09",
				"EFORM_NUM": this.form_number,
				"Rtype": "ED",
				"FirstName": fNameTxt,
				"Lastname": LNameTxt,
				"Location": locTxt,
				"Tel_Number": phoneNum,
				"eMailAddress": emailTxt,
				"Reason": reasonTxt,
				"CreatedBy": prepare,
				"CreatedDateTime": submitDateTime,
				"SubmittedOn": submitDate,
				"Status_Desc": "",
				"Status_User": "",
				"Status_Username": "",
				"StatusDateTime": "",
				"CreationDate_From": "",
				"CreationDate_To": "",
				"BPNumber": BPnumber
			};
			var oDataSet = [];
			oDataSet.push({
				BusinessPartner: BPnumber
			});

			data.eFormBPInformationSet = [];
			data.eFormBPInformationSet = oDataSet;
			data.eFormBPDetailsSet = [];
			data.eFormBPDetailsSet[0] = ModelBPData.BPInfoSelectedItem;
			var commentModel = this.getView().getModel("commentModel").getData();
			if (commentModel === null || commentModel === undefined) {
				commentModel = "";
			}
			data.eFormCommentSet = [];
			for (var k = 0; k < commentModel.length; k++) {
				var D = {};
				D.EFORM_NUM = this.form_number;
				D.comments = commentModel[k].comments;
				D.CreatorId = commentModel[k].CreatorId;
				D.CreatorName = commentModel[k].CreatorName;
				D.CommentNo = commentModel[k].CommentNo;
				D.CommentDate = "";
				D.CommentTime = "";
				D.Rtype = "SH";
				data.eFormCommentSet[k] = D;
			}

			var approverDataModel = this.getView().getModel("approverModelChange").getData();
			if (approverDataModel === null || approverDataModel === undefined) {
				approverDataModel = "";
			}
			var table = this.getView().byId("tblApproverChng").getItems();
			var i = null;
			for (i = 0; i < table.length; i++) {
				var tempappr;
				if (table[i].getCells()[0].mProperties.value === undefined)
					tempappr = table[i].getCells()[0].getText();
				else
					tempappr = table[i].getCells()[0].getValue();
				if (tempappr === undefined || tempappr === "null" || tempappr === "") {
					MessageBox.alert("Approver field Can not be empty");
					return false;
				}
			}
			data.eFormApproverSet = [];
			for (var i = 0; i < approverDataModel.length; i++) {
				var D = {};
				D.MDMNR = this.form_number;
				D.APPR_ID = approverDataModel[i].APPR_ID;
				D.APPREMAIL = "";
				D.APPRCONTACT = "";
				D.APPRDIV = "";
				D.REVIEWER_TYPE = approverDataModel[i].REVIEWER_TYPE;
				D.SEQUENCE = String(i + 1);
				D.ACTION = approverDataModel[i].ACTION;
				D.ACTION_DATE = approverDataModel[i].ACTION_DATE;
				var datab = D.ACTION_DATE;
				var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
					pattern: "yyyyMMdd"
				});
				var actionDate = dateFormat.format(new Date(datab));
				D.ACTION_DATE = actionDate;
				D.ACTION_TIME = approverDataModel[i].ACTION_TIME;
				D.ACTION_BY = approverDataModel[i].ACTION_BY;
				D.GRP = "";
				D.ACT_NAME = approverDataModel[i].ACT_NAME;
				D.APPRNAME = approverDataModel[i].APPRNAME;

				D.MANUAL = approverDataModel[i].MANUAL;
				data.eFormApproverSet[i] = D;
			}
			odataModel.create("/eFormHeaderSet", data, {
				async: false,
				success: function (oData, response) {
					sap.ui.core.BusyIndicator.hide();
					var msg_type = oData.MsgID;

					if (msg_type == "E") {
						MessageBox.show(
							"Error",
							MessageBox.Icon.ERROR,
							"Error"
						);
					}
					if (msg_type == "W") {
						sap.m.MessageBox.warning("Warning", {
							title: "Warning",
							actions: ["OK"],
							onClose: function (sActionClicked) {
								if (sActionClicked === "OK") {
									that.oRouter.navTo("SearchIC", true);
								}
							}
						});
					}
					if (msg_type == "S") {
						sap.m.MessageBox.success("Inter Company has been maintained successfully", {
							title: "Success",
							actions: ["OK"],
							onClose: function (sActionClicked) {
								if (sActionClicked === "OK") {
									that.oRouter.navTo("SearchIC", true);
								}
							}
						});
					}
				},
				error: function (oError) {
					debugger;
					var ArrayError = [];
					var strResponse = oError.responseText;
					var strErrorDetail = strResponse.substr(strResponse.indexOf("errordetails"));
					var strStatusMsg = strErrorDetail.split(",");
					for (var i = 0; i < strStatusMsg.length; i++) {
						if (strStatusMsg[i].match(/message":"/gi)) {
							var strStatus = strStatusMsg[i].substring(strStatusMsg[i].indexOf("message") + 10);
							ArrayError.push(strStatus);
						}
					}
					ArrayError.pop();
					var errorDisplay = {
						"results": ArrayError
					};
					if (!that._oDialog1) {
						that._oDialog1 = sap.ui.xmlfragment("com.spe.YIC_FORM.Fragments.AutoErrors", that);
						that.getView().addDependent(that._oDialog1);
					}
					that._oDialog1.open();
					var oModellist1 = new sap.ui.model.json.JSONModel();
					oModellist1.setData(errorDisplay);
					that._oDialog1.setModel(oModellist1);

				}.bind(this)
			});
		},
		onCloseDialog1: function () {
			var that = this;
			this._oDialog1.close();
		}
	});

});