sap.ui.define([
	"./BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageBox",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"../model/formatter"
], function (BaseController, JSONModel, MessageBox, Filter, FilterOperator, formatter) {
	"use strict";
	var data = [];
	var createdBy_Id = "";
	return BaseController.extend("com.spe.YIC_FORM.controller.SearchIC", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.spe.YIC_FORM.view.SearchIC
		 */
		onInit: function () {
			this._serverModel = this.getModel("ICsrvmodel");
			var searchModel = new JSONModel();
			this.getView().setModel(searchModel, "searchModel");

			this.oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this.oRouter.attachRouteMatched(this._onObjectMatched, this);
		},
		_onObjectMatched: function (oEvent) {
			if (oEvent.getParameters().name === "SearchIC" || oEvent.getParameters().name === "CreateICValue" || oEvent.getParameters()
				.name === "ChangeICValue") {
				this.getView().getModel("searchModel").setData(data);
				// this.search_records();
			} else {
				data = [];
				this.getView().byId("fromDate").setValue("");
				this.getView().byId("toDate").setValue("");
				this.getView().byId("created_by").setValue("");
				this.getView().byId("form_num").setValue("");
				this.getView().byId("form_status").setSelectedKey("");
				this.getView().byId("request_type").setSelectedKey("");
				this.getView().getModel("searchModel").setData(data);
			}
			this.clear_fields();
		},
		search_records: function () {
			var myfilter = [];
			var fromDate1 = this.getView().byId("fromDate").getValue();
			var toDate1 = this.getView().byId("toDate").getValue();
			var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: "yyyyMMdd"
			});
			var fromDate = dateFormat.format(new Date(fromDate1));
			var toDate = dateFormat.format(new Date(toDate1));
			if (this.getView().byId("created_by").getCustomData()[0] != undefined && this.getView().byId("created_by").getCustomData()[0] !==
				null) {
				var created_by = this.getView().byId("created_by").getCustomData()[0].getValue();
			} else {
				var created_by = createdBy_Id;
			}

			var form_num = this.getView().byId("form_num").getValue();
			var form_status = "";
			if (this.getView().byId("form_status").getSelectedItem() !== null) {
				form_status = this.getView().byId("form_status").getSelectedKey();
			}
			var request_type = "";
			if (this.getView().byId("request_type").getSelectedItem() !== null) {
				request_type = this.getView().byId("request_type").getSelectedKey();
			}
			var oFilter1 = new sap.ui.model.Filter("CreationDate_From", sap.ui.model.FilterOperator.EQ, fromDate);
			var oFilter1a = new sap.ui.model.Filter("CreationDate_To", sap.ui.model.FilterOperator.EQ, toDate);
			var oFilter2 = new sap.ui.model.Filter("CreatedBy", sap.ui.model.FilterOperator.EQ, created_by);
			var oFilter3 = new sap.ui.model.Filter("EFORM_NUM", sap.ui.model.FilterOperator.Contains, form_num);
			var oFilter6 = new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, form_status);
			var oFilter7 = new sap.ui.model.Filter("Rtype", sap.ui.model.FilterOperator.EQ, request_type);
			if (oFilter1.oValue1 != "") {
				myfilter.push(oFilter1);
			}
			if (oFilter1a.oValue1 != "") {
				myfilter.push(oFilter1a);
			}
			if (oFilter2.oValue1 != "" && oFilter2.oValue1 != undefined) {
				myfilter.push(oFilter2);
			}
			if (oFilter3.oValue1 != "") {
				myfilter.push(oFilter3);
			}
			if (oFilter6.oValue1 != "") {
				myfilter.push(oFilter6);
			}
			if (oFilter7.oValue1 != "") {
				myfilter.push(oFilter7);
			}
			sap.ui.core.BusyIndicator.show();
			var that = this;
			var url = "/eFormHeaderSet";
			this._serverModel.read(url, {
				filters: myfilter,
				success: function (oData) {
					sap.ui.core.BusyIndicator.hide();
					data = {
						searchData: oData.results,
						totalCount: oData.results.length
					};
					that.getView().getModel("searchModel").setData(data);
				},
				error: function (error) {
					sap.ui.core.BusyIndicator.hide();
					var response = JSON.parse(error.responseText);
					MessageBox.show(
						response.error.message.value,
						MessageBox.Icon.ERROR,
						"Error"
					);
				}
			});
			this.getView().byId("created_by").destroyCustomData();
			fromDate = "";
			toDate = "";
		},
		onPress: function (oEvent) {
			var oItem = oEvent.getSource();
			var oTable = oItem.getBindingContext("searchModel");
			var Row = oTable.oModel.getProperty(oTable.sPath);
			if (Row.Rtype === "CR") {
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("CreateICValue", {
					context: Row.EFORM_NUM
				});
			}
			if (Row.Rtype === "ED") {
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("ChangeICValue", {
					context: Row.EFORM_NUM
				});
			}
		},
		clear_fields: function () {
			this.getView().byId("fromDate").setValue("");
			this.getView().byId("toDate").setValue("");
			this.getView().byId("created_by").setValue("");
			this.getView().byId("form_num").setValue("");
			this.getView().byId("form_status").setSelectedKey("");
			this.getView().byId("request_type").setSelectedKey("");
			this.getView().getModel("searchModel").setData(null);
			createdBy_Id = "";
		},
		userValueHelpRequest: function (oEvent) {
			var userName = oEvent.getSource();
			var oValueHelpDialog_RespDiv = new sap.m.SelectDialog({
				title: "Users List",
				items: {
					path: "/C_GHOUserNameVH",
					template: new sap.m.StandardListItem({
						title: "{FullName}",
						description: "{UserID}",
						//active: true
					})
				},
				//Shipping Point can be searched using Search Bar
				search: function (oEvent) {
					var sValue = oEvent.getParameter("value");
					var oFilter = new sap.ui.model.Filter(
						"FullName",
						//	"mc_namefir",
						sap.ui.model.FilterOperator.Contains, sValue
					);
					oEvent.getSource().getBinding("items").filter([oFilter]);
				},

				confirm: function (oEvent) {
					var oSelectedItem = oEvent.getParameter("selectedItem");
					if (oSelectedItem) {
						userName.setValue(oSelectedItem.getTitle());
						userName.data("key", oSelectedItem.getDescription());
						createdBy_Id = oSelectedItem.getDescription();
					}
				}
			});
			// }
			var model = this.getOwnerComponent().getModel("ICsrvmodel");
			oValueHelpDialog_RespDiv.setModel(model);
			oValueHelpDialog_RespDiv.open();

		},
		report_records: function (oEvent) {
			debugger;
			var url = "/sap/opu/odata/sap/YFPSFIFRDD0040_IC_FORM_SRV/";
			var oModelData = new sap.ui.model.odata.ODataModel(url, true);
			this.getView().setModel(oModelData);
			var myfilter = [];
			var fromDate1 = this.getView().byId("fromDate").getValue();
			var toDate1 = this.getView().byId("toDate").getValue();
			var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: "yyyyMMdd"
			});
			var fromDate = dateFormat.format(new Date(fromDate1));
			var toDate = dateFormat.format(new Date(toDate1));
			if (this.getView().byId("created_by").getCustomData()[0] != undefined && this.getView().byId("created_by").getCustomData()[0] !==
				null) {
				var created_by = this.getView().byId("created_by").getCustomData()[0].getValue();
			} else {
				var created_by = createdBy_Id;
			}

			var form_num = this.getView().byId("form_num").getValue();
			var form_status = "";
			if (this.getView().byId("form_status").getSelectedItem() !== null) {
				form_status = this.getView().byId("form_status").getSelectedKey();
			}
			var request_type = "";
			if (this.getView().byId("request_type").getSelectedItem() !== null) {
				request_type = this.getView().byId("request_type").getSelectedKey();
			}
			// var oFilter1 = new sap.ui.model.Filter("CreationDate_From", sap.ui.model.FilterOperator.EQ, fromDate);
			// var oFilter1a = new sap.ui.model.Filter("CreationDate_To", sap.ui.model.FilterOperator.EQ, toDate);
			// var oFilter2 = new sap.ui.model.Filter("CreatedBy", sap.ui.model.FilterOperator.EQ, created_by);
			// var oFilter3 = new sap.ui.model.Filter("EFORM_NUM", sap.ui.model.FilterOperator.Contains, form_num);
			// var oFilter6 = new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, form_status);
			// var oFilter7 = new sap.ui.model.Filter("Rtype", sap.ui.model.FilterOperator.EQ, request_type);
			// if (oFilter1.oValue1 != "") {
			// 	myfilter.push(oFilter1);
			// }
			// if (oFilter1a.oValue1 != "") {
			// 	myfilter.push(oFilter1a);
			// }
			// if (oFilter2.oValue1 != "" && oFilter2.oValue1 != undefined) {
			// 	myfilter.push(oFilter2);
			// }
			// if (oFilter3.oValue1 != "") {
			// 	myfilter.push(oFilter3);
			// }
			// if (oFilter6.oValue1 != "") {
			// 	myfilter.push(oFilter6);
			// }
			// if (oFilter7.oValue1 != "") {
			// 	myfilter.push(oFilter7);
			// }
			var that = this;
			/*var relPath = "/sap/opu/odata/sap/YFPSFIFRDD0040_IC_FORM_SRV/eFormHeaderSet?$filter=EFORM_NUM eq '" + form_num +
				"'and CreationDate_From eq '" + fromDate +
				"'and CreationDate_To eq '" + toDate +
				"'and CreatedBy eq '" + created_by +
				"'and Status eq '" + form_status +
				"'and Rtype eq '" + request_type +
				"'&$format=xlsx";*/
			var relPath = "/sap/opu/odata/sap/YFPSFIFRDD0040_IC_FORM_SRV/eFormHeaderSet?$format=xlsx";
			var encodeUrl = encodeURI(relPath);
			sap.m.URLHelper.redirect(encodeUrl, true);
		},

	});

});