/*global QUnit*/

sap.ui.define([
	"com/spe/YIC_FORM/controller/HomeToolPage.controller"
], function (Controller) {
	"use strict";

	QUnit.module("HomeToolPage Controller");

	QUnit.test("I should test the HomeToolPage controller", function (assert) {
		var oAppController = new Controller();
		oAppController.onInit();
		assert.ok(oAppController);
	});

});