sap.ui.define([
	"com/alcon/mybank/test/unit/controller/Home.controller"
], function () {
	"use strict";
});