sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/Device",
	"sap/ui/core/Fragment",
	"sap/m/MessageBox",
	"sap/m/MessageToast",
	"com/alcon/MyBank/model/models",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"com/alcon/MyBank/util/formatter",
	"sap/ui/core/routing/History"
], function (Controller, Device, Fragment, MessageBox, MessageToast, models, JSONModel, Filter, FilterOperator, formatter, History) {
	"use strict";
	var busyDialog = new sap.m.BusyDialog();
	var globalModel = new JSONModel();
	var countryKey = [];
	return Controller.extend("com.alcon.MyBank.controller.Home", {
		formatter: formatter,
		onInit: function () {

			this.getView().addStyleClass(this.getContentDensityClass());
			jQuery.sap.includeStyleSheet("/sap/bc/ui5_ui5/sap/zmybank/css/style.css");
			var sRootPath = jQuery.sap.getModulePath("zmybank");
			var location = $(location).attr('href');
			this.getView().byId("btnEdit1").setVisible(false);
			this.getView().byId("btnNoTrvl").setVisible(false);
			this.byId("inpIban").setVisible(false);
			this.byId("sknowBank").setVisible(false);
			this.toHideFiled1();
			// this.byId("inpPayeeName1").setVisible(true);
			//this.byId("inpBankCntry").setVisible(false);
			// this.getView().byId("inpBankCtrlKeyf4").setVisible(true);
			// this.getView().byId("inpBankCtrlKey").setVisible(false);
			this._getEmployee();
			this.countryKey = ""; //Make it as empty by default;
			this.showFieldsNoBank();
			this.getFooterText();
		},
		onAfterRendering: function () {

		},
		onForAccount: function () {

			var cntryKey = this.getView().getModel("EmployeeDetails").oData.BANKCOUNTRY2;
			this.showFields(cntryKey, "travelBank", 1);
			this.byId("IdIban").setSelected(false);
			this.byId("idAccount").setSelected(true);
			this.byId("btnGenerate1").setVisible(false);
			this.byId("inLabel").setVisible(false);
			this.byId("inpIban1").setVisible(false);
			this.byId("inpIban").setVisible(false);
			this.byId("sknowBank").setVisible(true);
			this.byId("inpBankCntryR").setVisible(true);
			this.byId("txtBankNameR").setText("");
			this.getView().byId("inpIban3").setVisible(false);
			this.getView().byId("inpIbantx1").setVisible(false);
			this.getView().byId("inpIbantx2").setVisible(false);
			this.getView().byId("inpBankCtrlKey").setVisible(false);
			this.getView().byId("inpIban").setVisible(false);
		},

		onForIBAN: function () {

			this.byId("btnGenerate1").setVisible(true);
			this.byId("inLabel").setVisible(true);
			this.byId("inpIban1").setVisible(true);
			this.byId("IdIban").setSelected(true);
			this.byId("idAccount").setSelected(false);
			this.byId("inpIban").setVisible(true);
			this.byId("btnGenerate1").setVisible(true);
			this.byId("inLabel").setVisible(true);
			this.byId("inpIban").setVisible(false);
			this.byId("sknowBank").setVisible(false);
			this.byId("inpBankCntryR").setVisible(false);
			this.byId("sknowBank").setVisible(false);
			// this.showFieldsNoBank();
			this.getView().byId("inpIban3").setVisible(false);
			this.getView().byId("inpIbantx1").setVisible(false);
			this.getView().byId("inpIbantx2").setVisible(false);
			this.getView().byId("inpBankCtrlKey").setVisible(false);
			// this.toClear();
			// this.toEditabel()
		},
		toHideFiled1: function () {

			this.byId("inpIbantx1").setVisible(false);
			this.byId("inpIbantx2").setVisible(false);
			this.byId("inpIbantx1").setVisible(false);
			this.byId("inpBankAc").setVisible(false);
			this.byId("inpBankKey").setVisible(false);
			this.byId("inpBankRf").setVisible(false);
			this.byId("inpBankCntry").setVisible(false);
			this.byId("inpIbantx2").setVisible(false);
			this.byId("idcurrency").setVisible(false);
			this.byId("inpIban3").setVisible(false);
			this.byId("txtBankName").setVisible(false);
			this.byId("inpBankCtrlKey").setVisible(false);

		},

		toHideFiled: function () {

			this.byId("inpIbantx1").setVisible(false);
			this.byId("inpIbantx2").setVisible(false);
			this.byId("inpIbantx1").setVisible(false);
			this.byId("inpBankAc").setVisible(false);
			this.byId("inpBankKey").setVisible(false);
			this.byId("inpBankRf").setVisible(false);
			this.byId("inpBankCntry").setVisible(true);
			this.byId("inpBankCntry").setEditable(true);
			this.byId("idcurrency").setVisible(false);
			this.byId("txtBankName").setVisible(false);
			this.byId("inpBankCtrlKey").setVisible(false);

		},

		toEditabel: function () {

			this.byId("inpIbantx1").setEditable(true);;
			this.byId("inpIbantx2").setEditable(true);
			// this.byId("inpIbantx1").setVisible(false);
			this.byId("inpBankAc").setEditable(true);
			this.byId("inpBankKey").setEditable(true);
			this.byId("inpBankRf").setEditable(true);
			// this.byId("inpBankCntry").setVisible(true);
			this.byId("inpBankCntry").setEditable(true);
			this.byId("idcurrency").setVisible(true);
			this.byId("txtBankName").setVisible(true);
			this.byId("inpBankCtrlKey").setEditable(true);

		},
		getFooterText: function () {

			var oThat = this;
			var name = "X";
			var oModel = oThat.getOwnerComponent().getModel("Z8C_MYBANK_SRV");
			oModel.read("/linkhelpSet(Data='" + name + "')", {
				success: function (oData, oResponse) {

					oThat.byId("txtHelp1").setText(oData.Value);
					// oThat.byId("txtHelp2").setText(oData.Value);
					oThat.byId("lnkHelp").setHref(oData.Link);

				}
			});
		},

		_getEmployee: function (src) {
			var oThat = this;
			var name = (sap.ushell) ? sap.ushell.Container.getUser().getId() : "KUMARRA2"; //"kumarra2";
			//var name="test_ess_03";
			var dataArray = [];
			//	var sServiceLocation = "/sap/opu/odata/SAP/Z8C_MYBANK_SRV";
			busyDialog.open();
			busyDialog.setText("Loading");
			//	var oModel = new sap.ui.model.odata.ODataModel(sServiceLocation, true);

			var oModel = this.getOwnerComponent().getModel("Z8C_MYBANK_SRV");
			oModel.read("/EmployeeDetailSet(Username='" + name + "')", {
				success: function (oData, oResponse) {
					var oJSONModel = new JSONModel(oData);

					if (oData.Type === "E") {
						busyDialog.close();
						MessageBox.error(oData.Message, {
							actions: [MessageBox.Action.CLOSE],
							onClose: function (oAction) {
								oThat.closeAction();
							}.bind(this)
						});
						return;
					}
					if (oData.ACCOUNTNO0 == "") {
						oThat.byId('tblPayroll').setVisible(false);
						oThat.byId('pyEmptyPage').setVisible(true);
						oThat.byId('pyEmptyPage1').setVisible(true);
						// oThat.getView().byId("inpIban").setVisible(false);
					} else {
						oThat.byId('tblPayroll').setVisible(true);
						oThat.byId('pyEmptyPage').setVisible(false);
						oThat.byId('pyEmptyPage1').setVisible(false);
						// oThat.getView().byId("inpIban").setVisible(false);
					}
					dataArray.push(oData);
					var oJSONModel1 = new JSONModel(dataArray);
					oThat.getView().setModel(oJSONModel, "EmployeeDetails");
					oThat.getView().setModel(oJSONModel1, "PayrollDetail");
					// oThat.getView().byId("inpPayeeName1").setText(oData.name);
					busyDialog.close();

					if (oData.BANKCOUNTRY0 !== "") {
						if (src !== 1) {
							oThat.showFields(oData.BANKCOUNTRY0.toUpperCase(), "payrollBank");
						}
					}
                      if (oData.ACCOUNTNO2 !== "") {
						if (src !== 1) {
							oThat.showFields(oData.BANKCOUNTRY2.toUpperCase(), "travelBank");
						}
						oThat.byId("sfDisplay").setVisible(true);
						oThat.byId("sfEmptyPage").setVisible(false);
						// oThat.getView().byId("sfEdit2").setVisible(true);
					} else if (oData.ACCOUNTNO2 === "") {
						oThat.showFieldsNoBank();
						// oThat.showFieldsNoBank1();
						oThat.byId("sfDisplay").setVisible(false);
						oThat.byId("sfEmptyPage").setVisible(true);
						oThat.byId("btnNoTrvl").setVisible(false);
						oThat.byId("btnCancel").setVisible(false);
						oThat.byId("btnEdit1").setVisible(true);
						oThat.byId("btnEdit").setVisible(false);
						// oThat.getView().byId("sfEdit2").setVisible(true);
					}

				},
				// }
				error: function (oError) {
					var errorMsg = oThat.errorMsgParse(oError);
					MessageBox.error(errorMsg);
					busyDialog.close();
				}
			});

		},
		closeAction: function () {
			/*	var oHistory = History.getInstance();
				var sPreviousHash = oHistory.getPreviousHash();

				if (sPreviousHash !== undefined) {*/
			window.history.go(-1);
			/*	} else {

				}*/
		},

		showFieldsNoBank1: function () {
			var data = {
				"PAYEE": "N",
				"BANK_KEY": "N",
				"BANK_ACC": "N",
				"BANK_CTRL_KEY": "N",
				"IBAN": "N",
				"REF_DETAILS": "N",
				"TAX1": "N",
				"TAX2": "N"
			}
			var oJSONModel = new JSONModel(data);

			this.getView().setModel(oJSONModel, "FieldVisibleModel1");
			this.getView().getModel("FieldVisibleModel1").refresh(true);
		},
		// onSelectionChnages: function () {

		// },
		showFieldsNoBank: function () {
			var data = {
				"PAYEE": "N",
				"BANK_KEY": "N",
				"BANK_ACC": "N",
				"BANK_CTRL_KEY": "N",
				"IBAN": "N",
				"REF_DETAILS": "N",
				"TAX1": "N",
				"TAX2": "N"
			}
			var oJSONModel = new JSONModel(data);

			this.getView().setModel(oJSONModel, "FieldVisibleModel");
			this.getView().getModel("FieldVisibleModel").refresh(true);
		},

		getTodayDate: function () {
			var date = new Date();
			var day = (date.getDate() < 10) ? "0" + date.getDate() : date.getDate();
			var month = ((date.getMonth() + 1) < 10) ? "0" + (date.getMonth() + 1) : date.getMonth() + 1;
			var year = date.getFullYear();
			return day + "-" + month + "-" + year;
		},

		showTaxLabel: function (cntryKey) {

			var oThat = this;
			var oModel = oThat.getOwnerComponent().getModel("Z8C_MYBANK_SRV");
			// "/EmployeeDetailSet(Username='" + name + "')"
			oModel.read("/LabeltextSet(BankCountry='" + cntryKey + "')", {
				success: function (oData, oResponse) {

					oThat.byId("inpIbantx2S").setValue(oData.TEXT);
					oThat.byId("inpIbantx1S").setValue(oData.TEXT);

				},
				error: function (oError) {
						oThat.byId("inpIbantx2S").setValue("");
					oThat.byId("inpIbantx1S").setValue("");
					// var errorMsg = that.errorMsgParse(oError);
					// MessageBox.error(errorMsg);
					// busyDialog.close();
				}
			});
		},

		showFields1: function (cntryKey, bankAcType) {
			var oThat = this;
			var oModel = this.getOwnerComponent().getModel("Z8C_MYBANK_SRC_SRV");
			var oFilter = [];
			oFilter.push(new Filter("ISO_COUNTRY_GRP", FilterOperator.EQ, cntryKey));
			oModel.read("/country_grpSet", {
				filters: oFilter,
				success: function (oData, oResponse) {
					var data = oData.results[0];
					var oJSONModel = new JSONModel(data);
					if (bankAcType === "travelBank") {
						oThat.getView().byId("inpIban").setVisible(true);
						oThat.getView().setModel(oJSONModel, "FieldVisibleModel1");
						oThat.getView().getModel("FieldVisibleModel1").refresh(true);
						var country = oThat.getView().getModel("FieldVisibleModel1").oData.ISO_COUNTRY_GRP;
						// oThat.showTaxLabel(cntryKey);
						oThat.onBankSearchkey(country);
					} else if (bankAcType === "payrollBank") {
						oThat.getView().setModel(oJSONModel, "PayrollVisibleModel");
						oThat.getView().getModel("PayrollVisibleModel").refresh(true);
					}
					busyDialog.close();
				},
				error: function (oError) {
					var errorMsg = that.errorMsgParse(oError);
					MessageBox.error(errorMsg);
					busyDialog.close();
				}
			});

		},
		showFields: function (cntryKey, bankAcType, src) {
			var oThat = this;
			var oModel = this.getOwnerComponent().getModel("Z8C_MYBANK_SRC_SRV");
			var oFilter = [];
			oFilter.push(new Filter("ISO_COUNTRY_GRP", FilterOperator.EQ, cntryKey));
			oModel.read("/country_grpSet", {
				filters: oFilter,
				success: function (oData, oResponse) {
					var data = oData.results[0];
					var oJSONModel = new JSONModel(data);
					if (bankAcType === "travelBank") {
						if (src !== 1) {
							oThat.getView().byId("inpIban").setVisible(true);
						}
						if(src !== "undefined")
						{
						oThat.byId("inpIban").setVisible(false); 
						
						}
						oThat.getView().setModel(oJSONModel, "FieldVisibleModel");
						oThat.getView().getModel("FieldVisibleModel").refresh(true);
						// oThat.showFieldsNoBank1();
						var country = oThat.getView().getModel("FieldVisibleModel").oData.ISO_COUNTRY_GRP;
						oThat.showTaxLabel(cntryKey);
						oThat.onBankSearchkey(country);
					} else if (bankAcType === "payrollBank") {
						oThat.getView().setModel(oJSONModel, "PayrollVisibleModel");
						oThat.getView().getModel("PayrollVisibleModel").refresh(true);
						// oThat.showFieldsNoBank1();
					}
					busyDialog.close();
				},
				error: function (oError) {
					var errorMsg = that.errorMsgParse(oError);
					MessageBox.error(errorMsg);
					busyDialog.close();
				}
			});
		},
		toClear: function () {
			var oThat = this;
			oThat.getView().byId("inpIbantx1R").setValue("");
			oThat.getView().byId("inpIbantx2R").setValue("");
			oThat.getView().byId("inpBankRfR").setValue("");
			oThat.getView().byId("inpBankKeyR").setValue("");
			oThat.getView().byId("inpBankAcR").setValue("");
			oThat.getView().byId("inpIbanR").setValue("");
			oThat.getView().byId("txtBankNameR").setText("");
			oThat.getView().byId("inpBankCtrlKeyR").setValue("");
			this.byId("inpIban1").setValue("");
			// oThat.getView().byId("idbankcur").setText("");
			// oThat.getView().byId("idbankcountry").setText("");
			oThat.showFieldsNoBank1();
		},
		onBankSearchkey: function (data) {

			var oThat = this;
			// var name = this.getView().byId('inpBankCntry1').getSelectedKey().split(' ')[0];
			// var oCore = sap.ui.getCore();
			var oFilter = [];
			if (data !== "") {
				busyDialog.open();
				busyDialog.setText("Fetching");
				// oFilter.push(new Filter("ID_521", FilterOperator.EQ, oCore.byId("id1--in521").getValue()));
				oFilter.push(new Filter("COUNTRY_GRP", FilterOperator.EQ, data));
				// oFilter.push(new Filter("BANKA", FilterOperator.EQ, oCore.byId('id1--inBankName').getValue()));
				// oFilter.push(new Filter("ORT01", FilterOperator.EQ, oCore.byId('id1--inCity').getValue()));
				// oFilter.push(new Filter("BANKL", FilterOperator.EQ, ""));
			} else {
				MessageToast.show("Please enter a value in any of the fields to search Bank key");
				return;
			}
			let oModel = this.getOwnerComponent().getModel("Z8C_MYBANK_SRV");
			oModel.read("/SearchBankControlSet", {
				filters: oFilter,
				success: function (oData, oResponse) {
					var oJSONModel = new JSONModel(oData.results);
					oThat.getView().setModel(oJSONModel, "BankKeyModel1");
					// oThat.showFieldsNoBank1();
					// oThat.getView().byId("inpIban").setVisible(false);
					busyDialog.close();
				},
				error: function (oError) {
					var oJSONModel = new JSONModel({});
					oThat.getView().setModel(oJSONModel, "BankKeyModel1");
					// oThat.showFieldsNoBank1();
					// oThat.getView().byId("inpIban").setVisible(false);
					// var errorMsg = oThat.errorMsgParse(oError);
					// MessageBox.error(errorMsg);
					busyDialog.close();
				}
			});

		},
	
		onSelectionChnage: function () {

			var key = this.getView().byId("inpBankCtrlKeyR").getValue();
			key.length;
			if (key.length !== 2) {
				// this.byId("inpBankCtrlKeyR").setValueState("Error");
				this.byId("inpBankCtrlKeyR").setValue(key.substring(0, 2));
				// this.byId("inpBankCtrlKeyR").setValueStateText("Control Key cannot be more than 2 Char");

			} else {
				this.getView().byId("inpBankCtrlKeyR").setValue(key);
				this.byId("inpBankCtrlKeyR").setValueState("Success");
				this.byId("inpBankCtrlKeyR").setValueStateText("");
			}

		},
		onBankSearch: function () {

			var oThat = this;
			// var name = this.getView().byId('inpBankCntry').getSelectedKey().split(' ')[0];
			var oCore = sap.ui.getCore();
			var oFilter = [];

			if (oCore.byId('id1--inBankCountry').getValue() !== "" && (oCore.byId('id1--inBankName').getValue() !== "" || oCore.byId(
						'id1--inCity').getValue() !==
					"")) {
				busyDialog.open();
				busyDialog.setText("Fetching");
				// oFilter.push(new Filter("ID_521", FilterOperator.EQ, oCore.byId("id1--in521").getValue()));
				oFilter.push(new Filter("BANKS", FilterOperator.EQ, oCore.byId('id1--inBankCountry').getValue()));
				oFilter.push(new Filter("BANKA", FilterOperator.EQ, oCore.byId('id1--inBankName').getValue()));
				oFilter.push(new Filter("ORT01", FilterOperator.EQ, oCore.byId('id1--inCity').getValue()));
				oFilter.push(new Filter("BANKL", FilterOperator.EQ, ""));
			} else {
				MessageToast.show("Please enter a value in any of the fields to search Bank key");
				return;
			}
			let oModel = this.getOwnerComponent().getModel("Z8C_MYBANK_SRC_SRV");
			oModel.read("/Search_helpSet", {
				filters: oFilter,
				success: function (oData, oResponse) {
					var oJSONModel = new JSONModel(oData.results);
					oThat.getView().setModel(oJSONModel, "BankKeyModel");
					busyDialog.close();
				},
				error: function (oError) {
					var errorMsg = oThat.errorMsgParse(oError);
					MessageBox.error(errorMsg);
					busyDialog.close();
				}
			});

		},
		setBtnVisible() {
			sap.ui.getCore().byId("id1--btOK").setVisible(true);
		},
		onValueHelpCancelPress: function () {
			this._oValueHelpDialog.close();
			this._oValueHelpDialog.destroy(true);
			this._oValueHelpDialog = null;
		},
		getCountryKey: function () {
			var cntry;
			if (this.countryKey === "") {
				cntry = this.getView().getModel("EmployeeDetails").getData().BANKCOUNTRY2;
			} else {
				cntry = this.countryKey;
			}
			return cntry;
		},
		onSubmitBankkey: function () {
			var oThat = this;
			busyDialog.open();
			busyDialog.setText("Fetching");
			oThat.byId("inpBankKeyR").setValueState("None");
			var oFilter = [];
			oFilter.push(new Filter("BANKS", FilterOperator.EQ, this.getCountryKey()));
			oFilter.push(new Filter("BANKA", FilterOperator.EQ, ""));
			oFilter.push(new Filter("ORT01", FilterOperator.EQ, ""));

			oFilter.push(new Filter("BANKL", FilterOperator.EQ, this.getView().byId('inpBankKeyR').getValue()));
			let oModel = this.getOwnerComponent().getModel("Z8C_MYBANK_SRC_SRV");
			oModel.read("/Search_helpSet", {
				filters: oFilter,
				success: function (oData, oResponse) {
					if (oData.results.length === 1) {
						oThat.byId("inpBankKeyR").setValueState("None");
						oThat.byId("txtBankNameR").setText(oData.results[0].BANKA + " " + oData.results[0].ORT01);
					} else {
						oThat.byId("inpBankKeyR").setValueState("Error");
					}
					busyDialog.close();
				},
				error: function (oError) {
					oThat.byId("inpBankKeyR").setValueState("Error");
					var errorMsg = oThat.errorMsgParse(oError);
					MessageBox.error(errorMsg);
					busyDialog.close();
				}
			});

		},
		onValueHelpOkPress: function (oEvent) {
			if (sap.ui.getCore().byId("id1--tblBankList").getSelectedItem() == null) {
				MessageBox.error("Please select One User");
			} else {
				var bankKey = sap.ui.getCore().byId("id1--tblBankList").getSelectedItem().mAggregations.cells[0].getText();
				var bankName = sap.ui.getCore().byId("id1--tblBankList").getSelectedItem().mAggregations.cells[1].getText();
				var city = sap.ui.getCore().byId("id1--tblBankList").getSelectedItem().mAggregations.cells[2].getText();
				this.byId("inpBankKeyR").setValueState("None");
				this.byId("inpBankKeyR").setValue(bankKey);
				this.byId("txtBankNameR").setText(bankName + " " + city);

				this._oValueHelpDialog.close();
				this._oValueHelpDialog.destroy(true);
				this._oValueHelpDialog = null;
					// this.toClear();

			}
		},

		onValueHelpOkPressc: function (oEvent) {
			if (sap.ui.getCore().byId("id1--tblBankList1").getSelectedItem() == null) {
				MessageBox.error("Please select One User");
			} else {
				var CTRL_KEY = sap.ui.getCore().byId("id1--tblBankList1").getSelectedItem().mAggregations.cells[0].getText();
				this.byId("inpBankCtrlKey").setValue(CTRL_KEY);

				this._oValueHelpDialog.close();
				this._oValueHelpDialog.destroy(true);
				this._oValueHelpDialog = null;
					// this.toClear();
			}
		},

		_getBankCountry: function () {

			var oThat = this;
			let oModel = this.getOwnerComponent().getModel("Z8C_MYBANK_SRC_SRV");
			/*	var sServiceLocation = "/sap/opu/odata/SAP/Z8C_MYBANK_SRC_SRV";
				var oModel = new sap.ui.model.odata.ODataModel(sServiceLocation, true);*/
			oModel.read("/Search_t001Set", {
				success: function (oData, oResponse) {
					let oJSONModel = new JSONModel();
					oJSONModel.setSizeLimit(oData.results.length);
					oJSONModel.setData(oData.results);
					// this.setModel(oJSONModel, "systemModel");
					oThat.getView().setModel(oJSONModel, "BankCountry");
					busyDialog.close();
				},
				error: function (oError) {
					var errorMsg = that.errorMsgParse(oError);
					MessageBox.error(errorMsg);
					busyDialog.close();
				}
			});

		},

		getContentDensityClass: function () {
			if (!this._sContentDensityClass) {
				if (!Device.support.touch) {
					this._sContentDensityClass = "sapUiSizeCompact";
				} else {
					this._sContentDensityClass = "sapUiSizeCozy";
				}
			}
			return this._sContentDensityClass;
		},

		toEdit: function () {
			var oThat = this;
			oThat.byId("inpIban").setVisible(false);
			oThat.byId("btnGenerate1").setVisible(true);
			oThat.byId("IdIban").setSelected(false);
			oThat.byId("idAccount").setSelected(false);
			oThat.byId("inLabel").setVisible(false);
			oThat.byId("inpIban1").setVisible(false);
			oThat.byId("btnGenerate1").setVisible(false);
			oThat.byId("inpBankCntry").setVisible(false);
			this.byId("btnEdit").setVisible(false);
			this.byId("btnSave").setVisible(true);
			this.byId("btnCancel").setVisible(true);
			this.byId("sfDisplay").setVisible(false);
			this.byId("sfEmptyPage").setVisible(false);
			this.byId("sfEdit").setVisible(true);
			this.byId("sfEdit1").setVisible(true);
			this.byId("inpBankCtrlKey").setVisible(false);
			this.byId("btnNoTrvl").setVisible(false);
			this._getBankCountry();
			this.byId("dtFrmDate").setText(this.getTodayDate());
			// this.showFieldsNoBank();
		},

		OnChange1: function (oEvent) {
			// var path = oEvent.getParameter("selectedItem").getBindingContext("BankCountry1").getPath();
			var data = oEvent.getParameter("selectedItem").mProperties.text.split(" ")[0];
			this.getView().byId("inpBankCtrlKey").setValue(data);
		},

		OnChange: function (oEvent) {
			var path = oEvent.getParameter("selectedItem").getBindingContext("BankCountry").getPath();
			var data = this.getView().getModel("BankCountry").getProperty(path);
			var currency = data.WAERS;
			var country = data.LANDX;
			this.countryKey = data.LAND1;
			this.getView().byId('idcurrencyR').setText(currency);
			this.showFields(this.countryKey.toUpperCase(), "travelBank");
			this.byId("inpIban").setVisible(false);
			this.toClear();
			this.IBAnHide();

		},

		IBAnHide: function () {

			var oThat = this;
			oThat.byId("inpIban").setVisible(false);
			oThat.byId("inpBankCntry").setVisible(false);
			oThat.byId("inpBankKey").setVisible(false);
			oThat.byId("inpBankAc").setVisible(false);
			oThat.byId("inpBankRf").setVisible(false);
			oThat.byId("inpIban3").setVisible(false);
			oThat.byId("inpIbantx1").setVisible(false);
			oThat.byId("inpIbantx2").setVisible(false);
			oThat.byId("idcurrency").setVisible(false);
			oThat.byId("txtBankName").setVisible(false);
			oThat.byId("inpBankCtrlKey").setVisible(false);
		},

		TrvelCancel: function () {
			var oThat = this;
			oThat.byId("sfEmptyPage").setVisible(true);
			oThat.byId("btnEdit").setVisible(false);
			oThat.byId("sknowBank").setVisible(false);
			oThat.byId("btnEdit1").setVisible(true);
			oThat.byId("btnNoTrvl").setVisible(false);
			oThat.byId("btnSave").setVisible(false);
			oThat.byId("btnCancel").setVisible(false);
			oThat.byId("sfDisplay").setVisible(false);
			oThat.byId("btnSave").setVisible(false);
			oThat.byId("sfEdit").setVisible(false);
			oThat.byId("sfEdit1").setVisible(false);
			oThat.byId("inpIban").setVisible(false);
			oThat.byId("btnGenerate1").setVisible(false);
			oThat.byId("inLabel").setVisible(false);
			oThat.byId("inpIban1").setVisible(false);
			oThat.byId("IdIban").setSelected(false);
			oThat.byId("idAccount").setSelected(false);
			// oThat._getEmployee();
		},

		toEdit1: function () {
			var oThat = this;
			oThat.byId("idAccount").setSelected(false);
			oThat.byId("IdIban").setSelected(false);
			oThat.byId("btnGenerate1").setVisible(false);
			oThat.byId("sknowBank").setVisible(false);
			oThat.byId("inLabel").setVisible(false);
			oThat.byId("inpIban1").setVisible(false);
			oThat.byId("btnSave").setVisible(true);
			oThat.byId("btnNoTrvl").setVisible(true);
			oThat.byId("btnEdit1").setVisible(false);
			oThat.byId("sfEdit").setVisible(true);
			oThat.byId("sfEdit1").setVisible(true);
			oThat.byId("sfEmptyPage").setVisible(false);
			oThat.byId("inpIban").setVisible(false);
			oThat.byId("inpBankCntryR").setVisible(false);
			this.byId("dtFrmDate").setText(this.getTodayDate());
			this._getBankCountry();
			this.showFieldsNoBank();

		},

		toCancel: function () {
			this.countryKey = "";
			this.byId("btnEdit").setVisible(true);
			this.byId("inpBankCtrlKeyR").setVisible(true);
			this.byId("sknowBank").setVisible(false);
			this.byId("btnSave").setVisible(false);
			this.byId("btnCancel").setVisible(false);
			this.byId("sfDisplay").setVisible(true);
			this.byId("sfEmptyPage").setVisible(false);
			this.byId("sfEdit").setVisible(false);
			this.byId("sfEdit1").setVisible(false);
			this.getView().byId("inpIban").setVisible(false);
			this.byId("IBANH").setVisible(false);
			this.byId("cntrlkey").setVisible(false);
			this.byId("Tax2H").setVisible(false);
			this.byId("RfH").setVisible(false);
			this.byId("inpIban1").setValue("");
			this.byId("Tax1H").setVisible(false);
			this._getEmployee(2);
			// this.showFieldsNoBank1();
			// this.toHideFiled1();
			this.toClear();

		},

		// for Bank key Serach Help
		onValueHelpKeyCon: function (oEvent) {
			var cntry;
			if (!this._oValueHelpDialog) {
				this._oValueHelpDialog = sap.ui.xmlfragment("id1", "com.alcon.MyBank.view.fragments.ControllKey", this);
			}
			this.getView().addDependent(this._oValueHelpDialog);
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._oValueHelpDialog);
			if (this.getView().getModel("BankKeyModel1") !== undefined) {
				this.getView().getModel("BankKeyModel1").setData({});
				this.getView().getModel("BankKeyModel1").refresh(true);
			}

			sap.ui.getCore().byId("id1--inBankCountry1").setValue(this.getCountryKey());
			this._oValueHelpDialog.open();

		},

		onValueHelpKey: function (oEvent) {
			var cntry;
			if (!this._oValueHelpDialog) {
				this._oValueHelpDialog = sap.ui.xmlfragment("id1", "com.alcon.MyBank.view.fragments.key", this);
			}
			this.getView().addDependent(this._oValueHelpDialog);
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._oValueHelpDialog);
			if (this.getView().getModel("BankKeyModel") !== undefined) {
				this.getView().getModel("BankKeyModel").setData({});
				this.getView().getModel("BankKeyModel").refresh(true);
			}

			sap.ui.getCore().byId("id1--inBankCountry").setValue(this.getCountryKey());
			this._oValueHelpDialog.open();

		},

		onValueHelpSearch: function (oEvent) {
			var sValue = oEvent.getParameter("value");
			var oFilter = new Filter("Name", FilterOperator.Contains, sValue);

			oEvent.getSource().getBinding("items").filter([oFilter]);
		},

		onValueHelpClose: function (oEvent) {
			var oSelectedItem = oEvent.getParameter("selectedItem");
			oEvent.getSource().getBinding("items").filter([]);

			if (!oSelectedItem) {
				return;
			}
			this.byId("productInput").setValue(oSelectedItem.getTitle());
		},
		validateAcNumber: function () {

			var acNo = this.byId("inpBankAcR").getValue();
			this.byId("inpBankAcR").setValueState("None");

			var expression = /^[a-z0-9-]+$/i;
			if (acNo.search(expression) === -1) {
				this.byId("inpBankAc").setValueState("Error");
				return;
			}

		},
		onIBAN: function (oEvent) {
			var oThat = this;
			var Iban_No = oThat.byId("inpBankAcR").getValue();
			if (Iban_No !== "") {
				MessageBox.confirm("Please Verify IBAN Before Saving", {
					actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
					emphasizedAction: MessageBox.Action.OK,
					onClose: function (sAction) {
						if (sAction === "OK") {
							oThat.generateIBan();
						} else if (sAction === "CANCEL") {
							return;
						}

					}
				});
			} else {
				oThat.byId("inpBankAc").setValueState("Error");
				oThat.byId("inpBankAc").setValueStateText("Please Fill the Bank Account Number");
			}

		},
		onIBANK: function (oEvent) {
			var oThat = this;
			var Iban_No = oThat.byId("inpIban1").getValue();
			if (Iban_No !== "") {
				MessageBox.confirm("Please Verify Bank Details Before Saving", {
					actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
					emphasizedAction: MessageBox.Action.OK,
					onClose: function (sAction) {
						if (sAction === "OK") {

							oThat.generateIBanK();

						} else if (sAction === "CANCEL") {
							return;
						}

					}
				});
			} else {
				oThat.byId("inpIban").setValueState("Error");
				oThat.byId("inpIban").setValueStateText("Please Fill the IBAN");
			}
		},
		generateIBan: function () {
			var oThat = this;
			if (this.validationForIban()) {

				var payload = {
					"Bank_Account": this.byId("inpBankAcR").getValue(),
					"Bank_Control_key": this.byId("inpBankCtrlKey").getValue(),
					"Bank_Country": this.getCountryKey(),
					"Bank_Number": this.byId("inpBankKeyR").getValue(),
					"Bank_Key": this.byId("inpBankKeyR").getValue(),
					"Iban_No": "",
					"Error_Msg": ""

				};
				busyDialog.open();
				busyDialog.setText("Generating IBan");
				let oModel = this.getOwnerComponent().getModel("Z8C_MYBANK_SRC_SRV");
				oModel.create("/IBAN_CREATESet", payload, {
					success: function (oData) {
						oThat.byId("inpIbanR").setValueState("None");
						if (oData.Error_Msg !== "") {
							MessageBox.error(oData.Error_Msg);
							//	oThat.byId("inpIban").setValueState("Error");
							//	oThat.byId("inpIban").setValueStateText(oData.Error_Msg);
						} else if (oData.Iban_No !== "") {
							oThat.byId("inpIbanR").setValue(oData.Iban_No);
						}
						busyDialog.close();

					},
					error: function (oError) {
						var errorMsg = oThat.errorMsgParse(oError);
						MessageBox.error(errorMsg);
						busyDialog.close();
					}
				});
			} else {
				MessageToast.show("Fix the highlighted errors");
				return;
			}

		},
		generateIBanK: function () {
			var oThat = this;
			var Iban_No = oThat.byId("inpIban1").getValue();
			busyDialog.open();
			busyDialog.setText("Generating Bank Details");
			var IBANModel = oThat.getOwnerComponent().getModel("Z8C_MYBANK_SRV");
			IBANModel.read("/IBANtoBankAccountSet(IIban='" + Iban_No + "')", {
				success: function (oData, oResponse) {

					if (oData.EMsg == "") {
						var oJSONModel = new JSONModel(oData);
						countryKey = oData;
						var cntryKey = oData.EBankCountry;
						oThat.showFields1(cntryKey, "travelBank");
						//oThat.getView().setModel(oJSONModel, "IBANAccount");
						//oThat.getView().getModel("IBANAccount").refresh(true);
						oThat.byId("inpBankCntry").setText(oData.Name);
						oThat.byId("inpBankCntry").setVisible(true);
						oThat.byId("inLabel").setVisible(true);
						oThat.byId("inpIban1").setVisible(true);
						oThat.byId("btnGenerate1").setVisible(true);
						oThat.byId("inpBankKey").setText(oData.EBankNumber);
						oThat.byId("inpBankKey").setVisible(true);
						oThat.byId("inpBankAc").setText(oData.EBankAccount);
						oThat.byId("inpBankAc").setVisible(true);
						//oThat.byId("inpBankRf").setValue(oData.);
						//oThat.byId("inpBankRf").setVisible(true);
						var IBAN = oThat.byId("inpIban1").getValue();
						// oThat.byId("inpIban3").setText(IBAN);
						oThat.byId("inpIban3").setVisible(false);
						oThat.byId("inpIbanRR").setVisible(false);
						//oThat.byId("inpIbantx1").setText(oData.);
						//oThat.byId("inpIbantx1").setVisible(true);
						//oThat.byId("inpIbantx2").setText(oData.);
						//oThat.byId("inpIbantx2").setVisible(true);
						oThat.byId("idcurrency").setText(oData.waers);
						oThat.byId("idcurrency").setVisible(true);
						oThat.byId("txtBankName").setText(oData.BANK_NAME + " " + oData.CITY);
						oThat.byId("txtBankName").setVisible(true);
						oThat.byId("inpBankCtrlKey").setValue(oData.EBankControlKey);
						oThat.byId("inpBankCtrlKey").setVisible(true);
					} else {
						MessageBox.error(oData.EMsg);
						busyDialog.close();
					}
					busyDialog.close();
				},
				error: function (oError) {
					var errorMsg = oThat.errorMsgParse(oError);
					MessageBox.error(errorMsg);
					oThat.byId("inpIban").setValueState("Error");
					oThat.byId("inpIban").setValueStateText("Please check IBAN");
					busyDialog.close();
				}
			});
			// } else
			// {
			// this.byId("inpIban").setValueState("Error");
			// this.byId("inpIban").setValueStateText("Please Fill the IBAN");
			// }
		},
		ControllKeyf4: function (country) {

			var oThat = this;
			if (country.includes("JAPAN")) {
				oThat.byId("inpBankCtrlKeyf4").setVisible(true);
				oThat.byId("inpBankCtrlKey").setVisible(false);
			} else if (country.includes("INDIA")) {
				oThat.byId("inpBankCtrlKeyf4").setVisible(true);
				oThat.byId("inpBankCtrlKey").setVisible(false);
			} else if (country.includes("USA")) {
				oThat.byId("inpBankCtrlKeyf4").setVisible(true);
				oThat.byId("inpBankCtrlKey").setVisible(false);
			} else if (country.includes("SOUTH AFRICA")) {
				oThat.byId("inpBankCtrlKeyf4").setVisible(true);
				oThat.byId("inpBankCtrlKey").setVisible(false);
			} else if (country.includes("MEXICO")) {
				oThat.byId("inpBankCtrlKeyf4").setVisible(true);
				oThat.byId("inpBankCtrlKey").setVisible(false);
			} else if (country.includes("Venezuela")) {
				oThat.byId("inpBankCtrlKeyf4").setVisible(true);
				oThat.byId("inpBankCtrlKey").setVisible(false);
			} else if (country.includes("ARgentina")) {
				oThat.byId("inpBankCtrlKeyf4").setVisible(true);
				oThat.byId("inpBankCtrlKey").setVisible(false);
			} else {
				oThat.byId("inpBankCtrlKeyf4").setVisible(false);
				// oThat.byId("inpBankCtrlKey").setVisible(true);
			}
		},

		validationForIban: function () {
			if (this.countryKey === "" && this.getView().getModel("EmployeeDetails").getData().BANKCOUNTRY2 == "") {
				this.byId("inpBankCntryR").setValueState("Error");
				return false;
			} else if (this.byId("inpBankKeyR").getVisible() === true && (this.byId("inpBankKeyR").getValue() === "" || this.byId("inpBankKeyR")
					.getValueState() ===
					"Error")) {
				this.byId("inpBankKey").setValueState("Error");
				return false;
			} else if (this.byId("inpBankAcR").getValue() === "" || this.byId("inpBankAcR").getValueState() === "Error") {
				this.byId("inpBankAcR").setValueState("Error");
				return false;
			} else {
				return true;
			}
		},
		onChangeAcNo: function () {
			this.byId("inpBankAcR").setValueState("None");
			this.byId("inpIbanR").setValueStateText("");
			this.byId("inpBankAcR").setValueStateText("");
			this.byId("inpBankKeyR").setValueStateText("");
			this.byId("inpIbantx1R").setValueStateText("");
			this.byId("inpIbantx2R").setValueStateText("");
			this.byId("inpBankCtrlKeyR").setValueStateText("");
			this.byId("inpBankRfR").setValueStateText("");
		},
		onChangeIBan: function () {
			this.byId("inpIban1").setValueState("None");
		},
		onChangeOfTax1: function () {
			this.byId("inpIbantx1").setValueState("None");
		},
		onChangeOfTax1: function () {
			this.byId("inpIbantx2").setValueState("None");
		},
		onChangeOfCtrlKey: function () {
			this.byId("inpBankCtrlKey").setValueState("None");
			this.byId("inpIbanR").setValueStateText("");
			this.byId("inpBankAcR").setValueStateText("");
			this.byId("inpBankKeyR").setValueStateText("");
			this.byId("inpIbantx1R").setValueStateText("");
			this.byId("inpIbantx2R").setValueStateText("");   
		    this.byId("inpBankRfR").setValueStateText(""); 
		},
		toShowError: function (oData) {
			var msg = oData.Message + oData.EMsg + oData.EMsg1 + oData.EMsg2 + oData.EMsg3;
			if (msg.includes("IBAN")) {
				this.byId("inpIbanR").setValueState("Error");
				this.byId("inpIbanR").setValueStateText(msg);
			} else if (msg.includes("Bank Acct")) {
				this.byId("inpBankAcR").setValueState("Error");
				this.byId("inpBankAcR").setValueStateText(msg);
			} else if (msg.includes("Bank key")) {
				this.byId("inpBankKeyR").setValueState("Error");
				this.byId("inpBankKeyR").setValueStateText(msg);
			} else if (msg.includes("Tax code 1")) {
				this.byId("inpIbantx1R").setValueState("Error");
				this.byId("inpIbantx1R").setValueStateText(msg);
			} else if (msg.includes("Tax code 2")) {
				this.byId("inpIbantx2R").setValueState("Error");
				this.byId("inpIbantx2R").setValueStateText(msg);
			} else if (msg.includes("Bank control key")) {
				this.byId("inpBankCtrlKeyR").setValueState("Error");
				this.byId("inpBankCtrlKeyR").setValueStateText(msg);
			} else {
				MessageBox.error(msg);
			}

		},
		toSave: function () {
			//validation
			var oThat = this;
			if (oThat.getView().byId("IdIban").getSelected()) {
				var cntry;

				var payload = {
					"Number": this.getView().getModel("EmployeeDetails").getData().Employeenumber,
					"bank_key": this.byId("inpBankKey").getText(),
					"bank_account": this.byId("inpBankAc").getText(),
					"country_group": countryKey.EBankCountry,
					"bank_country": countryKey.EBankCountry,
					"payee": this.byId("inpPayeeName").getValue(),
					"bank_control_key": this.byId("inpBankCtrlKey").getValue(),
					"iban": this.byId("inpIban1").getValue(),
					"currency": this.byId("idcurrency").getText(),
					"tax1": this.byId("inpIbantx1").getValue(),
					"tax2": this.byId("inpIbantx2").getValue(),
					"reference": this.byId("inpBankRf").getValue()
				}

				busyDialog.open();
				busyDialog.setText("Saving");
				let oModel = this.getOwnerComponent().getModel("Z8C_MYBANK_SRV");
				oModel.create("/TravelnExpeUpdateSet", payload, {
					success: function (oData) {
						if (oData.Type === "S") {
							MessageToast.show(oData.Message);
							oThat.toCancel();
							oThat._getEmployee(1);
						} else if (oData.Type === "E") {
							// MessageBox.error(oData.EMsg1);
							// oThat.toShowError(oData);
							// oThat.byId('inpBankKey').setValueState('Error');
							// oThat.byId('inpBankKey').setValueStateText(oData.EMsg); 
							// // if (oData.EMsg2 <> " ") {
							// oThat.byId('inpBankAc').setValueState('Error');
							// oThat.byId('inpBankAc').setValueStateText(oData.EMsg2);
							// }
							MessageBox.error(oData.Message + oData.EMsg + oData.EMsg1 + oData.EMsg2 + oData.EMsg3);
						}
						busyDialog.close();

					},
					error: function (Error) {
						var errorMsg = oThat.errorMsgParse(Error);
						MessageBox.error(errorMsg);
						busyDialog.close();
					}
				});
			} else if (this.validationForIban()) {
				var cntry;

				var payload = {
					"Number": this.getView().getModel("EmployeeDetails").getData().Employeenumber,
					"bank_key": this.byId("inpBankKeyR").getValue(),
					"bank_account": this.byId("inpBankAcR").getValue(),
					"country_group": this.getCountryKey(),
					"bank_country": this.getCountryKey(),
					"payee": this.byId("inpPayeeName").getValue(),
					"bank_control_key": this.byId("inpBankCtrlKeyR").getValue(),
					"iban": this.byId("inpIbanR").getValue(),
					"currency": this.byId("idcurrencyR").getText(),
					"tax1": this.byId("inpIbantx1R").getValue(),
					"tax2": this.byId("inpIbantx2R").getValue(),
					"reference": this.byId("inpBankRfR").getValue()
				}

				busyDialog.open();
				busyDialog.setText("Saving");
				let oModel = this.getOwnerComponent().getModel("Z8C_MYBANK_SRV");
				oModel.create("/TravelnExpeUpdateSet", payload, {
					success: function (oData) {
						if (oData.Type === "S") {
							MessageToast.show(oData.Message);
							oThat.toCancel();
							oThat._getEmployee();
						} else if (oData.Type === "E") {
							oThat.toShowError(oData);
							// oThat.byId('inpBankKey').setValueState('Error');
							// oThat.byId('inpBankKey').setValueStateText(oData.EMsg); 
							// // if (oData.EMsg2 <> " ") {
							// oThat.byId('inpBankAc').setValueState('Error');
							// oThat.byId('inpBankAc').setValueStateText(oData.EMsg2);
							// }
							// MessageBox.error(oData.Message + oData.EMsg + oData.EMsg1 + oData.EMsg2 + oData.EMsg3);
						}
						busyDialog.close();

					},
					error: function (Error) {
						var errorMsg = oThat.errorMsgParse(Error);
						MessageBox.error(errorMsg);
						busyDialog.close();
					}
				});

			} else {
				MessageToast.show("Fix the highlighted errors");
			}
		},

		errorMsgParse: function (error) {
			var xmlParser, xmlDoc, responseText, jsonParser;
			var i18nModel = this.getOwnerComponent().getModel("i18n");
			var errorCodes = [500, 501, 502, 503, 504];

			try {
				responseText = error.responseText;
				if (responseText && responseText.substring(0, 1) === "<") { // consider it as xml error message
					xmlParser = new DOMParser();
					xmlDoc = xmlParser.parseFromString(responseText, "text/xml");
					if (xmlDoc.getElementsByTagName("message").length > 0) {
						return xmlDoc.getElementsByTagName("message")[0].innerHTML;
					} else if (xmlDoc.getElementsByTagName("body").length > 0) {
						return xmlDoc.getElementsByTagName("body")[0].innerHTML;
					}
				} else if (responseText && responseText.substring(0, 1) === "{") { //consider it as json error message
					jsonParser = JSON.parse(responseText);
					return jsonParser.error.message.value;
				} else if (responseText) {
					return responseText;
				} else if (error.response) {
					xmlParser = new DOMParser();
					xmlDoc = xmlParser.parseFromString(error.response, "text/xml");
					if (xmlDoc.getElementsByTagName("body").length > 0) {
						return xmlDoc.getElementsByTagName("body")[0].innerHTML;
					}
				} else if (errorCodes.includes(error.statusCode)) {
					return "HTTP Connection timed out or refused connection error" + i18nModel.getProperty("errorMessage1");
				} else {
					return "Error occured: " + i18nModel.getProperty("errorMessage1");
				}
			} catch (err) {
				return "Some error happened:Unable to parse the error message";
			}
		}

	});
});