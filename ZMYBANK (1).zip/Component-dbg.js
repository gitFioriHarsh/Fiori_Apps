sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"com/alcon/MyBank/model/models",
	"sap/ui/model/json/JSONModel"
], function (UIComponent, Device, models,JSONModel) {
	"use strict";

	return UIComponent.extend("com.alcon.MyBank.Component", {

		metadata: {
			manifest: "json"
		},

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
		init: function () {
			// call the base component's init function
			jQuery.sap.includeStyleSheet("/sap/bc/ui5_ui5/sap/zmybank/css/style.css");
			var sRootPath = jQuery.sap.getModulePath("zmybank");
			var location= $(location).attr('href'); 
			UIComponent.prototype.init.apply(this, arguments);

			// enable routing
			this.getRouter().initialize();

			// set the device model
			this.setModel(models.createDeviceModel(), "device");
			
			// var sServiceLocation = "/sap/opu/odata/SAP/Z8C_MYBANK_SRC_SRV";
   //         var oModel = new sap.ui.model.odata.ODataModel(sServiceLocation, true);
		 //   oModel.read("/APPL_TYPESet",null,null,true, function(oData, oResponse)
		 //   {
		 //   var oJSONModel = new sap.ui.model.json.JSONModel(oData.results);
		 //   // this.setModel(oJSONModel, "systemModel");
		 //   sap.ui.getCore().setModel(oJSONModel, "systemModel");
		 //   // sap.ui.getCore().byId('').set                        
		    
		 //   });
			    this.setModel(new JSONModel(), "BankCountry");
			    this.setModel(new JSONModel(), "bankModel");
			    this.setModel(new JSONModel(), "userDetails"); 
			    this.setModel(new JSONModel(), "employeModel");
			    this.setModel(new JSONModel(), "DateModel");
				
		}
	});
});