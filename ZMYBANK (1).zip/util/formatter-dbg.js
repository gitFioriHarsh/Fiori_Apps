sap.ui.define([], function () {
	"use strict";
	return {
	  formatDate:function(date){
	  	if(date!==""&& date!==null&& date!==undefined){
	  			return date.substring(6, 8)+"-"+date.substring(4, 6)+"-"+date.substring(0, 4);
	  	}
	  	else{
	  		return "";
	  	}
	  
	  	
	  },
	  formatDateCondition:function(date){
	  		if(date!==""){
	  			return date.substring(6, 8)+"-"+date.substring(4, 6)+"-"+date.substring(0, 4);
	  	}
	  	else if(date===""|| date!==null|| date!==undefined){
	  		///return today's date
	  	var date = new Date();
			var day = (date.getDate() < 10) ? "0" + date.getDate() : date.getDate();
			var month = ((date.getMonth() + 1) < 10) ? "0" + (date.getMonth() + 1) : date.getMonth() + 1;
			var year = date.getFullYear();
			return day + "-" + month + "-" + year;
	  	}
	  }
	};

});