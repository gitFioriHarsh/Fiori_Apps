/*&---------------------------------------------------------------------*
*& Development ID: ZDDI-00021587                                       *
*&                                                                     *
*& Component                                                           *
*&                                                                     *
*&- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*
*& Change Log:                                                         *
*&                                                                     *
*& Init. Who          Date         Text                                *
*& JHU   HUNDEJU1     08-09-2015   Initial version CD 1200005515       *
*&---------------------------------------------------------------------*/

jQuery.sap.declare('com.novartis.uwf.setdelegation.Component');

jQuery.sap.registerModulePath('com.novartis.uwf.lib', '/sap/bc/ui5_ui5/sap/zuwf_lib');
jQuery.sap.registerModulePath('com.novartis.search', '/sap/bc/ui5_ui5/sap/zuwf_search');
jQuery.sap.require('com.novartis.uwf.lib.model.TaskProcessing');
//jQuery.sap.require('com.novartis.uwf.lib.util.Router');
jQuery.sap.require('com.novartis.uwf.setdelegation.util.Router');
sap.ui.core.UIComponent.extend('com.novartis.uwf.setdelegation.Component', {
	metadata: {
		name: 'Universal Workflow - Set Delegation',
		version: '1.0',
		includes: [],
		dependencies: {
			'libs' : [
				'sap.m',
				'sap.me'
			],
			'components' : []
		},
		config: {
			'resourceBundle' : 'i18n/i18n.properties',
			'titleResource' : 'My Delegations',
			'icon' : 'sap-icon://collaborate',
			'homeScreenIconPhone' : './resources/sap/ca/ui/themes/base/img/launchicon/Approve_Requests/57_iPhone_Desktop_Launch.png', //FIXME: should use F0392, but resource is not like that for
			'homeScreenIconPhone@2' : './resources/sap/ca/ui/themes/base/img/launchicon/Approve_Requests/114_iPhone-Retina_Web_Clip.png', //FIXME: should use F0392, but resource is not like that for
			'homeScreenIconTablet' : './resources/sap/ca/ui/themes/base/img/launchicon/Approve_Requests/72_iPad_Desktop_Launch.png', //FIXME: should use F0392, but resource is not like that for
			'homeScreenIconTablet@2' : './resources/sap/ca/ui/themes/base/img/launchicon/Approve_Requests/144_iPad_Retina_Web_Clip.png', //FIXME: should use F0392, but resource is not like that for
			/*'favIcon' : './resources/sap/ca/ui/themes/base/img/favicon/Approve_Requests.ico', //FIXME: should use F0392, but resource is not like that for W1s
			'homeScreenIconPhone' : './resources/sap/ca/ui/themes/base/img/launchicon/Approve_Requests/57_iPhone_Desktop_Launch.png', //FIXME: should use F0392, but resource is not like that for
			'homeScreenIconPhone@2' : './resources/sap/ca/ui/themes/base/img/launchicon/Approve_Requests/114_iPhone-Retina_Web_Clip.png', //FIXME: should use F0392, but resource is not like that for
			'homeScreenIconTablet' : './resources/sap/ca/ui/themes/base/img/launchicon/Approve_Requests/72_iPad_Desktop_Launch.png', //FIXME: should use F0392, but resource is not like that for
			'homeScreenIconTablet@2' : './resources/sap/ca/ui/themes/base/img/launchicon/Approve_Requests/144_iPad_Retina_Web_Clip.png', //FIXME: should use F0392, but resource is not like that for
			'startupImage320x460' : './resources/sap/ca/ui/themes/base/img/splashscreen/320_x_460.png',
			'startupImage640x920' : './resources/sap/ca/ui/themes/base/img/splashscreen/640_x_920.png',
			'startupImage640x1096' : './resources/sap/ca/ui/themes/base/img/splashscreen/640_x_1096.png',
			'startupImage768x1004' : './resources/sap/ca/ui/themes/base/img/splashscreen/768_x_1004.png',
			'startupImage748x1024' : './resources/sap/ca/ui/themes/base/img/splashscreen/748_x_1024.png',
			'startupImage1536x2008' : './resources/sap/ca/ui/themes/base/img/splashscreen/1536_x_2008.png',
			'startupImage1496x2048' : './resources/sap/ca/ui/themes/base/img/splashscreen/1496_x_2048.png'*/
		},

		rootView: 'com.novartis.uwf.setdelegation.view.App',

		routing: {
			config: {
//				routerClass: com.novartis.uwf.lib.util.Router,
				routerClass: com.novartis.uwf.setdelegation.util.Router,
				viewType: 'XML',
				viewPath: 'com.novartis.uwf.setdelegation.view',
				clearTarget: false,
				transition: 'slide'
			},
			routes: [{
				pattern: "",
				name: "main",
				view: "Master",
				viewLevel: 1,
				targetAggregation: "masterPages",
  				targetControl: 'NavContainer',
  				subroutes: [{
					pattern: "{type}",
					name: "master2",
					view: "Master2",
					viewLevel: 2,
					targetAggregation: "masterPages"
				}]
			}, {
				pattern: "{type}",
				name: "master02",
				view: "Master2",
				viewLevel: 2,
				targetAggregation: "masterPages",
  				targetControl: 'NavContainer',
				subroutes: [{
					pattern: "{type}/{entity}",
					name: "detail",
					view: "Detail",
					viewLevel: 3,
					targetAggregation: "detailPages"
				},
				{
					pattern: "{type}/newdelegation",
					name: "newdelegation",
					view: "NewDelegation",
					viewLevel: 3,
					targetAggregation: "detailPages"
				}]
			}]
		}
	},

  init: function() {
    var config = this.getMetadata().getConfig();

    // Call super init function
    sap.ui.core.UIComponent.prototype.init.apply(this, arguments);

		// Always use absolute paths relative to our own component
		var rootPath = jQuery.sap.getModulePath('com.novartis.uwf.setdelegation');

		// Set i18n model
		var i18nModel = new sap.ui.model.resource.ResourceModel({
			bundleUrl: [rootPath, config.resourceBundle].join('/')
		});
		this.setModel(i18nModel, 'i18n');

    // Set model
		this.setModel(com.novartis.uwf.lib.model.TaskProcessing.load(),'global');
//		this.getModel('global').refreshAfterChange(true);

		com.novartis.uwf.lib.model.TaskProcessing.read(['SubstitutionProfileCollection'], {
			async: false
		}, jQuery.proxy(function(data, model, subs) {
			// Set scenario customizing as global model
			this.setModel(new sap.ui.model.json.JSONModel(subs.data.results), 'substitution');
		},this));

    // Start app
    this.getRouter().initialize();
    
//    this.loadNavBar();
  },
  
//  loadNavBar: function () {
//	  var model = sap.ui.getCore().byId('shell') && sap.ui.getCore().byId('shell').getModel();
//	    if (model) {
//	      // Reset buttons
//	      buttonsInModel = model.getProperty('/currentState/actions');
//	      buttonsInModel.length = 0;
//
//	      // Only add standard shell actions
//	      buttonsInModelShellActions = model.getProperty('/currentState/shellActions');
//	      for (var i = 0; i < buttonsInModelShellActions.length; i++) {
//	      	buttonsInModel.push(buttonsInModelShellActions[i]);
//	      }
//
//		  // Add "My Approvals" button if user has the corresponding role
//		  var service = sap.ushell.Container.getService('NavTargetResolution');
//		  var current = service.getCurrentResolution();
//		  var target = '#ZUWF-inbox';
//		  service.isIntentSupported([target]).then(function(intents) {
//			  if (intents[target] && intents[target].supported) {
//			  	this.loadMyApprovalsApp();
//			  }
//		  }.bind(this))
//
//	      model.setProperty('/currentState/actions', buttonsInModel);
//	    }
//
//	    // Always show details when an error occurs
//	    var showMessageBox = sap.ca.ui.dialog.factory.showMessageBox;
//	    sap.ca.ui.dialog.factory.showMessageBox = function(settings, onClose) {
//	    	// Change title
//	    	settings.title = sap.ca.ui.utils.resourcebundle.getText('messagetype.info');
//
//	    	// Try to show actual error message
//	    	try {
//	    		var parsed = JSON.parse(settings.details);
//	    		settings.message = parsed.error.message.value;
//	    	} catch(e) {
//	    		// Keep standard details if object could not be parsed
//	    	}
//
//	    	showMessageBox.apply(this, [settings, onClose]);
//	    };
//	},
//
//	loadMyApprovalsApp: function() {
//		var buttons = [];
//		var delegationButton = new sap.m.Button({
//			text: 'My Inbox',
//			icon: "sap-icon://citizen-connect",
//			press: function(event) {
//				var navigationService = sap.ushell.Container.getService("CrossApplicationNavigation");
//				navigationService.toExternal({
//					target: {
//						shellHash : "ZUWF-inbox"
//					}
//				});
//			}
//		});
//
//		buttons.push(delegationButton);
//		sap.ushell.services.AppConfiguration.addApplicationSettingsButtons(buttons);
//	}

//Initialize the application
//	createContent: function() {
//		var view = {
//			component: this
//		};
//
		// Load scenario customizing synchronous to stay in the context of the component creation
//		com.novartis.uwf.lib.model.TaskProcessing.read(['SubstitutionProfileCollection'], {
//			async: false
//		}, jQuery.proxy(function(data, model, subs) {
//			// Set scenario customizing as global model
//			this.setModel(new sap.ui.model.json.JSONModel(subs.data.results), 'substitution');
//		},this));
//
//		// Load scenario customizing synchronous to stay in the context of the component creation
//		com.novartis.uwf.lib.model.TaskProcessing.read(['SubstitutionRuleCollection?$expand=ZProfiles'], {
//			async: false
//		}, jQuery.proxy(function(data, model, rules) {
//			// Set scenario customizing as global model
//			this.setModel(new sap.ui.model.json.JSONModel(rules.data.results), 'rules');
//		},this));
//
//			// Load scenario customizing synchronous to stay in the context of the component creation
//			com.novartis.uwf.lib.model.TaskProcessing.read(['SubstitutionRuleCollection?$expand=ZProfiles&$filter=ZDelegatedToMe%20eq%20true'], {
//				async: false
//			}, jQuery.proxy(function(data, model, rules) {
//				// Set scenario customizing as global model
//				this.setModel(new sap.ui.model.json.JSONModel(rules.data.results), 'delegatedme');
//			},this));
//
//		this.getModel('global').read('SubstitutionRuleCollection?$expand=ZProfiles', {
//			async: false
//		}, jQuery.proxy(function(data, model, rules) {
//			// Set scenario customizing as global model
//			debugger;
//			this.setModel(new sap.ui.model.json.JSONModel(rules.data.results), 'rules');
//		},this));

//		// Load scenario customizing synchronous to stay in the context of the component creation
//		com.novartis.uwf.lib.model.TaskProcessing.read(['ConsumerScenarioCollection'], {
//			async: false
//		}, jQuery.proxy(function(data, model, scenarios) {
//			// Set scenario customizing as global model
//			this.setModel(new sap.ui.model.json.JSONModel(scenarios.data.results), 'scenarios');
//		},this));
//
//		sap.ui.getCore().setModel(this.getModel('scenarios'),'scenarios');
//
//		//eliminate View All of delegation baseline options
//		if (sap.ui.getCore().getModel('scenarios').oData[0].UniqueName == '*') {
//			sap.ui.getCore().getModel('scenarios').oData.shift();
//		}
//
//		this.mainView = sap.ui.view({
//			viewName: "com.novartis.uwf.setdelegation.view.App",
//			type: sap.ui.core.mvc.ViewType.XML,
//			viewData: view
//		});
//		return this.mainView;
//	}
});
