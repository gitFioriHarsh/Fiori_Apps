/*&---------------------------------------------------------------------*
*& Development ID: ZDDE-00019502                                       *
*&                                                                     *
*& Shared Library                                                      *
*&                                                                     *
*&---------------------------------------------------------------------*
*& Change Log:                                                         *
*&                                                                     *
*& Init. Who          Date         Text                                *
*& JCP   COSTAJOJ     14-09-2015   Initial version CD 1200006098       *
*&---------------------------------------------------------------------*/

jQuery.sap.declare('com.novartis.uwf.setdelegation.util.Formatter');
jQuery.sap.require('com.novartis.uwf.lib.util.Component');
jQuery.sap.require('com.novartis.uwf.setdelegation.Component');
jQuery.sap.require('sap.ui.core.format.DateFormat');
jQuery.sap.require('sap.ui.core.format.NumberFormat');

com.novartis.uwf.setdelegation.util.Formatter = {
		
	stateMap: {
		"true" : "Success",
		"false" : "Error"
	},

	statusMap: {
		"true" : "Active",
		"false" : "Inactive"
	},

//	isSingleProfile : function (profiles) {
//		if (profiles != null) {
//			switch (profiles.results.length)
//			{
//			case 0:
//				break;
//			case 1:
//				return profiles.results[0].ZScenarioText;
//				break;
//			default:
//				return sap.ui.component(sap.ui.core.Component.getOwnerIdFor(this.getParent())).getModel('i18n').getProperty('text.multipleValues');
//				break;
//			}
//		}
//	},

	getStatus: function (bool,profiles) {
		if (bool != null) {
			var map = com.novartis.uwf.setdelegation.util.Formatter.statusMap;
			var status = map[bool];

			if (status == 'Inactive') {
				profiles && profiles.forEach(function(item) {
					item = this.getModel().getProperty('/' + item);
					if (item.ZStatus != '0') {
						return 'Invalid';
					}
				}.bind(this))
			}
			if ((this.getParent().sId.indexOf('detailPage')) >= 0) {
				status = status.toLowerCase();
			}
			return status;
		}
	},

	classDef: function (none) {
		$(".sapMToken ").css("display", "none");
		return sapMToken;
	},

	getState: function (bool,profiles) {
		if (bool != null) {
			var map = com.novartis.uwf.setdelegation.util.Formatter.stateMap;
			var status = map[bool];

			if (status == 'Inactive') {
				profiles.forEach(function(item) {
					item = this.getModel().getProperty('/' + item);
					if (item.ZStatus != '0') {
						return 'Warning';
					}
				}.bind(this))
			}
			return status;
		}
	},

	//to create translation in i18n
	setTitle: function (profiles) {
		if (profiles && profiles.length) {
			var lastID = '';
			var uniqueProfiles = [];
			for (var i=0;i<profiles.length;i++) {
				var profile = this.getModel().getProperty('/' + profiles[i]);
				if (profile.ZScenarioID != lastID) {
					uniqueProfiles.push(profile.ZScenarioID);
					lastID = profile.ZScenarioID;
				}
			}
//			var component = new com.novartis.uwf.setdelegation.Component;
			var scenariosModel = this.getParent().getModel('substitution').getData();
			lastID = '';
//			var i = 1;
			if (scenariosModel.length != 0) {
				scenariosLength = 0;
			}
			scenariosModel.forEach(function(item) {
				if (item.ZScenarioID != lastID) {
					scenariosLength++;
				}
				lastID = item.ZScenarioID;
			})
			var profLength = uniqueProfiles.length;

			switch(true) {
			case (profLength == 0):
				return this.getParent().getModel('i18n').getProperty('text.noApplication');
				break;
			case (profLength == 1):
				return this.getModel().getProperty('/' + profiles[0]).ZScenarioText;
				break;
			case (profLength > 1 && (profLength < scenariosLength)):
				return this.getParent().getModel('i18n').getProperty('text.multipleApplications');
				break;
			case (profLength == scenariosLength):
				return this.getParent().getModel('i18n').getProperty('text.allApplications');
				break;
			default:
				return this.getParent().getModel('i18n').getProperty('text.invalid');// to complete
				break;
			}
		}
	},

	labelDelegate: function(bool) {
		if (bool == true) {
			return sap.ui.component(sap.ui.core.Component.getOwnerIdFor(this.getParent())).getModel('i18n').getProperty('label.delegateFrom');
		} else {
			return sap.ui.component(sap.ui.core.Component.getOwnerIdFor(this.getParent())).getModel('i18n').getProperty('label.delegate');
		}
	},
	
	titleDelegate: function(bool) {
		if (bool == true) {
			return sap.ui.component(sap.ui.core.Component.getOwnerIdFor(this.getParent())).getModel('i18n').getProperty('detailTitleFrom');
		} else {
			return sap.ui.component(sap.ui.core.Component.getOwnerIdFor(this.getParent())).getModel('i18n').getProperty('detailTitle');
		}
	},

	statusVisible: function(bool) {
		if (bool == true) {
			return false;
		} else {
			return true;
		}
	},
	
	periodFormatter: function(from, to) {
		var period = '',
			fullDate = sap.ui.core.format.DateFormat.getDateInstance({ style: 'long' }),
			dayDate = sap.ui.core.format.DateFormat.getDateInstance({ pattern: 'EEEE' });
		
		if (from) {
			period = dayDate.format(from) + ', ' + fullDate.format(from);
		}
		
		if (to && from && from.toDateString() !== to.toDateString()) {
			period += ' - ' + dayDate.format(to) + ', ' + fullDate.format(to);
		}

		return period;
	},

};
