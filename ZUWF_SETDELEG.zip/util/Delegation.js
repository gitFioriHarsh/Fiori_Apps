/*&---------------------------------------------------------------------*
*& Development ID: ZDDE-00019502                                       *
*&                                                                     *
*& Shared Library                                                      *
*&                                                                     *
*&---------------------------------------------------------------------*
*& Change Log:                                                         *
*&                                                                     *
*& Init. Who          Date         Text                                *
*& JCP   COSTAJOJ     14-09-2015   Initial version CD 1200006098       *
*&---------------------------------------------------------------------*/

jQuery.sap.declare('com.novartis.uwf.setdelegation.util.Delegation');
jQuery.sap.require('com.novartis.search.control.UserSearchField');
jQuery.sap.require('com.novartis.search.util.Transport');
jQuery.sap.require('com.novartis.search.util.Misc');

com.novartis.uwf.setdelegation.util.Delegation = {

		openSelectDialog: function (sValue, that) {

			this.view = that.view;

			this._model = new sap.ui.model.json.JSONModel([]);

			// create list
			var oEmplSearchList = new sap.m.List({
				inset: false,
				growing: true,
				growingScrollToLoad: true,
				growingThreshold: 20,
				mode:'SingleSelectMaster',
				select: [this.onSelectEmployee, this]
			});

			oEmplSearchList.setModel(this._model);

			// create list items var oItemTemplate = new
			var oItemTemplate = new sap.m.StandardListItem({
				title: "{firstName} {lastName}",
				infoState: "Success",
				info: "{uname}",
				press: [this.onSelectEmployee, this],
				type: "{device>/listItemType}",
				icon: "sap-icon://employee"
			});

			// create list items
			var oItemTemplateMobile = new sap.m.StandardListItem({
				title: "{firstName} {lastName}",
				description: "{uname}",
				press: [this.onSelectEmployee, this],
				type: "{device>/listItemType}",
				icon: "sap-icon://employee"

			});


			//Create User Search field from global search api
			var oSearch = new com.novartis.search.control.UserSearchField(
				{
					result: jQuery.proxy(this.onResult, this),
					//websocket: "wss://" + location.host + "/sap/bc/apc/sap/ywebxx_user_search",
					value: sValue,
					json: "/sap/zuwf_json/zuwf_search_usr"
				}
			);

			this._oSearch = oSearch;

			var that = this;


			this._oListDialog = new sap.m.Dialog({
				title: "{i18n>dialog.title}",
				contentWidth: "40rem",
				contentHeight: "30rem",
				subHeader: new sap.m.Bar({
					contentMiddle: [oSearch]
				}),
				stretch: (jQuery.device.is.phone) ? true: false,
				content: [oEmplSearchList],
				beginButton: new sap.m.Button({
					text: "{i18n>dialog.close}",
					press: function () {
						that._oListDialog.close();
					}
				})
			});


			this.view.addDependent(this._oListDialog);

			// bind items
			oEmplSearchList.bindAggregation("items", {
				path: "/",
				template: sap.ui.Device.system.phone ? oItemTemplateMobile : oItemTemplate
			});
			this._oListDialog.open();

			if (sValue){
				this._oSearch.fireLiveChange();
			}
//			this._oSearch.focus();
//			this._oListDialog.onAfterRendering( this._oListDialog.applyFocusInfo(this._oSearch.getFocusInfo()));

		},

		onSelectEmployee: function (oEvent) {
			var list = oEvent.getParameter("listItem") || oEvent.getSource();
			if (!this._oListDialog) {
				this._oListDialog = this.getView()
					.getDependent()[0];
			}
			this._oListDialog.close();

			if (!list) {
				return;
			}

			var nomineeInput = this.view.byId("searchHelpDelegator");
			nomineeInput.setValue(list.getTitle());
			if (!jQuery.device.is.phone) {
				nomineeInput.setValueStateText(list.getInfo());
			} else {
				nomineeInput.setValueStateText(list.getDescription());
			}
		},

		onResult: function (event) {
			this._model.setData(event.getParameter('result'));
		},
}
