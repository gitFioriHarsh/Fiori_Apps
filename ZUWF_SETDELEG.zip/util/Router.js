/*&---------------------------------------------------------------------*
*& Development ID: ZDDI-00021587                                       *
*&                                                                     *
*& Details                                                             *
*&                                                                     *
*&- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*
*& Change Log:                                                         *
*&                                                                     *
*& Init. Who          Date         Text                                *
*& JCP   COSTAJOJ     24-11-2015   Initial version CD 1200005515       *
*&---------------------------------------------------------------------*/

jQuery.sap.declare('com.novartis.uwf.setdelegation.util.Router');
jQuery.sap.require('sap.m.routing.RouteMatchedHandler');
jQuery.sap.require('sap.ui.core.routing.Router');

sap.ui.core.routing.Router.extend('com.novartis.uwf.setdelegation.util.Router', {
	_routeMatchedHandler: null,

	constructor: function() {
		sap.ui.core.routing.Router.apply(this, arguments);

		this._routeMatchedHandler = new sap.m.routing.RouteMatchedHandler(this);
		this._routeMatchedHandler.setCloseDialogs(false);
	},

	navToWithoutHash: function(options) {
		var splitApp = this._findSplitApp(options.currentView);

		// Load view, add it to the page aggregation, and navigate to it
		var view = this.getView(options.targetViewName, options.targetViewType);
		splitApp.addPage(view, options.isMaster);
		splitApp.to(view.getId(), options.transition || 'show', options.data);
	},

	hasPreviousHash: function() {
		var history = sap.ui.core.routing.History.getInstance();

		return history.getPreviousHash() !== undefined;
	},

	back: function(route, data) {
		var history = sap.ui.core.routing.History.getInstance(),
			previousHash = history.getPreviousHash();

		// The history contains a previous entry
		if (previousHash !== undefined) {
			window.history.go(-1);
		} else {
			this.navTo(route, data, true); // otherwise we go backwards with a forward history
		}
	},

	backWithoutHash: function(currentView, isMaster) {
		var backMethod = isMaster ? 'backMaster' : 'backDetail';
		this._findSplitApp(currentView)[backMethod]();
	},

	destroy: function() {
		sap.ui.core.routing.Router.prototype.destroy.apply(this, arguments);
		this._routeMatchedHandler.destroy();
	},

	_findSplitApp: function(control) {
		var ancestorControlName = 'NavContainer';
		if (control instanceof sap.ui.core.mvc.View && control.byId(ancestorControlName)) {
			return control.byId(ancestorControlName);
		}

		return control.getParent() ? this._findSplitApp(control.getParent(), ancestorControlName) : null;
	}
});
