/*&---------------------------------------------------------------------*
*& Development ID: ZDDE-00019502                                       *
*&                                                                     *
*& Shared Library                                                      *
*&                                                                     *
*&---------------------------------------------------------------------*
*& Change Log:                                                         *
*&                                                                     *
*& Init. Who          Date         Text                                *
*& JCP   COSTAJOJ     14-09-2015   Initial version CD 1200006098       *
*&---------------------------------------------------------------------*/

jQuery.sap.declare('com.novartis.uwf.setdelegation.util.Validation');
jQuery.sap.require('sap.m.MessageBox');

com.novartis.uwf.setdelegation.util.Validation = {

	userValidation: function(user,control) {
		if (user == '') {
			this.showErrorMessage(control.i18n.getProperty('text.validUser'),control.i18n.getProperty('text.error'));
		}
		else { return true };
	},

	dateValidation: function(startDate, endDate,control) {
		if (startDate == null) {
			this.showErrorMessage(control.i18n.getProperty('text.defineStartDate'),control.i18n.getProperty('text.error'));
		} else
		if (endDate == null){
			this.showErrorMessage(control.i18n.getProperty('text.defineEndDate'),control.i18n.getProperty('text.error'));
		} else
		if (startDate > endDate) {
			this.showErrorMessage(control.i18n.getProperty('text.wrongDates'),control.i18n.getProperty('text.error'));
		} else { return true };
	},
	
	startDateValid: function(date,control) {
		if (date < new Date().setHours(00)) {
			this.showErrorMessage(control.i18n.getProperty('text.defineStartDate'),control.i18n.getProperty('text.error'));
		}
		else { return true };
	},
	
	endDateValid: function(date,control) {
		if (date < new Date().setHours(00)) {
			this.showErrorMessage(control.i18n.getProperty('text.defineEndDate'),control.i18n.getProperty('text.error'));
		}
		else { return true };
	},

	validPeriod: function(startDate, endDate, control) {
		if (startDate > endDate) {
			this.showErrorMessage(control.i18n.getProperty('text.wrongDates'),control.i18n.getProperty('text.error'));
		}
		else { return true };
	},
	
	addHours: function(h){
		return h*3600*1000;
	},

	profileValidation: function(profile,control) {
		if (profile.length == 0) {
			this.showErrorMessage(control.i18n.getProperty('text.selectProfile'),control.i18n.getProperty('text.error'));
		} else { return true };
	},

	showErrorMessage: function(message,type) {
		sap.m.MessageBox.show(message,{
			  title: type,
			  actions: [sap.m.MessageBox.Action.OK],
	          onClose: function(oAction) {
	        	  if (oAction == sap.m.MessageBox.Action.OK) {
		        	  return false;
	        	  }}
		});
	},

}
