/*&---------------------------------------------------------------------*
*& Development ID: ZDDI-00021587                                       *
*&                                                                     *
*& Welcome                                                             *
*&                                                                     *
*&- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*
*& Change Log:                                                         *
*&                                                                     *
*& Init. Who          Date         Text                                *
*& JCP   COSTAJOJ     11-09-2015   Initial version CD 1200005515       *
*&---------------------------------------------------------------------*/

	jQuery.sap.require('com.novartis.uwf.setdelegation.util.Delegation');
	jQuery.sap.require('com.novartis.uwf.setdelegation.util.Validation');
	jQuery.sap.require("sap.ca.ui.message.message");

sap.ui.core.mvc.Controller.extend('com.novartis.uwf.setdelegation.view.NewDelegation', {

	fragment: null,
	user: null,
	scenario: [],
	beginDate: null,
	endDate: null,
	created: null,
	scenariosModel: null,
	delegationCombo: null,
	profileValues: '',
	profiles: [{}],
	validate: com.novartis.uwf.setdelegation.util.Validation,

	onInit: function() {

		this.view = this.getView();
		this.component = sap.ui.component(sap.ui.core.Component.getOwnerIdFor(this.view));
		this.resourceBundle = this.component.getModel("i18n").getResourceBundle();
		this.i18n = this.component.getModel('i18n');
		this.router = this.component.getRouter();
		if (jQuery.device.is.phone) {
			this.view.byId('detailPage').setShowNavButton(true);
		}
		this.oEventBus = this.getEventBus();
		if (!jQuery.device.is.phone) {
			this.oEventBus.publish("Detail", "SetMasterBusy", {bForce: true});
		}
		this.scenariosModel = this.component.getModel("substitution");

		this.applyScenario(this.scenariosModel);

	},

	handleSelectionChange: function(oEvent) {
		var selectedItem = oEvent.getParameter('changedItem').getKey();
		this.previousSelected = selectedItem;
		var state = oEvent.getParameter("selected");
		var data = this.scenariosModel.getData();
		var text = oEvent.getParameter('changedItem').getText();
		var profileExists = false;
		var cellProfileText;
		var table = this.getView().byId('profilesTable');
		for(var j=0;j<data.length;j++) {
			if (state && data[j].ZScenarioID == selectedItem) {
				if (data[j].Profile == '' || data[j].ProfileText == '') {
					this.profiles.push(data[j]);
					if (!jQuery.device.is.phone) {
						this.createTable(this.getProfiles());
					}
					this.removeTokens(this);
				}
				else {
					profileExists = true;
				}
				break;
			}
		}
		if (state && profileExists) {
			this.applyProfileScenario(this.scenariosModel,selectedItem,text);
		}
		if (!state) {
			for(var j=0;j<this.profiles.length;j++) {
				if (this.profiles[j].ZScenarioID == selectedItem) {
					if (this.profiles[j].ProfileText !== '') {
						cellProfileText = this.profiles[j].ZScenarioText+": "+this.profiles[j].ProfileText;
					}
					else {
						cellProfileText = this.profiles[j].ZScenarioText;
					}
					var row = new sap.m.ColumnListItem({
						cells: [new sap.m.Text({text: cellProfileText})]
					});
					this.profiles.splice(j,1);
				}
			}
			if (table.getItems().length !== 0){
				table.removeAllItems();
			}
			if (this.getProfiles().length != 0) {
				if (!jQuery.device.is.phone) {
					this.createTable(this.getProfiles());
				}
				this.removeTokens(this);
			}
			else {
				//this.getView().byId('profilesElementTable').setVisible(false);
			}
		}
		this.getView().byId('delegationCombo').open();
	},

	handleSelectionFinish: function (event) {
		if (jQuery.device.is.phone && this.getProfiles().length !== 0) {
			this.createTable(this.getProfiles());
		}
	},

	removeTokens: function (control) {
		control.getView().byId('delegationCombo')._oTokenizer.removeAllTokens();
	},

	createTable: function(data) {
	 	var table = this.getView().byId('profilesTable');
	 	var cellProfileText;
	 	if (table.getItems().length !== 0){
			table.removeAllItems();
		}
	 	//this.getView().byId('profilesElementTable').setVisible(true);
		data && data.forEach(function(item){
			if(item.ProfileText !== ''){
				cellProfileText = item.ZScenarioText+": "+item.ProfileText;
			}
			else {
				cellProfileText = item.ZScenarioText;
			}
			var row = new sap.m.ColumnListItem({
				cells: [new sap.m.Text({text: cellProfileText})]
			});
			table.addItem(row);
		});
	},

	onSubmit: function(oEvent) {
		var model = this.component.getModel('global');
		var user = this.getUser();
		var startDate = this.getStartDate();
		var endDate = this.getEndDate();
		var validate = com.novartis.uwf.setdelegation.util.Validation;
		var profiles = this.getProfiles();
		this.oEventBus.publish("New", "CreateNewItem", {bForce: false});

		if (validate.userValidation(user,this) && validate.endDateValid(endDate,this) &&
				validate.startDateValid(startDate,this) && validate.dateValidation(startDate,endDate,this) &&
				validate.profileValidation(profiles,this)) {

			this.lockFooter(true);
			model.create("/SubstitutionRuleCollection",
					{ User: user,// IsEnabled: true,
					BeginDate: startDate,
					EndDate: endDate },
					{ success: jQuery.proxy(function(obj) {
						this.applyAssignment(model,obj,profiles);
						this.component.getRouter().navTo('detail', {
							type: 'mydelegations',
							entity: obj.SubstitutionRuleID
						}, true)
					},this ),
					  error : jQuery.proxy(function(obj) { sap.ca.ui.message.showMessageToast(this.i18n.getProperty('text.errorMessage'))},this)});
			this.cleanScreen();
			if (jQuery.device.is.phone) {
				//this.navToMaster2();
				this.oEventBus.publish("Detail", "ChangeFlagMobile", {bForce: false});
			} else {
//				this.oEventBus.publish("Detail", "RefreshModel", {bForce: true});
			}
			this.oEventBus.publish("New", "TableModel", {bForce: true});
			this.lockFooter(false);
		}
	},

	applyAssignment: function(model,data,profiles) {

		var batchProc = [];
		var eventBus = this.getEventBus();
		var ruleId = data.SubstitutionRuleID;

			for (var i=0;i<profiles.length;i++) {

				var profile = {
						ZScenarioID: profiles[i].ZScenarioID,
						Profile: profiles[i].Profile,
	                };

				batchProc.push(model.createBatchOperation(
						"/SubstitutionRuleCollection(SubstitutionRuleID='"+data.SubstitutionRuleID+"')/ZProfiles",
	                    "POST",
	                    profile)
	                );
			}

			model.addBatchChangeOperations(batchProc);
			model.submitBatch(function(data) {
				model.refresh(true);
				eventBus.publish("Detail", "RefreshModel", {ruleId: ruleId});
	        },undefined, false);

	},

	handleCancelProfiles: function(event) {
		this.removeTokens(this);
		this.getView().byId('delegationCombo').removeSelectedKeys([this.previousSelected]);
	},

	getProfiles: function() {
		if (this.profiles.length!=0 && !this.profiles[0].ZScenarioID) {
			this.profiles.shift();
		}
		return this.profiles;
	},

	handleChangeBD: function(oEvent) {
		var value = oEvent.getParameter('value');
		var date = oEvent.getSource().getDateValue();
		var endDate = this.getEndDate();
		this.getView().byId('datePickerBeginDate').setValue(value);
		var startDate = this.getStartDate();

		if (this.validate.startDateValid(startDate,this)) {
			if (endDate !== '' && endDate !== null && endDate !== undefined) {
				this.validate.validPeriod(startDate,endDate,this)
			}
		}
	},

	handleChangeED: function(oEvent) {
		var value = oEvent.getParameter('value');
		var date = oEvent.getSource().getDateValue();
		var startDate = this.getStartDate();
		this.getView().byId('datePickerEndDate').setValue(value);
		var endDate = this.getEndDate();

		if (this.validate.endDateValid(endDate,this)) {
			if (startDate !== '' && startDate !== null && startDate !== undefined) {
				this.validate.validPeriod(startDate,endDate,this)
			}
		}
	},

	getUser: function () {
		return this.view.byId('searchHelpDelegator').getValueStateText();
	},

	getStartDate: function () {
		var date =  this.getView().byId('datePickerBeginDate').getDateValue();
		if (date != null) {
			date.setHours(23);
		}
		return date;
	},

	getEndDate: function () {
		var date =  this.getView().byId('datePickerEndDate').getDateValue();
		if (date != null) {
			date.setHours(23);
		}
		return date;
	},

	addHours: function(h){
		return h*3600*1000;
	},

	handleValueHelp: function(oEvent) {
		var that = this;
		var value = this.getView().byId('searchHelpDelegator').getValue();
		com.novartis.uwf.setdelegation.util.Delegation.openSelectDialog(value,that);
	},

	getEventBus: function() {
		return sap.ui.getCore().getEventBus();
	},

	applyScenario: function(model) {

		var individualScenariosModel = new sap.ui.model.json.JSONModel();
		var individualScenarios = [];
		var dataScenario = model.getData();

		var delegationCombo = this.byId('delegationCombo');
		var comboRender = delegationCombo.getRenderer();
		comboRender.addInnerClasses = function(delegationCombo, oControl) {
			oControl._oTokenizer.removeAllTokens();
		};

		var lastID = '';
		for (var i=0;i<dataScenario.length;i++) {
			if (dataScenario[i].ZScenarioID != lastID) {
				individualScenarios.push(dataScenario[i]);
			}
			lastID = dataScenario[i].ZScenarioID;
		}
		individualScenariosModel.setData(individualScenarios);
		delegationCombo.setModel(individualScenariosModel);
	},

	applyProfileScenario: function(model,key,profileName) {
		var individualScenariosModel = new sap.ui.model.json.JSONModel();
		var individualScenarios = [];
		var dataScenario = model.getData();

		var fragmentHrProfiles = sap.ui.xmlfragment("com.novartis.uwf.setdelegation.view.HrProfiles", this.getView().getController());
		for (var i=0;i<dataScenario.length;i++) {
			if(dataScenario[i].ZScenarioID == key) {
				individualScenarios.push(dataScenario[i]);
			}
		}
		individualScenariosModel.setData(individualScenarios);
		fragmentHrProfiles.setModel(individualScenariosModel);
		fragmentHrProfiles.setTitle(profileName);
		//set Custom Data
		var items = fragmentHrProfiles.getItems();
		for (var i=0;i<items.length;i++) {
			items[i].addCustomData(new sap.ui.core.CustomData({key:'Profile', value:items[i].getModel().getData()[i].Profile}))
		}
		fragmentHrProfiles.open();
	},


	handleCloseHrProfiles: function(oEvent) {
		var data = this.scenariosModel.getData();
		var scenario;
		var profile;
		var selectedItem;// = oEvent.getParameters('selectedItems').selectedItem.getDescription();
		var customData = oEvent.getParameter('selectedItem').getCustomData();
		customData.forEach(jQuery.proxy(function(item) {
			selectedItem = item.getProperty('value');
		}),this)

		for(var j=0;j<data.length;j++) {
			if (data[j].Profile == selectedItem) {
				this.profiles.push(data[j]);
				break;
			}
		}
		this.removeTokens(this);
		if (!jQuery.device.is.phone) {
			this.createTable(this.getProfiles());
		}
		this.getView().byId('delegationCombo').open();
	},

	onCancel: function () {
		this.cleanScreen();
		if (jQuery.device.is.phone) {
			this.navToMaster2();
		} else {
			this.oEventBus.publish("Detail", "RefreshModel");
		}
	},

	onNavBack: function () {
		this.cleanScreen();
		if (jQuery.device.is.phone) {
			this.navToMaster2();
		} else {
			this.oEventBus.publish("Detail", "RefreshModel");
		}
	},

	navToMaster2: function() {
		this.component.getRouter().navToWithoutHash({
			currentView: this.getView(),
			targetViewName: "com.novartis.uwf.setdelegation.view.Master2",
			targetViewType: "XML"
		});
	},

	cleanScreen: function () {
		this.getView().byId('searchHelpDelegator').setValue('');
		this.getView().byId('searchHelpDelegator').setValueStateText('');
		this.getView().byId('delegationCombo').setSelectedItems();
		this.getView().byId('datePickerBeginDate').setValue('');
		this.getView().byId('datePickerEndDate').setValue('');
		var table = this.getView().byId('profilesTable');
		if (table.getItems().length !== 0){
			table.removeAllItems();
		}
		//this.getView().byId('profilesElementTable').setVisible(false);
		this.profileValues = '';
		this.profiles = [{}];
	},

	lockFooter: function (bool) {
		this.view.byId('detailPage').getFooter().setBusy(bool);
	},

	handleSearch: function(oEvent) {
		var aFilters = [];
		var sQuery = oEvent.getSource()._sSearchFieldValue;
		if (sQuery && sQuery.length > 0) {
			var filter = new sap.ui.model.Filter("ProfileText", sap.ui.model.FilterOperator.Contains, sQuery);
			aFilters.push(filter);
		}
		var oBinding = oEvent.getSource().getBinding("items");
		oBinding.filter(aFilters);
	},

	getSubstitutionModel: function() {
		com.novartis.uwf.lib.model.TaskProcessing.read(['SubstitutionProfileCollection'], {
		async: false
	}, jQuery.proxy(function(data, model, subs) {
		// Set scenario customizing as global model
		this.setModel(new sap.ui.model.json.JSONModel(subs.data.results), 'substitution');
	},this));
		return this.getModel('substituion');
	}
});
