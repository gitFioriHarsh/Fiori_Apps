/*&---------------------------------------------------------------------*
*& Development ID: ZDDI-00021587                                       *
*&                                                                     *
*& Master2                                                             *
*&                                                                     *
*&- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*
*& Change Log:                                                         *
*&                                                                     *
*& Init. Who          Date         Text                                *
*& JHU   HUNDEJU1     08-09-2015   Initial version CD 1200005515       *
*&---------------------------------------------------------------------*/
jQuery.sap.require('com.novartis.uwf.setdelegation.util.Formatter');
jQuery.sap.require('com.novartis.uwf.lib.util.Formatter');
sap.ui.core.mvc.Controller.extend('com.novartis.uwf.setdelegation.view.Master2', {

	loaded: false,

onInit: function() {

	this.view = this.getView();
	this.component = sap.ui.component(sap.ui.core.Component.getOwnerIdFor(this.view));
	this.resourceBundle = this.component.getModel("i18n").getResourceBundle();
	this.router = this.component.getRouter();

	this.globalModel = this.component.getModel("global");
	this.i18n = this.component.getModel('i18n');

	this.listItem = this.view.byId('master2ListItem').clone();

	this.view.setModel(this.globalModel);

	this.oInitialLoadFinishedDeferred = jQuery.Deferred();

	var oEventBus = this.getEventBus();
	oEventBus.subscribe("Detail", "TabChanged", this.onDetailTabChanged, this);
	oEventBus.subscribe("Detail", "RefreshModel", this.refreshList, this);
	oEventBus.subscribe("Master", "MasterBusy", this.setMasterBusy, this);
	oEventBus.subscribe("Detail", "ChangeFlagMobile", this.setFlag, this);

	var oList = this.getView().byId("master2List");
	oList.attachEvent("updateFinished", function() {
		this.oInitialLoadFinishedDeferred.resolve();
		oEventBus.publish("Master", "InitialLoadFinished");
	}, this);

	this.getRouter().attachRoutePatternMatched(this.onRouteMatched, this);

	oEventBus.subscribe("Detail", "Changed", this.onDetailChanged, this);
	oEventBus.subscribe("Detail", "NotFound", this.onNotFound, this);

	if (sap.ui.Device.system.phone) {
		return;
	}

},

onRoutePatternMatched: function(oEvent) {
	var sName = oEvent.getParameter("name");

	if (sName !== "master2") {
		return;
	}
	

	//		Load the detail view in desktop
	this.getRouter().navToWithoutHash({
		currentView: this.getView(),
		targetViewName: "com.novartis.uwf.setdelegation.view.Detail",
		targetViewType: "XML",
		transition: "slide"
	});
},

onRouteMatched: function(oEvent) {
	var sName = oEvent.getParameter("name");

	var list = this.view.byId('master2List');
	if (sName !== "master2" && list.getBinding('items')) {
		return;
	}
	
	this.type = oEvent.getParameter("arguments").type;
	list.unbindItems();
	if (!jQuery.device.is.phone){
		this.oInitialLoadFinishedDeferred = jQuery.Deferred();
	}
	if (this.type == 'mydelegations'){
		this.getView().byId('master2Page').setTitle(this.i18n.getProperty('master2Title'));
		list.bindItems({ path : '/SubstitutionRuleCollection', template: this.listItem, parameters: { expand : 'ZProfiles' } });
		this.showButtons(true);
	} else if (this.type == 'delegatedme') {
		this.getView().byId('master2Page').setTitle(this.i18n.getProperty('master2DelegatedMeTitle'));
		list.bindItems({
			path: '/SubstitutionRuleCollection',
			template: this.listItem,
			filters: [ new sap.ui.model.Filter('ZDelegatedToMe', sap.ui.model.FilterOperator.EQ, true) ],
			parameters: {
				expand: 'ZProfiles',

			}
		});
		this.showButtons(false);
	}
	
	if(!jQuery.device.is.phone) {
	//Load the detail view in desktop
		this.loadDetailView();

		//Wait for the list to be loaded once
		this.waitForInitialListLoading(function() {

			//On the empty hash select the first item
		this.selectFirstItem();

		});
	}
},

	onDetailChanged: function(sChanel, sEvent, oData) {
	var sEntityPath = oData.sEntityPath;
	var list = this.getView().byId("master2List");
	var items = list.getItems();
	
	this.waitForInitialListLoading(function() {
		items && items.forEach(function (item) {
			if(item.getBindingContext().getPath() == sEntityPath) {
				list.setSelectedItem(item, true);
			}
		})
	})
	//Wait for the list to be loaded once
//	this.waitForInitialListLoading(function() {
//		var oList = this.getView().byId("master2List");
//
//		var oSelectedItem = oList.getSelectedItem();
//		// The correct item is already selected
//		if (oSelectedItem && oSelectedItem.getBindingContext().getPath() === sEntityPath) {
//			return;
//		}
//
//		var aItems = oList.getItems();
//
//		for (var i = 0; i < aItems.length; i++) {
//			if (aItems[i].getBindingContext().getPath() === sEntityPath) {
//				oList.setSelectedItem(aItems[i], true);
//				break;
//			}
//		}
//	});
},

onDetailTabChanged: function(sChanel, sEvent, oData) {
	this.sTab = oData.sTabKey;
},

refreshList: function(sChanel, sEvent, oData) {
	var list = this.getView().byId("master2List");
	var items = list.getItems();
	this.getView().setBusy(false);
	var ruleId = oData.ruleId;
	if (!jQuery.device.is.phone) {
		this.getView().setBusy(false);
		if (items.length) {
			if (ruleId !== undefined) {
				this.getRouter().navTo("detail", {
					from: "master",
					entity: ruleId,
					type: 'mydelegations',
					tab: ''
				})
			this.selectMasterItem(ruleId);	
			}
			else {
				this.selectFirstItem();
			}
			this.oInitialLoadFinishedDeferred.resolve();
			this.getEventBus().publish("Master", "InitialLoadFinished");
		}
		else {
			this.getRouter().navToWithoutHash({
				currentView: this.getView(),
				targetViewName: "com.novartis.uwf.setdelegation.view.NotFound",
				targetViewType: "XML"
			});
		}
	}
},

selectMasterItem: function(ruleId) {
	var list = this.getView().byId("master2List");
	var items = list.getItems();
	
	items && items.forEach(function (item) {
		if(item.getBindingContext().getPath().indexOf(ruleId) >= 0) {
			list.setSelectedItem(item, true);
		}
	})
},

setFlag: function(sChanel, sEvent, oData) {
	var bForce = oData.bForce;
	this.loaded = bForce;
	this.getView().byId("master2List").removeSelections();
},

loadDetailView: function() {
	this.getRouter().navToWithoutHash({
		currentView: this.getView(),
		targetViewName: "com.novartis.uwf.setdelegation.view.Detail",
		targetViewType: "XML"
	});
},

waitForInitialListLoading: function(fnToExecute) {
	jQuery.when(this.oInitialLoadFinishedDeferred).then(jQuery.proxy(fnToExecute, this));
},

onNotFound: function() {
	this.getView().byId("master2List").removeSelections();
},

selectFirstItem: function() {
	var oList = this.getView().byId("master2List");
	var aItems = oList.getItems();
	if (aItems.length) {
		oList.setSelectedItem(aItems[0], true);
		//Load the detail view in desktop
		this.loadDetailView();
		oList.fireSelect({
			"listItem": aItems[0]
		});
	} else {
		this.getRouter().navToWithoutHash({
			currentView: this.getView(),
			targetViewName: "com.novartis.uwf.setdelegation.view.NotFound",
			targetViewType: "XML"
		});
	}
},

showButtons: function(bool) {
	this.getView().byId('newDelegation').setVisible(bool);
},

onSearch : function (oEvt) {
	this.oInitialLoadFinishedDeferred = jQuery.Deferred();
	// add filter for search
	var aFilters = [];
	var sQuery = oEvt.getSource().getValue();
	
	var list = this.getView().byId("master2List");
	var binding = list.getItems();
	binding && binding.forEach(function(item) {
		if(item.getProperty('title').toLowerCase().indexOf(sQuery.toLowerCase()) >= 0) { 
			item.setVisible(true);
		} else {
			item.setVisible(false);
		}
	})
	if (sap.ui.Device.system.phone) {
		return;
	}

	//Wait for the list to be reloaded
	this.waitForInitialListLoading(function() {
		//On the empty hash select the first item
		this.selectFirstItem();
	});
},


onSelect: function(oEvent) {
	// Get the list item either from the listItem parameter or from the event's
	// source itself (will depend on the device-dependent mode)
	if ((jQuery.device.is.phone && !this.loaded) || (!jQuery.device.is.phone)) {
		this.loaded = true;
		this.showDetail(oEvent.getParameter("listItem") || oEvent.getSource());
	}
},

showDetail: function(oItem) {
	// If we're on a phone device, include nav in history
	var bReplace = jQuery.device.is.phone ? false : true;
	this.getRouter().navTo("detail", {
		from: "master",
		entity: oItem.getBindingContext().getObject().SubstitutionRuleID,
		type: this.type,
		tab: this.sTab
	},
	bReplace);
	if (jQuery.device.is.phone) {
		var oList = this.getView().byId("master2List");
		var aItems = oList.getItems();
		if (aItems.length) {
			oList.setSelectedItem(aItems[oItem.getBindingContext().getPath().substr(1)], true);
			this.loadDetailView();
			oList.fireSelect({
				"listItem": aItems[oItem.getBindingContext().getPath().substr(1)]
			});
		}
	}
},

getEventBus: function() {
	return sap.ui.getCore().getEventBus();
},

getRouter: function() {
	return sap.ui.core.UIComponent.getRouterFor(this);
},

onExit: function(oEvent) {
	var oEventBus = this.getEventBus();
	oEventBus.unsubscribe("Detail", "TabChanged", this.onDetailTabChanged, this);
	oEventBus.unsubscribe("Detail", "Changed", this.onDetailChanged, this);
	oEventBus.unsubscribe("Detail", "NotFound", this.onNotFound, this);
},

onNavBack: function() {
	// This is only relevant when running on phone devices
//	this.getRouter().navTo("main", {
//		from: "master2"})
	window.history.go(-1);
},

addDelegation: function() {
	if (!jQuery.device.is.phone) {
		this.getView().setBusy(true);
	}
	this.getRouter().navToWithoutHash({
		currentView: this.getView(),
		targetViewName: "com.novartis.uwf.setdelegation.view.NewDelegation",
		targetViewType: "XML"
	});
},

	setMasterBusy: function(sChanel, sEvent, oData) {
		var bForce = oData.bForce;
		if (!jQuery.device.is.phone) {
			this.getView().setBusy(bForce);
		}
	},

});
