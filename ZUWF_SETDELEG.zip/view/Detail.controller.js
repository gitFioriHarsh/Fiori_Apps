/*&---------------------------------------------------------------------*
*& Development ID: ZDDI-00021587                                       *
*&                                                                     *
*& Details                                                             *
*&                                                                     *
*&- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*
*& Change Log:                                                         *
*&                                                                     *
*& Init. Who          Date         Text                                *
*& JHU   HUNDEJU1     08-09-2015   Initial version CD 1200005515       *
*& JCP   COSTAJOJ     14-09-2015   Implementation  CD 1200006098       *
*&---------------------------------------------------------------------*/

jQuery.sap.require('com.novartis.uwf.setdelegation.util.Formatter');
jQuery.sap.require('com.novartis.uwf.setdelegation.util.Delegation');
jQuery.sap.require('com.novartis.uwf.setdelegation.util.Validation');
jQuery.sap.require("sap.ca.ui.message.message");
jQuery.sap.require('sap.m.MessageBox');
sap.ui.core.mvc.Controller.extend('com.novartis.uwf.setdelegation.view.Detail', {

	editMode: false,
	oData: false,
	profileValues: '',
	profiles: [{}],
	oldStatus: null,
	deletedItem: false,
	detailChange: true,
	validate: com.novartis.uwf.setdelegation.util.Validation,

	onInit: function() {
		this.view = this.getView();
		this.component = sap.ui.component(sap.ui.core.Component.getOwnerIdFor(this.view));
		this.resourceBundle = this.component.getModel("i18n").getResourceBundle();
		this.router = this.component.getRouter();
		this.oEventBus = this.getEventBus();
		this.globalModel = this.component.getModel("global");
		this.scenariosModel = this.component.getModel("substitution");
		var oEventBus = this.getEventBus();
		this.view.setModel(this.globalModel);
		this.i18n = this.component.getModel('i18n');

		if (jQuery.device.is.phone) {
			this.view.byId('detailPage').setShowNavButton(true);
		}
		this.oInitialLoadFinishedDeferred = jQuery.Deferred();

		if (sap.ui.Device.system.phone) {
			//Do not wait for the master when in mobile phone resolution
			this.oInitialLoadFinishedDeferred.resolve();
		} else {
			this.getView().setBusy(true);
			oEventBus.subscribe("Component", "MetadataFailed", this.onMetadataFailed, this);
			oEventBus.subscribe("Master", "InitialLoadFinished", this.onMasterLoaded, this);
		}

		oEventBus.subscribe("New", "TableModel", this.refreshLocal, this);
		oEventBus.subscribe("New", "CreateNewItem", this.newChangeFlag, this);
		this.getRouter().attachRouteMatched(this.onRouteMatched, this);

//		if (sap.ui.Device.system.phone) {
//			if (window.location.hash.indexOf('mydelegations') != -1){
//				this.view.setModel(this.rulesModel);
//			}
//			if (window.location.hash.indexOf('delegatedme') != -1){
//				this.view.setModel(this.delegateMeModel);
//			}
//			var path = this.reverse(window.location.hash);
//			this.bindView('/'+path);
//			this.refreshLocalModels();
//			return;
//		}

		this.globalModel.attachRequestCompleted(this.onRefreshModel,this);
		this.applyHeaderStyle();
		this.applyTableStyle(true);

//		var multi = this.getView().byId('delegationCombo');
//
//		multi.onAfterClose = function(){
//			  multi.focus();
//		};

	},

	onRefreshModel: function(evt){
		this.refreshLocalModels();
		if (this.detailChange) {
			if (this.getView().getBindingContext() !== undefined) {
				var path = this.getView().getModel().getProperty(this.getView().getBindingContext().getPath());
			}
			if (path && (evt.getParameter('url').indexOf('SubstituteRuleCollection') === 0 || evt.getParameter('url').indexOf('SubstitutionRuleCollection') === 0 )) {
//				this.refreshLocalModels();
				if (this.deletedItem) {
					this.oEventBus.publish("Detail", "RefreshModel");
				}
				else {
					this.oEventBus.publish("Detail", "RefreshModel", {ruleId: path.SubstitutionRuleID});
				}
			}
			else {
				this.oEventBus.publish("Detail", "RefreshModel");
			}
		}
	},

	onMasterLoaded: function(sChannel, sEvent) {
		this.getView().setBusy(false);
		this.oInitialLoadFinishedDeferred.resolve();
	},

	onMetadataFailed: function() {
		this.getView().setBusy(false);
		this.oInitialLoadFinishedDeferred.resolve();
		this.showEmptyView();
	},

	onRouteMatched: function(oEvent) {
		var oParameters = oEvent.getParameters();

		jQuery.when(this.oInitialLoadFinishedDeferred).then(jQuery.proxy(function() {
			var oView = this.getView();

			// When navigating in the Detail page, update the binding context
			if (oParameters.name !== "detail") {
				return;
			}

			this.type = oParameters.arguments.type;

			if (this.type == 'mydelegations'){
				this.showButtons(true);
			} else if (this.type == 'delegatedme') {
				this.showButtons(false);
			}

			var sEntityPath = "/SubstitutionRuleCollection('" + oParameters.arguments.entity + "')";
			this.bindView(sEntityPath);

			// Specify the tab being focused
			var sTabKey = oParameters.arguments.tab;
			this.getEventBus().publish("Detail", "TabChanged", {
				sTabKey: sTabKey
			});

			this.refreshLocalModels();

		}, this));
	},

	bindView: function(sEntityPath) {
		var oView = this.getView();
		oView.bindElement(sEntityPath);

		//Check if the data is already on the client
		if (!oView.getModel().getData(sEntityPath)) {

			// Check that the entity specified was found.
			oView.getElementBinding().attachEventOnce("dataReceived", jQuery.proxy(function() {
				var oData = oView.getModel().getData(sEntityPath);
				if (!oData) {
					this.showEmptyView();
					this.fireDetailNotFound();
				} else {
					this.fireDetailChanged(sEntityPath);
				}
			}, this));

		} else {
			this.fireDetailChanged(sEntityPath);
		}
	},

	setUser: function (data) {
		var nomineeInput = this.view.byId("searchHelpDelegator");
		nomineeInput.setValueStateText(data.User);
//		nomineeInput.setValue(data.FullName);
	},

	setDetailChangeFlag: function(bool) {
		this.detailChange = bool;
	},

	checkProfile: function (data,profiles) {
		this.cleanProfiles();
		profiles && profiles.forEach(jQuery.proxy(function(item){
			var profile = this.view.getModel().oData[item];
			this.profiles.push(profile);
		}),this);
	},

	showButtons: function(bool) {
		this.getView().byId('editIcon').setVisible(bool);
		this.getView().byId('activateIcon').setVisible(bool);
		this.getView().byId('deleteIcon').setVisible(bool);
	},

	showEmptyView: function() {
		this.getRouter().navToWithoutHash({
			currentView: this.getView(),
			targetViewName: "com.novartis.uwf.setdelegation.view.NotFound",
			targetViewType: "XML"
		});
	},

	fireDetailChanged: function(sEntityPath) {
		this.getEventBus().publish("Detail", "Changed", {
			sEntityPath: sEntityPath
		});
	},

	fireDetailNotFound: function() {
		this.getEventBus().publish("Detail", "NotFound");
	},

	onNavBack: function() {
		// This is only relevant when running on phone devices
			this.oEventBus.publish("Detail", "ChangeFlagMobile", {bForce: false});
			window.history.go(-1);
//			this.getRouter().back("master2");
			if (this.view.byId('formChange').getVisible() == true) {
				this.changeMode();
			}

	},

	onDetailSelect: function(oEvent) {
		sap.ui.core.UIComponent.getRouterFor(this).navTo("detail", {
			entity: oEvent.getSource().getBindingContext().getPath().slice(1),
			tab: oEvent.getParameter("selectedKey")
		}, true);
	},

	getEventBus: function() {
		return sap.ui.getCore().getEventBus();
	},

	getRouter: function() {
		return sap.ui.core.UIComponent.getRouterFor(this);
	},

	onExit: function(oEvent) {
		var oEventBus = this.getEventBus();
		oEventBus.unsubscribe("Master", "InitialLoadFinished", this.onMasterLoaded, this);
		oEventBus.unsubscribe("Component", "MetadataFailed", this.onMetadataFailed, this);
		if (this._oActionSheet) {
			this._oActionSheet.destroy();
			this._oActionSheet = null;
		}
	},
	onEdit: function () {
		this.setEditTitle(true);
		this.applyTableStyle(false);
		if(!jQuery.device.is.phone) {
			this.oEventBus.publish("Master", "MasterBusy", {bForce: true});
		}
		this.changeMode();
	},

	onSave: function () {
		this.deletedItem = false;
		this.setDetailChangeFlag(true);
		var user = this.getUser();
		var scenarios = this.getSelectedScenarios();
		var startDate = this.getStartDate();
		var endDate = this.getEndDate();
		var subsId = this.getSubstitutionId();
		var model = this.getGlobalModel();
		var profiles = this.getProfiles();
		var validate = com.novartis.uwf.setdelegation.util.Validation;
		var path = this.getView().getModel().getProperty(this.getView().getBindingContext().getPath());
		if (jQuery.device.is.phone && this.view.byId('formChange').getVisible() == true) {
			this.oEventBus.publish("Detail", "ChangeFlagMobile", {bForce: false});
//			this.changeMode();
		}
//		this.changeMode();

		if (validate.userValidation(user,this) && validate.endDateValid(endDate,this) &&
			validate.startDateValid(startDate,this) && validate.dateValidation(startDate,endDate,this) &&
			validate.profileValidation(profiles,this)) {

			this.lockFooter(true);
			this.changeMode();
			model.update("/SubstitutionRuleCollection('"+subsId+"')",
				{ User: user, BeginDate: startDate, EndDate: endDate },
				{
					success: function() {
						this.applyAssignment.apply(this,[subsId,model,profiles]);
						this.updateSuccess();
						if (!jQuery.device.is.phone) {
//							this.oEventBus.publish("Detail", "RefreshModel", {bForce: true});
						}
						this.bindView(this.view.getBindingContext().getPath());
						this.lockFooter(false);
						this.setEditTitle(false);
						if (jQuery.device.is.phone) {
							//window.history.go(-1);
							this.oEventBus.publish("Detail", "ChangeFlagMobile", {bForce: false});
						}
					}.bind(this),
					error: jQuery.proxy(function(obj) { this.showError(obj.response.body)},this)
				}
			);
		}
	},

	applyAssignment: function(subsId,model,profiles) {

		var batchProc = [];

		for (var i=0;i<profiles.length;i++) {

			var profile = {
					ZScenarioID: profiles[i].ZScenarioID,
					Profile: profiles[i].Profile,
                };
			batchProc.push(model.createBatchOperation(
					"/SubstitutionRuleCollection(SubstitutionRuleID='"+subsId+"')/ZProfiles",
                    "POST",
                    profile)
                );
		}

		model.addBatchChangeOperations(batchProc);
		model.submitBatch(function(data) {
            model.refresh(true,false);
        }, undefined, false);
	},

	updateSuccess: function() {
		this.activatePopup();
	},

	activatePopup: function() {

		var oldStatus = this.getOldStatus();
		if (oldStatus == true){
			sap.m.MessageBox.show(this.i18n.getProperty('text.activatePopup'),{
				  title: this.i18n.getProperty('text.confirm'),
				  actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
		          onClose: jQuery.proxy(function(oAction) {
		        	  if (oAction == sap.m.MessageBox.Action.YES) {
			        	  this.onActivate();
		        	  }
		          },this)
			});
		}
	},

	setNewModel: function () {

		model = com.novartis.uwf.lib.model.TaskProcessing.load();
	},

	refreshLocalModels: function() {
		if (this.getView().getBindingContext()) {
			var data = this.getView().getModel().getProperty(this.getView().getBindingContext().getPath());
			if (data !== undefined) {
				var profiles = data.ZProfiles.__list;
				this.setTableModel(data,profiles);
				this.setComboModel(data,profiles);
				this.setUser(data);
				this.setOldNameValue(this.view.byId("searchHelpDelegator").getValue());
				this.checkProfile(data,profiles);
				var status = this.getStatus();
				this.oldStatus = this.getStatus();
				this.createTable(this.getProfiles());
				this.setStartDate(this.getStartDate());
				this.setEndDate(this.getEndDate());
				if (status == true) {
						this.view.byId('activateIcon').setText(this.i18n.getProperty('label.buttonOnDeactivate'));
						this.view.byId('activateIcon').setType('Reject');
				}
				else {
					this.view.byId('activateIcon').setText(this.i18n.getProperty('label.buttonOnActivate'));
					this.view.byId('activateIcon').setType('Emphasized');
				}
			}
		}
		this.applyTableStyle(true);
	},

	getGlobalModel: function() {
		return this.component.getModel('global');
	},

	getUser: function () {
		return this.view.byId('searchHelpDelegator').getValueStateText();
	},

	getSubstitutionId: function () {
		return this.getView().getModel().getProperty(this.getView().getBindingContext().getPath()).SubstitutionRuleID;
	},

	getStatus: function () {
		return this.getView().getModel().getProperty(this.getView().getBindingContext().getPath()).IsEnabled;
	},

	getOldStatus: function () {
		return this.oldStatus;
	},

	getStartDate: function () {
		var date =  this.getView().byId('datePickerBeginDate').getDateValue();
		if (date != null) {
			date.setHours(23);
		}
		return date;
	},
	getEndDate: function () {
		var date =  this.getView().byId('datePickerEndDate').getDateValue();
		if (date != null) {
			date.setHours(23);
		}
		return date;
	},
	setOldDates: function () {
		this.getView().byId('datePickerBeginDate').setDateValue(this.getOldStartDate());
		this.getView().byId('datePickerEndDate').setDateValue(this.getOldEndDate());
	},
	setStartDate: function(date) {
		this.oldStartDateValue = date;
	},

	setOldNameValue: function(fullName) {
		this.oldName = fullName;
	},

	getOldNameValue: function(fullName) {
		return this.oldName;
	},

	ChangeDisplayName: function() {
		var nomineeInput = this.view.byId("searchHelpDelegator");
		nomineeInput.setValue(this.getOldNameValue());
	},

	getOldStartDate: function() {
		return this.oldStartDateValue;
	},

	setEndDate: function(date) {
		this.oldEndDateValue = date;
	},

	getOldEndDate: function() {
		return this.oldEndDateValue;
	},

	getSelectedScenarios: function () {
		return this.getView().byId('delegationCombo').getSelectedKeys();
	},

	getEventBus: function() {
		return sap.ui.getCore().getEventBus();
	},

	onActivate: function() {
		this.deletedItem = false;
		this.setDetailChangeFlag(true);
		var subsId = this.getSubstitutionId();
		var message = '';
		var model = this.getGlobalModel();
		var status = this.getStatus();
		model.callFunction("EnableSubstitutionRule",
				{ method: 'POST', urlParameters: { SubstitutionRuleID: subsId, Enabled: !status },
				success: jQuery.proxy(function(obj) { if (status) { message = this.i18n.getProperty('text.successDeactivate');}
										 else if (!status) { message = this.i18n.getProperty('text.successActivate');}
										sap.ca.ui.message.showMessageToast(message); },this),
				error: jQuery.proxy(function(obj) { this.showError(obj.response.body)},this)
				});

		model.refresh(true,false);
		if (jQuery.device.is.phone) {
//			window.history.go(-1);
			this.oEventBus.publish("Detail", "ChangeFlagMobile", {bForce: false});
		}
	},

	showError: function(message) {
		// This 8 must be added since its the size of 'value:"'
		var startIndex = message.indexOf('value') + 8;
		// This -4 must be added since its the size of "},"
		var endIndex = message.indexOf("innererror") - 4;
		var displayMessage = message.slice (startIndex,endIndex);
		sap.m.MessageBox.show(displayMessage,{
			  title: this.i18n.getProperty('text.error'),
	          actions: [sap.m.MessageBox.Action.OK]
		});
	},

	onCancel: function () {
		this.setEditTitle(false);
		this.deletedItem = false;
		if (this.view.byId('formChange').getVisible() == true) {
			this.changeMode();
		}
		this.setOldDates();
		this.ChangeDisplayName();
		if (jQuery.device.is.phone) {
			window.history.go(-1);
			this.oEventBus.publish("Detail", "ChangeFlagMobile", {bForce: false});
		} else {
			this.oEventBus.publish("Master", "MasterBusy", {bForce: false});
		}
		this.refreshLocalModels();
	},

	onDelete: function (oEvent) {

//		var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
		sap.m.MessageBox.show(this.i18n.getProperty('text.onDeleteConfirm'),{
				  title: this.i18n.getProperty('text.confirm'),
		          actions: [sap.m.MessageBox.Action.NO, sap.m.MessageBox.Action.YES],
		          onClose: jQuery.proxy(function(oAction) {
		        	  if (oAction == sap.m.MessageBox.Action.YES) {
			        	  var subsId = this.getSubstitutionId();
			      		  var model = this.getGlobalModel();
			      		this.deletedItem = true;
			      		this.setDetailChangeFlag(true);
			      		var batchProc = [];
			      		batchProc.push(model.createBatchOperation(
			      				"/SubstitutionRuleCollection(SubstitutionRuleID='"+subsId+"')",
			                    "Delete")
			                );

			      		model.addBatchChangeOperations(batchProc);
						model.submitBatch(function(data) {
				            model.refresh();
				        });

				      	  if (jQuery.device.is.phone) {
				    		  window.history.go(-1);
				    		  this.oEventBus.publish("Detail", "ChangeFlagMobile", {bForce: false});
				    	  }
		        	  }
		          },this)
			}
		);
	},

//	setTableModel: function (data,profiles) {
//		var table = this.getView().byId('scenariosTable');
//		if (table.getItems().length !== 0){
//			table.removeAllItems();
//		}
//		profiles && profiles.forEach(jQuery.proxy(function(item){
//			var profile = this.view.getModel().oData[item];
//			var row = new sap.m.ColumnListItem({
//				cells: [new sap.m.Text({text:profile.ZScenarioText}), new sap.m.Text({text:profile.ProfileText}), new sap.m.Text({text:profile.ZStatusText})]
//			});
//			table.addItem(row);
//		}),this);
//
//	},

	setTableModel: function (data,profiles) {
		var table = this.getView().byId('scenariosTable');
		var cellProfileText;
		if (table.getItems().length !== 0){
			table.removeAllItems();
		}
		profiles && profiles.forEach(jQuery.proxy(function(item){
			var profile = this.view.getModel().oData[item];
			if(profile.ProfileText !== ''){
				cellProfileText = profile.ZScenarioText+": "+profile.ProfileText;
			}
			else{
				cellProfileText = profile.ZScenarioText;
			}
			var statusTextFormatted = new sap.m.Text({text:profile.ZStatusText}).addStyleClass('errorText');
			var row = new sap.m.ColumnListItem({
				cells: [new sap.m.Text({text:cellProfileText}), statusTextFormatted]
			});
			table.addItem(row);
		}),this);
	},

	refreshLocal: function(sChanel, sEvent, oData) {
		this.refreshLocalModels();
	},

	newChangeFlag: function(sChanel, sEvent, oData) {
		var bForce = oData.bForce;
		this.setDetailChangeFlag(bForce);
	},

	changeMode: function () {
		var formDisplayVisibility = this.view.byId('formDisplay').getVisible();
		var editIconVisibility = this.view.byId('editIcon').getVisible();
		var formChangeVisibility = this.view.byId('formChange').getVisible();
		var saveIconVisibility = this.view.byId('saveIcon').getVisible();
		var activateIconVisibility = this.view.byId('activateIcon').getVisible();
		var cancelIconVisibility = this.view.byId('cancelIcon').getVisible();
		var deleteIconVisibility = this.view.byId('deleteIcon').getVisible();

		this.view.byId('formDisplay').setVisible(!formDisplayVisibility);
		this.view.byId('editIcon').setVisible(!editIconVisibility);
		this.view.byId('formChange').setVisible(!formChangeVisibility);
		this.view.byId('saveIcon').setVisible(!saveIconVisibility);
		this.view.byId('activateIcon').setVisible(!activateIconVisibility);
		this.view.byId('cancelIcon').setVisible(!cancelIconVisibility);
		this.view.byId('deleteIcon').setVisible(!deleteIconVisibility);
	},

	setComboModel: function (data,profiles) {

		var individualScenariosModel = new sap.ui.model.json.JSONModel();
		var individualScenarios = [];
		var dataScenario = this.scenariosModel.getData();
		var lastID = '';

		var delegationCombo = this.byId('delegationCombo');
		for (var i=0;i<dataScenario.length;i++) {
			if (dataScenario[i].ZScenarioID != lastID) {
				individualScenarios.push(dataScenario[i]);
			}
			lastID = dataScenario[i].ZScenarioID;
		}
		if (delegationCombo.getItems().length !== 0){
			delegationCombo.removeAllItems();
		}
//		delegationCombo.removeAllItems();
		var comboRender = delegationCombo.getRenderer();
		comboRender.addInnerClasses = function(delegationCombo, oControl) {
			oControl._oTokenizer.removeAllTokens();
		};

		individualScenarios && individualScenarios.forEach(jQuery.proxy(function(scen){
			var scena = new sap.ui.core.Item({ key:scen.ZScenarioID, text:scen.ZScenarioText});
			delegationCombo.insertItem(scena);
			profiles && profiles.forEach(jQuery.proxy(function(item){
				var profile = this.view.getModel().oData[item];
					if (scen.ZScenarioID == profile.ZScenarioID) {
						delegationCombo.addSelectedItem(scena);
					}
			}),this);
		}),this);
	},

	applyProfileScenario: function(model,key,profileName) {
		var individualScenariosModel = new sap.ui.model.json.JSONModel();
		var individualScenarios = [];
		var dataScenario = model.getData();

		var fragmentHrProfiles = sap.ui.xmlfragment("com.novartis.uwf.setdelegation.view.HrProfiles", this.getView().getController());
		for (var i=0;i<dataScenario.length;i++) {
			if(dataScenario[i].ZScenarioID == key) {
				individualScenarios.push(dataScenario[i]);
			}
		}
		individualScenariosModel.setData(individualScenarios);
		fragmentHrProfiles.setModel(individualScenariosModel);
		fragmentHrProfiles.setTitle(profileName);
		//set Custom Data
		var items = fragmentHrProfiles.getItems();
		for (var i=0;i<items.length;i++) {
			items[i].addCustomData(new sap.ui.core.CustomData({key:'Profile', value:items[i].getModel().getData()[i].Profile}))
		}
		fragmentHrProfiles.open();
	},

	removeTokens: function (control) {
		control.getView().byId('delegationCombo')._oTokenizer.removeAllTokens();
	},


	handleCloseHrProfiles: function(oEvent) {
		var data = this.scenariosModel.getData();
		var scenario;
		var profile;
		var selectedItem;// = oEvent.getParameters('selectedItems').selectedItem.getDescription();
		var customData = oEvent.getParameter('selectedItem').getCustomData();
		customData.forEach(jQuery.proxy(function(item) {
			selectedItem = item.getProperty('value');
		}),this)

		for(var j=0;j<data.length;j++) {
			if (data[j].Profile == selectedItem) {
				this.profiles.push(data[j]);
				break;
			}
		}
		this.removeTokens(this);
		this.createTable(this.profiles);
		this.getView().byId('delegationCombo').open();
	},

	handleCancelProfiles: function(event) {
		this.removeTokens(this);
		this.getView().byId('delegationCombo').removeSelectedKeys([this.previousSelected]);
	},

	handleChangeBD: function(oEvent) {
		var value = oEvent.getParameter('value');
		var date = oEvent.getSource().getDateValue();
		var endDate = this.getEndDate();
		this.getView().byId('datePickerBeginDate').setValue(value);
		var startDate = this.getStartDate();

		if (this.validate.startDateValid(startDate,this)) {
			if (endDate !== '' && endDate !== null && endDate !== undefined) {
				this.validate.validPeriod(startDate,endDate,this)
			}
		}
	},

	handleChangeED: function(oEvent) {
		var value = oEvent.getParameter('value');
		var date = oEvent.getSource().getDateValue();
		var startDate = this.getStartDate();
		this.getView().byId('datePickerEndDate').setValue(value);
		var endDate = this.getEndDate();

		if (this.validate.endDateValid(endDate,this)) {
			if (startDate !== '' && startDate !== null && startDate !== undefined) {
				this.validate.validPeriod(startDate,endDate,this)
			}
		}
	},

	handleValueHelp: function(oEvent) {
		var that = this;
		var value = this.getView().byId('searchHelpDelegator').getValue();
		com.novartis.uwf.setdelegation.util.Delegation.openSelectDialog(value,that);
	},

	handleSelectionChange: function(oEvent) {
		var selectedItem = oEvent.getParameter('changedItem').getKey();
		this.previousSelected = selectedItem;
		var state = oEvent.getParameter("selected");
		var data = this.scenariosModel.getData();
		var text = oEvent.getParameter('changedItem').getText();
		var profileExists = false;
		var table = this.getView().byId('profilesTable');
//		var profile;
		for(var j=0;j<data.length;j++) {
			if (state && data[j].ZScenarioID == selectedItem) {
				if (data[j].Profile == '' || data[j].ProfileText == '') {
					this.profiles.push(data[j]);
					this.createTable(this.getProfiles());
					this.removeTokens(this);
				}
				else {
					profileExists = true;
				}
				break;
			}
		}
		if (state && profileExists) {
			this.applyProfileScenario(this.scenariosModel,selectedItem,text);
		}
		if (!state) {
			for(var j=0;j<this.profiles.length;j++) {
				if (this.profiles[j].ZScenarioID == selectedItem) {
					var row = new sap.m.ColumnListItem({
						cells: [new sap.m.Text({text:this.profiles[j].ZScenarioText}), new sap.m.Text({text:this.profiles[j].ProfileText})]
					});
					this.profiles.splice(j,1);
				}
			}
			if (table.getItems().length !== 0){
				table.removeAllItems();
			}
			if (this.getProfiles().length != 0) {
				this.createTable(this.getProfiles());
				this.removeTokens(this);
			}
			else {
				// this.getView().byId('profilesElementTable').setVisible(false);
			}
		}
		this.getView().byId('delegationCombo').open();
	},

//	createTable: function(data) {
//	 	var table = this.getView().byId('profilesTable');
//	 	if (table.getItems().length !== 0){
//			table.removeAllItems();
//		}
//	 	this.getView().byId('profilesElementTable').setVisible(true);
//		data && data.forEach(function(item){
//			var row = new sap.m.ColumnListItem({
//				cells: [new sap.m.Text({text:item.ZScenarioText}), new sap.m.Text({text:item.ProfileText}),new sap.m.Text({text:item.ZStatusText})]
//			});
//			table.addItem(row);
//		});
//		this.removeTokens(this);
//	},
	createTable: function(data) {
	 	var table = this.getView().byId('profilesTable');
	 	var cellProfileText;
	 	if (table.getItems().length !== 0){
			table.removeAllItems();
		}
	 	// this.getView().byId('profilesElementTable').setVisible(true);
		data && data.forEach(function(item){
			if(item.ProfileText !== ''){
				cellProfileText = item.ZScenarioText +": "+item.ProfileText;
			}
			else {
				cellProfileText = item.ZScenarioText;
			}
			var statusTextFormatted = new sap.m.Text({text:item.ZStatusText}).addStyleClass('errorText');
			var row = new sap.m.ColumnListItem({
				cells: [new sap.m.Text({text:cellProfileText}), statusTextFormatted]
			});
			table.addItem(row);
		});
		this.removeTokens(this);
	},


	getProfiles: function() {
		if (this.profiles.length!=0 && !this.profiles[0].ZScenarioID) {
			this.profiles.shift();
		}
		return this.profiles;
	},

	cleanProfiles: function() {
		this.profiles = [{}];
	},

	lockFooter: function (bool) {
		this.view.byId('detailPage').getFooter().setBusy(bool);
	},

	handleSearch: function(oEvent) {
		var aFilters = [];
		var sQuery = oEvent.getSource()._sSearchFieldValue;
		if (sQuery && sQuery.length > 0) {
			var filter = new sap.ui.model.Filter("ProfileText", sap.ui.model.FilterOperator.Contains, sQuery);
			aFilters.push(filter);
		}
		var oBinding = oEvent.getSource().getBinding("items");
		oBinding.filter(aFilters);
	},

	setEditTitle: function(action) {
		if (action == true) {
			this.getView().byId('detailPage').setTitle (this.i18n.getProperty('editdetailTitle'));
		} else {
			this.getView().byId('detailPage').setTitle (this.i18n.getProperty('detailTitle'));
		}
	},

	addHours: function(h){
		return h*3600*1000;
	},

	reverse: function(s) {
		var o = '';
		var pushed = '';
		for (var i = s.length - 1; i >= 0; i--) {
			o += s[i];
		}
//		return o;
		i = o.indexOf('/');

		for (;i>0;i--){
			pushed += o[i-1];
		}
		return pushed;
	},

	applyHeaderStyle: function() {
		var headerStyle = document.createElement('style');
		var page = this.getView().getAggregation('content')[0].getId();
		var headerElement = document.getElementById('HeaderStyle');
		var $headerStyle = jQuery(headerStyle);
		var $headerElement = jQuery(headerElement);
		if (headerElement) {
			headerElement.parentNode.removeChild(headerElement);
		}
		document.head.appendChild(headerStyle);
		headerStyle.id = 'HeaderStyle';
		headerStyle.type = 'text/css';
		headerStyle.innerHTML = '#' + page + ' .sapUiFormTitle { height: 1rem !important; }';
	},

	applyTableStyle: function(bool) {
		var tableStyle = document.createElement('style');
		var page = this.getView().getAggregation('content')[0].getId();
		var tableElement = document.getElementById('TableStyle');
		var $tableStyle = jQuery(tableStyle);
		var $tableElement = jQuery(tableElement);
		if (bool) {
			if (tableElement) {
				tableElement.parentNode.removeChild(tableElement);
			}
			document.head.appendChild(tableStyle);
			tableStyle.id = 'TableStyle';
			tableStyle.type = 'text/css';
			tableStyle.innerHTML += '#' + page + ' .sapUiFormResGrid div { padding: 0rem !important; }';
		}
		else {
			if (tableElement) {
				tableElement.parentNode.removeChild(tableElement);
			}
		}
	},

	});
