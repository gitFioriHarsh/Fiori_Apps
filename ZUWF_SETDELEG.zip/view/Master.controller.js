/*&---------------------------------------------------------------------*
*& Development ID: ZDDI-00021587                                       *
*&                                                                     *
*& Master                                                              *
*&                                                                     *
*&- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*
*& Change Log:                                                         *
*&                                                                     *
*& Init. Who          Date         Text                                *
*& JHU   HUNDEJU1     08-09-2015   Initial version CD 1200005515       *
*&---------------------------------------------------------------------*/

sap.ui.core.mvc.Controller.extend('com.novartis.uwf.setdelegation.view.Master', {
	onInit: function() {
		this.oInitialLoadFinishedDeferred = jQuery.Deferred();

		var eventBus = this.getEventBus();

		this.getView().byId('master1List').attachEventOnce('updateFinished', function() {
			this.oInitialLoadFinishedDeferred.resolve();
			eventBus.publish('Master', 'InitialLoadFinished', {
				oListItem: this.getView().byId('master1List').getItems()[0]
			});
			this.getRouter().detachRoutePatternMatched(this.onRouteMatched, this);
		}, this);

		//On phone devices, there is nothing to select from the list. There is no need to attach events.
		if (sap.ui.Device.system.phone) {
			return;
		}
		
		var oEventBus = this.getEventBus();
//
		this.getRouter().attachRoutePatternMatched(this.onRouteMatched, this);
//
		eventBus.subscribe('Master2', 'NotFound', this.onNotFound, this);
	},
	
	onSelect: function(oEvent) {
		/*// Get the list item either from the listItem parameter or from the event's
		// source itself (will depend on the device-dependent mode)
		var oList = this.getView().byId("master1List");
		this.showDetail(oEvent.getParameter("listItem") || oEvent.getSource());
		oList.removeSelections();*/
		this.oEvent = oEvent;
		this.getRouter().navTo("master2", {
			from: "main",
			type: "mydelegations"
		});
	},
	
	onSelectMe: function(oEvent) {
		/*// Get the list item either from the listItem parameter or from the event's
		// source itself (will depend on the device-dependent mode)
		var oList = this.getView().byId("master1List");
		this.showDetail(oEvent.getParameter("listItem") || oEvent.getSource());
		oList.removeSelections();*/
		this.oEvent = oEvent;
		this.getRouter().navTo("master2", {
			from: "main",
			type: "delegatedme"
		});
	},
	
	
	onNavBack: function() {
		// This is only relevant when running on phone devices
//		window.history.go(-1);
//		this.getRouter().back('')
//		window.location = '#';
		window.history.go(-1);
	},
	
//	onRoutePatternMatched: function(oEvent) {
//		var sName = oEvent.getParameter("name");
//
//		if (sName !== "master2") {
//			return;
//		}
//		
//		//		Load the detail view in desktop
//		this.getRouter().navToWithoutHash({
//			currentView: this.getView(),
//			targetViewName: "com.novartis.uwf.setdelegation.view.Detail",
//			targetViewType: "XML",
//			transition: "slide"
//		});
//	},

	onRouteMatched: function(oEvent) {
		var sName = oEvent.getParameter('name');

		if (sName !== 'main') {
			return;
		}
//
//		//Load the master2 view in desktop
		
//		
//			this.getRouter().navToWithoutHash({
//				currentView: this.getView(),
//				targetViewName: 'com.novartis.uwf.setdelegation.view.Master2',
//				targetViewType: 'XML'
//			});
		
		if(!jQuery.device.is.phone) {
			//Load the welcome view in desktop
			this.getRouter().navToWithoutHash({
				currentView: this.getView(),
				targetViewName: 'com.novartis.uwf.setdelegation.view.Welcome',
				targetViewType: 'XML'
			});
		}
	},
////
	waitForInitialListLoading: function(fnToExecute) {
		jQuery.when(this.oInitialLoadFinishedDeferred).then(jQuery.proxy(fnToExecute, this));
	},

	onNotFound: function() {
		this.getView().byId('master1List').removeSelections();
	},
//
//	onSelect: function(oEvent) {
//		// Get the list item either from the listItem parameter or from the event's
//		// source itself (will depend on the device-dependent mode)
//		var oList = this.getView().byId('master1List');
//		this.showDetail(oEvent.getParameter('listItem') || oEvent.getSource());
//		oList.removeSelections();
//	},
//
//	showDetail: function(oItem) {
//		// If we're on a phone device, include nav in history
//		var bReplace = jQuery.device.is.phone ? false : true;
//		this.getRouter().navTo('master2', {
//			from: 'main'
////			entity: oItem.getBindingContext().getPath().substr(1)
//		}, bReplace);
//	},
//
	getEventBus: function() {
		return sap.ui.getCore().getEventBus();
	},
	
	getRouter: function() {
		return sap.ui.core.UIComponent.getRouterFor(this);
	}
//
//	onExit: function(oEvent) {
//		this.getEventBus().unsubscribe('Master2', 'NotFound', this.onNotFound, this);
//	}
});
